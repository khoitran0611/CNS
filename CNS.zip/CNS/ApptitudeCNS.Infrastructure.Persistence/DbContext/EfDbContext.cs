﻿using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using System.Reflection;


namespace ApptitudeCNS.Infrastructure.Persistence.DbContext
{
    public class EfDbContext : EfDbContextBase
    {
        public EfDbContext(string connectionString) : base(connectionString)
        {
        }

        protected override Assembly GetExecutingAssembly()
        {
            return Assembly.GetExecutingAssembly();
        }
    }
}
