﻿using ApptitudeCNS.Core;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace ApptitudeCNS.Infrastructure.Persistence.Repositories
{
    public class UserRepository : IUserRepository
    {
        public IDbContext DbContext { get; }
        private readonly DbSet<User> dbUserSet;

        public UserRepository(IDbContext dbContext)
        {
            DbContext = dbContext;
            dbUserSet = dbContext.Set<User>();
        }        

        public User FindByEmail(string userName)
        {
            return dbUserSet.SingleOrDefault(u => u.Email == userName);         
        }

        public int Create(User user)
        {
            dbUserSet.Add(user);
            return DbContext.SaveChanges();
        }
        
    }
}
