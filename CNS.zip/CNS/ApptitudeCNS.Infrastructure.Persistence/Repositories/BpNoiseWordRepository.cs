﻿using System.Collections.Generic;
using System.Linq;
using ApptitudeCNS.Core;
using ApptitudeCNS.Core.IRepository;
using ApptitudeCNS.Core.Reports;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;

namespace Bp.Infrastructure.Persistence.Repositories
{
    public class BpNoiseWordRepository : IBpNoiseWordRepository
    {
        private IDbContext _dbContext;
        public BpNoiseWordRepository(IDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public List<IdName> GetBpNoiseWords()
        {
            string sqlQuery = @"SELECT NoiseWordID AS Id, NoiseWord AS Name FROM dbo.tblNoiseWord ORDER BY NoiseWord";
            var result = _dbContext.DatabaseFacade.SqlQuery<IdName>(sqlQuery).ToList();
            return result;
        }

    }
}
