﻿using System.Collections.Generic;
using System.Linq;
using ApptitudeCNS.Core;
using ApptitudeCNS.Core.IRepository;
using ApptitudeCNS.Core.Reports;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;

namespace Bp.Infrastructure.Persistence.Repositories
{
    public class BpAggregatorRepository : IBpAggregatorRepository
    {
        private IDbContext _dbContext;
        public BpAggregatorRepository(IDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public List<IdName> GetBpAggregators()
        {
            string sqlQuery = @"SELECT WholeSalerID AS Id, Name FROM dbo.tblWholeSaler";
            var result = _dbContext.DatabaseFacade.SqlQuery<IdName>(sqlQuery).ToList();
            return result;
        }

        public BpUser GetProinspectUser(long id)
        {
            string sqlQuery = $@"SELECT Email, Email as SenderEmail, FirstName, LastName, MobilePhone as Phone, CompanyName as Company, 
                                    ChildUserID as BpUserId, AddressLine1 as Address, JobTitleText as Title, NULL as AggregatorId, NULL as SubAggregatorId
                                FROM dbo.Child_User WHERE ChildUserID = {id}";
            var result = _dbContext.DatabaseFacade.SqlQuery<BpUser>(sqlQuery).FirstOrDefault();
            return result;
        }

        public BpUser GetBrokerpediaUser(long id)
        {
            string sqlQuery = $@"SELECT Email, Email as SenderEmail, FirstName, LastName, MobilePhone as Phone, CompanyName as Company, 
                                    UserID as BpUserId, WorkAddress1 as Address, Title, WholeSalerId as AggregatorId, SubWholeSalerID as SubAggregatorId
                                FROM dbo.tblUser WHERE UserID = {id}";
            var result = _dbContext.DatabaseFacade.SqlQuery<BpUser>(sqlQuery).FirstOrDefault();
            return result;
        }
    }
}
