﻿using ApptitudeCNS.Core;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ApptitudeCNS.Infrastructure.Persistence.Repositories
{
    public class RoleRepository : IRoleRepository
    {
        public IDbContext DbContext { get; }
        public RoleRepository(IDbContext dbContext)
        {
            DbContext = dbContext;
        }

        public List<Role> FindRolesByUserName(string email)
        {
            List<Role> result = null;
            string sqlQuery;
            System.Data.SqlClient.SqlParameter[] sqlParams;

            try
            {
                sqlQuery = "User_FindRoles";

                sqlParams = new System.Data.SqlClient.SqlParameter[]
                {
                new System.Data.SqlClient.SqlParameter { ParameterName = "@userId",  Value = (Object)DBNull.Value , Direction = System.Data.ParameterDirection.Input},
                new System.Data.SqlClient.SqlParameter { ParameterName = "@email",  Value = email, Direction = System.Data.ParameterDirection.Input }
                };

                result = DbContext.CurrentContext.Database.SqlQuery<Role>("exec User_FindRoles @userId,@email", sqlParams).ToList();

            }
            catch (System.Exception ex)
            {
                throw ex;
            }

            return result;
        }
    }
}
