﻿using System.Collections.Generic;
using System.Linq;
using ApptitudeCNS.Core.IRepository;
using ApptitudeCNS.Core.Reports;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;

namespace Bp.Infrastructure.Persistence.Repositories
{
    public class RateRepository : IRateRepository
    {
        private IDbContext _dbContext;
        public RateRepository(IDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IList<LowestLenderRateType> GetTop12LowestLenders()
        {
            string sqlQuery = @"WITH DataSource
                                AS (    
                                    SELECT l.LenderId, l.Name as LenderName, RateDetailId, RateType, LoanType, FinalCurrent
                                    FROM Rate_Master_BP_v2 rm
                                    INNER JOIN Rate_Detail_BP_v2 rd ON rm.RateMasterId = rd.RateMasterId
                                    Inner join tblLender l on rm.LenderId = l.LenderID
                                    WHERE RateType in (1, 5, 6, 7, 8, 9) and NextRateMasterId = 0 and rm.IsInSleepMode = 0 and rd.IsGrey = 0 and FinalCurrent <> 0
                                ),
                                TopLenders As
                                (   
                                    SELECT TOP 12 lenderId
                                    FROM DataSource
                                    GROUP BY LenderId
                                    ORDER BY MIN(FinalCurrent)
                                ),
                                TopLendersWithOrder As
                                (   
                                    SELECT *, ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) As LenderOrder
                                    FROM	  (	 SELECT TOP 12 lenderId
			                                 FROM DataSource
			                                 GROUP BY LenderId
			                                 ORDER BY MIN(FinalCurrent) 
		                                  ) AS TopLenders
                                ),
                                Report AS
                                (
                                    SELECT *, ROW_NUMBER() OVER(PARTITION BY LenderId, LenderName, RateType ORDER BY FinalCurrent) AS RowNum
                                    FROM DataSource
                                    WHERE LenderID IN (SELECT LenderId from TopLendersWithOrder)
                                )
                                SELECT *
                                FROM Report r INNER JOIN TopLendersWithOrder tl ON r.LenderId = tl.LenderId
                                WHERE RowNum = 1
                                order by LenderOrder";

            var result = _dbContext.DatabaseFacade.SqlQuery<LowestLenderRateType>(sqlQuery).ToList();
            return result;
        }
    }
}
