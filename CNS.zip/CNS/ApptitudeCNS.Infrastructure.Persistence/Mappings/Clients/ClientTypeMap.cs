﻿using System.Data.Entity.ModelConfiguration;
using ApptitudeCNS.Core;

namespace ApptitudeCNS.Infrastructure.PersistenceMappings.MailTrackings
{
    public class ClientTypeMap : EntityTypeConfiguration<ClientType>
    {
        public ClientTypeMap()
        {
        }
    }
}
