﻿using System.Data.Entity.ModelConfiguration;
using ApptitudeCNS.Core;

namespace ApptitudeCNS.Infrastructure.PersistenceMappings.Articles
{
    public class ArticleAttachmentMap : EntityTypeConfiguration<ArticleAttachment>
    {
        public ArticleAttachmentMap()
        {
        }
    }
}
