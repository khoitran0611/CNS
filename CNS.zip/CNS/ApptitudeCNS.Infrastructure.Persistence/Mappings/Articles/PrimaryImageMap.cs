﻿using System.Data.Entity.ModelConfiguration;
using ApptitudeCNS.Core;

namespace ApptitudeCNS.Infrastructure.PersistenceMappings.Articles
{
    public class PrimaryImageMap : EntityTypeConfiguration<PrimaryImage>
    {
        public PrimaryImageMap()
        {
        }
    }
}
