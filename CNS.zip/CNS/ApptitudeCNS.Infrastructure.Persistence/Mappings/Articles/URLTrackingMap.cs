﻿using System.Data.Entity.ModelConfiguration;
using ApptitudeCNS.Core;

namespace ApptitudeCNS.Infrastructure.PersistenceMappings.Articles
{
    public class URLTrackingMap : EntityTypeConfiguration<URLTracking>
    {
        public URLTrackingMap()
        {
        }
    }
}
