﻿using System.Data.Entity.ModelConfiguration;
using ApptitudeCNS.Core;

namespace ApptitudeCNS.Infrastructure.PersistenceMappings.Users
{
    public class UserMap : EntityTypeConfiguration<User>
    {
        public UserMap()
        {
        }
    }

    

    
}
