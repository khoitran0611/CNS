﻿using System.Data.Entity.ModelConfiguration;
using ApptitudeCNS.Core;

namespace ApptitudeCNS.Infrastructure.PersistenceMappings.Users
{
    public class UserHistoryMap : EntityTypeConfiguration<UserHistory>
    {
        public UserHistoryMap()
        {
        }
    }
}
