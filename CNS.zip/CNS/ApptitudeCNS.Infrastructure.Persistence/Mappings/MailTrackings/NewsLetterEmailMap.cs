﻿using System.Data.Entity.ModelConfiguration;
using ApptitudeCNS.Core;

namespace ApptitudeCNS.Infrastructure.PersistenceMappings.MailTrackings
{
    public class NewsLetterEmailMap : EntityTypeConfiguration<NewsLetterEmail>
    {
        public NewsLetterEmailMap()
        {
        }
    }
}
