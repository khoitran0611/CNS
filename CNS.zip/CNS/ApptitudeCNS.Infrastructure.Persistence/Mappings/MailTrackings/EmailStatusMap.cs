﻿using System.Data.Entity.ModelConfiguration;
using ApptitudeCNS.Core;

namespace ApptitudeCNS.Infrastructure.PersistenceMappings.MailTrackings
{
    public class EmailStatusMap : EntityTypeConfiguration<EmailStatus>
    {
        public EmailStatusMap()
        {
            ToTable("EmailStatuses");
        }
    }
}
