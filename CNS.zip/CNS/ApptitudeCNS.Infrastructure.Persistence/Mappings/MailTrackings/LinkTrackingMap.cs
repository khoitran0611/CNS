﻿using System.Data.Entity.ModelConfiguration;
using ApptitudeCNS.Core;

namespace ApptitudeCNS.Infrastructure.PersistenceMappings.MailTrackings
{
    public class LinkTrackingMap : EntityTypeConfiguration<LinkTracking>
    {
        public LinkTrackingMap()
        {
        }
    }
}
