﻿using ApptitudeCNS.Core.Reports;
using ApptitudeCNS.Helpers;
using System.Collections.Generic;

namespace ApptitudeCNS.Core.IRepository
{
    public interface IBpAggregatorRepository
    {
        List<IdName> GetBpAggregators();
        BpUser GetProinspectUser(long id);
        BpUser GetBrokerpediaUser(long id);
    }
}
