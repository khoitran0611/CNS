﻿using ApptitudeCNS.Core.Reports;
using ApptitudeCNS.Helpers;
using System.Collections.Generic;

namespace ApptitudeCNS.Core.IRepository
{
    public interface IBpNoiseWordRepository
    {
        List<IdName> GetBpNoiseWords();
    }
}
