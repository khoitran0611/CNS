﻿using ApptitudeCNS.Core.Reports;
using System.Collections.Generic;

namespace ApptitudeCNS.Core.IRepository
{
    public interface IRateRepository
    {
        IList<LowestLenderRateType> GetTop12LowestLenders();
    }
}
