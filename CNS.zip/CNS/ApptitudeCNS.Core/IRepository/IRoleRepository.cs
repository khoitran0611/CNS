﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Core
{
    public interface IRoleRepository
    {
        List<Role> FindRolesByUserName(string userName);
    }
}
