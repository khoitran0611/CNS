﻿using ApptitudeCNS.Helpers;
using System;
using System.ComponentModel;

namespace ApptitudeCNS.Core
{
    public class User : EntityBase
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public string PasswordHash { get; set; }
        [DisplayName("First Name")]
        public string FirstName { get; set; }
        [DisplayName("Last Name")]
        public string LastName { get; set; }
        public string Phone { get; set; }
        [DisplayName("Active")]
        public bool IsActive { get; set; }
        //--------------------------------//
        public string Company { get; set; }
        public string Signature { get; set; }
        [DisplayName("Primary Color")]
        public string PrimaryColor { get; set; }
        [DisplayName("Secondary Color")]
        public string SecondaryColor { get; set; }
        [DisplayName("Sender Email")]
        public string SenderEmail { get; set; }
        [DisplayName("Email Subscribe")]
        public bool? EmailSubscribe { get; set; }
        [DisplayName("SMS Subscribe")]
        public bool? SMSSubscribe { get; set; }
        //[DisplayName("Broker Message")]
        //public string BrokerMessage { get; set; }
        [DisplayName("Active Date From")]
        public DateTime? ActiveDateFrom { get; set; }
        [DisplayName("Active Date To")]
        public DateTime? ActiveDateTo { get; set; }
        [DisplayName("Last Sent")]
        public DateTime? LastSendMassEmail { get; set; }

        public int UserTypeId { get; set; }

        [DisplayName("BID")]
        public long? BpUserId { get; set; }
        public long? AggregatorId { get; set; }
        public long? SubAggregatorId { get; set; }
        public string Logo { get; set; }
        public string Address { get; set; }
        public string Title { get; set; }

        public string ABN { get; set; }
        [DisplayName("Google+ Url")]
        public string GooglePlusLink { get; set; }
        [DisplayName("Facebook Url")]
        public string FacebookLink { get; set; }
        [DisplayName("Twitter Url")]
        public string TwitterLink { get; set; }
        [DisplayName("Linkedin Url")]
        public string LinkedinLink { get; set; }

        [DisplayName("Website Url")]
        public string WebsiteLink { get; set; }

        [DisplayName("Broker Message")]
        public string BrokerMessage { get; set; }

        [DisplayName("Company Image")]
        public string CompanyImage { get; set; }

        public int? SendSampleEmailType { get; set; }

        [DisplayName("Logo Position")]
        public int? LogoPositionType { get; set; }

        [DisplayName("Internal Identifier")]
        public string InternalIdentifier { get; set; }
    }
}
