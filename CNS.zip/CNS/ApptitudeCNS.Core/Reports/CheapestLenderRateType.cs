﻿namespace ApptitudeCNS.Core.Reports
{
    public class CheapestLenderRateType
    {
        public long LenderId { get; set; }
        public string LenderName { get; set; }

        public long RateDetailId { get; set; }
        public int RateType { get; set; }
        public int LoanType { get; set; }

        public decimal FinalCurrent { get; set; }
    }
}
