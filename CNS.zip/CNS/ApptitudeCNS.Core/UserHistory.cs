﻿namespace ApptitudeCNS.Core
{
    public class UserHistory : EntityBase
    {
        public long UserId { get; set; }
        public int TypeId { get; set; }
        public string Content { get; set; }
        public bool Pinned { get; set; }
        public bool IsSystemAutogen { get; set; }
        public long? CreatedUserId { get; set; }
    }
}
