﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Core
{
    public class Article : EntityBase
    {
        //public string Subject { get; set; }
        public string Title { get; set; }
        public DateTime? ArticleDate { get; set; }
        public long? URLTrackingId { get; set; }
        public string Summary { get; set; }
        public string Picture { get; set; }
        public string Author { get; set; }
        public DateTime? LastSent { get; set; }
        public long CreatedUserId { get; set; }
        public long UpdatedUserId { get; set; }
        public int? ArticleTypeId { get; set; }
        public string Organisation { get; set; }
        public string SiteName { get; set; }
        public string BrokerMessage { get; set; }
        //public string DoNotSend { get; set; }
        //public string DoNotSendUserTypeIds { get; set; }
        //public string DoNotSendClientTypeIds { get; set; }

        public string SentUserTypeIds { get; set; }
        public string SentClientTypeIds { get; set; }

        public bool? IsDeclined { get; set; }
        public int? Status { get; set; }

        public bool IsNewsletterArticleLink { get; set; }
        //public string Attachment { get; set; }        
        public int OrderByDate { get; set; }
    }
}
