﻿namespace ApptitudeCNS.Core
{
    public class Role
    {
        public long Id { get; set; }
        public string RoleName { get; set; }
    }

    public class UserRole
    {
        public int Id { get; set; }
        public long UserId { get; set; }
        public long RoleId { get; set; }
    }
}
