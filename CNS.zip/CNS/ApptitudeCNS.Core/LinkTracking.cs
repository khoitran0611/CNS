﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Core
{
    public class LinkTracking
    {
        public long Id { get; set; }
        public long LinkId { get; set; }
        public long? ClientId { get; set; }
        public long? UserId { get; set; }
        public DateTime ClickedDate { get; set; }
    }
}
