﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace ApptitudeCNS.Helpers
{
    public enum EnumHistoryType
    {
        Note = 1,
        Email,
        [Description("Phone Call")]
        PhoneCall,
        SMS,
        Other
    }

    public enum EnumEmailStatusType
    {
        Unsent = 1,
        Sent,
        Failed,
        Read,
        Clicked
    }

    public enum EnumEmailType
    {
        [Description("Broker Message")]
        BrokerMessage = 1,
        Article,
        [Description("Lowest Rates")]
        LowestRates
    }

    public enum EnumRecipientType
    {
        BrokerClient = 1,
        BrokerAccounts,
        ConveyancerClients,
        AccountantClient
    }

}