﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Core
{
    public class PrimaryImage: EntityBase
    {
        public string Name { get; set; }
        public long CreatedUserId { get; set; }
        public long? UpdatedUserId { get; set; }
    }
}
