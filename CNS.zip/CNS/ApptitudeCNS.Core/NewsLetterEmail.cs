﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Core
{
    public class NewsLetterEmail
    {
        public long Id { get; set; }
        public long UserId { get; set; }
        //public long MailingId { get; set; }
        public long CreatedUserId { get; set; }
        public string ArticleIds { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public bool IsChangable { get; set; }

        public string PrimaryImageName { get; set; }
        public bool? IsSelectedCompanyImage { get; set; }
    }
}
