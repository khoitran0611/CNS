﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Core
{
    public class ArticleSentHistory 
    {
        public long Id { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreatedDate { get; set; }
        public long ArticleId { get; set; }
        public int RecipientTypeId { get; set; }
        public long? CreatedUserId { get; set; }        
    }
}
