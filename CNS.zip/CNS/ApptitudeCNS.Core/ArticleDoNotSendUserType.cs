﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Core
{
    public class ArticleDoNotSendUserType
    {
        public long Id { get; set; }
        public long ArticleId { get; set; }
        public int UserTypeId { get; set; }
    }
}
