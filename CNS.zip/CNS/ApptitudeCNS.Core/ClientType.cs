﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Core
{
    public class ClientType
    {
        public long Id { get; set; }
        public long ClientId { get; set; }
        public int TypeId { get; set; }
    }
}
