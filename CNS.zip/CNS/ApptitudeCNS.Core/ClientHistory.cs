﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Core
{
    public class ClientHistory : EntityBase
    {
        public long ClientId { get; set; }
        public int TypeId { get; set; }
        public string Content { get; set; }
        public bool Pinned { get; set; }
        public bool IsSystemAutogen { get; set; }
        public long? CreatedUserId { get; set; }
        public long? MailTrackingId { get; set; }
    }
}
