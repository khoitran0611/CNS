﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Core
{
    public class SpellfixDictionary: EntityBase
    {
        public SpellfixDictionary()
        {
            CreatedDate = UpdatedDate = DateTime.Now;
            IsDeleted = false;
        }

        //public string Subject { get; set; }
        public string CurrentText { get; set; }
        public string ProperText { get; set; }
        public long CreatedUserId { get; set; }
        public long UpdatedUserId { get; set; }
    }
}
