﻿using System;
using System.ComponentModel;

namespace ApptitudeCNS.Core
{
    public class Client : EntityBase
    {
        public string Email { get; set; }
        [DisplayName("First Name")]
        public string FirstName { get; set; }
        [DisplayName("Last Name")]
        public string LastName { get; set; }    
        public string Salutation { get; set; }
        public string Phone { get; set; }
        [DisplayName("Email Status")]
        public int EmailSubscribe { get; set; }
        [DisplayName("SMS Subscribe")]
        public bool? SMSSubscribe { get; set; }
        public DateTime? Birthday { get; set; }
        [DisplayName("Rentokil Referrer ID")]
        public string BrokerRefNo { get; set; }
        [DisplayName("B User ID")]
        public string BrokerUserNo { get; set; }
        public long UserId { get; set; }
    }
}
