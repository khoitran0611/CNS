﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Core
{
    public class SystemConfig : EntityBase
    {
        public string KeyName { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
        public long CreatedUserId { get; set; }
        public long? UpdatedUserId { get; set; }
    }
}
