﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Core
{
    public class Tag 
    {
        public Tag()
        {
            CreatedDate = UpdatedDate = DateTime.Now;
            IsDeleted = false;
        }
        public int Id { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }

        //public string Subject { get; set; }
        public string Name { get; set; }
        public string MapNames { get; set; }
        public long CreatedUserId { get; set; }
        public long UpdatedUserId { get; set; }
        public int OrderNumber { get; set; }
    }
}
