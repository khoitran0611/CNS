﻿using ApptitudeCNS.Application.Articles;
using ApptitudeCNS.Application.Clients;
using ApptitudeCNS.Application.MailTrackings;
using ApptitudeCNS.Application.PrimaryImages;
using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.SpellfixDictionaries;
using ApptitudeCNS.Application.Tags;
using ApptitudeCNS.Application.UserMailTrackings;
using ApptitudeCNS.Application.Users;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using HtmlAgilityPack;
using InfoCorp.Ico.Senc.Infrastructure.Logging;
using NLog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace ApptitudeCNS.Controllers
{
    public class ArticleController : BaseController
    {
        private IArticleApp articleApp { get; }
        private IMailTrackingApp mailTrackingApp { get; }
        private IUserMailTrackingApp userMailTrackingApp { get; }
        private IUserApp userApp { get; }
        private IClientApp clientApp { get; }
        private IPrimaryImageApp primaryImageApp { get; }
        private ITagApp tagApp { get; }
        private ISpellfixDictionaryApp spellfixDictionaryApp { get; }
        //private ILogger logger { get; }
        private static NLog.ILogger logger = LogManager.GetCurrentClassLogger();

        //private int CurrentPage
        //{
        //    get
        //    {
        //        if (this.Session[CURRENT_PAGE_ARTICLE_SESSION] == null)
        //        {
        //            return 1;
        //        }
        //        return int.Parse(this.Session[CURRENT_PAGE_ARTICLE_SESSION].ToString());
        //    }
        //    set
        //    {
        //        this.Session[CURRENT_PAGE_ARTICLE_SESSION] = value;
        //    }
        //}

        public ArticleController(IArticleApp _articleApp,
            IMailTrackingApp _mailTrackingApp,
            IUserApp _userApp,
            IClientApp _clientApp,
            IUserMailTrackingApp _userMailTrackingApp,
            IPrimaryImageApp _primaryImageApp,
            ITagApp _tagApp,
            ISpellfixDictionaryApp _spellfixDictionaryApp)
        {
            articleApp = _articleApp;
            mailTrackingApp = _mailTrackingApp;
            userApp = _userApp;
            clientApp = _clientApp;
            userMailTrackingApp = _userMailTrackingApp;
            primaryImageApp = _primaryImageApp;
            tagApp = _tagApp;
            spellfixDictionaryApp = _spellfixDictionaryApp;
        }

        // GET: Article
        [Authorize(Roles = "Administrator")]
        public ActionResult Index(long id = 0)
        {
            ViewBag.UserTypes = CommonHelper.GetListForEnum<EnumUserType>();
            ViewBag.ClientTypes = CommonHelper.GetListForEnum<EnumClientType>();
            //var recipientTypes = CommonHelper.GetListForEnum<EnumUserType>();
            //recipientTypes.AddRange(CommonHelper.GetListForEnum<EnumClientType>(startId: 1000));
            //ViewBag.DoNotSendRecipientTypes = recipientTypes;
            ViewBag.DoNotSendRecipientTypes = CommonHelper.GetListForEnum<EnumClientType>(startId: 1000);

            ViewBag.ArticleTypes = CommonHelper.GetListForEnum<EnumArticleType>();
            ViewBag.ArticleTypesFilter = CommonHelper.GetListForEnum<EnumArticleType>(true);

            ViewBag.ArticleTags = tagApp.GetList().Where(x => x.Id != 100).ToList();

            //var tags = CommonHelper.GetListForEnum<EnumArticleTagType>();
            //tags.Insert(0, tags[tags.Count - 1]);
            //tags.RemoveAt(tags.Count - 1);
            ViewBag.FilterArticleTags = tagApp.GetList();
            ViewBag.Id = id;
            ViewBag.UserId = CurrentUser.Id;
            //return View(articleList);

            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public ActionResult Post(ArticleFilterViewModel filter = null)
        {
            try
            {
                //logger.LogInfo($"Start Post article {CurrentUser.Email}");

                //var searchText = Request["searchText"];
                var count = articleApp.GetCount(filter);
                //logger.LogInfo($"Run Post article {CurrentUser.Email}");
                var articleList = articleApp.GetArticleList(filter);
                //logger.LogInfo($"End Post article {CurrentUser.Email}");
                return Json(new { success = true, data = articleList, count, pageSize = ArticleConstants.PAGE_SIZE }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize(Roles = "Administrator")]
        public ActionResult GetDataFromLink(long id, string link, bool isCheckedExist = true, ArticleViewModel model = null)
        {
            try
            {
                var picture = string.Empty;
                var title = string.Empty;
                var summary = string.Empty;
                var articleDate = string.Empty;
                var sitename = string.Empty;
                var author = string.Empty;
                //existingLink
                if (model != null)
                {
                    model.Title = title;
                    //model.Subject = title;
                    model.Summary = summary;
                    model.Picture = picture;
                    model.ArticleDate = null;
                    model.SiteName = sitename;
                    model.Author = author;
                    model.DoNotSendClientTypeIds = new System.Collections.Generic.List<int>();
                    model.DoNotSendUserTypeIds = new System.Collections.Generic.List<int>();
                    model.IsDeclined = null;
                    model.LastSent = null;
                    model.Organisation = string.Empty;
                    model.Status = null;
                }

                if (isCheckedExist && articleApp.CheckExistLink(id, link))
                {
                    return Json(new
                    {
                        success = false,
                        existingLink = true,
                        message = "This link existed. Please enter other Link"
                    }, JsonRequestBehavior.AllowGet);
                }
                using (var webClient = new WebClientEx(isCookies: true))
                {
                    using (var stream = new MemoryStream(webClient.DownloadData(link)))
                    {
                        var html = new HtmlDocument();
                        html.Load(stream, Encoding.UTF8);

                        title = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "main-content" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "content publication-details" },
                            new HtmlTagInfo { TagName = "h1" }
                        });
                        title = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "page-main" },
                            new HtmlTagInfo { TagName = "article", PropertyName = "class", PropertyValue = "the-document" },
                            new HtmlTagInfo { TagName = "h1" }
                        }, title);
                        title = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "page" },
                            new HtmlTagInfo { TagName = "h1", PropertyName = "class", PropertyValue = "story-headline"  }
                        }, title);
                        title = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "property", PropertyValue = "mol:headline", PropertyNameValue = "content" }, title);

                        title = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "page_margins" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article section" },
                            new HtmlTagInfo { TagName = "h1" }
                        }, title);

                        title = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "article", PropertyName = "class", PropertyValue = "article-detail-page" },
                            new HtmlTagInfo { TagName = "h1", PropertyName = "itemprop", PropertyValue = "name" }
                        }, title);

                        title = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "story-body" },
                            new HtmlTagInfo { TagName = "h1" }
                        }, title);

                        title = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "property", PropertyValue = "og:title", PropertyNameValue = "content" }, title);
                        title = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "header", PropertyName = "class", PropertyValue = "intro-text" },
                            new HtmlTagInfo { TagName = "h1" }
                        }, title);
                        title = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "center-page news-item page-padding-bottom" },
                            new HtmlTagInfo { TagName = "h1" }
                        }, title);
                        title = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "h1", PropertyName = "class", PropertyValue = "article-title" },
                            new HtmlTagInfo { TagName = "span" }
                        }, title);
                        title = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "name", PropertyValue = "dcterms.title", PropertyNameValue = "content" }, title);
                        title = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "name", PropertyValue = "twitter:title", PropertyNameValue = "content" }, title);

                        title = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "title" },
                            new HtmlTagInfo { TagName = "h1"  }
                        }, title);
                        title = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "row article-header" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "col-md-9" },
                            new HtmlTagInfo { TagName = "h1", IsMultiValues = true  }
                        }, title);
                        //https://www.morgans.com.au/research-and-markets/market-news-and-data/Breaking-News/CBA-to-exit-aligned-financial-advice-S-1960006
                        title = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "entry-hd" },
                            new HtmlTagInfo { TagName = "h1", IsMultiValues = false  }
                        }, title);
                        //https://www.ft.com/content/8e718656-b88e-11e9-8a88-aa6628ac896c?ftcamp=traffic/partner/feed_headline/us_yahoo/auddev&yptr=yahoo
                        title = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "barrier-banner__container" },
                            new HtmlTagInfo { TagName = "h1"},
                            new HtmlTagInfo { TagName = "blockquote", IsMultiValues = false  }
                        }, title);

                        var minWordCount = 40;
                        var wordCount = 50;
                        summary = html.GetValue(new HtmlTagInfo[] {
                                new HtmlTagInfo { TagName = "main", PropertyName = "id", PropertyValue = "site-content" },
                                new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "article-content" },
                                new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine}
                            }, summary, minWordCount);
                        summary = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "property", PropertyValue = "og:description", PropertyNameValue = "content" }, summary);
                        summary = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "name", PropertyValue = "dcterms.description", PropertyNameValue = "content" }, summary);
                        summary = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "name", PropertyValue = "description", PropertyNameValue = "content" }, summary);
                        summary = html.GetValue(new HtmlTagInfo[] {
                                new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "domain-article-content-wrap" },
                                new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "inner-container" },
                                new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "domain-article-content-body" },
                                new HtmlTagInfo { TagName = "p", TagName2 = "ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine}
                            }, summary, minWordCount);
                        summary = html.GetValue(new HtmlTagInfo[] {
                                new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "main-content" },
                                new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "field_text" },
                                new HtmlTagInfo { TagName = "div" },
                                new HtmlTagInfo { TagName = "p", TagName2 = "ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine}
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "main-content" },
                                new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "field_text" },
                                new HtmlTagInfo { TagName = "p", TagName2 = "ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine}
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "section", PropertyName = "class", PropertyValue = "node" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article-header clearfix", WordCount = wordCount, IsFirstValue = true, Separator = Environment.NewLine,
                                        TagName2 = "div", PropertyName2 = "class", PropertyValue2 = "article-body clearfix", IsMultiValues = true },
                                    //new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article-body clearfix", IsIgnored = true },
                                    new HtmlTagInfo { TagName = "p", TagName2 = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "article", PropertyName = "id", PropertyValue = "article" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "content__standfirst--wrapper", IsFirstValue = true, Separator = Environment.NewLine,
                                        TagName2 = "div", PropertyName2 = "class", PropertyValue2 = "content__main tonal__main tonal__main--tone-feature", IsMultiValues = true },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "content__standfirst content__standfirst--immersive-article",
                                        TagName2 = "div", PropertyName2 = "class", PropertyValue2 = "content__article-body from-content-api js-article__body" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        //side-content
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "inner-container" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "side-content" },
                                    new HtmlTagInfo { TagName = "p", TagName2="ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "column left" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "wysiwyg" },
                                    new HtmlTagInfo { TagName = "p", TagName2="ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "column left" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "wysiwyg" },
                                    new HtmlTagInfo { TagName = "strong", TagName2="#text", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "article", PropertyName = "class", PropertyValue = "article" },
                                    new HtmlTagInfo { TagName = "div", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "text-abstract",
                                        TagName2 = "div", PropertyName2 = "class", PropertyValue2 = "text-body",
                                        IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, IsFoundChildren = true },
                                    new HtmlTagInfo { TagName = "p", TagName2="ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article__body column" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "text-body" },
                                    new HtmlTagInfo { TagName = "p", TagName2="ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "center-page news-item page-padding-bottom" },
                                    new HtmlTagInfo { TagName = "p", TagName2="ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "sqs-block-content" },
                                    new HtmlTagInfo { TagName = "p", TagName2="ul", TagName3 = "h3", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "tnd-content-style tnd-content-style--article" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);


                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "content__main-column content__main-column--article js-content-main-column" },
                                    new HtmlTagInfo { TagName = "div", TagName2="header", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "content__standfirst", IsIgnored = true },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content" },
                                    new HtmlTagInfo { TagName = "section", PropertyName = "class", PropertyValue = "_1ysFk" },
                                    new HtmlTagInfo { TagName = "div" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "text-page-wrapper" },
                                    new HtmlTagInfo { TagName = "p", TagName2 = "ul", TagName3 = "h2", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article__content" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "cq-article-content-paras section" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "page_margins" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article section" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine,
                                        IgnoreItem = new HtmlTagInfo { TagName = "p", PropertyName = "class", PropertyValue = "published" }}
                            }, summary, minWordCount);
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "main-content-container" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article-text" },
                                    new HtmlTagInfo { TagName = "p", TagName2 = "ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article_body" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "itemprop", PropertyValue = "articleBody" },
                                    new HtmlTagInfo { TagName = "p", TagName2="h2", TagName3="header", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article__body" },
                                    new HtmlTagInfo { TagName = "p", TagName2 = "ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article__main" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "ory-cell-inner ory-cell-leaf" },
                                    new HtmlTagInfo { TagName = "div" },
                                    new HtmlTagInfo { TagName = "p", TagName2 = "ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article-content" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article-body" },
                                    new HtmlTagInfo { TagName = "p", TagName2 = "ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "article", PropertyName = "class", PropertyValue = "article-content" },
                                    new HtmlTagInfo { TagName = "p", TagName2 = "ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "article", PropertyName = "id", PropertyValue = "article" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "itemprop", PropertyValue = "articleBody" },
                                    new HtmlTagInfo { TagName = "p", TagName2 = "ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article-content" },
                                    new HtmlTagInfo { TagName = "div", TagName2 = "h3", TagName3 = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article-content" },
                                    new HtmlTagInfo { TagName = "strong", TagName2 = "#text", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "body-copy-v2 fence-body" },
                                    new HtmlTagInfo { TagName = "p", TagName2 = "ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "widget_container content_page" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "post_content" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "page" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "story", TagName3 = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine },
                                    new HtmlTagInfo { TagName = "article" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "story-content", TagName3 = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "container__main" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "container__main__element" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "text parbase", TagName2 = "div", PropertyName2 = "class", PropertyValue2 = "columns", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "text__content" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "row nested-row" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "col col-xs-8 col-lg-9 nested-col-1" },
                                    new HtmlTagInfo { TagName = "div", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "panel-pane pane-entity-field pane-node-body pane-first pos-0",
                                        TagName2 = "div", PropertyName2 = "class", PropertyValue2 = "panel-pane pane-entity-field pane-node-field-subheading pos-1" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "pane-content" },
                                    new HtmlTagInfo { TagName = "p", PropertyName = "class", PropertyValue = "v2-processed", TagName2 = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "row article-content" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "col-md-9 col-md-offset-3 col-sm-10 col-sm-offset-1" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul", TagName3 = "div" }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "story-body__inner" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul" }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "column-wrapper" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "c-text-block" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul" }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "primary" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "entry-content" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul", TagName3 = "h3" }
                            }, summary, minWordCount);

                        //https://www.therealestateconversation.com.au/2018/09/25/reinsw-pushing-real-estate-be-formally-recognised/1537839486
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "content" },
                                    //new HtmlTagInfo { TagName = "div", IsFirstValue = true },
                                    new HtmlTagInfo { TagName = "div", IsFoundChildren = true, IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, PropertyName = "class", PropertyValue = "group-header",
                                        TagName2 = "div", PropertyName2 = "class", PropertyValue2 = "group-left" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "field-type-text-long", IsContained = true,
                                        TagName2 = "div", PropertyName2 = "class", PropertyValue2 = "field-type-text-with-summary", IsContained2 = true  },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "field-item even" },
                                    new HtmlTagInfo { TagName = "p", TagName2 = "ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        //https://www.sciencenews.org/article/eating-ultraprocessed-food-weight-gain-nutrition-studies
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "zone-content" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "field-name-field-sn-subtitle", IsContained = true,
                                        IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine,
                                        TagName2 = "div", PropertyName2 = "class", PropertyValue2 = "field-type-text-with-summary", IsContained2 = true, IsFoundChildren = true },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "field-item even", TagName2 = "div", PropertyName2 = "class", PropertyValue2 = "field-items-even"  },
                                    new HtmlTagInfo { TagName = "h2", TagName2 = "span", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine },
                                    //new HtmlTagInfo { TagName = "#text", IsFirstValue= true, TagName2 = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        //https://qz.com/work/1593918/michelle-obamas-becoming-is-a-lesson-in-how-to-find-fulfillment/
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "main" },
                                    new HtmlTagInfo { TagName = "article" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "_61c55 b8d47" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul", TagName3 = "div" }
                            }, summary, minWordCount);

                        //https://www.businessinsider.com.au/what-owning-a-yacht-is-really-like-2018-10
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "story-wrapper" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "story" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul" }
                            }, summary, minWordCount);

                        //https://www.dailymail.co.uk/news/article-7038945/Sydney-experience-property-boom-192-000-new-houses-built-five-years.html
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "itemprop", PropertyValue = "articleBody" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul" }
                            }, summary, minWordCount);

                        //https://thedriven.io/2019/05/23/amazons-jeff-bezos-says-ev-industry-will-be-exciting-to-watch/
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "main", PropertyName = "id", PropertyValue = "main" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "entry-content" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "container" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "row" },
                                    new HtmlTagInfo { TagName = "div" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul",
                                        IgnoreItem = new HtmlTagInfo{ TagName = "p", PropertyName = "class", PropertyValue = "has-small-font-size"} }
                            }, summary, minWordCount);

                        //https://thewest.com.au/business/housing-market/falling-values-push-house-prices-back-to-2006-levels-ng-b881218873z
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "article", PropertyName = "itemprop", PropertyValue = "articleBody" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "css-lv7v80" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "css-8atqhb" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul" }
                            }, summary, minWordCount);

                        //https://www.ratecity.com.au/home-loans/mortgage-news/proposed-apra-changes-open-door-home-buyers
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "main", PropertyName = "class", PropertyValue = "news-article" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "itemprop", PropertyValue = "articleBody" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul" }
                            }, summary, minWordCount);

                        //https://www.westpac.com.au/news/making-news/2019/05/bills-bites-barely-acceptable-forecasts/
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "bodycopy" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul" }
                            }, summary, minWordCount);

                        //https://www.itnews.com.au/news/comyn-bets-cbas-big-app-revamp-will-restore-lost-trust-525827
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "article-primary" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "article-body", TagName2 = "h2", PropertyName2 = "id", PropertyValue2 = "article-intro",
                                        IsMultiValues = true, Separator = Environment.NewLine },
                                    new HtmlTagInfo { TagName = "#text", IsFirstValue = true, IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul", TagName3 = "p" }
                            }, summary, minWordCount);

                        //https://www.cnbc.com/2019/05/16/california-governor-pushes-new-taxes-fees-despite-states-21-billion-surplus.html?recirc=taboolainternal
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "MainContent" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "KeyPoints-keyPoints" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "KeyPoints-list" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "group" },
                                    new HtmlTagInfo { TagName = "ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "p"}
                            }, summary, minWordCount);

                        //https://www.internationalinvestment.net/news/4002281/china-looming-current-account-deficit-consequences-devere
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article-page-body-content" },
                                    new HtmlTagInfo { TagName = "ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "p"}
                            }, summary, minWordCount);

                        //https://edition.cnn.com/2019/05/24/investing/uber-lyft-stock-ipo-market/index.html
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "itemprop", PropertyValue = "articleBody" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "l-container" },
                                    new HtmlTagInfo { TagName = "ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "p", TagName3 = "div"}
                            }, summary, minWordCount);

                        //https://www.finder.com.au/when-can-i-get-5g-in-australia
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "main" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "entry" },
                                    new HtmlTagInfo { TagName = "body" },
                                    new HtmlTagInfo { TagName = "h2", IsFirstValue = true, IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "p", TagName3 = "h3" }
                            }, summary, minWordCount);

                        //https://www.itnews.com.au/news/comyn-bets-cbas-big-app-revamp-will-restore-lost-trust-525827
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "article-primary" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "article-body", TagName2 = "h2", PropertyName2 = "id", PropertyValue2 = "article-intro",
                                        IsMultiValues = true, Separator = Environment.NewLine },
                                    new HtmlTagInfo { TagName = "#text", IsFirstValue = true, IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul", TagName3 = "p" }
                            }, summary, minWordCount);

                        //https://www.canberratimes.com.au/story/6184421/brace-for-impact-climate-change-litigation-is-fast-approaching/?cs=14258
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "main" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "itemprop", PropertyValue = "articleBody" },
                                    new HtmlTagInfo { TagName = "#text", IsFirstValue = true, IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul", TagName3 = "p" }
                            }, summary, minWordCount);

                        //https://www.financialstandard.com.au/news/financial-advice-valued-beyond-returns-136783714
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "news_story_content" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "cms_content" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul" }
                            }, summary, minWordCount);

                        //https://www.moneymanagement.com.au/news/policy-regulation/tpb-confirms-35-higher-risk-breach-crack-down
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "main-column" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "content" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content-column" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "views-field-field-short-headline story-long-headline",
                                        TagName2 = "div", PropertyName2 = "id", PropertyValue2 = "content", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine },
                                    new HtmlTagInfo { TagName = "#text", IsFirstValue = true, IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine,
                                        TagName2 = "div", PropertyName2 = "class", PropertyValue2 = "field field-name-body field-type-text-with-summary field-label-hidden" }
                            }, summary, minWordCount);

                        //https://www.interest.co.nz/property/99794/lower-interest-rates-flat-house-prices-and-slowly-rising-incomes-are-turning
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "cm-article" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "cm-article-body" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul" }
                            }, summary, minWordCount);

                        //https://www.sciencenews.org/article/eating-ultraprocessed-food-weight-gain-nutrition-studies
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "cm-article" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "cm-article-body" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul" }
                            }, summary, minWordCount);

                        //https://www.domain.com.au/research/first-home-loan-deposit-scheme-three-things-buyers-need-to-remember-841941/
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content" },
                                    new HtmlTagInfo { TagName = "section", PropertyName = "class", PropertyValue = "dm-news-article-body domain-content-event-track" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul" }
                            }, summary, minWordCount);

                        //https://www.allhomes.com.au/news/greater-open-home-attendance-increase-in-appraisals-point-to-renewed-spark-in-property-market-842860/?utm_campaign=strap-masthead&utm_source=canberra-times&utm_medium=link&utm_content=pos5
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "news-article-content-body" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul" }
                            }, summary, minWordCount);

                        //https://tmmonline.nz/article/976514913/lvr-restrictions-stabilise-property-market-rbnz
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "container" },
                                    new HtmlTagInfo { TagName = "article" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "post-content",
                                        TagName2 = "header", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "lead", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "p", TagName3 = "ul" }
                            }, summary, minWordCount);

                        //https://www.theverge.com/good-deals/2019/6/10/18659632/apple-watch-series-4-discount-sale-ipad-sony-1000x-m3-anker
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "main", PropertyName = "id", PropertyValue = "content" },
                                    new HtmlTagInfo { TagName = "article" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "l-segment",
                                        TagName2 = "div", PropertyName2 = "class", PropertyValue2 = "l-sidebar-fixed l-segment l-article-body-segment",
                                        IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "c-entry-hero c-entry-hero--default",
                                        TagName2 = "div", PropertyName2 = "class", PropertyValue2 = "c-entry-content", IsFoundChildren = true },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        //https://www.reuters.com/article/us-usa-trade-huawei/white-house-seeks-delay-on-huawei-ban-for-contractors-idUSKCN1TA0T1
                        summary = html.GetValue(new HtmlTagInfo[] {
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "StandardArticleBody_container" },
                                    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "StandardArticleBody_body" },
                                    new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "ul" }
                            }, summary, minWordCount);

                        //https://www.gerardmaloufpartners.com.au/DailyLegalNews/6067269-What-are-the-public-liability-implications-of-peanuts-on-airplanes.aspx
                        summary = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "main-content" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "content publication-details" },
                            new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "h2", TagName3 = "ul" }
                            }, summary, minWordCount);

                        //http://www.austlii.edu.au/cgi-bin/viewdoc/au/cases/vic/VCC/2019/602.html
                        summary = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "main-content" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "content publication-details" },
                            new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine, TagName2 = "h2", TagName3 = "ul" }
                            }, summary, minWordCount);

                        //http://www.austlii.edu.au/cgi-bin/viewdoc/au/cases/vic/VCC/2019/602.html
                        summary = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "page-main" },
                            new HtmlTagInfo { TagName = "article", PropertyName = "class", PropertyValue = "the-document"  },
                            new HtmlTagInfo { TagName = "p", PropertyName = "class", PropertyValue = "h1", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine,
                                TagName2 = "p", PropertyName2 = "class", PropertyValue2 = "h2" }
                        }, summary, minWordCount);

                        //https://www.morgans.com.au/research-and-markets/market-news-and-data/Breaking-News/CBA-to-exit-aligned-financial-advice-S-1960006
                        summary = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content" },
                            new HtmlTagInfo { TagName = "p", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        //https://www.ft.com/content/8e718656-b88e-11e9-8a88-aa6628ac896c?ftcamp=traffic/partner/feed_headline/us_yahoo/auddev&yptr=yahoo
                        summary = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "site-content" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "barrier-banner__content" },
                             new HtmlTagInfo {  TagName = "p", TagName2 = "h2", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        //https://www.cgw.com.au/publication/it-pays-to-check-apprentice-butcher-awarded-578k-for-slip-on-sausage-mince/
                        summary = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "content-holder" },
                            new HtmlTagInfo { TagName = "article", PropertyName = "role", PropertyValue = "article" },
                            new HtmlTagInfo { TagName = "section", PropertyName = "class", PropertyValue = "post_content" },
                            new HtmlTagInfo {  TagName = "p", TagName2 = "ul", IsMultiValues = true, WordCount = wordCount, Separator = Environment.NewLine }
                            }, summary, minWordCount);

                        summary = html.GetValue(new HtmlTagInfo[] { new HtmlTagInfo { TagName = "meta", PropertyName = "property", PropertyValue = "og:description", PropertyNameValue = "content" } }, summary, 10);

                        //summary = html.GetValue(new HtmlTagInfo[] {
                        //    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article clearfix" },
                        //    new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "two-col" },
                        //    new HtmlTagInfo { TagName = "p", Ig = true }
                        //}, summary);


                        //https://www.sciencenews.org/article/monkeys-can-use-basic-logic-decipher-order-items-list?utm_source=email&utm_medium=email&utm_campaign=latest-newsletter-v2&utm_source=Latest_Headlines&utm_medium=email&utm_campaign=Latest_Headlines
                        picture = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "rel", PropertyValue = "rnews:associatedMedia schema:associatedMedia", PropertyNameValue = "resource" },

                        }, picture);

                        //https://www.cgw.com.au/publication/it-pays-to-check-apprentice-butcher-awarded-578k-for-slip-on-sausage-mince/
                        picture = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "content-holder" },
                            new HtmlTagInfo { TagName = "article", PropertyName = "role", PropertyValue = "article" },
                            new HtmlTagInfo { TagName = "section", PropertyName = "class", PropertyValue = "post_content" },
                            new HtmlTagInfo {  TagName = "img", PropertyName = "class", PropertyValue ="publication-feature-image", PropertyNameValue = "src" }
                            }, picture);


                        picture = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "property", PropertyValue = "og:image", PropertyNameValue = "content" }, picture);
                        picture = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "itemprop", PropertyValue = "url", PropertyNameValue = "content" }, picture);

                        picture = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article-image" },
                            new HtmlTagInfo { TagName = "img", PropertyNameValue = "src" }
                        }, picture);
                        picture = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "container article" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "col-md-8 article" },
                            new HtmlTagInfo { TagName = "img", PropertyNameValue = "src", IsMultiValues=true }
                        }, picture);

                        //https://www.ft.com/content/8e718656-b88e-11e9-8a88-aa6628ac896c?ftcamp=traffic/partner/feed_headline/us_yahoo/auddev&yptr=yahoo
                        picture = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "barrier-banner__img-container" },
                            new HtmlTagInfo { TagName = "img", PropertyNameValue = "src", IsMultiValues=true }
                        }, picture);


                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "news_story_date", FindWord = "BY" },
                        });

                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "section", PropertyName = "class", PropertyValue = "main-content" },
                            new HtmlTagInfo { TagName = "header" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "timestamp" },
                        }, articleDate);

                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "cm-article" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "datatype", PropertyValue = "xsd:dateTime", PropertyNameValue = "content" },
                        }, articleDate);

                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "main-column" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "by-line" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "views-field-published-at published-at" }
                        }, articleDate);

                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "page-main" },
                            new HtmlTagInfo { TagName = "article", PropertyName = "class", PropertyValue = "the-document" },
                            new HtmlTagInfo { TagName = "p", FindWord = "Last Updated:" }
                        }, articleDate);

                        articleDate = html.GetValue(new HtmlTagInfo[] {
                             new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "main-content" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "content publication-details" },
                           new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "published-date", FindWord="Date:" },
                        }, articleDate);

                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "metadata-header" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "metadata" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "metadata-date" }
                        }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "primary" },
                            new HtmlTagInfo { TagName = "h2", PropertyName = "class", PropertyValue = "entry-meta" },
                            new HtmlTagInfo { TagName = "time", PropertyNameValue = "datetime" }
                        }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "itemprop", PropertyValue = "datePublished", PropertyNameValue = "content", FindWord = "Updated " }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo { TagName = "time", PropertyName = "itemprop", PropertyValue = "datePublished", PropertyNameValue = "content" }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "property", PropertyValue = "article:published_time", PropertyNameValue = "content" }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "property", PropertyValue = "og:published_time", PropertyNameValue = "content" }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "name", PropertyValue = "dcterms.date.created", PropertyNameValue = "content" }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "name", PropertyValue = "sailthru.date", PropertyNameValue = "content" }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "name", PropertyValue = "date", PropertyNameValue = "content" }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo { TagName = "p", PropertyName = "class", PropertyValue = "paragraph-active news-date" }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "entry-dateline" },
                            new HtmlTagInfo { TagName = "a" }
                        }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "wire__date" },
                            new HtmlTagInfo { TagName = "a" }
                        }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article-meta" },
                            new HtmlTagInfo { TagName = "p", PropertyName = "class", PropertyValue = "date" }
                        }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "articledate" },
                            new HtmlTagInfo { TagName = "p", PropertyName = "class", PropertyValue = "date" }
                        }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "header", PropertyName = "class", PropertyValue = "intro-text" },
                            new HtmlTagInfo { TagName = "span" }
                        }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "ul", PropertyName = "class", PropertyValue = "cfx list horizontal article_meta" },
                            new HtmlTagInfo { TagName = "li" }
                        }, articleDate);

                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "p", PropertyName = "class", PropertyValue = "date" },
                            new HtmlTagInfo { TagName = "time", PropertyName = "class", PropertyValue = "dt-published", PropertyNameValue = "datetime" }
                        }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "author__profile" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "text--byline" }
                        }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "author" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "post-date rui-clearfix" }
                        }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "article_date" },
                            new HtmlTagInfo { TagName = "time" }
                        }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "articledate" },
                            new HtmlTagInfo { TagName = "span" }
                        }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "articledate" },
                            new HtmlTagInfo { TagName = "span" }
                        }, articleDate);

                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article clearfix" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "two-col" },
                            new HtmlTagInfo { TagName = "p", WordCount = 3, IsMultiValues = true, IsFirstValue = true,
                                IgnoreItem = new HtmlTagInfo { TagName = "p", PropertyName = "class", PropertyValue = "pdf" },
                            }
                        }, articleDate);

                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "row article-header" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "col-md-9" },
                            new HtmlTagInfo { TagName = "h4", IsMultiValues = true  }
                        }, articleDate);

                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "mini-info-list-wrap" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "date date--v2"  }
                        }, articleDate);

                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "header-content" },
                            new HtmlTagInfo { TagName = "p", PropertyName = "class", PropertyValue = "date"  }
                        }, articleDate);

                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "group-header" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "field-name-post-date", IsContained = true  }
                        }, articleDate);
                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "main" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "date", IsContained = true  },
                            new HtmlTagInfo { TagName = "time", PropertyNameValue="datetime"  }
                        }, articleDate);

                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "col-wrapper" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "byline-post-info single", PropertyNameValue="datetime"},
                        }, articleDate);

                        //https://www.westpac.com.au/news/making-news/2019/05/bills-bites-barely-acceptable-forecasts/
                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article-header-wrapper" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "author-title-detail" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "time-detail"},
                        }, articleDate);

                        //https://www.itnews.com.au/news/comyn-bets-cbas-big-app-revamp-will-restore-lost-trust-525827
                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "article-details" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "itemprop", PropertyValue = "datePublished", PropertyNameValue = "content" },
                        }, articleDate);

                        if (!string.IsNullOrWhiteSpace(articleDate) && articleDate.Contains("|"))
                        {
                            var list = articleDate.Split('|');
                            articleDate = list[1].Trim();
                            author = list[0].Trim();
                        }
                        //https://www.morgans.com.au/research-and-markets/market-news-and-data/Breaking-News/CBA-to-exit-aligned-financial-advice-S-1960006
                        articleDate = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "entry-meta" },
                        }, articleDate);

                        if (!string.IsNullOrWhiteSpace(articleDate) && articleDate.Contains("|"))
                        {
                            var list = articleDate.Split('|');
                            articleDate = list[1].Trim();
                            //author = list[0].Trim();
                        }

                        articleDate = CommonHelper.ConvertDateTimeStringToString(articleDate);

                        sitename = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "property", PropertyValue = "og:site_name", PropertyNameValue = "content" });
                        sitename = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "navigation-container" },
                            new HtmlTagInfo { TagName = "a", PropertyName = "class", PropertyValue = "navbar-brand"   },
                            new HtmlTagInfo { TagName = "span"   }
                        }, sitename);
                        sitename = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "header-main"   },
                            new HtmlTagInfo { TagName = "img", PropertyNameValue = "alt" }
                        }, sitename);

                        sitename = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "itemprop", PropertyValue = "name", PropertyNameValue = "content" }, sitename);
                        sitename = html.GetValue(new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "logo-text visuallyhidden" }, sitename);
                        //
                        sitename = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "desktop-menu clearfix" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "title"   }
                        }, sitename);

                        sitename = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "logo" },
                            new HtmlTagInfo { TagName = "a", PropertyNameValue = "aria-label", FindWord = " logo" }
                        }, sitename);

                        sitename = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "logo-container" },
                            new HtmlTagInfo { TagName = "a" }
                        }, sitename);
                        sitename = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "a", PropertyName = "class", PropertyValue = "site-logo" },
                            new HtmlTagInfo { TagName = "img", PropertyNameValue = "alt" }
                        }, sitename);
                        sitename = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "site-logo" },
                            new HtmlTagInfo { TagName = "img", PropertyNameValue = "alt" }
                        }, sitename);
                        sitename = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "a", PropertyName = "class", PropertyValue = "logo logo--brand" },
                            new HtmlTagInfo { TagName = "img", PropertyNameValue = "alt" }
                        }, sitename);
                        sitename = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "a", PropertyName = "class", PropertyValue = "rui-main-logo" },
                            new HtmlTagInfo { TagName = "img", PropertyNameValue = "alt" }
                        }, sitename);
                        sitename = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "a", PropertyName = "class", PropertyValue = "logo" },
                            new HtmlTagInfo { TagName = "img", PropertyName = "class", PropertyValue = "default", PropertyNameValue = "alt", FindWord=" Logo" }
                        }, sitename);

                        //https://www.reuters.com/article/us-usa-trade-huawei/white-house-seeks-delay-on-huawei-ban-for-contractors-idUSKCN1TA0T1
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "BylineBar_byline" },
                            new HtmlTagInfo { TagName = "a"},
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        //https://www.interest.co.nz/property/99794/lower-interest-rates-flat-house-prices-and-slowly-rising-incomes-are-turning
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "main", PropertyName = "id", PropertyValue = "content" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "c-byline" },
                            new HtmlTagInfo { TagName = "a"},
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "main-story-column" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "by-line" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "author-name" },
                            new HtmlTagInfo { TagName = "a"},
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        //https://www.moneymanagement.com.au/news/policy-regulation/tpb-confirms-35-higher-risk-breach-crack-down
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "cm-article" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "cm-byline" },
                            new HtmlTagInfo { TagName = "a"},
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        //https://edition.cnn.com/2019/05/24/investing/uber-lyft-stock-ipo-market/index.html
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "metadata" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "metadata__info js-byline-images" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "metadata__byline__author" },
                            new HtmlTagInfo { TagName = "a"},
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        //https://www.itnews.com.au/news/comyn-bets-cbas-big-app-revamp-will-restore-lost-trust-525827
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "article-details" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "itemprop", PropertyValue = "author" },
                            new HtmlTagInfo { TagName = "span"},
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        //https://www.itnews.com.au/news/comyn-bets-cbas-big-app-revamp-will-restore-lost-trust-525827
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article-meta-container group" },
                            new HtmlTagInfo { TagName = "li", PropertyName = "class", PropertyValue = "author-dateline-name" },
                            new HtmlTagInfo { TagName = "a"},
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        //
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article-header-wrapper" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "author-title-detail" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article-author-name" },
                            new HtmlTagInfo { TagName = "a" },
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        //https://www.ratecity.com.au/home-loans/mortgage-news/proposed-apra-changes-open-door-home-buyers
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "author-details-wrapper" },
                            new HtmlTagInfo { TagName = "p", PropertyName = "property", PropertyValue = "author" },
                            new HtmlTagInfo { TagName = "span" },
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content" },
                            new HtmlTagInfo { TagName = "a", PropertyName = "class", PropertyValue = "author", FindWord="For Daily Mail Australia" },
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "main" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "d3284 _3c16e" },
                            new HtmlTagInfo { TagName = "a" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article__main" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article__info-block" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "article__info-block__author", FindWord = "By " }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "wire-byline" },
                            new HtmlTagInfo { TagName = "a", PropertyName = "class", PropertyValue = "wire-author", FindWord = "By " }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "_2QKfP" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "_1VNac", FindWord = "By " }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "_2c9lV" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "_1VNac", FindWord = "By " }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "p", PropertyName = "class", PropertyValue = "meta" },
                            new HtmlTagInfo { TagName = "a", PropertyName = "rel", PropertyValue = "author" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "author__profile" },
                            new HtmlTagInfo { TagName = "span", FindWord = "By " }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article-author" },
                            new HtmlTagInfo { TagName = "p", PropertyName = "class", PropertyValue = "main-info__name" },
                            new HtmlTagInfo { TagName = "a" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article__tools" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "article-author__item article-author__item--name" },
                            new HtmlTagInfo { TagName = "a" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "entry-author vcard" },
                            new HtmlTagInfo { TagName = "a" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "author-name-contact clearfix" },
                            new HtmlTagInfo { TagName = "span" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "author_top" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "author_byline", FindWord = "By " }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "author" },
                            new HtmlTagInfo { TagName = "a", PropertyName = "class", PropertyValue = "author-name" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "p", PropertyName = "class", PropertyValue = "author" },
                            new HtmlTagInfo { TagName = "a" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "meta__contact-wrap" },
                            new HtmlTagInfo { TagName = "a", PropertyName = "class", PropertyValue = "tone-colour" },
                            new HtmlTagInfo { TagName = "span" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "avatar" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "style" },
                            new HtmlTagInfo { TagName = "a" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content" },
                            new HtmlTagInfo { TagName = "h5", PropertyName = "class", PropertyValue = "_2FyET" },
                            new HtmlTagInfo { TagName = "a" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content" },
                            new HtmlTagInfo { TagName = "h5", PropertyName = "class", PropertyValue = "_2FyET", FindWord="By " }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "ul", PropertyName = "class", PropertyValue = "avatar--list" },
                            new HtmlTagInfo { TagName = "li", IsMultiValues = true, Separator = ", " },
                            new HtmlTagInfo { TagName = "a" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "byline" },
                            new HtmlTagInfo { TagName = "a" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        //https://www.bbc.com/news/business-48256535?intlink_from_url=https://www.bbc.com/news/business-38507481&link_location=live-reporting-story
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "byline" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "byline__name", FindWord = "By " }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "p", PropertyName = "class", PropertyValue = "news-author" },
                            new HtmlTagInfo { TagName = "a" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "authors" },
                            new HtmlTagInfo { TagName = "span" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "h2", PropertyName = "class", PropertyValue = "entry-meta" },
                            new HtmlTagInfo { TagName = "a", PropertyName = "rel", PropertyValue = "author" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "c-publish-by" },
                            new HtmlTagInfo { TagName = "p", PropertyName = "class", PropertyValue = "display-micro", FindWord="Published by" },
                            //new HtmlTagInfo { TagName = "a", IsMultiValues = true, Separator = ", " }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "site-content" },
                            new HtmlTagInfo { TagName = "span", PropertyName = "class", PropertyValue = "author vcard" },
                            new HtmlTagInfo { TagName = "a" }
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo { TagName = "p", PropertyName = "class", PropertyValue = "article-header__author", FindWord = "By " },
                            "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "name", PropertyValue = "shareaholic:article_author_name", PropertyNameValue = "content" },
                            "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);
                        author = html.GetValue(new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "author" },
                            "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "name", PropertyValue = "author", PropertyNameValue = "content" },
                            "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);
                        author = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "property", PropertyValue = "article:author", PropertyNameValue = "content" },
                            "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);
                        author = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "name", PropertyValue = "article:author", PropertyNameValue = "content" },
                            "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "name", PropertyValue = "article:author", PropertyNameValue = "content" },
                            "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        if (author == "https://www.facebook.com/bbcnews")
                        {
                            author = "";
                        }

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "col-wrapper" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "author-links"},
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article clearfix" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "one-col-last" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "thumb clearfix", IsMultiValues = true, Separator = ", " },
                            new HtmlTagInfo { TagName = "h4" },
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "section", PropertyName = "class", PropertyValue = "content-authors" },
                            new HtmlTagInfo { TagName = "li", PropertyName = "itemprop", PropertyValue = "author" , IsFoundChildren = true, IsMultiValues = true, Separator = ", " },
                            new HtmlTagInfo { TagName = "a", PropertyName = "rel", PropertyValue = "author"  },
                            new HtmlTagInfo { TagName = "span", PropertyName = "itemprop", PropertyValue = "name"  },
                            //new HtmlTagInfo { TagName = "h4" },
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        //https://www.savings.com.au/term-deposits/commbank-racq-cua-drop-term-deposit-rates/
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "main", PropertyName = "id", PropertyValue = "main" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "article-header" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "author-info"},
                            new HtmlTagInfo { TagName = "a", PropertyName = "rel", PropertyValue = "author"},
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        //https://www.therealestateconversation.com.au/blog/johnathon-broome/lifting-the-lid-investment-loans-encourages-investors-and-first-home-buyers
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "content" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "content" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "group-header"},
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "view-id-contributor_headshot", IsContained = true},
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "views-field views-field-title"},
                            new HtmlTagInfo { TagName = "a" },
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        //https://www.startupdaily.net/2019/06/australias-money-laundering-cop-is-worried-about-fintech-startups-such-as-afterpay/
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "content grid-container" },
                            new HtmlTagInfo { TagName = "header", PropertyName = "class", PropertyValue = "article-header"},
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "post-top-meta"},
                            new HtmlTagInfo { TagName = "a" },
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        //https://thewest.com.au/business/housing-market/falling-values-push-house-prices-back-to-2006-levels-ng-b881218873z
                        author = html.GetValue(new HtmlTagInfo { TagName = "span", PropertyName = "itemprop", PropertyValue = "author name" },
                            "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        //https://www.sharecafe.com.au/2019/08/07/cba-maintains-dividend-as-profit-slips-4-7/
                        author = html.GetValue(new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "author-information" },
                            "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        if (!string.IsNullOrEmpty(author) && author.Contains("|"))
                        {
                            author = author.Split('|')[0];
                        }
                        if (!string.IsNullOrEmpty(author) && author.ToLower().Contains("by "))
                        {
                            author = author.Substring(author.LastIndexOf("by ", StringComparison.OrdinalIgnoreCase) + 3);
                        }

                        //https://qz.com/work/1682579/jpmorgan-chase-chooses-ai-copywriter-persado-to-write-ads/                 
                        author = html.GetValue(new HtmlTagInfo { TagName = "meta", PropertyName = "property", PropertyValue = "author", PropertyNameValue = "content" },
                           "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        //https://www.afr.com/property/residential/ralan-in-state-watchdog-s-sights-over-deposit-policy-20190807-p52eno
                        author = html.GetValue(new HtmlTagInfo { TagName = "a", PropertyName = "class", PropertyValue = "sLxGg" },
                           "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);
                        //IsFirstValue
                        //https://www.cgw.com.au/publication/it-pays-to-check-apprentice-butcher-awarded-578k-for-slip-on-sausage-mince/
                        author = html.GetValue(new HtmlTagInfo[] {
                            new HtmlTagInfo { TagName = "div", PropertyName = "id", PropertyValue = "speaker-holder" },
                            new HtmlTagInfo { TagName = "div", PropertyName = "class", PropertyValue = "row-speaker", IsFirstValue=true },
                            new HtmlTagInfo { TagName = "a", PropertyName = "class", PropertyValue = "sidebar-title"},
                        }, "author".Equals(author, StringComparison.OrdinalIgnoreCase) ? "" : author);

                        if ("author".Equals(author, StringComparison.OrdinalIgnoreCase))
                        {
                            author = string.Empty;
                        }
                        var url = new Uri(link);
                        //https://www.morgans.com.au/research-and-markets/market-news-and-data/Breaking-News/CBA-to-exit-aligned-financial-advice-S-1960006
                        //                        -need Title, Summary, currently Author is Morgans Financial Limited, it is better to have it blank as there not authored
                        if (url.Host == "www.morgans.com.au")
                        {
                            author = string.Empty;
                        }

                        if (string.IsNullOrWhiteSpace(sitename))
                        {
                            sitename = url.Host;
                        }
                        else if (url.Host == "www.reuters.com")
                        {
                            sitename = "Reuters";
                        }
                        if (sitename == "interest.co.nz")
                        {
                            sitename = "Interest";
                        }
                        sitename = Helpers.UrlHelper.NormaliseUrl(sitename);

                        // Remove site name with special characters before and after it
                        title = GetTitle(title, sitename);
                        title = GetTitle(title, url.Host);
                        if (url.Host.StartsWith("www."))
                        {
                            title = GetTitle(title, url.Host.Substring(4));
                        }
                    }
                }

                picture = GetPicture(picture, link);
                var tagIds = new List<int>();
                tagIds = tagApp.GetTagIdsByMapNames(title);
                if (tagIds.Count() == 0)
                    tagIds = tagApp.GetTagIdsByMapNames(summary);
                if (model != null)
                {
                    model.Title = title;
                    //model.Subject = title;
                    model.Summary = summary;
                    model.Picture = picture;
                    model.ArticleDate = CommonHelper.ConvertDateTimeString(articleDate);
                    model.SiteName = sitename;
                    model.Author = author;
                    model.TagIds = tagIds;
                }

                if (tagIds != null && tagIds.Count > 0 && !string.IsNullOrWhiteSpace(summary))
                {
                    var item = new ArticleViewModel
                    {
                        Id = id,
                        Title = title,
                        Summary = summary,
                        Picture = picture,
                        ArticleDate = CommonHelper.ConvertDateTimeString(articleDate),
                        SiteName = sitename,
                        Author = author,
                        Link = link,
                        TagIds = tagIds,
                        IsNewsletterArticleLink = true
                    };
                    logger.Info(string.Format("Broker: {0}", Newtonsoft.Json.JsonConvert.SerializeObject(item)));

                    Create(item);
                    id = item.Id;
                }
                return Json(new
                {
                    success = !string.IsNullOrWhiteSpace(title) || !string.IsNullOrWhiteSpace(summary) ||
                    !string.IsNullOrWhiteSpace(picture) || !string.IsNullOrWhiteSpace(articleDate) ||
                    !string.IsNullOrWhiteSpace(sitename) || !string.IsNullOrWhiteSpace(author),
                    id,
                    title,
                    summary,
                    picture,
                    articleDate,
                    sitename,
                    author,
                    tagIds
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        // GET: Article/Create
        //public ActionResult Create()
        //{
        //    return View();
        //}
        [HttpGet]
        [Authorize(Roles = "Administrator")]
        public ActionResult GetTagsByMapNames(string mapNames)
        {
            //if (CurrentUser == null || CurrentUser.Id == 0)
            //{
            //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
            //}
            var tagIds = tagApp.GetTagIdsByMapNames(mapNames);
            return Json(new { success = true, tagIds }, JsonRequestBehavior.AllowGet);
        }

        // POST: Article/Create
        [HttpPost]
        //[ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrator")]
        public ActionResult Create(ArticleViewModel model)//FormCollection collection)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                model.Picture = model.Picture ?? Request["filename"];
                model.Attachment = string.IsNullOrWhiteSpace(Request["Attachment"]) ? null : Newtonsoft.Json.JsonConvert.DeserializeObject<ArticleAttachment>(Request["Attachment"]);
                model.DoNotSendUserTypeIds = Request["DoNotUserTypeIds"]?.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(x => CommonHelper.GetInt(x)).ToList() ?? new System.Collections.Generic.List<int>();
                model.DoNotSendClientTypeIds = Request["DoNotClientTypeIds"]?.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(x => CommonHelper.GetInt(x)).ToList() ?? new System.Collections.Generic.List<int>();
                if (model.TagIds == null || model.TagIds.Count == 0)
                {
                    model.TagIds = Request["TagIds"]?.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(x => CommonHelper.GetInt(x)).ToList();

                    if (model.TagIds == null || model.TagIds.Count == 0)
                    {
                        logger.Warn(string.Format("Create Article: {0}", Newtonsoft.Json.JsonConvert.SerializeObject(model)));
                    }
                    else
                    {
                        logger.Info(string.Format("Create Article: {0}", Newtonsoft.Json.JsonConvert.SerializeObject(model)));
                    }
                }
                //model.RecipientTypes = Request["checkboxRecipientType[]"].Split(',').Select(x => int.Parse(x)).ToList();
                model.UpdatedDate = DateTime.Now;
                model.UpdatedUserId = CurrentUser.Id; // will put it later
                model.Link = Helpers.UrlHelper.StandardizeUrl(model.Link);

                var id = model.Id;
                if (model.Id > 0)
                {
                    articleApp.Update(model);
                }
                else
                {
                    model.CreatedDate = DateTime.Now;
                    model.CreatedUserId = CurrentUser.Id; // will put it later
                    model.HistoryNote = $"Make one up including the {model.Link}";
                    id = model.Id = articleApp.Create(model);
                }
                return Json(new { success = true, id }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        [Authorize(Roles = "Administrator")]
        public ActionResult Edit(long id)
        {
            //if (CurrentUser == null || CurrentUser.Id == 0)
            //{
            //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
            //}
            var result = articleApp.FindBy(id);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Authorize()]
        public ActionResult CheckExistLink(long id, string link)
        {
            //if (CurrentUser == null || CurrentUser.Id == 0)
            //{
            //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
            //}
            var exist = articleApp.CheckExistLink(id, link);
            return Json(exist ? "This link existed. Please enter other Link" : "true", JsonRequestBehavior.AllowGet);

            //if (exist)
            //{
            //    return Json("This link existed. Please enter other Link", JsonRequestBehavior.AllowGet);
            //}
            //return Json(true, JsonRequestBehavior.AllowGet);
            //dynamic result = true;
            //if (exist)
            //exist ? "This link existed. Please enter other Link" : true;
            //return Json(result ? "This link existed. Please enter other Link" : "true", JsonRequestBehavior.AllowGet);
        }

        [Authorize(Roles = "Administrator")]
        public ActionResult LoadArticles()
        {
            try
            {
                var data = articleApp.LoadArticles();
                return Json(new { success = true, data }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public ActionResult SaveSelectedArticles(long[] ids)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var userId = CurrentUser.Id; // Will put it later
                articleApp.SaveSelectedArticles(ids, userId);
                return Json(new { success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        // GET: Article/Delete/5
        [Authorize(Roles = "Administrator")]
        public ActionResult Delete(long id)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var userId = CurrentUser.Id; // Will put it later
                articleApp.Delete(id, userId);
                return Json(new { success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public ActionResult UploadPicture()
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var files = Request.Files;
                if (files == null || files.Count == 0 || files[0].ContentLength <= 0)
                    return Json(new { success = false, message = "Please select a file before uploading picture." }, JsonRequestBehavior.AllowGet);

                var file = files[0];
                string fileName = Path.GetFileName(file.FileName);
                if (!MimeMapping.GetMimeMapping(fileName).StartsWith("image/") && MimeMapping.GetMimeMapping(fileName) != "application/octet-stream")
                {
                    return Json(new { success = false, message = "The attached file is not supported." }, JsonRequestBehavior.AllowGet);
                }

                var path = Server.MapPath(ArticleConstants.UPLOADED_PICTURE_FOLDER);
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                fileName = $"{ DateTime.Now.ToString("yyyyMMddHHmmss")}_{fileName.Replace(" ", "-")}";
                path = Path.Combine(path, fileName);
                file.SaveAs(path);
                var pictureName = $"{CNSConstant.THUMBNAIL_NAME}_{ImageHelper.GetJpecFileName(fileName)}";
                string pathThumbnail = Path.Combine(Server.MapPath(ArticleConstants.UPLOADED_PICTURE_FOLDER), pictureName);
                //file.SaveAs(pathThumbnail);
                using (var image = ImageHelper.GetImage(path))
                {
                    using (var thubnailImage = ImageHelper.ResizeImage(image))
                    {
                        thubnailImage.Save(pathThumbnail);
                    }
                }
                return Json(new { success = true, picture = pictureName }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public ActionResult UploadPrimaryImage()
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var files = Request.Files;
                if (files == null || files.Count == 0 || files[0].ContentLength <= 0)
                    return Json(new { success = false, message = "Please select a file before uploading picture." }, JsonRequestBehavior.AllowGet);

                var file = files[0];
                string fileName = Path.GetFileName(file.FileName);
                if (!MimeMapping.GetMimeMapping(fileName).StartsWith("image/") && MimeMapping.GetMimeMapping(fileName) != "application/octet-stream")
                {
                    return Json(new { success = false, message = "The attached file is not supported." }, JsonRequestBehavior.AllowGet);
                }

                var path = Server.MapPath(ArticleConstants.UPLOADED_PRIMARY_IMAGE_FOLDER);
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                fileName = $"{ DateTime.Now.ToString("yyyyMMddHHmmss")}_{fileName.Replace(" ", "-")}";
                path = Path.Combine(path, fileName);
                file.SaveAs(path);
                var pictureName = $"{CNSConstant.THUMBNAIL_NAME}_{ImageHelper.GetJpecFileName(fileName)}";
                string pathThumbnail = Path.Combine(Server.MapPath(ArticleConstants.UPLOADED_PRIMARY_IMAGE_FOLDER), pictureName);
                //file.SaveAs(pathThumbnail);
                using (var image = ImageHelper.GetImage(path))
                {
                    using (var thubnailImage = ImageHelper.FixedSize(image, 720, 0))
                    {
                        thubnailImage.Save(pathThumbnail);
                    }
                }
                var result = primaryImageApp.Save(new PrimaryImage
                {
                    Name = pictureName,
                    CreatedDate = DateTime.Now,
                    CreatedUserId = CurrentUser.Id
                });
                return Json(new { success = true, item = result }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize(Roles = "Administrator")]
        public ActionResult DeleteAttachment(long id, string attachment)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                articleApp.DeleteAttachment(id, CurrentUser.Id);
                if (!string.IsNullOrWhiteSpace(attachment))
                {
                    var item = Newtonsoft.Json.JsonConvert.DeserializeObject<ArticleAttachment>(attachment);
                    ImageHelper.DeletePicture(item.Name, Server.MapPath(ArticleConstants.UPLOADED_ATTACHMENT_FOLDER), Server.MapPath(ArticleConstants.DELETED_PICTURE_FOLDER), CNSConstant.THUMBNAIL_NAME);
                }
                return Json(new { success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public ActionResult UploadAttachment(long id = 0)
        {
            try
            {
                var files = Request.Files;
                if (files == null || files.Count == 0 || files[0].ContentLength <= 0)
                    return Json(new { success = false, message = "Please select a file before uploading picture." }, JsonRequestBehavior.AllowGet);

                var file = files[0];
                var attachmentName = Path.GetFileName(file.FileName);

                var path = Server.MapPath(ArticleConstants.UPLOADED_ATTACHMENT_FOLDER);
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                var name = $"{Path.GetFileNameWithoutExtension(attachmentName.Replace(" ", "-"))}_{ DateTime.Now.ToString("yyyyMMddHHmmss")}{Path.GetExtension(attachmentName)}";
                path = Path.Combine(path, name);
                file.SaveAs(path);
                var attachment = new { Name = name, OriginalName = attachmentName, OriginalFile = file.FileName };
                //var result = primaryImageApp.Save(new PrimaryImage
                //{
                //    Name = pictureName,
                //    CreatedDate = DateTime.Now,
                //    CreatedUserId = CurrentUser.Id
                //});
                return Json(new { success = true, attachment }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize(Roles = "Administrator")]
        public ActionResult UploadAttachmentLink(string link, long id = 0)
        {
            try
            {
                var path = Server.MapPath(ArticleConstants.UPLOADED_ATTACHMENT_FOLDER);
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                var attachment = AttachmentHelper.UploadAttachmentLink(link, path);
                //var attachment = new { Name = attachmentName, OriginalName = Path.GetFileName(link), OriginalFile = link };

                return Json(new { success = true, attachment }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize(Roles = "Administrator")]
        public ActionResult DeletePicture(long id, string pictureName)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var item = articleApp.FindBy(id);
                if (item != null && item.Id > 0)
                {
                    item.Picture = string.Empty;
                    item.UpdatedDate = DateTime.Now;
                    item.UpdatedUserId = CurrentUser.Id; // will put it later
                    articleApp.UpdatePictureArticle(item);
                }
                ImageHelper.DeletePicture(pictureName, Server.MapPath(ArticleConstants.UPLOADED_PICTURE_FOLDER), Server.MapPath(ArticleConstants.DELETED_PICTURE_FOLDER), CNSConstant.THUMBNAIL_NAME);
                return Json(new { success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize()]
        public ActionResult PostEmailTemplate(string ids, bool isCurrentUser = false, string brokerMessage = "", bool isSelectedCompanyImage = true, string primaryImageName = "", long userId = 0)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var idList = ids.Split(',').Select(id => long.Parse(id)).ToArray();
                //var clientId = isCurrentUser ? mailTrackingApp.GetClientIdByUserId(CurrentUser.Id) : ConfigManager.ClientTestId;
                var currentUserId = userId > 0 ? userId : CurrentUser.Id;
                //var clientId = isCurrentUser ? mailTrackingApp.GetClientIdByUserId(currentUserId) : ConfigManager.ClientTestId;
                var clientId = mailTrackingApp.GetClientIdByUserId(currentUserId);

                var emailTemplate = mailTrackingApp.GetEmailTemplateBody(new EmailTemplateBodyRequest
                {
                    ArticleIds = idList,
                    SenderId = currentUserId,
                    ClientId = clientId,
                    UserId = currentUserId,
                    Url = GetUrl(),
                    brokerMessage = brokerMessage,
                    isUsedBrokerMessage = isCurrentUser,
                    IsSelectedCompanyImage = isSelectedCompanyImage,
                    PrimaryImageName = primaryImageName
                });

                // GetBodyTemplate(idList)
                return Json(new
                {
                    success = true,
                    emailTemplate,
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize()]
        public ActionResult PostEmailData(string ids, bool isCurrentUser = true)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var idList = ids.Split(',').Select(id => long.Parse(id)).ToArray();
                //var clientId = isCurrentUser ? mailTrackingApp.GetClientIdByUserId(CurrentUser.Id) : ConfigManager.ClientTestId;
                var currentUserId = CurrentUser.Id;
                var clientId = isCurrentUser ? mailTrackingApp.GetClientIdByUserId(currentUserId) : ConfigManager.ClientTestId;

                var users = userApp.GetAll().Where(x => x.IsActive && x.EmailSubscribe == true && !string.IsNullOrWhiteSpace(x.Logo) && x.SendSampleEmailType == null).ToList();
                var user = users.FirstOrDefault(x => x.Id == currentUserId);
                var emailTemplate = mailTrackingApp.GetEmailTemplateBody(new EmailTemplateBodyRequest
                {
                    ArticleIds = idList,
                    SenderId = currentUserId,
                    UserId = currentUserId,
                    ClientId = clientId,
                    Url = GetUrl(),
                    IsSelectedCompanyImage = true,
                });
                if (user == null)
                {
                    emailTemplate = string.Empty;
                }
                else
                {
                    // Move user to the end
                    if (users.Remove(user))
                    {
                        users.Insert(0, user);
                    }
                }
                // GetBodyTemplate(idList)
                return Json(new
                {
                    success = true,
                    emailTemplate,
                    primaryImages = primaryImageApp.GetList(),
                    users = users.Select(x => new
                    {
                        x.Id,
                        x.Logo,
                        x.LogoPositionTypeName,
                        x.CompanyImage,
                        PrimaryColor = x.PrimaryColor ?? CNSConstant.DEFAULT_BROKER_COLOR,
                        SecondaryColor = x.SecondaryColor ?? CNSConstant.DEFAULT_BROKER_COLOR2,
                        x.GooglePlusLink,
                        x.FacebookLink,
                        x.LinkedinLink,
                        x.TwitterLink,
                        x.WebsiteLink,
                        x.Address,
                        x.ABN,
                        LeftFooter = CommonHelper.GetUserLeftFooterValue(x.Phone, x.Company)
                    }).ToList()
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize(Roles = "Administrator")]
        public ActionResult DeletePrimaryImage(long id)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var userId = CurrentUser.Id; // Will put it later
                primaryImageApp.Delete(id, userId);
                return Json(new { success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public ActionResult SendTest(SendTestRequest request) //long[] ids, DateTime sentDate)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                //var subject = GetSubjectTemplate(ids);
                //var emailTemplate = GetBodyTemplate(ids);
                //var userId = ConfigManager.SystemUserId;
                var userId = CurrentUser.Id;
                request.ScheduledTime = DateTime.Now;
                request.ClientId = ConfigManager.ClientTestId;
                request.SenderId = userId;
                request.Url = GetUrl();
                request.TypeId = EnumEmailType.Article;
                mailTrackingApp.SendTest(request);
                //    new SendTestRequest
                //{
                //    ClientId = ConfigManager.ClientTestId,// CommonHelper.GetLong(ConfigurationManager.AppSettings["ClientTestId"]),
                //    SenderId = userId,
                //    ArticleIds = ids,
                //    Url = GetUrl(),
                //    //Subject = subject,
                //    //Content = emailTemplate,
                //    ScheduledTime = DateTime.Now,
                //    TypeId = EnumEmailType.Article,
                //});
                return Json(new { success = true, message = "The email is added to system sending schedule successfully." }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public ActionResult SendToAll(SendToAllRequest request) //long[] ids, DateTime sentDate, int[] userTypeIds, int[] clientTypeIds)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                //var subject = GetSubjectTemplate(ids);
                //var emailTemplate = GetBodyTemplate(ids);
                //var userId = ConfigManager.SystemUserId;
                var userId = CurrentUser.Id;
                request.SenderId = userId;
                request.Url = GetUrl();
                request.TypeId = EnumEmailType.Article;

                mailTrackingApp.SendToAll(request);
                //    new SendToAllRequest
                //{
                //    UserTypeIds = userTypeIds,
                //    ClientTypeIds = clientTypeIds,
                //    ArticleIds = ids,
                //    ScheduledTime = sentDate,
                //    CreatedUserId = CurrentUser.Id,
                //    SenderId = userId,
                //    Url = GetUrl(),
                //    //Subject = subject,
                //    //Content = emailTemplate,
                //    TypeId = EnumEmailType.Article
                //});
                return Json(new { success = true, message = "The email is added to system sending schedule successfully." }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public ActionResult SendToOne(SendToOneRequest request)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                //var subject = GetSubjectTemplate(ids);
                //var emailTemplate = GetBodyTemplate(ids);
                //var userId = ConfigManager.SystemUserId;
                var userId = CurrentUser.Id;
                request.SenderId = userId;
                //request.CreatedUserId = userId;
                request.Url = GetUrl();
                request.TypeId = EnumEmailType.Article;
                request.ScheduledTime = DateTime.Now;
                mailTrackingApp.SendToOne(request);
                //new SendToAllRequest
                //{
                //    CreatedUserId = CurrentUser.Id,
                //    SenderId = userId,
                //    ArticleIds = ids,
                //    Url = GetUrl(),
                //    //Subject = subject,
                //    //Content = emailTemplate,
                //    ScheduledTime = sentDate,
                //    TypeId = EnumEmailType.Article
                //});
                return Json(new { success = true, message = "The email is added to system sending schedule successfully." }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        [Authorize()]
        public ActionResult NewsLetterEmail(string NewsLetterEmailId = null, string UserMailId = null)
        {
            //var encrypt = Encryption.Base64EncodeUrl("2");
            var id = CommonHelper.GetLong(Encryption.Base64DecodeUrl(NewsLetterEmailId));

            var userMailId = CommonHelper.GetLong(Encryption.Base64DecodeUrl(UserMailId));
            //var id = CommonHelper.GetLong(Encryption.Base64DecodeUrl(encrypt));
            ViewBag.NewsLetterEmailId = id;

            var data = articleApp.GetNewsLetterEmails(id, CurrentUser.Id);
            ViewBag.Articles = data.Articles;
            ViewBag.ErrorMessage = string.Empty;
            if (data.Articles.Count == 0)
            {
                ViewBag.ErrorMessage = "You're not authorized to make changes on the newsletter";
            }
            ViewBag.PrimaryImageName = data.Item.PrimaryImageName;
            ViewBag.IsSelectedCompanyImage = data.Item.IsSelectedCompanyImage == true ? "true" : "false";

            ViewBag.BrokerMessage = userApp.FindByUserId(CurrentUser.Id).BrokerMessage;

            userMailTrackingApp.ClickUserMail(userMailId);
            return View();
        }

        [HttpPost]
        [Authorize()]
        public ActionResult NewsLetterEmail(NewsLetterEmailRequest request)
        {
            try
            {
                //model.DoNotSend = Request["DoNotSend"];
                var user = userApp.FindByUserId(CurrentUser.Id);
                var brokerMessage = user.BrokerMessage;
                var isChanged = false;
                if (!(brokerMessage == request.BrokerMessage || (string.IsNullOrWhiteSpace(brokerMessage) && string.IsNullOrWhiteSpace(request.BrokerMessage))))
                {
                    isChanged = true;
                    user.BrokerMessage = request.BrokerMessage;
                    userApp.CreateAndUpdate(user, CurrentUser.Id, isUpdatedBrokerMessage: true);
                }

                if (articleApp.SaveNewsLetterEmail(request, CurrentUser.Id) || isChanged)
                {
                    request.Url = GetUrl();
                    mailTrackingApp.UpdateClientEmailContent(request);
                }
                return Json(new { success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    error = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        [Authorize()]
        public ActionResult Broker()
        {
            var article = articleApp.FindByBrokerId(CurrentUser.Id);
            return View(article);
        }

        [Authorize()]
        public ActionResult GetBrokers(string term, bool includeClients = false)
        {
            try
            {
                //model.DoNotSend = Request["DoNotSend"];
                var data = userApp.GetUserList(term, includeClients);
                return Json(new { success = true, data }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    error = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }


        [Authorize()]
        public ActionResult GetClients(string term)
        {
            try
            {
                //model.DoNotSend = Request["DoNotSend"];
                var data = clientApp.GetClientList(term);
                return Json(new { success = true, data }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    error = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Authorize()]
        public ActionResult Broker(ArticleViewModel model)
        {
            try
            {
                var oldArticle = articleApp.GetArticleByBrokerId(CurrentUser.Id);

                if (model.Id > 0 && (oldArticle.IsDeclined == true || oldArticle.Status >= (int)EnumArticleStatusType.Reviewing || (oldArticle.Id <= 0 && model.Id != oldArticle.Id)))
                {
                    return Json(new
                    {
                        success = false,
                        error = "The article is not available to edit. Please try again after the page is refreshed. Thank you!"
                    }, JsonRequestBehavior.AllowGet);
                }

                if (model.Id <= 0)
                {
                    model.Id = oldArticle.Id;
                }

                //model.DoNotSend = Request["DoNotSend"];
                model.UpdatedDate = DateTime.Now;
                model.UpdatedUserId = CurrentUser.Id; // will put it later
                model.Link = Helpers.UrlHelper.StandardizeUrl(model.Link);

                var user = userApp.FindByUserId(CurrentUser.Id);
                if (user.BrokerMessage != model.BrokerMessage && (!string.IsNullOrWhiteSpace(user.BrokerMessage) || !string.IsNullOrWhiteSpace(model.BrokerMessage)))
                {
                    user.BrokerMessage = model.BrokerMessage;
                    userApp.CreateAndUpdate(user, CurrentUser.Id, isUpdatedBrokerMessage: true);
                }

                if (string.IsNullOrWhiteSpace(model.Link))
                {
                    articleApp.Delete(model.Id, CurrentUser.Id);
                    return Json(new { success = true }, JsonRequestBehavior.AllowGet);
                }

                model.TagIds = new System.Collections.Generic.List<int>();
                model.TagIds.Add(TagConstants.NO_TAG);

                if (model.Id > 0)
                {
                    var article = articleApp.FindBy(model.Id);
                    if (article.Link != model.Link)
                    {
                        GetDataFromLink(model.Id, model.Link, false, model);
                        articleApp.Update(model);
                    }
                }
                else
                {
                    model.CreatedDate = DateTime.Now;
                    model.CreatedUserId = CurrentUser.Id; // will put it later
                    GetDataFromLink(model.Id, model.Link, false, model);
                    model.HistoryNote = $"Make one up including the {model.Link}";
                    logger.Info(string.Format("Broker: {0}", Newtonsoft.Json.JsonConvert.SerializeObject(model)));
                    model.Id = articleApp.Create(model);
                }

                return Json(new { success = true, id = model.Id }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    error = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize()]
        public ActionResult DeleteBroker(long id)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var userId = CurrentUser.Id; // Will put it later
                articleApp.Delete(id, userId);

                var user = userApp.FindByUserId(CurrentUser.Id);
                if (!string.IsNullOrWhiteSpace(user.BrokerMessage))
                {
                    user.BrokerMessage = string.Empty;
                    userApp.CreateAndUpdate(user, CurrentUser.Id);
                }

                return Json(new { success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize(Roles = "Administrator")]
        public ActionResult ArticleSentHistories(long id)
        {
            try
            {
                return Json(new
                {
                    success = true,
                    histories = articleApp.GetArticleSentHistories(id)
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize(Roles = "Administrator")]
        public ActionResult GetAuthorFromLastArticle()
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var author = articleApp.GetAuthorFromLastArticle();
                return Json(new { success = true, author }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize(Roles = "Administrator")]
        public ActionResult GetSiteNameFromLastArticle()
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var siteName = articleApp.GetSiteNameFromLastArticle();
                return Json(new { success = true, siteName }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize(Roles = "Administrator")]
        public ActionResult GetSpellfixDictionaries()
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var data = spellfixDictionaryApp.GetList();
                return Json(new { success = true, data }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public ActionResult CreateSpellfixDictionary(SpellfixDictionaryViewModel model)
        {
            try
            {
                model.UpdatedDate = DateTime.Now;
                model.UpdatedUserId = CurrentUser.Id;
                if (model.Id > 0)
                {
                    spellfixDictionaryApp.Update(model);
                }
                else
                {
                    model.CreatedDate = DateTime.Now;
                    model.CreatedUserId = CurrentUser.Id;
                    model.Id = spellfixDictionaryApp.Create(model);
                }
                return Json(new { success = true, id = model.Id }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    error = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize(Roles = "Administrator")]
        public ActionResult DeleteSpellfixDictionary(long id)
        {
            try
            {
                spellfixDictionaryApp.Delete(id, CurrentUser.Id);
                return Json(new { success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    error = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }


        [Authorize(Roles = "Administrator")]
        public ActionResult GetTitle(string title)
        {
            try
            {
                title = spellfixDictionaryApp.GetProperTextTitle(title);
                return Json(new { success = true, title }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    error = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize(Roles = "Administrator")]
        public ActionResult UpdateOrderByDate(long id, int changeOrder)
        {
            try
            {
                var changedItemCount = articleApp.UpdateOrderByDate(id, changeOrder, CurrentUser.Id);
                return Json(new { success = true, changedItemCount }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    error = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }


        #region Private method
        private string GetTitle(string title, string sitename)
        {
            // Remove site name with special characters before and after it
            if (!string.IsNullOrWhiteSpace(title) &&
                (title.ToLower().StartsWith(sitename.ToLower() + " ") ||
                title.ToLower().EndsWith(" " + sitename.ToLower())))
            {
                if (title.ToLower().StartsWith(sitename.ToLower()))
                {
                    var charList = new List<char>(new char[] { '\'', '"', '`', '‘', '’', '“', '”' });
                    for (int i = sitename.Length + 1; i < title.Length; i++)
                    {
                        if (char.IsLetterOrDigit(title[i]) || charList.Contains(title[i]))
                        {
                            title = title.Substring(i).Trim();
                            break;
                        }
                    }
                }
                if (title.ToLower().EndsWith(sitename.ToLower()))
                {
                    var charList = new List<char>(new char[] { '\'', '"', '`', '‘', '’', '“', '”', '!', '?', '.' });
                    for (int i = title.Length - 1 - sitename.Length; i > 0; i--)
                    {
                        if (char.IsLetterOrDigit(title[i]) || charList.Contains(title[i]))
                        {
                            title = title.Substring(0, i + 1).Trim();
                            break;
                        }
                    }
                }
            }
            return title;
        }

        private string GetPicture(string picture, string link)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(picture))
                {
                    if (picture.StartsWith("//", StringComparison.OrdinalIgnoreCase))
                    {
                        picture = $"http:{picture}";
                    }
                    else if (!picture.StartsWith("http", StringComparison.OrdinalIgnoreCase) &&
                   !picture.StartsWith("ftp", StringComparison.OrdinalIgnoreCase))
                    {
                        var url = new Uri(link);
                        picture = picture.StartsWith("/") ? $"{url.Scheme}://{url.Host}{picture}" : $"{url.Scheme}://{url.Host}/{picture}";
                    }

                    var path = Server.MapPath(ArticleConstants.UPLOADED_PICTURE_FOLDER);
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    var fileName = $"{ DateTime.Now.ToString("yyyyMMddHHmmss")}_PictureFromLink.jpg";
                    path = Path.Combine(path, fileName);

                    using (var client = new WebClientEx())
                    {
                        //System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls | System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                        using (var pictureStream = new MemoryStream(client.DownloadData(picture)))
                        {
                            ImageHelper.ConvertImage(pictureStream, ImageFormat.Jpeg, path);
                            //webClient.DownloadFile(picture, path);
                            var pictureName = $"{CNSConstant.THUMBNAIL_NAME}_{fileName}";
                            string pathThumbnail = Path.Combine(Server.MapPath(ArticleConstants.UPLOADED_PICTURE_FOLDER), pictureName);
                            //file.SaveAs(pathThumbnail);
                            using (var image = ImageHelper.GetImage(path))
                            {
                                using (var thubnailImage = ImageHelper.ResizeImage(image))
                                {
                                    thubnailImage.Save(pathThumbnail);
                                }
                            }
                            picture = pictureName;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                picture = GetPicture2(picture, link);
            }
            return picture;
        }

        private string GetPicture2(string picture, string link)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(picture))
                {
                    if (picture.StartsWith("//", StringComparison.OrdinalIgnoreCase))
                    {
                        picture = $"http:{picture}";
                    }
                    else if (!picture.StartsWith("http", StringComparison.OrdinalIgnoreCase) &&
                   !picture.StartsWith("ftp", StringComparison.OrdinalIgnoreCase))
                    {
                        var url = new Uri(link);
                        picture = picture.StartsWith("/") ? $"{url.Scheme}://{url.Host}{picture}" : $"{url.Scheme}://{url.Host}/{picture}";
                    }

                    var path = Server.MapPath(ArticleConstants.UPLOADED_PICTURE_FOLDER);
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    var fileName = $"{ DateTime.Now.ToString("yyyyMMddHHmmss")}_PictureFromLink.jpg";
                    path = Path.Combine(path, fileName);

                    using (var client = new WebClient())
                    {
                        //System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls | System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                        using (var pictureStream = new MemoryStream(client.DownloadData(picture)))
                        {
                            ImageHelper.ConvertImage(pictureStream, ImageFormat.Jpeg, path);
                            //webClient.DownloadFile(picture, path);
                            var pictureName = $"{CNSConstant.THUMBNAIL_NAME}_{fileName}";
                            string pathThumbnail = Path.Combine(Server.MapPath(ArticleConstants.UPLOADED_PICTURE_FOLDER), pictureName);
                            //file.SaveAs(pathThumbnail);
                            using (var image = ImageHelper.GetImage(path))
                            {
                                using (var thubnailImage = ImageHelper.ResizeImage(image))
                                {
                                    thubnailImage.Save(pathThumbnail);
                                }
                            }
                            picture = pictureName;

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                picture = string.Empty;
            }
            return picture;
        }
        //private string GetBodyTemplate(long[] ids)
        //{
        //    var list = articleApp.FindBy(ids);
        //    var sbEmailTemplate = new StringBuilder();
        //    var articleTemplate = System.IO.File.ReadAllText(Server.MapPath(ArticleConstants.ARTICLE_TEMPLATE_FILE));
        //    var articleDetailTemplate = System.IO.File.ReadAllText(Server.MapPath(ArticleConstants.ARTICLE_DETAIL_TEMPLATE_FILE));
        //    var imageTagTemplate = System.IO.File.ReadAllText(Server.MapPath(ArticleConstants.IMAGE_TAG_TEMPLATE_FILE));
        //    var lineTagTemplate = System.IO.File.ReadAllText(Server.MapPath(ArticleConstants.LINE_TAG_TEMPLATE_FILE));
        //    var index = 0;
        //    var url = Request.Url.OriginalString.Substring(0, Request.Url.OriginalString.IndexOf(Request.Url.LocalPath));
        //    var actionController = "/EmailLink";
        //    foreach (var id in ids)
        //    {
        //        var item = list.FirstOrDefault(x => x.Id == id);
        //        if (item == null) continue;

        //        var imageTag = string.IsNullOrWhiteSpace(item.Picture) ? string.Empty :
        //           imageTagTemplate.Replace("{Picture}", ImageHelper.GetFullUrl(url, ArticleConstants.UPLOADED_PICTURE_FOLDER.Substring(1), item.Picture));
        //        index++;

        //        var lineTag = string.Empty;
        //        if (index < list.Count)
        //        {
        //            lineTag = lineTagTemplate.Replace("{SecondColor}", "red");
        //        }

        //        sbEmailTemplate.AppendLine().AppendLine();
        //        sbEmailTemplate.AppendLine(articleDetailTemplate
        //            .Replace("{Link}", ImageHelper.GetFullUrl(url, actionController, item.LinkId.ToString()))
        //            .Replace("{Title}", item.Title).Replace("{Author}", item.Author)
        //            .Replace("{ArticleDateDisplay}", item.ArticleDateDisplay).Replace("{ImageTag}", imageTag).Replace("{Summary}", item.Summary).Replace("{LineTag}", lineTag));
        //    }
        //    foreach (var item in list)
        //    {
        //    }
        //    return articleTemplate.Replace("{PrimaryColor}", "blue").Replace("{ArticleDetail}", sbEmailTemplate.ToString());
        //}

        //private string GetSubjectTemplate(long[] ids)
        //{
        //    var item = articleApp.FindBy(ids[0]);
        //    return item?.Subject;
        //}
        #endregion
    }
}
