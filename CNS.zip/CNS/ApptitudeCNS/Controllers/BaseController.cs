﻿using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Helpers;
using System.IO;
using System.Linq;
using System.Web.Mvc;

namespace ApptitudeCNS.Controllers
{
    public class BaseController : Controller
    {
        public UserWithRoleViewModel CurrentUser
        {
            get
            {
                var tempt = Session["CurrentUser"];                
                if (tempt == null)
                {
                    tempt = Infrastructure.IoC.EngineContext
                        .Current.Resolve<Application.Users.IUserApp>()
                        .FindUserWithRoleByEmail(User.Identity.Name);
                }
                return tempt as UserWithRoleViewModel;
            }
            set
            {
                Session["CurrentUser"] = value;
            }
        }

        public bool IsAdmin
        {
            get
            {
                if(CurrentUser != null && CurrentUser.Roles.Count > 0)
                {
                    return CurrentUser.Roles.Any(r => r.RoleName == CNSConstant.Administrator);
                }
                return false;
            }
        }

        public string GetUrl()
        {
            return Request.Url.OriginalString.Substring(0, Request.Url.OriginalString.IndexOf(Request.Url.LocalPath));
        }

    }

    public static class RazorViewToString
    {
        public static string RenderRazorViewToString(this Controller controller, string viewName, object model)
        {
            controller.ViewData.Model = model;
            using (var sw = new StringWriter())
            {
                var viewResult = ViewEngines.Engines.FindPartialView(controller.ControllerContext, viewName);
                var viewContext = new ViewContext(controller.ControllerContext, viewResult.View, controller.ViewData, controller.TempData, sw);
                viewResult.View.Render(viewContext, sw);
                viewResult.ViewEngine.ReleaseView(controller.ControllerContext, viewResult.View);
                return sw.GetStringBuilder().ToString();
            }
        }
    }

}