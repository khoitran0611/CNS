﻿using ApptitudeCNS.Application.MailTrackings;
using System.Web.Mvc;
using System.Linq;
using System;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Application.UserMailTrackings;

namespace ApptitudeCNS.Controllers
{
    [Authorize(Roles = "Administrator")]
    public class MailTrackingController : BaseController
    {

        private IMailTrackingApp mailTrackingApp { get; set; }
        private IUserMailTrackingApp userMailTrackingApp { get; set; }

        public MailTrackingController(IMailTrackingApp _mailTrackingApp, IUserMailTrackingApp _userMailTrackingApp)
        {
            mailTrackingApp = _mailTrackingApp;
            userMailTrackingApp = _userMailTrackingApp;
        }

        // GET: Article
        public ActionResult Index()
        {
            //var searchText = Request["searchText"];
            //var articleList = articleApp.GetArticleList(searchText);
            ViewBag.Types = CommonHelper.GetListForEnum<EnumEmailType>();// mailTrackingApp.GetMailTypes();

            //return View(articleList);
            return View();
        }

        public ActionResult Post(MailTrackingFilterViewModel filter = null)//(int pageIndex, string typeIds, string searchText, string sortByName)
        {
            try
            {   
                //var searchText = Request["searchText"];
                //var typeIdList = typeIds == string.Empty ? null : typeIds.Split(',').Select(x => int.Parse(x)).ToList();
                if (filter.recipientId == 2)
                {
                    var count = mailTrackingApp.GetCount(filter);
                    var mailTrackingList = mailTrackingApp.GetMailTrackingList(filter);
                    return Json(new { success = true, data = mailTrackingList, count, pageSize = MailTrackingConstants.PAGE_SIZE }, JsonRequestBehavior.AllowGet);
                }
                var userCount = userMailTrackingApp.GetCount(filter);
                var userMailTrackingList = userMailTrackingApp.GetMailTrackingList(filter);
                return Json(new { success = true, data = userMailTrackingList, count = userCount, pageSize = MailTrackingConstants.PAGE_SIZE }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult GetEmailContent(long id)
        {
            try
            {
                return Json(new { success = true, data = mailTrackingApp.GetEmailContent(id) }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult GetUserEmailContent(long id)
        {
            try
            {
                return Json(new { success = true, data = userMailTrackingApp.GetEmailContent(id) }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }


    }
}