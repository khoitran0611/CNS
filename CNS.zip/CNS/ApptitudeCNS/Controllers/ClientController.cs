﻿using ApptitudeCNS.Application.ClientHistories;
using ApptitudeCNS.Application.Clients;
using ApptitudeCNS.Application.MailTrackings;
using ApptitudeCNS.Application.Users;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace ApptitudeCNS.Controllers
{
    [Authorize]
    public class ClientController : BaseController
    {
        private IClientApp clientApp { get; set; }
        private IUserApp userApp { get; set; }
        private IMailTrackingApp mailTrackingApp { get; set; }
        private IClientHistoryApp clientHistoryApp { get; set; }

        public ClientController(IClientApp _clientApp, IMailTrackingApp _mailTrackingApp, IUserApp _userApp, IClientHistoryApp _clientHistoryApp)
        {
            clientApp = _clientApp;
            mailTrackingApp = _mailTrackingApp;
            userApp = _userApp;
            clientHistoryApp = _clientHistoryApp;
        }

        [HttpGet]
        public ActionResult Index(long? id = null)
        {
            long numOfItem = 0;
            //id > 0 ? id : 
            var filter = new ClientFilterViewModel
            {
                EmailSubscribes = new long[1] { 1 }
            };
            var clients = clientApp.FindByUserId(id > 0 ? id : IsAdmin ? (long?)null : CurrentUser.Id, 1, CNSConstant.PAGE_SIZE, "CreatedDate", true, filter, ref numOfItem);
            ViewBag.OrderBy = EnumOrderBy.desc.ToString();
            ViewBag.IsAdmin = IsAdmin;
            ViewBag.UserId = id;
            if (IsAdmin)
            {
                var users = userApp.GetAll().Select(u => new SelectListItem { Value = u.Id.ToString(), Text = $"[{u.Id}] {u.Fullname}" }).ToList(); ;
                users.Insert(0, new SelectListItem { Value = "0", Text = "All" });
                ViewBag.Users = users;
            }
            ViewBag.IsShowClientOwner = IsAdmin;
            ViewBag.TotalItem = numOfItem;
            ViewBag.PageSize = CNSConstant.PAGE_SIZE;
            ViewBag.EmailIcons = CommonHelper.GetIconList();
            ViewBag.EmailStatuses = CommonHelper.GetClientMailStatusList(false, new List<int>());

            return View(clients);
        }

        [HttpPost]
        public ActionResult GetClients(int pageIndex = 1, string sortFieldName = "", string orderBy = "", ClientFilterViewModel filter = null)
        {
            try
            {
                long numOfItem = 0;
                sortFieldName = string.IsNullOrEmpty(sortFieldName) ? "CreatedDate" : sortFieldName;
                orderBy = string.IsNullOrWhiteSpace(orderBy) ? EnumOrderBy.desc.ToString() : orderBy;
                var clients = clientApp.FindByUserId(IsAdmin ? (filter != null && filter.UserId.HasValue && filter.UserId > 0 ? filter.UserId : (long?)null) : CurrentUser.Id,
                    pageIndex,
                    CNSConstant.PAGE_SIZE,
                    sortFieldName, orderBy == EnumOrderBy.desc.ToString(),
                    filter,
                    ref numOfItem);
                ViewBag.OrderBy = orderBy;
                ViewBag.IsShowClientOwner = IsAdmin;
                ViewBag.EmailIcons = CommonHelper.GetIconList();
                return Json(new
                {
                    Status = true,
                    Html = RazorViewToString.RenderRazorViewToString(this, "_ClientList", clients),
                    TotalItem = numOfItem,
                    PageSize = CNSConstant.PAGE_SIZE
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    Status = false,
                    Message = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public ActionResult GetClients(long userId)
        {
            long numOfItem = 0;
            var sortFieldName = "CreatedDate";
            var clients = clientApp.FindByUserId(userId, 1, 1000, sortFieldName, false, null, ref numOfItem);
            ViewBag.OrderBy = EnumOrderBy.asc.ToString();
            ViewBag.TotalItem = numOfItem;
            ViewBag.IsShowClientOwner = IsAdmin;
            ViewBag.EmailIcons = CommonHelper.GetIconList();
            return PartialView("_ClientList", clients);
        }

        [HttpPost]
        public ActionResult SendMassEmail(string subject, string content, long[] clientIds, bool isNow, DateTime scheduleDate)
        {
            try
            {
                mailTrackingApp.SendMassEmail(CurrentUser.Id, subject, content, clientIds, isNow ? DateTime.Now : scheduleDate);
                return Json(new
                {
                    success = true
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    errors = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult Delete(int id)
        {
            try
            {
                clientApp.Delete(id);
                return Json(new
                {
                    Status = true
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    Status = false,
                    Message = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult UpdateEmailAndSmsSubscribe(long clientId, bool? sms, int email = 1)
        {
            try
            {
                clientApp.UpdateEmailAndSmsSubscribe(clientId, email, sms);
                return Json(new
                {
                    success = true
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    Message = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public ActionResult Detail(long id)
        {
            var client = clientApp.FindById(id);
            ViewBag.EmailStatuses = GetClientMailStatusList(client, CurrentUser);
            ViewBag.EmailStatusBreakLine = 4;
            ViewBag.ClientHistories = clientHistoryApp.FindByClientId(id);
            return View("Detail", client);
        }

        [HttpGet]
        public ActionResult ClientDetail(int? clientId)
        {
            ViewBag.Title = "Create Client";
            ClientViewModel model = new ClientViewModel() { UserId = CurrentUser.Id };
            if (clientId.HasValue && clientId.Value > 0)
            {
                model = clientApp.FindById(clientId.Value);
            }
            ViewBag.EmailStatuses = GetClientMailStatusList(model, CurrentUser);
            ViewBag.EmailStatusBreakLine = 6;
            //ViewBag.RecipientTypes = clientApp.GetRecipientTypes();
            return PartialView("_Client", model);
        }

        [HttpPost]
        public ActionResult ClientDetail(ClientViewModel model)//, string RecipientTypes)
        {
            try
            {
                //ModelState.Remove("RecipientTypes");
                if (!ModelState.IsValid)
                {
                    return Json(new { success = false, errors = ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage).ToList() }, JsonRequestBehavior.AllowGet);
                }

                //var client = clientApp.FindByUserId(model.UserId).Where(c => c.Email.Trim().ToLower() == model.Email.Trim().ToLower()).FirstOrDefault();
                //if (client != null && (model.Id == 0 || model.Id != client.Id))
                if (clientApp.CheckExistEmail(model.UserId, model.Id, model.Email))
                {
                    return Json(new { success = false, errors = new List<string>() { "Email already exists. Please choose a different email." } }, JsonRequestBehavior.AllowGet);
                }

                //if (!string.IsNullOrEmpty(RecipientTypes))
                //{
                //    model.RecipientTypes = RecipientTypes.Split(new string[] { "," }, StringSplitOptions.None).Where(r => !string.IsNullOrEmpty(r)).Select(r => int.Parse(r)).ToList();
                //}
                clientApp.CreateAndUpdate(model);


                return Json(new
                {
                    success = true
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    Message = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public ActionResult ClientHistory(long clientId, long? clientHistoryId = null)
        {

            try
            {
                ClientHistoryViewModel client = null;
                if (clientHistoryId.HasValue)
                {
                    client = clientHistoryApp.FindById(clientHistoryId.Value);
                }
                else
                {
                    client = new ClientHistoryViewModel() { CreatedUserId = CurrentUser.Id, ClientId = clientId, Pinned = false, CreatedDate = DateTime.Now, TypeId = 0, IsSystemAutogen = false };
                }
                return Json(new
                {
                    success = true,
                    Html = RazorViewToString.RenderRazorViewToString(this, "_ClientHistory", client)
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    errors = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult ClientHistory(ClientHistoryViewModel model)
        {
            try
            {
                var history = clientHistoryApp.CreateAndUpdate(model);
                return Json(new
                {
                    success = true,
                    clientId = history.ClientId
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    errors = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult GetClientHistories(long clientId)
        {
            try
            {
                var clientHistories = clientHistoryApp.FindByClientId(clientId);
                return Json(new
                {
                    success = true,
                    Html = RazorViewToString.RenderRazorViewToString(this, "_ClientHistories", clientHistories)
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    errors = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult DeleteHistories(long clientHistoryId)
        {
            try
            {
                clientHistoryApp.Delete(clientHistoryId);
                return Json(new
                {
                    success = true
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    errors = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult SetClientHistoryPinned(long clientHistoryId, bool pinned)
        {
            try
            {
                clientHistoryApp.SetPinned(clientHistoryId, pinned);
                return Json(new
                {
                    success = true
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    errors = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult GetCurrentUser()
        {
            return Json(new
            {
                success = true,
                user = userApp.FindByUserId(CurrentUser.Id)
            }, JsonRequestBehavior.AllowGet);
        }

        #region Private Methods
        private static List<ClientMailStatus> GetClientMailStatusList(ClientViewModel client, UserWithRoleViewModel currentUser)
        {
            if (client != null)
            {
                //ViewBag.RecipientTypes = clientApp.GetRecipientTypes();
                var isDisabled = client.EmailSubscribe == (int)EnumClientEmailStatus.ClientUnsubscribe;
                var disabledList = new List<int>();
                disabledList.Add((int)EnumClientEmailStatus.ClientUnsubscribe);
                disabledList.Add((int)EnumClientEmailStatus.SystemFailure);

                if (!isDisabled)
                {
                    //var currentUser = CurrentUser;
                    if (currentUser.Id != client.UserId)
                    {
                        if (client.EmailSubscribe == (int)EnumClientEmailStatus.BrokerDecided)
                        {
                            isDisabled = true;
                        }
                        disabledList.Add((int)EnumClientEmailStatus.BrokerDecided);
                    }
                    if (currentUser.Roles.Count < 2)
                    {
                        disabledList.Add((int)EnumClientEmailStatus.AdminDecided);
                    }
                }
                return CommonHelper.GetClientMailStatusList(isDisabled, disabledList);
            }
            else
            {
                var isDisabled = false;
                var disabledList = new List<int>();
                disabledList.Add((int)EnumClientEmailStatus.ClientUnsubscribe);
                disabledList.Add((int)EnumClientEmailStatus.SystemFailure);
                return CommonHelper.GetClientMailStatusList(isDisabled, disabledList);
            }
        }

        #endregion
    }
}