﻿using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Application.Users;
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using ApptitudeCNS.Helpers;
using System.IO;
using OfficeOpenXml;
using ApptitudeCNS.Application.Clients;
using System.Linq;
using static ApptitudeCNS.Helpers.CommonHelper;
using ApptitudeCNS.Application.UserMailTrackings;
using ApptitudeCNS.Core.IRepository;
using ApptitudeCNS.Application;
using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.MailTrackings;
using ApptitudeCNS.Application.Articles;
using ApptitudeCNS.Application.PrimaryImages;

namespace ApptitudeCNS.Controllers
{
    [Authorize]
    public class UserController : BaseController
    {
        private IUserApp userApp { get; set; }
        private IRoleApp roleApp { get; set; }
        private IClientApp clientApp { get; set; }
        private IUserHistoryApp userHistoryApp { get; set; }
        private IUserMailTrackingApp userMailTrackingApp { get; set; }
        private IMailTrackingApp mailTrackingApp { get; set; }
        private IArticleApp articleApp { get; set; }
        private IPrimaryImageApp primaryImageApp { get; }

        private IBpAggregatorRepository bpAggregatorRepository { get; set; }


        public UserController(IUserApp _userApp, IRoleApp _roleApp, IClientApp _clientApp, IUserHistoryApp _userHistoryApp, IUserMailTrackingApp _userMailTrackingApp, IBpAggregatorRepository _bpAggregatorRepository, IMailTrackingApp _mailTrackingApp, IArticleApp _articleApp, IPrimaryImageApp _primaryImageApp)
        {
            userApp = _userApp;
            roleApp = _roleApp;
            clientApp = _clientApp;
            userHistoryApp = _userHistoryApp;
            userMailTrackingApp = _userMailTrackingApp;
            mailTrackingApp = _mailTrackingApp;
            bpAggregatorRepository = _bpAggregatorRepository;
            articleApp = _articleApp;
            primaryImageApp = _primaryImageApp;
        }
        // GET: User
        [HttpGet]
        [AllowAnonymous]
        public ActionResult Login()
        {
            ViewBag.ReturnUrl = !string.IsNullOrWhiteSpace(Request.QueryString["ReturnUrl"]) ? Request.QueryString["ReturnUrl"] : Request.UrlReferrer?.PathAndQuery ?? "/";
            if (Request.IsAuthenticated)
            {
                if (IsAdmin)
                {
                    return RedirectToAction("Users");
                }
                return RedirectToAction("Index", "Client", new { id = (long?)null });
            }
            return this.View();
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult Login(string Email, string Password, bool RememberMe, string ReturnUrl)
        {
            var returnUrlConst = "returnurl";
            if (string.IsNullOrWhiteSpace(ReturnUrl) && Request.UrlReferrer.Query.ToLower().Contains(returnUrlConst))
            {
                ReturnUrl = HttpUtility.UrlDecode(Request.UrlReferrer.Query.Substring(Request.UrlReferrer.Query.ToLower().IndexOf(returnUrlConst) + returnUrlConst.Length + 1));
            }

            if (userApp.LogIn(Email, Password))
            {
                if (!string.IsNullOrWhiteSpace(ReturnUrl) && ReturnUrl.EndsWith("ChangePassword", StringComparison.OrdinalIgnoreCase))
                {
                    ReturnUrl = "";
                }
                if (RememberMe)
                {
                    FormsAuthentication.SetAuthCookie(Email, true);
                }
                else
                {
                    FormsAuthentication.SetAuthCookie(Email, false);
                }
                //Set current user on session
                CurrentUser = userApp.FindUserWithRoleByEmail(Email);

                if (!string.IsNullOrEmpty(ReturnUrl) && Url.IsLocalUrl(ReturnUrl))
                    return Redirect(ReturnUrl);

                if (IsAdmin)
                {
                    return RedirectToAction("Users");
                }
                return RedirectToAction("Index", "Client", new { id = (long?)null });
            }

            ModelState.AddModelError("", "Invalid user name or password");
            ViewBag.ReturnUrl = ReturnUrl;
            return View();
        }

        public ActionResult LogOff()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login");
        }

        //
        // GET: /Manage/ChangePassword
        public ActionResult ChangePassword()
        {
            return View();
        }

        //
        // POST: /Manage/ChangePassword
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ChangePassword(ChangePasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var result = userApp.ChangePassword(User.Identity.Name, model.OldPassword, model.NewPassword);
            if (result)
            {
                //return RedirectToAction("Login", "User");
                FormsAuthentication.SignOut();
                return RedirectToAction("Login");
            }
            return View(model);
        }

        [HttpGet]
        [Authorize(Roles = "Administrator")]
        public ActionResult Users()
        {
            long numOfItem = 0;
            var users = userApp.GetAllWithRole(1, CNSConstant.PAGE_SIZE, "CreatedDate", true, null, ref numOfItem);
            ViewBag.OrderBy = EnumOrderBy.desc.ToString();
            ViewBag.SendMailBrokerTypes = CommonHelper.GetListForEnum<EnumUserType>();
            var brokerTypes = CommonHelper.GetListForEnum<EnumUserType>().Select(x => new SelectListItem { Text = x.Name, Value = x.Id.ToString() }).ToList();
            brokerTypes.Insert(0, new SelectListItem { Value = "0", Selected = true, Text = "All" });
            ViewBag.BrokerTypes = brokerTypes;
            ViewBag.Roles = roleApp.GetAll().Where(r => r.RoleName != CNSConstant.Broker).ToList();
            ViewBag.TotalItem = numOfItem;
            ViewBag.PageSize = CNSConstant.PAGE_SIZE;
            return View(users);
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public ActionResult GetUsers(int pageIndex = 1, string sortFieldName = "", string orderBy = "", UserFilterViewModel filter = null)
        {
            try
            {

                long numOfItem = 0;
                sortFieldName = string.IsNullOrEmpty(sortFieldName) ? "CreatedDate" : sortFieldName;
                orderBy = string.IsNullOrWhiteSpace(orderBy) ? EnumOrderBy.desc.ToString() : orderBy;
                var users = userApp.GetAllWithRole(pageIndex, CNSConstant.PAGE_SIZE, sortFieldName, orderBy == EnumOrderBy.desc.ToString(), filter, ref numOfItem);
                ViewBag.OrderBy = orderBy;
                ViewBag.Roles = roleApp.GetAll().Where(r => r.RoleName != CNSConstant.Broker).ToList();
                return Json(new
                {
                    Status = true,
                    Html = RazorViewToString.RenderRazorViewToString(this, "_UserList", users),
                    TotalItem = numOfItem,
                    PageSize = CNSConstant.PAGE_SIZE
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    Status = false,
                    Message = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult SendMassEmail(string subject, string content, long[] userIds, bool isNow, DateTime scheduleDate, bool isSelectedUsers, int[] brokerTypeIds)
        {
            try
            {
                userMailTrackingApp.SendMassEmail(CurrentUser.Id, subject, content, userIds, isNow ? DateTime.Now : scheduleDate, isSelectedUsers, brokerTypeIds);
                return Json(new
                {
                    success = true
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    errors = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public ActionResult Profile(int? id)
        {
            UserWithRoleViewModel user = null;
            string title = string.Empty;
            List<UserHistoryViewModel> userhistories = null;
            if (id.HasValue && id.Value > 0)
            {
                if (IsAdmin)
                {
                    user = userApp.FindUserWithRoleById(id.Value);
                    title = "User Profile";
                    userhistories = userHistoryApp.FindByUserId(id.Value);
                }
                else
                {
                    return RedirectToAction("Login");
                }
            }
            else
            {
                user = userApp.FindUserWithRoleByEmail(User.Identity.Name);
                userhistories = userHistoryApp.FindByEmail(User.Identity.Name);
                title = "My Profile";
            }
            ViewBag.Title = title;
            ViewBag.IsAdmin = IsAdmin;
            ViewBag.UserHistories = userhistories;
            ViewBag.Roles = roleApp.GetAll().Where(x => x.RoleName != CNSConstant.Broker).ToList();
            ViewBag.BrokerTypes = CommonHelper.GetListForEnum<EnumUserType>();
            ViewBag.LogoPositionTypes = CommonHelper.GetListForEnum<EnumLogoPositionType>();

            var aggregators = bpAggregatorRepository.GetBpAggregators();
            aggregators.Insert(0, new IdName { Id = 0, Name = "Select aggregator..." });
            var cbAggregators = new SelectList(aggregators, "Id", "Name");
            ViewBag.Aggregator = cbAggregators;
            ViewBag.SubAggregator = cbAggregators;

            return this.View("User", user);
        }

        [HttpGet]
        [Authorize(Roles = "Administrator")]
        public ActionResult CreateUser()
        {
            ViewBag.Title = "Create User";
            ViewBag.IsAdmin = true;
            ViewBag.Roles = roleApp.GetAll().Where(x => x.RoleName != "Broker").ToList();
            ViewBag.BrokerTypes = CommonHelper.GetListForEnum<EnumUserType>();
            ViewBag.LogoPositionTypes = CommonHelper.GetListForEnum<EnumLogoPositionType>();

            var aggregators = bpAggregatorRepository.GetBpAggregators();
            aggregators.Insert(0, new IdName { Id = 0, Name = "Select aggregator..." });
            var cbAggregators = new SelectList(aggregators, "Id", "Name");
            ViewBag.Aggregator = cbAggregators;
            ViewBag.SubAggregator = cbAggregators;
            return this.View("User", new UserWithRoleViewModel());
        }

        [HttpGet]
        [Authorize(Roles = "Administrator")]
        public ActionResult SendSample(long id, int type)
        {
            try
            {
                ViewBag.Title = "Send Sample Email";
                ViewBag.IsAdmin = true;
                ViewBag.LogoPositionTypes = CommonHelper.GetListForEnum<EnumLogoPositionType>();
                var model = userApp.FindUser(id, type);
                return this.View(model);
            }
            catch (Exception ex)
            {
                return RedirectToAction("Users");
            }
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public ActionResult PreviewSample(UserSampleEmailViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return Json(new { success = false, errors = ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage).ToList() }, JsonRequestBehavior.AllowGet);
                }

                var articleIds = userApp.GetArticles(model.SendSampleEmailType.Value);
                var inactiveArticleIds = articleApp.GetInactiveArticles(articleIds.ToList());
                if (inactiveArticleIds != null && inactiveArticleIds.Length > 0)
                {
                    return Json(new
                    {
                        success = true,
                        message = $"The system couldn't send the sample email because some of selected articles for the newsletter are deleted/declined (Article IDs: {string.Join(",", inactiveArticleIds)})",
                    }, JsonRequestBehavior.AllowGet);
                }

                var newUser = SaveSampleUser(model);
                var emailTemplate = mailTrackingApp.GetEmailTemplateBody(new EmailTemplateBodyRequest
                {
                    ArticleIds = articleIds,
                    SenderId = ConfigManager.SystemUserId,
                    ClientId = 0,
                    UserId = newUser.Id,
                    Url = GetUrl(),
                    IsSelectedCompanyImage = true,
                    PrimaryImageName = primaryImageApp.FindBy(1).Name,
                });

                return Json(new
                {
                    success = true,
                    id = newUser.Id,
                    isAdmin = true,
                    emailTemplate
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    errors = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public ActionResult SendSample(UserSampleEmailViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return Json(new { success = false, errors = ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage).ToList() }, JsonRequestBehavior.AllowGet);
                }

                var articleIds = userApp.GetArticles(model.SendSampleEmailType.Value);
                var inactiveArticleIds = articleApp.GetInactiveArticles(articleIds.ToList());
                if (inactiveArticleIds != null && inactiveArticleIds.Length > 0)
                {
                    return Json(new
                    {
                        success = true,
                        message = $"The system couldn't send the sample email because some of selected articles for the newsletter are deleted/declined (Article IDs: {string.Join(",", inactiveArticleIds)})",
                    }, JsonRequestBehavior.AllowGet);
                }

                var newUser = SaveSampleUser(model);
                var userId = CurrentUser.Id;
                var request = new SendToOneRequest
                {
                    SingleBrokerId = model.Id,
                    ArticleIds = articleIds,
                    IsSelectedCompanyImage = true,
                    PrimaryImageName = primaryImageApp.FindBy(1).Name,
                    ScheduledTime = DateTime.Now,
                    SenderId = ConfigManager.SystemUserId,
                    Url = GetUrl(),
                    TypeId = EnumEmailType.Article
                };
                mailTrackingApp.SendToOne(request);

                return Json(new
                {
                    success = true,
                    url = "/User/SendSampleResult",
                    isAdmin = true,
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    errors = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        private UserViewModel SaveSampleUser(UserSampleEmailViewModel model)
        {
            //model.Id = 0;
            var userModel = AutoMapperGenericsHelper<UserSampleEmailViewModel, UserWithRoleViewModel>.FullCopy(model);
            //if (userModel.Id == 0)
            //{
            //    if (userApp.FindByEmail(userModel.Email) != null)
            //    {
            //        return Json(new { success = false, errors = new List<string>() { "Email already exists. Please choose a different email." } }, JsonRequestBehavior.AllowGet);
            //    }
            //}
            userModel.Email += $"_temp_{DateTime.Now.Ticks}";
            UserViewModel newUser = null;
            if (IsAdmin)
            {
                var roles = new List<long>();
                roles.Add((long)EnumRole.Broker);
                newUser = userApp.CreateAndUpdateWithRole(userModel, roles, CurrentUser.Id, true);
            }
            else
            {
                newUser = userApp.CreateAndUpdate(userModel, CurrentUser.Id, isUpdatedBrokerMessage: true);
            }

            // Create new social icons if there is NO existing a icon for second color.
            ImageHelper.ChangeColorIcon(Server.MapPath(CNSConstant.SOCIAL_ICON_PATH), newUser.SecondaryColor);

            return newUser;
        }

        [HttpGet]
        [Authorize(Roles = "Administrator")]
        public ActionResult SendSampleResult()
        {
            try
            {
                ViewBag.Title = "Sent Sample Email Feedback";
                ViewBag.Message = "Sent sample email successfully.";
                return this.View();
            }
            catch (Exception ex)
            {
                return RedirectToAction("Users");
            }
        }

        [HttpPost]
        public ActionResult CreateUser(UserWithRoleViewModel userModel, string RoleIds)
        {
            try
            {
                if (userModel.Id > 0)
                {
                    ModelState.Remove("Password");
                }
                if (!IsAdmin)
                {
                    ModelState.Remove("UserTypeId");
                }

                if (!ModelState.IsValid)
                {
                    return Json(new { success = false, errors = ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage).ToList() }, JsonRequestBehavior.AllowGet);
                }

                CacheHandler.Clear(userModel.Email);

                if (userModel.Id == 0)
                {
                    if (userApp.FindByEmail(userModel.Email) != null)
                    {
                        return Json(new { success = false, errors = new List<string>() { "Email already exists. Please choose a different email." } }, JsonRequestBehavior.AllowGet);
                    }
                }
                UserViewModel newUser = null;
                if (IsAdmin)
                {
                    var roles = new List<long>();
                    if (!string.IsNullOrEmpty(RoleIds))
                    {
                        roles = RoleIds.Split(new string[] { "," }, StringSplitOptions.None).Where(r => !string.IsNullOrEmpty(r)).Select(r => long.Parse(r)).ToList();
                        if (!roles.Contains((long)EnumRole.Broker))
                        {
                            roles.Add((long)EnumRole.Broker);
                        }
                    }
                    newUser = userApp.CreateAndUpdateWithRole(userModel, roles, CurrentUser.Id);
                }
                else
                {
                    newUser = userApp.CreateAndUpdate(userModel, CurrentUser.Id);
                }

                // Create new social icons if there is NO existing a icon for second color.
                ImageHelper.ChangeColorIcon(Server.MapPath(CNSConstant.SOCIAL_ICON_PATH), newUser.SecondaryColor);

                return Json(new
                {
                    success = true,
                    isAdmin = IsAdmin,
                    url = $"/User/Profile/{newUser?.Id}"
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    errors = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }

        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public ActionResult Delete(int id)
        {
            try
            {
                userApp.Delete(id);
                return Json(new
                {
                    Status = true
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    Status = false,
                    Message = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public ActionResult GetClients(int userId)
        {
            try
            {
                return Json(new
                {
                    Status = true,
                    Clients = clientApp.FindByUserId(userId).Select(c => new
                    {
                        Name = c.FirstName + " " + c.LastName,
                        Phone = c.Phone,
                        SMSSubscribe = c.SMSSubscribe,
                        Email = c.Email,
                        EmailSubscribe = c.EmailSubscribe,
                        Id = c.Id
                    }).ToList()
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    Status = false,
                    Message = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult SetUserHistoryPinned(long userHistoryId, bool pinned)
        {
            try
            {
                userHistoryApp.SetPinned(userHistoryId, pinned);
                return Json(new
                {
                    success = true
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    errors = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult GetUserHistories(long userId)
        {
            try
            {
                var userHistories = userHistoryApp.FindByUserId(userId);
                return Json(new
                {
                    success = true,
                    Html = RazorViewToString.RenderRazorViewToString(this, "_UserHistories", userHistories)
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    errors = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public ActionResult UserHistory(long userId, long? userHistoryId = null)
        {
            try
            {
                UserHistoryViewModel userHistory = null;
                if (userHistoryId.HasValue)
                {
                    userHistory = userHistoryApp.FindById(userHistoryId.Value);
                }
                else
                {
                    userHistory = new UserHistoryViewModel() { CreatedUserId = CurrentUser.Id, UserId = userId, Pinned = false, CreatedDate = DateTime.Now, TypeId = 0, IsSystemAutogen = false };
                }
                return Json(new
                {
                    success = true,
                    Html = RazorViewToString.RenderRazorViewToString(this, "_UserHistory", userHistory)
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    errors = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult UserHistory(UserHistoryViewModel model)
        {
            try
            {
                var history = userHistoryApp.CreateAndUpdate(model);
                return Json(new
                {
                    success = true,
                    userId = history.UserId
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    errors = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult DeleteHistories(long userHistoryId)
        {
            try
            {
                userHistoryApp.Delete(userHistoryId);
                return Json(new
                {
                    success = true
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    errors = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize]
        public ActionResult UploadUserLogo(long id)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var files = Request.Files;
                if (files == null || files.Count == 0 || files[0].ContentLength <= 0)
                    return Json(new { success = false, message = "Please select a valid picture before uploading picture." }, JsonRequestBehavior.AllowGet);

                var file = files[0];
                string fileName = Path.GetFileName(file.FileName);
                if (!MimeMapping.GetMimeMapping(fileName).StartsWith("image/") && MimeMapping.GetMimeMapping(fileName) != "application/octet-stream")
                {
                    return Json(new { success = false, message = "The attached file is not supported." }, JsonRequestBehavior.AllowGet);
                }

                var path = Server.MapPath(UserConstants.UPLOADED_LOGO_PHOTO_FOLDER);
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                fileName = $"{ DateTime.Now.ToString("yyyyMMddHHmmss")}_{fileName.Replace(" ", "-")}";

                path = Path.Combine(path, fileName);
                file.SaveAs(path);
                var pictureName = $"{CNSConstant.THUMBNAIL_NAME}_{ImageHelper.GetJpecFileName(fileName)}";
                string pathThumbnail = Path.Combine(Server.MapPath(UserConstants.UPLOADED_LOGO_PHOTO_FOLDER), pictureName);
                //file.SaveAs(pathThumbnail);
                using (var image = ImageHelper.GetImage(path))
                {
                    using (var thubnailImage = ImageHelper.ResizeImage(image, 500, 125))
                    {
                        thubnailImage.Save(pathThumbnail);
                    }
                }

                //var item = userApp.FindByUserId(id);
                //if (item != null && item.Id > 0)
                //{
                //    item.Logo = pictureName;
                //    item.UpdatedDate = DateTime.Now;
                //    //item.UpdatedUserId = CurrentUser.Id; // will put it later
                //    userApp.UpdateLogoName(item);
                //}
                return Json(new { success = true, logo = pictureName }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize]
        public ActionResult DeleteLogo(long id, string logoName)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var item = userApp.FindByUserId(id);
                if (item != null && item.Id > 0)
                {
                    item.Logo = string.Empty;
                    item.UpdatedDate = DateTime.Now;
                    //item.UpdatedUserId = CurrentUser.Id; // will put it later
                    userApp.UpdateLogoName(item, CurrentUser.Id);
                }
                ImageHelper.DeletePicture(logoName, Server.MapPath(ArticleConstants.UPLOADED_PICTURE_FOLDER), Server.MapPath(ArticleConstants.DELETED_PICTURE_FOLDER), CNSConstant.THUMBNAIL_NAME);
                return Json(new { success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize]
        public ActionResult UploadUserCompanyImage(long id)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var files = Request.Files;
                if (files == null || files.Count == 0 || files[0].ContentLength <= 0)
                    return Json(new { success = false, message = "Please select a valid picture before uploading picture." }, JsonRequestBehavior.AllowGet);

                var file = files[0];
                string fileName = Path.GetFileName(file.FileName);
                if (!MimeMapping.GetMimeMapping(fileName).StartsWith("image/") && MimeMapping.GetMimeMapping(fileName) != "application/octet-stream")
                {
                    return Json(new { success = false, message = "The attached file is not supported." }, JsonRequestBehavior.AllowGet);
                }

                var path = Server.MapPath(UserConstants.UPLOADED_COMPANY_IMAGE_PHOTO_FOLDER);
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                fileName = $"{ DateTime.Now.ToString("yyyyMMddHHmmss")}_{fileName.Replace(" ", "-")}";

                path = Path.Combine(path, fileName);
                file.SaveAs(path);
                var pictureName = $"{CNSConstant.THUMBNAIL_NAME}_{ImageHelper.GetJpecFileName(fileName)}";
                string pathThumbnail = Path.Combine(Server.MapPath(UserConstants.UPLOADED_COMPANY_IMAGE_PHOTO_FOLDER), pictureName);
                //file.SaveAs(pathThumbnail);
                using (var image = ImageHelper.GetImage(path))
                {
                    using (var thubnailImage = ImageHelper.FixedSize(image, 720, 0))
                    {
                        thubnailImage.Save(pathThumbnail);
                    }
                }

                //var item = userApp.FindByUserId(id);
                //if (item != null && item.Id > 0)
                //{
                //    item.CompanyImage = pictureName;
                //    item.UpdatedDate = DateTime.Now;
                //    //item.UpdatedUserId = CurrentUser.Id; // will put it later
                //    userApp.UpdateLogoName(item);
                //}
                return Json(new { success = true, companyImage = pictureName }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize]
        public ActionResult DeleteCompanyImage(long id, string primaryImageName)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var item = userApp.FindByUserId(id);
                if (item != null && item.Id > 0)
                {
                    item.CompanyImage = string.Empty;
                    item.UpdatedDate = DateTime.Now;
                    //item.UpdatedUserId = CurrentUser.Id; // will put it later
                    userApp.UpdateCompanyImageName(item, CurrentUser.Id);
                }
                ImageHelper.DeletePicture(primaryImageName, Server.MapPath(ArticleConstants.UPLOADED_PICTURE_FOLDER), Server.MapPath(ArticleConstants.DELETED_PICTURE_FOLDER), CNSConstant.THUMBNAIL_NAME);
                return Json(new { success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        #region Download/Upload excel files 
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult DownloadExcelTemplateFile()
        {
            //get the temp folder and file path in server
            var fullPath = Server.MapPath(UserConstants.CLIENT_EXCEL_TEMPLATE_FILE);
            //var filename = Path.GetFileName(fullPath);

            //Response.ClearContent();
            //Response.Buffer = true;
            //Response.AddHeader("content-disposition", "attachment; filename=DemoExcel.xls");
            //Response.ContentType = "application/ms-excel";
            //Response.Charset = "";
            //StringWriter objStringWriter = new StringWriter();
            //HtmlTextWriter objHtmlTextWriter = new HtmlTextWriter(objStringWriter);
            //gv.RenderControl(objHtmlTextWriter);
            //Response.Output.Write(objStringWriter.ToString());
            //Response.Flush();
            //Response.End();


            //return the file for download, this is an Excel 
            //so I set the file content type to "application/vnd.ms-excel"
            return File(fullPath, "application/vnd.ms-excel", Path.GetFileName(fullPath));
        }

        [HttpPost]
        [Authorize]
        public ActionResult ImportClientsFromExcel(long brokerId)
        {
            try
            {
                var files = Request.Files;
                if (files == null || files.Count == 0 || files[0].ContentLength <= 0)
                    return Json(new { success = false, message = "Please select a valid excel file before import clients." }, JsonRequestBehavior.AllowGet);

                var file = files[0];
                string fileName = Path.GetFileName(file.FileName);
                //if (!MimeMapping.GetMimeMapping(fileName).EndsWith(".xlsx"))
                if (!fileName.EndsWith(".xlsx"))
                {
                    return Json(new { success = false, message = "The attached file is not supported." }, JsonRequestBehavior.AllowGet);
                }

                var path = Server.MapPath(UserConstants.UPLOADED_EXCEL_FOLDER);
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                path = Path.Combine(path, $"{ DateTime.Now.ToString("yyyyMMddHHmmss")}_{fileName}");
                file.SaveAs(path);
                var clients = new List<ImportClientViewModel>();
                var invalidRows = new List<int>();
                using (var package = new ExcelPackage(new FileInfo(path)))
                {
                    using (var sheet = package.Workbook.Worksheets[1])
                    {
                        var start = sheet.Dimension.Start;
                        var end = sheet.Dimension.End;
                        var emptyRow = new List<int>();
                        for (int row = start.Row + 1; row <= end.Row; row++)
                        {
                            try
                            {
                                if (emptyRow.Count >= 3 &&
       emptyRow[emptyRow.Count - 1] == emptyRow[emptyRow.Count - 2] + 1 &&
       emptyRow[emptyRow.Count - 1] == emptyRow[emptyRow.Count - 3] + 2)
                                {
                                    break;
                                }

                                var email = sheet.Cells[row, 4].Text;
                                if (!string.IsNullOrWhiteSpace(email))
                                {
                                    email = email.Replace(" ", "").Replace(")", "").Replace("]", "").Replace(">", "");
                                    if (email.EndsWith("."))
                                    {
                                        email = email.Substring(0, email.Length - 1);
                                    }
                                }
                                if (string.IsNullOrWhiteSpace(sheet.Cells[row, 1].Text) || !ValidationHelper.IsValidEmail(email))
                                {
                                    invalidRows.Add(row);
                                    if (string.IsNullOrWhiteSpace(sheet.Cells[row, 1].Text) && string.IsNullOrWhiteSpace(email))
                                    {
                                        emptyRow.Add(row);
                                    }
                                    continue;
                                }

                                var client = new ImportClientViewModel
                                {
                                    UserId = brokerId,
                                    FirstName = GetMaxLength(sheet.Cells[row, 1].Text.Trim(), 150),
                                    LastName = GetMaxLength(sheet.Cells[row, 2].Text.Trim(), 150),
                                    Salutation = GetMaxLength(sheet.Cells[row, 3].Text.Trim(), 350),
                                    Email = GetMaxLength(email, 150),
                                    Phone = GetMaxLength(sheet.Cells[row, 5].Text.Trim(), 50),
                                    Birthday = (DateTime?)sheet.Cells[row, 6].Value,
                                    BrokerRefNo = GetMaxLength(sheet.Cells[row, 7].Text.Trim(), 150),
                                    EmailSubscribe = (int)(sheet.Cells[row, 8].Text.Trim() == "1" ?
                                        EnumClientEmailStatus.Send :
                                        sheet.Cells[row, 8].Text.Trim() == "2" ? EnumClientEmailStatus.AdminDecided : EnumClientEmailStatus.Blank),
                                    CreatedUserId = CurrentUser.Id
                                };
                                //if (CommonHelper.GetBool(sheet.Cells[row, 8].Text.Trim()))
                                //{
                                //    client.RecipientTypes.Add(EnumRecipientType.BrokerClient);
                                //}
                                //if (CommonHelper.GetBool(sheet.Cells[row, 9].Text.Trim()))
                                //{
                                //    client.RecipientTypes.Add(EnumRecipientType.BrokerAccounts);
                                //}
                                //if (CommonHelper.GetBool(sheet.Cells[row, 10].Text.Trim()))
                                //{
                                //    client.RecipientTypes.Add(EnumRecipientType.ConveyancerClients);
                                //}
                                //if (CommonHelper.GetBool(sheet.Cells[row, 11].Text.Trim()))
                                //{
                                //    client.RecipientTypes.Add(EnumRecipientType.AccountantClient);
                                //}

                                var item = clients.FirstOrDefault(x => x.Email.Equals(client.Email, StringComparison.OrdinalIgnoreCase));
                                if (item != null)
                                {
                                    item.FirstName = client.FirstName;
                                    item.LastName = client.LastName;
                                    item.Salutation = client.Salutation;

                                    if (!string.IsNullOrWhiteSpace(client.Phone))
                                    {
                                        item.Phone = client.Phone;
                                    }
                                    if (!client.Birthday.HasValue)
                                    {
                                        item.Birthday = client.Birthday;
                                    }
                                    if (!string.IsNullOrWhiteSpace(client.BrokerRefNo))
                                    {
                                        item.BrokerRefNo = client.BrokerRefNo;
                                    }
                                    if (client.EmailSubscribe == 1)
                                    {
                                        item.EmailSubscribe = client.EmailSubscribe;
                                    }
                                }
                                else
                                {
                                    clients.Add(client);
                                }

                            }
                            catch
                            {
                                invalidRows.Add(row);
                            }
                        }
                    }
                }
                var result = clientApp.ImportClients(clients);
                var message = string.Empty;

                return Json(new { success = true, message = invalidRows.Count > 0 ? $@"{result.Message} <br /> <a href='#' onclick='ShowMoreImportClientErrorMessage();'>{invalidRows.Count} Invalid Rows (Please check valid FirstName, LastName, Salutation, Email Address)</a><br />
                        <div id='divError' style='color: red; font-weight: bold; padding: 10px; display: none;'>{string.Join(", ", invalidRows)}</div>" : result.Message }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }
        #endregion
    }
}