﻿using ApptitudeCNS.Application.MailLinks;
using ApptitudeCNS.Application.MailTrackings;
using ApptitudeCNS.Helpers;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ApptitudeCNS.Controllers
{
    public class MailLinkController : Controller
    {
        private IMailLinkApp _mailLinkApp { get; set; }
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public MailLinkController(IMailLinkApp _mailTrackingApp)
        {
            _mailLinkApp = _mailTrackingApp;
        }

        // GET: EmailLink
        public ActionResult Redirect(string MailId, string UserMailId, string ArticleId = "", string LinkId = "")
        {
            try
            {
                var link = _mailLinkApp.GetLink(CommonHelper.GetLong(Encryption.Base64DecodeUrl(ArticleId)), CommonHelper.GetLong(Encryption.Base64DecodeUrl(LinkId)), CommonHelper.GetLong(Encryption.Base64DecodeUrl(MailId)), CommonHelper.GetLong(Encryption.Base64DecodeUrl(UserMailId)));
                if (!string.IsNullOrWhiteSpace(link))
                {
                    ViewBag.Message = "Please see downloaded file.";
                    Response.Redirect(link);
                    return null;
                }
                ViewBag.Message = "We're sorry, this page isn't available.";
                //logger.Info($"Redirect MailId: {CommonHelper.GetLong(Encryption.Base64DecodeUrl(MailId))}, " +
                //    $"UserMailId: {CommonHelper.GetLong(Encryption.Base64DecodeUrl(UserMailId))}, " +
                //    $"ArticleId: {CommonHelper.GetLong(Encryption.Base64DecodeUrl(ArticleId))}, " +
                //    $"LinkId: {CommonHelper.GetLong(Encryption.Base64DecodeUrl(LinkId))} ");
            }
            catch (Exception ex)
            {
                logger.Error($"Redirect MailId: {CommonHelper.GetLong(Encryption.Base64DecodeUrl(MailId))}, " +
                    $"UserMailId: {CommonHelper.GetLong(Encryption.Base64DecodeUrl(UserMailId))}, " +
                    $"ArticleId: {CommonHelper.GetLong(Encryption.Base64DecodeUrl(ArticleId))}, " +
                    $"LinkId: {CommonHelper.GetLong(Encryption.Base64DecodeUrl(LinkId))} " +
                    $"{ex.ToString()}");
                //ViewBag.Message = ex.Message;
            }
            return View();
        }

        public ActionResult Unsubscribe(string ClientId, string MailId)
        {
            try
            {
                // You have successfully unsubscribed from further emails from Brokerpedia Client Newsletter System.
                var user = _mailLinkApp.UnsubscribeClient(CommonHelper.GetLong(Encryption.Base64DecodeUrl(ClientId)), CommonHelper.GetLong(Encryption.Base64DecodeUrl(MailId)));
                ViewBag.Message = "You have successfully unsubscribed from our Newsletter";
                ViewBag.PrimaryColor = "";
                if (!user.IsDeleted && user.Id > 0)
                {
                    if (!string.IsNullOrWhiteSpace(user.Company))
                    {
                        ViewBag.Message = $"You have successfully unsubscribed from {user.Company}'s Newsletter";
                    }
                    ViewBag.PrimaryColor = user.PrimaryColor;
                }
            }
            catch (Exception ex)
            {
                //ViewBag.Message = ex.Message;
            }
            return View();
        }

        public ActionResult ViewEmail(string ClientId, string MailId, string UserMailId)
        {
            ViewBag.Content = string.Empty;
            try
            {
                var content = _mailLinkApp.GetEmailContent(CommonHelper.GetLong(Encryption.Base64DecodeUrl(MailId)), CommonHelper.GetLong(Encryption.Base64DecodeUrl(UserMailId)));
                ViewBag.Content = content?.Replace("{MailId}", MailId).Replace("{UserMailId}", UserMailId).Replace("{ClientId}", ClientId);
            }
            catch (Exception ex)
            {
                //ViewBag.Message = ex.Message;
            }
            return View();
        }
    }
}