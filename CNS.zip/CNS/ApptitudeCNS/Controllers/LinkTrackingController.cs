﻿using ApptitudeCNS.Application.LinkTrackings;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ApptitudeCNS.Controllers
{
    [Authorize(Roles = "Administrator")]
    public class LinkTrackingController : Controller
    {
        private ILinkTrackingApp linkTrackingApp { get; set; }

        public LinkTrackingController(ILinkTrackingApp _linkTrackingApp)
        {
            linkTrackingApp = _linkTrackingApp;
        }

        // GET: LinkTrack
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GetList(int pageIndex, string sortByName)
        {
            try
            {
                //var searchText = Request["searchText"];
                var count = linkTrackingApp.GetCount();
                var linkTrackingList = linkTrackingApp.GetList(pageIndex, LinkTrackingConstants.PAGE_SIZE, sortByName);
                return Json(new { success = true, data = linkTrackingList, count, pageSize = MailTrackingConstants.PAGE_SIZE }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult ClientDetail(long id)
        {
            try
            {
                ViewBag.LinkId = id;
                //ViewBag.Link = linkTrackingApp.GetLink(id);
            }
            catch (Exception ex)
            {
            }
            return View();
        }

        public ActionResult UserDetail(long id)
        {
            try
            {
                ViewBag.LinkId = id;
                //ViewBag.Link = linkTrackingApp.GetLink(id);
            }
            catch (Exception ex)
            {
            }
            return View();
        }

        public ActionResult GetClientDetailList(int pageIndex, long linkId, string sortByName)
        {
            try
            {
                //var searchText = Request["searchText"];
                var count = linkTrackingApp.GetClientDetailCount(linkId);
                var linkTrackingList = linkTrackingApp.GetClientDetailList(pageIndex, LinkTrackingConstants.PAGE_SIZE, linkId, sortByName);
                var url = linkTrackingApp.GetLink(linkId);
                return Json(new { success = true, data = linkTrackingList, url, count, pageSize = MailTrackingConstants.PAGE_SIZE }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult GetUserDetailList(int pageIndex, long linkId, string sortByName)
        {
            try
            {
                //var searchText = Request["searchText"];
                var count = linkTrackingApp.GetUserDetailCount(linkId);
                var linkTrackingList = linkTrackingApp.GetUserDetailList(pageIndex, LinkTrackingConstants.PAGE_SIZE, linkId, sortByName);
                var url = linkTrackingApp.GetLink(linkId);
                return Json(new { success = true, data = linkTrackingList, url, count, pageSize = MailTrackingConstants.PAGE_SIZE }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

    }
}