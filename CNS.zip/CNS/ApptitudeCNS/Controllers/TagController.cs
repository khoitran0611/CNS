﻿using ApptitudeCNS.Application.Articles;
using ApptitudeCNS.Application.Clients;
using ApptitudeCNS.Application.MailTrackings;
using ApptitudeCNS.Application.PrimaryImages;
using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.Tags;
using ApptitudeCNS.Application.UserMailTrackings;
using ApptitudeCNS.Application.Users;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using HtmlAgilityPack;
using InfoCorp.Ico.Senc.Infrastructure.Logging;
using System;
using System.Configuration;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace ApptitudeCNS.Controllers
{
    public class TagController : BaseController
    {
        private ITagApp tagApp { get; }

        public TagController(ITagApp _tagApp)
        {
            tagApp = _tagApp;
        }

        // GET: Article
        [Authorize(Roles = "Administrator")]
        public ActionResult Index()
        {
            return View();
        }

        [Authorize(Roles = "Administrator")]
        public ActionResult GetList()
        {
            try
            {
                var list = tagApp.GetList();
                var itemNoTag = list.FirstOrDefault(x => x.Id == 100);
                list.Remove(itemNoTag);
                list.Insert(0, itemNoTag);

                //logger.LogInfo($"End Post article {CurrentUser.Email}");
                return Json(new { success = true, data = list }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }
        // POST: Article/Create
        [HttpPost]
        //[ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrator")]
        public ActionResult Create(TagViewModel model)//FormCollection collection)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                //model.RecipientTypes = Request["checkboxRecipientType[]"].Split(',').Select(x => int.Parse(x)).ToList();
                model.UpdatedDate = DateTime.Now;
                model.UpdatedUserId = CurrentUser.Id; // will put it later

                var id = model.Id;
                if (model.Id > 0)
                {
                    tagApp.Update(model);
                }
                else
                {
                    model.CreatedDate = DateTime.Now;
                    model.CreatedUserId = CurrentUser.Id; // will put it later
                    model.Id = tagApp.Create(model);
                }
                return Json(new { success = true, item = model }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Authorize()]
        public ActionResult CheckExistName(int id, string name)
        {
            //if (CurrentUser == null || CurrentUser.Id == 0)
            //{
            //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
            //}
            var exist = tagApp.CheckExistName(id, name);
            return Json(exist ? "This name existed. Please enter other name" : "true", JsonRequestBehavior.AllowGet);

            //if (exist)
            //{
            //    return Json("This link existed. Please enter other Link", JsonRequestBehavior.AllowGet);
            //}
            //return Json(true, JsonRequestBehavior.AllowGet);
            //dynamic result = true;
            //if (exist)
            //exist ? "This link existed. Please enter other Link" : true;
            //return Json(result ? "This link existed. Please enter other Link" : "true", JsonRequestBehavior.AllowGet);
        }

        // GET: Article/Delete/5
        [Authorize(Roles = "Administrator")]
        [HttpPost]
        public ActionResult DeleteRange(int[] ids)
        {
            try
            {
                //if (CurrentUser == null || CurrentUser.Id == 0)
                //{
                //    return Json(new { success = false, reloadPage = true }, JsonRequestBehavior.AllowGet);
                //}
                var userId = CurrentUser.Id; // Will put it later
                tagApp.DeleteRange(ids, userId);
                return Json(new { success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

    }
}
