﻿var newsLetterEmail = {
    UnselectLastItem: function () {
        $("ul#articleUnsortable li:last-child input.checkbox").prop('checked', false);
    },
    SelectItem: function (that) {
        //article.enableButtons();
        var dataId = $(that).val();
        var item = $('ul#articleUnsortable li.item-' + dataId);
        $("ul#articleUnsortable li:last-child input.checkbox").prop('checked', true);
        $("ul#articleUnsortable li:last-child").insertAfter(item);
        item.appendTo("ul#articleUnsortable");        
        //$("ul#articleUnsortable li:last-child input.checkbox").prop('checked', true);
        return false;
    },
    Validate: function (id, status) {
        var link = $('#link').val();
        if (!link && !$('#brokerMessage').val()) {
            $('#labelMessage').show();
            $('#labelMessage').text('Please enter Link or Broker Message');            
        }
        newsLetterEmail.CheckExistLink(id, link);
    },
    CheckExistLink: function (id, link) {
        toggleLoading();
        $.ajax({
            url: '/Article/CheckExistLink',// + '?filename=' + filename,
            type: 'POST',
            data: { "id": id, "link": link },
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }

                $('#labelMessage').hide();
                if (result != "true") {
                    $('#labelMessage').show().css({ 'color': 'red' });
                    $('#labelMessage').text(result);
                } else {
                    $('#labelMessage').text(null);
                    newsLetterEmail.SaveData();
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                console.log(err);
                //bootbox.alert("Can't retrieve the data");
                //alert("Can't save the data");
            }
        });
    },
    ViewData: function () {
        $('#modal').modal();
        newsLetterEmail.getEmailTemplate();
    },
    getEmailTemplate: function () {
        var ids = newsLetterEmail.getAllChecked();
        toggleLoading();
        $.ajax({
            url: '/Article/PostEmailTemplate',
            data: JSON.stringify({
                "ids": ids,
                isCurrentUser: true,
                brokerMessage: $('#brokerMessage').val(),
                primaryImageName: newsLetterEmail.primaryImageName,
                isSelectedCompanyImage: newsLetterEmail.isSelectedCompanyImage,
            }),
            type: "POST",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    $('#divEmailTemplateReview').html(result.emailTemplate);
                } else {
                    //bootbox.alert("Can't retrieve the data");
                    alert("Can't retrieve the data");
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                console.log(err);
                //bootbox.alert("Can't retrieve the data");
                //alert("Can't retrieve the data");
            }
        });
    },
    getAllChecked: function () {
        var result = $("#articleUnsortable .checkbox").map(function () {
            return parseInt($(this).val());
        }).get();
        if (!result) {
            result = [];
        }
        return result.join(',');
    },

    SaveData: function () {
        var request = {
            Id: $("#id").val(),
            ArticleIds: newsLetterEmail.getAllChecked(),
            BrokerMessage: $("#brokerMessage").val(),
            PrimaryImageName: newsLetterEmail.primaryImageName,
            IsSelectedCompanyImage: newsLetterEmail.isSelectedCompanyImage,
        }
        toggleLoading();    
        $.ajax({
            url: '/Article/NewsLetterEmail',// + '?filename=' + filename,
            type: 'POST',
            data: { request: request },
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    $('#modal').modal('hide');
                    alert('Newsletter has been saved successfully');
                    //showModalPopup('Information', 'NewsLetterEmail has been saved successfully',
                    //    {
                    //        Text: "Close", Func: function () {
                    //            //$('#labelMessage').show().css({ 'color': 'blue' });
                    //            //$('#labelMessage').text('Save data successfully.');
                    //        }
                    //    }, null);

                } else {
                    alert(result.error);
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                console.log(err);
                //bootbox.alert("Can't retrieve the data");
                alert("Can't save the data");
            }
        });
    },
    DeleteData: function (id) {
        if (!id || id <= 0) {
            $('#link').val('');
            $('#brokerMessage').val('');
            return;
        }
        //confirm("Are you sure want to delete this article ?", function (result) {
        if (confirm("Are you sure want to delete this article ?")) {
            toggleLoading();
            $.ajax({
                url: '/Article/DeleteBroker',
                data: { "id": id },
                type: "GET",
                dataType: 'json',
                contentType: "application/json;charset=utf-8",
                success: function (result) {
                    toggleLoading();
                    $('#link').val('');
                    $('#brokerMessage').val('');
                    //$('#labelMessage').show();
                    //$('#labelMessage').text('');
                    //location.reload();
                    //if (data != null) {
                    //    article.reloadPage();
                    //}
                },
                error: function (err) {
                    toggleLoading();
                    if (redirectLogin(err.responseText)) {
                        return;
                    }
                    //alert(err.error);
                }
            });
        }
    },

}

