﻿var SortAndPagging = { pageIndex: 1, pageSize: 20, count: 0, sortFieldName: '', orderBy: '', filter: { SearchText: '', SearchLevel: 0, RoleIds: [], BrokerTypeId: 0 } }
var User = {
    brokerId: 0,
    logo: ''
};

function GetUser(pageIndex, sortFieldName, orderBy, userFilter, isForceRefresh, successFunc) {
    toggleLoading();
    $.ajax({
        url: '/User/GetUsers',
        type: 'POST',
        dataType: "json",
        data: { pageIndex: pageIndex, sortFieldName: sortFieldName, orderBy: orderBy, filter: userFilter },
        success: function (data) {
            toggleLoading();
            User.isLoadingPage = false;
            if (redirectLogin(data)) {
                return;
            }
            if (data.Status) {
                if (successFunc != null && typeof successFunc === 'function') {
                    successFunc();
                }
                var $usersPanel = $('#user_list');
                if (isForceRefresh) {
                    $usersPanel.find('.row.list-items').remove();
                }
                $usersPanel.append(data.Html);
                SortAndPagging.pageIndex = pageIndex;
                SortAndPagging.sortFieldName = sortFieldName;
                SortAndPagging.orderBy = orderBy;
                SortAndPagging.count = data.TotalItem;
                SortAndPagging.pageSize = data.PageSize;
                $('.total-item .items').html(data.TotalItem);
            }
        },
        error: function (data) {
            toggleLoading();
            User.isLoadingPage = false;
            console.log(data);
            if (redirectLogin(data.responseText)) {
                return;
            }
        }
    });
}

function sortByHeader(target) {
    var $target = $(target);
    var pageIndex = 1;
    var sortFieldName = $target.data('field-name');
    var orderBy = $target.data('order-by');
    var userFilter = SortAndPagging.filter;

    GetUser(pageIndex, sortFieldName, orderBy, userFilter, false, function () {
        orderBy == 'asc' ? $target.data('order-by', 'desc') : $target.data('order-by', 'asc')
        $('#user_list').find('.row.list-items').remove();
    })
}

SearchUser = function () {
    var $filterItems = $('.filter-items');

    var currentSearchText = $filterItems.find('.search-text').val();
    var preSearchText = SortAndPagging.filter.SearchText;

    if (currentSearchText == preSearchText && currentSearchText != '') {
        SortAndPagging.filter.SearchLevel = 1;
    } else {
        SortAndPagging.filter.SearchLevel = 0;
    }

    SortAndPagging.filter.SearchText = currentSearchText;
    GetUser(1, SortAndPagging.sortFieldName, SortAndPagging.orderBy, SortAndPagging.filter, true, function () {
        User.clickedSearch = true;
        $('#buttonSearch').html("Search Further");
        //if (SortAndPagging.filter.SearchText != '') {
        //    $filterItems.find('.search-level').removeClass('hidden');
        //}
        //else {
        //    $filterItems.find('.search-level').addClass('hidden')
        //}
    });
}

ChangeSearchText = function () {
    //catchEnterKey(event, SearchUser);

    if (!User.clickedSearch) return;

    var $filterItems = $('.filter-items');
    var currentSearchText = $filterItems.find('.search-text').val();
    var preSearchText = SortAndPagging.filter.SearchText;
    if (currentSearchText.trim() == preSearchText.trim()) {
        $('#buttonSearch').html("Search Further");
    } else {
        $('#buttonSearch').html("Search");
    }
}

function FilterRole() {
    //RoleIds
    //var $user_list = $('#user_list');
    var chkRoles = $('.list-common-panel .filter-roles').find('input[type="checkbox"]:checked');
    var roleIds = [];
    for (var i = 0; i < chkRoles.length; i++) {
        var roleId = $(chkRoles[i]).data('role-id');
        roleIds.push(roleId);
    }

    SortAndPagging.filter.RoleIds = roleIds;

    GetUser(SortAndPagging.pageIndex, SortAndPagging.sortFieldName, SortAndPagging.orderBy, SortAndPagging.filter, true);
}

function FilterByBrokerType(that) {
    SortAndPagging.filter.BrokerTypeId = $(that).val();
    GetUser(SortAndPagging.pageIndex, SortAndPagging.sortFieldName, SortAndPagging.orderBy, SortAndPagging.filter, true);
}

function DeleteUser(userId) {
    showModalPopup('Delete Client', 'Do you want to delete ?', null, {
        Text: "Delete", Func: function () {
            toggleLoading();
            $.ajax({
                url: '/User/Delete',
                type: 'POST',
                dataType: "json",
                data: { id: userId },
                success: function (data) {
                    toggleLoading();
                    if (data.Status) {
                        //refresh the user list
                        GetUser(SortAndPagging.pageIndex, SortAndPagging.sortFieldName, SortAndPagging.orderBy, SortAndPagging.filter, true);
                    }
                },
                error: function (err) {
                    toggleLoading();
                    alert('Cannot delete user since ' + err.error);
                }
            });
        }
    });
}

SendMassEmail = function () {
    var selectedUser = $('#user_list').find('.mass-email:checked');
    if (selectedUser.length <= 0) {
        //$('.mass-email-panel.popup .selected-users').click();
        $('.mass-email-panel .selected-users').prop('checked', true);
        $('.mass-email-panel .selected-users-container').addClass('hidden');
        $('.mass-email-panel .broker-type-container').removeClass('hidden');
    } else {
        $('.mass-email-panel .selected-users-container').removeClass('hidden');
        $('.mass-email-panel .broker-type-container').addClass('hidden');

        $('.mass-email-panel .broker-type-container .check-box').each(function () { //iterate all listed checkbox items
            this.checked = false;
        });
    }

    var $massEmail = $('.mass-email-container').clone();
    $massEmail.find('.mass-email-panel').addClass('popup');
    $massEmail.find('input , textarea').val('');
    //$massEmail.find('textarea').text(data.user.BrokerMessage != null ? data.user.BrokerMessage : '');

    showModalPopup('Send Mass Email', $massEmail.html(), null, { Text: "Send", Func: CreateMassEmails }, CreateSendMassEmailInterface);

}

EnableSendButton = function () {
    if (!$('#dynamicModal .subject-text').val() ||
        !$('#dynamicModal .content-text').val() ||
        (($('#dynamicModal .selected-users-container').hasClass('hidden') || !$('#dynamicModal .selected-users').is(":checked"))
            && !$('#dynamicModal .broker-type-container .check-box').is(":checked"))) {
        $('#dynamicModal .modal-footer .btn.ok').prop('disabled', true);        
    } else {
        $('#dynamicModal .modal-footer .btn.ok').prop('disabled', false);        
    }   
}

ToggleScheduleDate = function () {
    var $scheduleDate = $('.mass-email-panel.popup .schedule-date');
    if (typeof $scheduleDate !== 'undefined' && $scheduleDate != null) {
        $scheduleDate.toggleClass('hidden');
    }
}

ToggleSelectedUsers = function () {
    if ($('.mass-email-panel.popup .selected-users').is(":checked")) {
        //$('.mass-email-panel.popup .selected-users-container').hide();
        $('.mass-email-panel.popup .broker-type-container').addClass('hidden');
    } else {
        //$('.mass-email-panel.popup .selected-users-container').show();
        $('.mass-email-panel.popup .broker-type-container').removeClass('hidden');
    }
}

CreateMassEmails = function () {
    var userIds = $('.mass-email-panel.popup .hidden-data').data('selected-ids');

    var $massEmail = $('.mass-email-panel.popup');
    var subject = $massEmail.find('.subject-text').val();
    var content = $massEmail.find('.content-text').val();
    var isNow = $massEmail.find('.is-now').is(":checked");
    var scheduleDate = $(".mass-email-panel.popup .datePicker.date").val() + " " + $(".mass-email-panel.popup .datePicker.time").val();
    var isSelectedUsers = !$massEmail.find('.selected-users-container').hasClass('hidden') && $massEmail.find('.selected-users').is(":checked");
    var brokerTypeIds = $(".mass-email-panel.popup .broker-type-container .check-box:checked").map(function () {
        return parseInt($(this).attr('data-id'));
    }).get();

    toggleLoading();
    $.ajax({
        url: '/User/SendMassEmail',
        type: 'POST',
        dataType: "json",
        data: { subject: subject, content: content, userIds: userIds, isNow: isNow, scheduleDate: scheduleDate, isSelectedUsers: isSelectedUsers, brokerTypeIds: brokerTypeIds },
        success: function (data) {
            toggleLoading();
            if (data.success) {
                closeModalPopup();
                showModalPopup("Information", "The email is added to system sending schedule successfully.", null, null, null);
            }
        },
        error: function (err) {
            toggleLoading();
            //alert('Cannot delete user since ' + err.error);
        },
        complete: function () {
            //toggleLoading();
        }
    });
}

CreateSendMassEmailInterface = function () {
    $(".mass-email-panel.popup .datePicker.date").datepicker
        ({
            dateFormat: 'dd/mm/yy',
            showStatus: true,
            showWeeks: true,
            highlightWeek: true,
            numberOfMonths: 1,
            showAnim: "scale",
            showOptions: {
                origin: ["top", "left"]
            }
        })
    //$(".mass-email-panel.popup .datePicker.time").datetimepicker
    //    ({
    //        format: 'HH:mm'
    //    })
    $(".mass-email-panel.popup .datePicker.date").val(moment(new Date()).format("DD/MM/YYYY"));
    $(".mass-email-panel.popup .datePicker.time").val(moment(new Date()).format("HH:mm"));

    //Get list user email un subscribe
    var selectedUser = $('#user_list').find('.mass-email:checked');
    var userIds = [];
    var userUnSubscribe = [];
    for (var i = 0; i < selectedUser.length; i++) {
        var $userItem = $(selectedUser[i]).parents('.list-items');
        var emailSubscribe = $(selectedUser[i]).attr('email-subscribe');
        if (emailSubscribe == 'email-subscribe') {
            var id = $userItem.data('user-id');
            userIds.push(id);
        }
        else {
            var name = $userItem.find('.full-name').html();
            userUnSubscribe.push(name);
        }

        if (userUnSubscribe.length > 0) {
            $('.mass-email-panel.popup .warning-user-unsubscribe').html(userUnSubscribe.join() + ' unsubscribe(s) email.Other users should receive the email');
        }

        $('.mass-email-panel.popup .hidden-data').data('selected-ids', userIds);
    }
    EnableSendButton();
}

chkMassAllEmails = function (targer) {
    $('#user_list input.mass-email[type="checkbox"]').prop('checked', $(targer).prop('checked'));
}

function ShowImportExcelPopup(brokerId, brokerName) {
    User.brokerId = brokerId;
    $('#spanBrokerName').text(brokerName);
    $('#fileUploadExcel').val(null);
    $('#divMessage').html('');
    $('#modal').modal();
}

function ImportClientsFromExcel() {
    // Checking whether FormData is available in browser
    if (window.FormData !== undefined) {

        var fileUpload = $("#fileUploadExcel").get(0);
        var files = fileUpload.files;

        if (!files || files.length == 0) {
            alert('Please select a valid excel file.');
            return;
        }
        // Create FormData object
        var fileData = new FormData();

        // Looping over all files and add it to FormData object
        for (var i = 0; i < files.length; i++) {
            fileData.append(files[i].name, files[i]);
        }

        // Adding one more key to FormData object
        //fileData.append('username', ‘Manas’);

        toggleLoading();
        $.ajax({
            url: '/User/ImportClientsFromExcel?brokerId=' + User.brokerId,
            type: "POST",
            contentType: false, // Not to set any content header
            processData: false, // Not to process data
            data: fileData,
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    $('#divMessage').html(result.message);
                    $('#divMessage').css('color', 'blue');
                } else {
                    $('#divMessage').html(result.message);
                    $('#divMessage').css('color', 'red');
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
            }
        });
    } else {
        alert("FormData is not supported.");
    }
}

function ShowMoreImportClientErrorMessage() {
    $('#divError').toggle();
}

function ShowClients(userId) {
    toggleLoading();
    $.ajax({
        url: '/User/GetClients',
        type: 'GET',
        data: { userId: userId },
        success: function (data) {
            toggleLoading();
            if (data.Status) {
                var $client_panel_modal = $('.client-panel-modal').clone();
                $client_panel_modal.removeClass('hidden');
                for (var i = 0; i < data.Clients.length; i++) {
                    var $item = $client_panel_modal.find('.list-items.hidden').clone();
                    $item.removeClass('hidden');
                    $item.find('.client-name').html('<a target="_blank"  href="/Client/Detail/' + data.Clients[i].Id + '">' + data.Clients[i].Name + '</a>');
                    $item.find('.client-email').append(data.Clients[i].Email);
                    $item.find('.client-phone').append(data.Clients[i].Phone);
                    $client_panel_modal.append($item);
                }
                showModalPopup('Clients', $client_panel_modal[0].outerHTML, null, null);
            }
        },
        error: function (err) {
            toggleLoading();
            if (redirectLogin(err.responseText)) {
                return;
            }
        }
    });
}

function SetTristate(target, val) {
    var $target = $(target);
    if (val == null) {
        $target.tristate('state', null);
    }
    else if (val == true) {

    }
}