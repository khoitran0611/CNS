﻿var mailTracking = {
    filter: {
        pageIndex: 1,
        pageCount: 1,
        searchText: '',
        clientSearchText: '',
        typeIds: [],
        //articleType: 0,
        recipientId: 2,
        sortField: 'SentDate',
        sortType: 'desc',
    },
    count: 30,
    pageSize: 100,
    getUrl: '',
    getEmailContentUrl: '',
    isLoadingPage: false,
    templateName: '#tmplMailTracking',
    gridName: '#mailTrackingGrid',

    getData: function () {
        var searchText = mailTracking.getSearchText();
        var clientSearchText = mailTracking.getClientSearchText();
        var typeIds = mailTracking.getTypeIds();

        mailTracking.showHideGrid();
        mailTracking.setGridControlName();

        if (!typeIds) {
            mailTracking.filter.pageIndex = 1;
            $(".row-body").remove();
            $("#spanCount").text(0);
            mailTracking.isLoadingPage = false;
           return;
        }

        if (searchText != mailTracking.filter.searchText ||
            clientSearchText != mailTracking.filter.clientSearchText ||
            typeIds.join(',') != mailTracking.filter.typeIds.join(',')) {
            mailTracking.filter.searchText = searchText;
            mailTracking.filter.clientSearchText = clientSearchText;
            mailTracking.filter.typeIds = typeIds;
            mailTracking.filter.pageIndex = 1;
            //$(".row-body").remove();
            //$("#spanCount").text(0);
        } else if (mailTracking.filter.pageIndex > 1 && (mailTracking.filter.pageIndex - 1)* mailTracking.pageSize >= mailTracking.count) {
            mailTracking.isLoadingPage = false;
            return;
        }
        if (mailTracking.filter.pageIndex == 1) {
            $(".row-body").remove();
        }

        toggleLoading();
        $.ajax({
            url: mailTracking.getUrl,
            //data: { "pageIndex": mailTracking.pageIndex, typeIds: typeIds, "searchText": searchText, sortByName: mailTracking.sortField + ' ' + mailTracking.sortType },
            data: JSON.stringify({ filter: mailTracking.filter }),
            type: "POST",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                mailTracking.isLoadingPage = false;
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    mailTracking.count = result.count;
                    mailTracking.pageSize = mailTracking.pageSize;
                    $("#spanCount").text(mailTracking.count);
                    $(mailTracking.templateName)
                        .tmpl(result.data)
                        .appendTo(mailTracking.gridName);
                } else {
                    console.log(result);
                }
            },
            error: function (err) {
                toggleLoading();
                mailTracking.isLoadingPage = false;
                if (redirectLogin(err.responseText)) {
                    return;
                } else {
                    console.log(err);
                    alert(err.error);
                }
            }
        });
    },
    search: function () {
        mailTracking.filter.pageIndex = 1;       
        mailTracking.getData();
    },
    setRecipientValue: function (value) {
        mailTracking.filter.pageIndex = 1;
        mailTracking.filter.recipientId = value;
    },
    onScroll: function (event) {
        if (mailTracking.isLoadingPage || (mailTracking.filter.pageIndex * mailTracking.pageSize >= mailTracking.count)) {
            return;
        }

        //var controlHeight = $("#" + self.ControlId)[0].clientHeight,
        //    sosScrollTop = $('#' + self.ScrollControlId)[0] ? $('#' + self.ScrollControlId)[0].offsetTop : 0;

        //if (sosScrollTop <= controlHeight + event.target.scrollTop) {
        //    self.ShowLoading(true);
        //    self.Presenter.Scroll();
        //}
        var controlHeight = window.innerHeight, //controlHeight = $("#mailTrackingGrid")[0].clientHeight,
            mailTrackingScrollTop = $('#mailTrackingScroll')[0] ? $('#mailTrackingScroll')[0].offsetTop : 0,
            scrollTop = window.pageYOffset || document.documentElement.scrollTop;

        if (mailTrackingScrollTop <= controlHeight + scrollTop + mailTrackingScrollTop * 0.3) {
            mailTracking.isLoadingPage = true;
            mailTracking.filter.pageIndex++;
            mailTracking.getData();
        }
    },
    getEmailContent: function (id) {
        toggleLoading();
        $.ajax({
            url: mailTracking.getEmailContentUrl,
            data: { id: id },
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                mailTracking.isLoadingPage = false;
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    $('#modal').modal();
                    $(".modal-body").html(result.data);
                }
            },
            error: function (err) {
                toggleLoading();
                mailTracking.isLoadingPage = false;
                if (redirectLogin(err.responseText)) {
                    return;
                } else {
                    alert(err.error);
                }
            }
        });
    },
    getUserEmailContent: function (id) {
        toggleLoading();
        $.ajax({
            url: mailTracking.getUserEmailContentUrl,
            data: { id: id },
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                mailTracking.isLoadingPage = false;
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    $('#modal').modal();
                    $(".modal-body").html(result.data);
                }
            },
            error: function (err) {
                toggleLoading();
                mailTracking.isLoadingPage = false;
                if (redirectLogin(err.responseText)) {
                    return;
                } else {
                    alert(err.error);
                }
            }
        });
    },
    getSearchText: function () {
        return $("#searchText").val();
    },
    getClientSearchText: function () {
        return $("#clientSearchText").val();
    },
    setGridControlName: function () {
        if (mailTracking.filter.recipientId == 1) {
            mailTracking.templateName = '#tmplUserMailTracking';
            mailTracking.gridName = '#userMailTrackingGrid';
        } else {
            mailTracking.templateName = '#tmplMailTracking';
            mailTracking.gridName = '#mailTrackingGrid';
        }
    },
    showHideGrid: function () {
        if (mailTracking.filter.recipientId == 1) {
            $('#mailTrackingGrid').hide();
            $('#userMailTrackingGrid').show();
        } else {
            $('#mailTrackingGrid').show();
            $('#userMailTrackingGrid').hide();
        }
    },
    getTypeIds: function () {
        var result = $("#divType .checkbox-type:checked").map(function () {
            return parseInt($(this).val());
        }).get();

        if (!result) {
            return [];
        }

        return result;
    },

    onSort: function (sortField) {
        var asc = 'asc', desc = 'desc';
        if (sortField == mailTracking.filter.sortField) {
            //mailTracking.filter.sortType = mailTracking.sortType == asc ? desc : asc;
            mailTracking.filter.sortType = mailTracking.filter.sortType == asc ? desc : asc;
        } else {
            mailTracking.filter.sortField = sortField;
            mailTracking.filter.sortType = sortField == 'SentDate' ? desc : asc;
        }
        mailTracking.isLoadingPage = true;
        mailTracking.filter.pageIndex = 1;
        $(".row-body").remove();
        mailTracking.getData();
    },
}

