﻿var tag = {
    id: 0,
    currentId: 0,
    data: [],
    isLoadingPage: false,
    setCurrentId: function () {
        var url = window.location.href;
        var lastIndex = url.lastIndexOf('/');
        tag.currentId = 0;
        if (lastIndex > 0) {
            var id = url.substring(lastIndex + 1);
            if (!isNaN(id)) {
                tag.currentId = parseInt(id);
            }
        }
        //
    },
    getData: function (callback) {
        toggleLoading();
        $.ajax({
            url: '/Tag/GetList',
            type: "GET",
            dataType: 'json',
            //data: { filter: tag.filter }, //JSON.stringify({ filter: tag.filter }),
            //contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                tag.isLoadingPage = false;
                if (redirectLogin(result)) {
                    return;
                }

                if (result.success) {
                    tag.data = result.data;
                    $("#divTagList").html(null);
                    var data = tag.filterData(result.data);
                    $("#spanCount").text(data.length - 1);
                    $("#tmplTag").tmpl(data).appendTo("#divTagList");
                } else {
                    alert(result.error);
                }
            },
            error: function (err) {
                toggleLoading();
                tag.isLoadingPage = false;
                if (redirectLogin(err.responseText)) {
                    return;
                }
                //alert(err.error);
            }
        });
    },
    createData: function (link) {
        tag.id = 0;
        tag.clearForm();
        //$('#modal').modal();

        tag.validate();
        tag.resetForm();

        $("#modalTagInput-Title").text("Create Tag");
        $('#name').focus();
    },

    editData: function (item) { //id, name, mapNames, orderNumber) {
        tag.id = item.Id;
        $('#id').val(item.Id);
        $('#name').val(item.Name);
        $('#mapNames').val(item.MapNameList);
        $('#orderNumber').val(item.OrderNumber);
        tag.validate();
        tag.resetForm();
        $('#mapNames').focus();
        $("#modalTagInput-Title").html("Edit Tag <b>" + item.Name + "</b>");
    },

    saveData: function (showMessage) {
        if (tag.saveTimeOut) {
            clearTimeout(tag.saveTimeOut);
        }
        tag.saveTimeOut = setTimeout(function () {
            toggleLoading();
            $.ajax({
                url: '/Tag/Create',// + '?filename=' + filename,
                type: 'POST',
                data: $('#frm').serialize(),
                success: function (result) {
                    toggleLoading();
                    if (redirectLogin(result)) {
                        return;
                    }
                    if (result.success) {
                        //$('#modal').hide();
                        //$('#modalTagInput').modal('hide');

                        $('#modalMessage').modal({
                            show: true
                        });
                        setTimeout(function () {
                            tag.reloadPage();
                        }, 1000);
                        //tag.reloadPage(true, result.id);
                    } else {
                        alert(result.error);
                    }
                },
                error: function (err) {
                    toggleLoading();
                    if (redirectLogin(err.responseText)) {
                        return;
                    }
                    console.log(err);
                    //bootbox.alert("Can't retrieve the data");
                    alert("Can't retrieve the data");
                }
            });
            //}
        }, 300);

    },

    clearForm: function () {
        $('#id').val('0');
        $('#name').val(null);
        $('#mapNames').val(null);
        $('#orderNumber').val(1);
        $(".model-content-tag .model-title").text("Create Tag");
    },

    resetForm: function () {
        try {
            tag.form.resetForm();
        } catch (e) {
            console.log(e);
        }
    },
    showDeleteDataPopup: function () {
        tag.selectedIds = tag.getAllChecked();
        if (tag.selectedIds.length > 0) {
            $('#modalDeleteTag').modal({
                show: true
            });

            var tags = "";
            for (var i = 0; i < tag.data.length; i++) {
                if (tag.selectedIds.indexOf(tag.data[i].Id) >= 0) {
                    tags += tags == "" ? tag.data[i].Name : ", " + tag.data[i].Name;
                }
            }
            $("#labelDeleteMessage").html('Do you want to delete the Tag(s): <b>' + tags + '</b>');
        } else {
            alert('Please select a or more tags before you click on this button');
        }
    },

    getAllChecked: function () {
        var result = $(".checkbox:checked").map(function () {
            return parseInt($(this).val());
        }).get();
        if (!result) {
            result = [];
        }
        return result;
    },

    filterData: function (data) {
        var result = [];
        for (var i = 0; i < data.length; i++) {
            if (!tag.currentId || data[i].Id == tag.currentId) {
                result.push(data[i]);
            }
        }
        return result;
    },

    getItem: function (data, id) {
        for (var i = 0; i < data.length; i++) {
            if (!id || data[i].Id == id) {
                return data[i];
            }
        }
        return {};
    },

    deleteData: function () {
        toggleLoading();
        $.ajax({
            url: '/Tag/DeleteRange',
            data: JSON.stringify({ "ids": tag.selectedIds }),
            type: "POST",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                tag.reloadPage();
                //if (data != null) {
                //    tag.reloadPage();
                //}
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                //alert(err.error);
            }
        });

    },

    reloadPage: function () {
        if (!tag.id && tag.currentId > 0) {
            window.location.href = window.location.href.substring(0, window.location.href.lastIndexOf('/'));
        } else {
            window.location.reload(true);
        }
    },
    validate: function () {
        var validator = $('#frm').data('validator');
        if (!validator) {
            tag.form = $('#frm').validate({
                ignore: [],
                rules: {
                    'name': {
                        required: true,
                        remote: {
                            url: '/Tag/CheckExistName',
                            type: "post",
                            data: {
                                id: function () {
                                    return tag.id;
                                },
                                name: function () {
                                    return $('#name').val();
                                },
                            },
                            complete: function (xhr) {
                                console.log(xhr)
                            }
                        }
                    },
                    'mapNames': {
                        required: true,
                    }
                },
                messages: {
                    'name': {
                        required: 'Please enter valid Tag',
                    },
                    'mapNames': {
                        required: 'Please enter valid Keywords',
                    },
                },
                errorPlacement: function (error, element) {
                    error.insertAfter(element);
                },
                submitHandler: function (form) {
                    // do other things for a valid form
                    //alert(JSON.stringify(form));
                    tag.saveData()
                }
            });
        }
    },

}
