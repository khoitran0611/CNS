﻿var linkTracking = {
    pageIndex: 1,
    pageSize: 100,
    count: 0,
    getListUrl: '',
    isLoadingPage: false,
    sortBy: 'CreatedDate',
    sortTypeBy: 'desc',
    getData: function () {
        if (linkTracking.pageIndex > 1 && (linkTracking.pageIndex - 1) * linkTracking.pageSize >= linkTracking.count) {
            linkTracking.isLoadingPage = false;
            return;
        }
        if (linkTracking.pageIndex == 1) {
            $(".row-body").remove();
        }

        toggleLoading();
        $.ajax({
            url: linkTracking.getListUrl,
            data: { "pageIndex": linkTracking.pageIndex, sortByName: linkTracking.sortBy + ' ' + linkTracking.sortTypeBy },
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                linkTracking.isLoadingPage = false;
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    linkTracking.count = result.count;
                    linkTracking.pageSize = linkTracking.pageSize;
                    $("#spanCount").text(linkTracking.count);
                    $("#tmplLinkTracking")
                        .tmpl(result.data)
                        .appendTo("#linkTrackingGrid");
                }
            },
            error: function (err) {
                toggleLoading();
                linkTracking.isLoadingPage = false;
                if (redirectLogin(err.responseText)) {
                    return;
                } else {
                    alert(err.error);
                }
            }
        });
    },
    onScroll: function (event) {
        if (linkTracking.isLoadingPage || (linkTracking.pageIndex * linkTracking.pageSize >= linkTracking.count)) {
            return;
        }

        var controlHeight = window.innerHeight, //controlHeight = $("#linkTrackingGrid")[0].clientHeight,
            linkTrackingScrollTop = $('#linkTrackingScroll')[0] ? $('#linkTrackingScroll')[0].offsetTop : 0,
            scrollTop = window.pageYOffset || document.documentElement.scrollTop;

        if (linkTrackingScrollTop <= controlHeight + scrollTop + linkTrackingScrollTop * 0.3) {
            linkTracking.isLoadingPage = true;
            linkTracking.pageIndex++;
            linkTracking.getData();
        }
    },

    onSort: function (sortBy) {
        var asc = 'asc', desc = 'desc';
        if (sortBy == linkTracking.sortBy) {
            linkTracking.sortTypeBy = linkTracking.sortTypeBy == asc ? desc : asc;
        } else {
            linkTracking.sortBy = sortBy;
            linkTracking.sortTypeBy = sortBy == 'CreatedDate' ? desc : asc;
        }
        linkTracking.isLoadingPage = true;
        linkTracking.pageIndex = 1;
        $(".row-body").remove();
        linkTracking.getData();
    },
}

