﻿var article = {
    filter: {
        pageIndex: 1,
        pageCount: 1,
        searchText: '',
        isNew: true,
        //articleType: 0,
        tagIds: [0],
        id: 0,
        ids: [],
        recipientTypeIds: [],
        isSearchAdvanced: false,
        sortBy: 'ArticleDate desc',
    },
    sortArticleDateField: 'ArticleDate',
    sortIdField: 'Id',
    sortType: 'desc',
    pageSize: 20,
    count: 30,
    articleTypesPrefix: 'ArticleType:',
    id: 0,
    idAfterPull: 0,
    tagIds: [],
    isSelectedCompanyImage: true,
    selectedUserIndex: 0,
    getUrl: '',
    getDataFromLinkUrl: '',
    addUrl: '',
    editUrl: '',
    deleteUrl: '',
    uploadPictureUrl: '',
    uploadPrimaryImageUrl: '',
    deletePictureUrl: '',
    getEmailDataUrl: '',
    sendTestUrl: '',
    sendToAllUrl: '',
    createTagControl: null,
    availableTags: [],
    startClientId: 1000,
    isLoadingPage: false,
    getData: function (callback) {
        var searchItem = article.getSearchText();
        //var searchText = article.getSearchText();
        //var articleType = article.getArticleType();
        article.showNew();

        if (!searchItem.searchText) {
            $("#divSearchAdvanced").hide();
        }

        if (searchItem.searchText != article.filter.searchText) { // || searchItem.articleType.Id != article.filter.articleType) {
            article.filter.searchText = searchItem.searchText;
            //article.filter.articleType = searchItem.articleType.Id;
            article.filter.pageIndex = 1;
            $("#articleUnsortable .ui-sortable-handle").remove();
        } else if (article.filter.pageIndex > 1 && (article.filter.pageIndex - 1) * article.pageSize >= article.count) {
            article.isLoadingPage = false;
            return;
        }

        if ($("#searchText").val().trim()) {
            $("#divClear").show();
        } else {
            $("#divClear").hide();
        }

        if (article.filter.pageIndex == 1) {
            $("#articleUnsortable .ui-sortable-handle").remove();
        }

        article.toggleOrderByDate();
        //console.log(article.filter);
        //toggleLoading("Displaying " + searchItem.articleType.Name + " articles");
        if (article.request) {
            console.log('article.request.abort');
            article.request.abort();
        }

        toggleLoading();
        article.request = $.ajax({
            url: article.getUrl,
            type: "POST",
            dataType: 'json',
            data: { filter: article.filter }, //JSON.stringify({ filter: article.filter }),
            //contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                article.isLoadingPage = false;
                if (redirectLogin(result)) {
                    return;
                }
                console.log('article.request');

                if (result.success) {
                    article.count = article.filter.isNew ? result.count.New : result.count.All;
                    article.pageSize = result.pageSize;
                    $(".new-count").text(result.count.New);
                    $(".all-count").text(result.count.All);
                    if (!article.isDeleted && result.count.All == 0) {
                        $("#articleUnsortable").html(null);
                        var searchTextElement = $("#searchText");
                        if (isUrl(searchTextElement.val(), searchTextElement)) {
                            showModalPopup("Information", "This Article URL is yet to be added... now forwarding you to the Create New screen.", null, null, null);
                            setTimeout(function () { closeModalPopup(); article.createData(searchTextElement.val()); }, 1500);
                        } else if (!article.filter.isSearchAdvanced && searchTextElement.val()) {
                            //article.searchAdvanced();
                            showModalPopup("Information", "...now searching further", null, null, null);
                            setTimeout(function () { closeModalPopup(); article.searchAdvanced(); }, 1500);
                        }
                    } else if (isUrl(searchItem.searchText) && result.data.length == 0 && result.count.All == 1) {
                        article.searchAll();
                    } else {
                        $("#tmplArticle").tmpl(article.filterData(result.data)).appendTo("#articleUnsortable");
                        if (isUrl(article.filter.searchText)) {
                            showModalPopup("Information", "This article has already been added.", null, null, null);
                            setTimeout(function () {
                                closeModalPopup();
                                var inputSearch = $("#searchText");
                                article.setSelection(inputSearch[0], 0, article.filter.searchText.length);
                                inputSearch.focus();
                            }, 1000);
                        }
                    }
                    article.isDeleted = false;

                    if (typeof callback === 'function') {
                        callback();
                    }
                } else {
                    alert(result.error);
                }
            },
            error: function (err) {
                toggleLoading();
                article.isLoadingPage = false;
                article.isSearchAdvanced = false;
                if (redirectLogin(err.responseText)) {
                    return;
                }
                //alert(err.error);
            }
        });
    },
    setSelection: function (txt, idx, length) {
        if (txt.createTextRange) {
            var range = txt.createTextRange();

            range.collapse(true);
            range.moveStart('character', idx);
            range.moveEnd('character', idx + length);
            range.select();
        }
        else if (txt.selectionEnd) {
            txt.selectionStart = idx;
            txt.selectionEnd = idx + length;
        }
    },

    toggleOrderByDate: function () {
        if (!article.filter.isNew && !article.filter.searchText &&
            (!article.filter.tagIds || (article.filter.tagIds.length == 1 && article.filter.tagIds[0] == 0))) {
            $('ul#articleUnsortable').removeClass('is-filter');
        } else {
            $('ul#articleUnsortable').addClass('is-filter');
        }
    },
    showNew: function () {
        if (article.filter.isNew) {
            $("#divNewArticles").show();
            $("#divAllArticles").hide();
        } else {
            $("#divNewArticles").hide();
            $("#divAllArticles").show();
        }

    },
    onSort: function () {
        if (article.filter.sortBy.indexOf(article.sortArticleDateField) == 0) {
            article.filter.sortBy = article.sortIdField + ' ' + article.sortType;
        } else {
            article.filter.sortBy = article.sortArticleDateField + ' ' + article.sortType;
        }
        article.filter.pageIndex = 1;
        article.getData();
    },
    filterData: function (data) {
        var ids = article.getAllChecked();
        if (!ids) {
            return data;
        }

        var result = [];
        for (var i = 0; i < data.length; i++) {
            if (ids.indexOf(data[i].Id) < 0) {
                result.push(data[i]);
            }
        }
        return result;
    },
    search: function (keepValue) {
        article.filter.pageIndex = 1;
        //article.filter.pageCount = 1
        article.filter.id = 0;

        if (!keepValue) {
            article.filter.isSearchAdvanced = false;
            article.filter.tagIds = [0];
            article.setFilterSelectedTags(article.filter.tagIds);

            if ($("#searchText").val().trim()) {
                $("#divSearchAdvanced").show();
            } else {
                $("#divSearchAdvanced").hide();
            }
        }

        article.getData();
    },
    searchButton: function () {
        if (!isUrl($("#searchText").val().trim())) {
            article.filter.isNew = true;
        }
        article.search();
    },
    searchNew: function () {
        article.filter.isNew = true;
        article.search(true);
    },
    searchAll: function () {
        article.filter.isNew = false;
        article.search(true);
    },
    clearSearch: function () {
        $("#searchText").val(null);
        $("#divSearchAdvanced").hide();
        article.filter.pageIndex = 1;
        article.filter.isSearchAdvanced = false;
        article.getData();
    },
    searchAdvanced: function () {
        article.filter.pageIndex = 1;
        article.filter.isSearchAdvanced = true;
        $("#divSearchAdvanced").hide();
        article.getData();
    },
    searchTags: function (tagIds) {
        article.filter.isNew = true;
        $("#searchText").val(null);
        $("#divSearchAdvanced").hide();
        article.filter.pageIndex = 1;
        //article.filter.pageCount = 1
        article.filter.id = 0;
        article.filter.isSearchAdvanced = false;
        article.filter.tagIds = tagIds;
        article.getData();
    },
    searchRecipientTypes: function (recipientTypeIds) {
        article.filter.pageIndex = 1;
        article.filter.recipientTypeIds = recipientTypeIds;
        article.getData();
    },
    onScroll: function (event) {
        if (article.isLoadingPage || article.filter.pageIndex * article.pageSize >= article.count) {
            return;
        }

        //var controlHeight = $("#" + self.ControlId)[0].clientHeight,
        //    sosScrollTop = $('#' + self.ScrollControlId)[0] ? $('#' + self.ScrollControlId)[0].offsetTop : 0;

        //if (sosScrollTop <= controlHeight + event.target.scrollTop) {
        //    self.ShowLoading(true);
        //    self.Presenter.Scroll();
        //}
        var controlHeight = window.innerHeight, //controlHeight = $("#articleGrid")[0].clientHeight,
            articleScrollTop = $('#articleScroll')[0] ? $('#articleScroll')[0].offsetTop : 0,
            scrollTop = window.pageYOffset || document.documentElement.scrollTop;// || document.body.scrollTop;

        if (articleScrollTop <= controlHeight + scrollTop + articleScrollTop * 0.3) {
            article.isLoadingPage = true;
            article.filter.pageIndex++;// += article.filter.pageCount;
            //article.filter.pageCount = 1;
            article.getData();
        }
    },
    getSearchText: function () {
        var searchText = $("#searchText").val().trim();
        //var articleType = { Id: 0, Name: '' };
        //if (searchText.indexOf(article.articleTypesPrefix) === 0) {
        //    var index = searchText.indexOf(' ');
        //    if (index > 0) {
        //        articleType = article.getArticleType(searchText.substring(0, index));
        //        searchText = searchText.substring(index + 1);
        //    } else {
        //        articleType = article.getArticleType(searchText);
        //        searchText = '';
        //    }

        //    if (articleType.Id == 0) {
        //        searchText = $("#searchText").val().trim();
        //    }
        //    //return { searchText: searchText, articleType: articleType };
        //}
        //return { searchText: searchText, articleType: articleType };
        return { searchText: searchText };
    },
    normaliseSiteName: function () {
        var sitename = $("#sitename").val();
        if (sitename) {
            if (sitename.indexOf('www.') >= 0) {
                sitename = sitename.substr(sitename.indexOf('www.') + 4);
            }
            if (sitename.indexOf('://') >= 0) {
                sitename = sitename.substr(sitename.indexOf('://') + 3);
            }

            var index = sitename.search(/\.com|\.org|\.net|\.int|\.edu|\.gov|\.mil|\.arpa|\.biz|\.asn/gi);
            if (index >= 0) {
                sitename = sitename.substr(0, index);
            } else {
                if (sitename.indexOf('/') >= 0) {
                    sitename = sitename.substr(0, sitename.indexOf('/'));
                }

                var index = sitename.lastIndexOf('.');
                if (index > 0) {
                    sitename = sitename.substr(0, index);
                }
                //var index = sitename.lastIndexOf('.'), i = 0;
                //while (index > 0 && i++ < 2) {
                //    sitename = sitename(0, index);
                //    index = sitename.lastIndexOf('.');
                //}
            }

            var index = sitename.lastIndexOf('.');
            if (index > 0) {
                sitename = sitename.substr(index + 1);
            }
            $("#sitename").val(sitename);
        }
    },
    getArticleType: function (name) {
        var item = $.grep(article.articleTypes, function (obj) {
            return obj.Name == name.substring(article.articleTypesPrefix.length);
        });
        //article.articleTypes.find(function (obj) { return obj.Name == name.substring(article.articleTypesPrefix.length); });
        if (item && item.length > 0)
            return item[0];
        return { Id: 0, Name: '' };
    },
    //getArticleType: function () {
    //    return $('#selectArticleType').val();
    //},
    uploadFile: function (fileUploadName, url, callback) {
        // Checking whether FormData is available in browser
        if (window.FormData !== undefined) {

            var fileUpload = $(fileUploadName).get(0);
            var files = fileUpload.files;

            if (!files || files.length == 0) {
                if (typeof callback === 'function') {
                    callback();
                }
                return;
            }
            // Create FormData object
            var fileData = new FormData();

            // Looping over all files and add it to FormData object
            for (var i = 0; i < files.length; i++) {
                fileData.append(files[i].name, files[i]);
            }

            // Adding one more key to FormData object
            //fileData.append('username', ‘Manas’);

            toggleLoading();
            $.ajax({
                url: url,
                type: "POST",
                contentType: false, // Not to set any content header
                processData: false, // Not to process data
                data: fileData,
                success: function (result) {
                    toggleLoading();
                    $(fileUploadName).val(null);
                    if (redirectLogin(result)) {
                        return;
                    }
                    if (result.success) {
                        callback(result);
                        //$('#hiddenAttachmentName').val(JSON.stringify(result.attachment));
                        //$('#inputAttachmentLink').val(null);
                        //$('#divAttachment').show();
                        //$('#aAttachmentLink').prop('href', '/UploadedAttachments/' + result.attachment.Name).text(result.attachment.OriginalName);
                        //$('#tmplLenderImageList').tmpl(result.data).appendTo('#divImageList');
                    } else {
                        console.log(result);
                        //alert('Please enter a valid link');
                    }
                    //alert(result.message);
                },
                error: function (err) {
                    toggleLoading();
                    $(fileUploadName).val(null);
                    if (redirectLogin(err.responseText)) {
                        return;
                    }
                    alert('Cannot upload file ' + err.error);
                    console.log(err);
                    //if (confirm(err.error + ". Do you want to save without picture or not?")) {
                    //    callback();
                    //}
                }
            });
        } else {
            alert("FormData is not supported.");
        }
    },
    uploadAttachmentCallback: function (result) {
        if (result && result.success) {
            article.setUploadAttachment(result.attachment);
        }
    },
    deleteUploadAttachment: function () {
        if (confirm("Are you sure want to delete the attachment?")) {
            toggleLoading();
            $.ajax({
                url: "/Article/DeleteAttachment",
                data: { "id": article.getId(), "attachment": $('#hiddenAttachmentName').val() },
                type: "GET",
                dataType: 'json',
                contentType: "application/json;charset=utf-8",
                success: function (result) {
                    toggleLoading();
                    if (redirectLogin(result)) {
                        return;
                    }
                    article.setUploadAttachment();
                },
                error: function (err) {
                    toggleLoading();
                    if (redirectLogin(err.responseText)) {
                        return;
                    }
                    //alert(err.error);
                }
            });
        }
    },
    setUploadAttachment: function (item) {
        var attachment = $("#hiddenAttachmentName").val();
        if (item) {
            $("#divAttachment").show();
            $("#aAttachmentLink").prop('href', '/UploadedAttachments/' + item.Name).text(item.OriginalName);
            $('#hiddenAttachmentName').val(JSON.stringify(item));
            article.changeRulesForLink(false);
        } else {
            $("#divAttachment").hide();
            $("#hiddenAttachmentName").val(null);
            article.changeRulesForLink(true);
        }
        var showPopup = false;
        if (!!$('#link').val() && !attachment && !!$('#hiddenAttachmentName').val()) {
            showPopup = true;
        }
        article.autosetNewsletterArticleLink(showPopup);
    },

    changeRulesForLink: function (isAdded) {
        if (isAdded) {
            $('#link').rules("add", {
                required: true,
            });
        } else {
            $('#link').rules("remove", 'required');
        }
        $('#link').blur();
    },

    autosetNewsletterArticleLink: function (showPopup) {
        if (!$('#hiddenAttachmentName').val() || !$('#link').val()) {
            if ($('#hiddenAttachmentName').val()) {
                $('#hiddenIsNewsletterArticleLink').val(false);
                $('#imgIsNewsletterArticleLink').prop("src", "/Content/Images/switch-off-icon-48.png");
            } else {
                $('#hiddenIsNewsletterArticleLink').val(true);
                $('#imgIsNewsletterArticleLink').prop("src", "/Content/Images/switch-on-icon-48.png");
            }
        } else if (showPopup && !article.isEditingPopup) {
            $('input.radio-newsletter-article-link').prop('checked', false);
            $('#modalNewsletterArticleLink').modal('show');
        }
    },
    setNewsletterArticleLink: function (value, hidePopup) {
        if (value) {
            $('#imgIsNewsletterArticleLink').prop("src", "/Content/Images/switch-on-icon-48.png");
        } else {
            $('#imgIsNewsletterArticleLink').prop("src", "/Content/Images/switch-off-icon-48.png");
        }
        $('#hiddenIsNewsletterArticleLink').val(value);
        if (hidePopup) {
            $('#modalNewsletterArticleLink').modal('hide');
        }
    },
    switchNewsletterArticleLink: function (value) {
        var value = $('#hiddenIsNewsletterArticleLink').val();
        if (value && (value == true || value == 'true')) {
            if ($('#hiddenAttachmentName').val()) {
                $('#hiddenIsNewsletterArticleLink').val(false);
                $('#imgIsNewsletterArticleLink').prop("src", "/Content/Images/switch-off-icon-48.png");
            }
        } else if ($('#link').val()) {
            $('#hiddenIsNewsletterArticleLink').val(true);
            $('#imgIsNewsletterArticleLink').prop("src", "/Content/Images/switch-on-icon-48.png");
        }
    },
    uploadAttachmentLink: function () {
        var link = $('#inputAttachmentLink').val();
        if (!isUrl(link, $('#inputAttachmentLink'))) {
            //alert('Link is required. Please enter it before click on Upload button.');
            alert('Please enter a valid link');
            return false;
        }

        //confirm("Are you sure want to delete the picture ?", function (result) {
        toggleLoading();
        $.ajax({
            url: '/Article/UploadAttachmentLink?id=' + article.getId() + '&link=' + $('#inputAttachmentLink').val(),
            //data: { "id": id, "pictureName": $('#hiddenPictureName').val() },
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    $('#inputAttachmentLink').val(null);
                    article.setUploadAttachment(result.attachment);
                    //$('#hiddenAttachmentName').val(JSON.stringify(result.attachment));
                    //$('#inputAttachmentLink').val(null);
                    //$('#divAttachment').show();
                    //$('#aAttachmentLink').prop('href', '/UploadedAttachments/' + result.attachment.Name).text(result.attachment.OriginalName);
                    //$('#tmplLenderImageList').tmpl(result.data).appendTo('#divImageList');
                } else {
                    console.log(result);
                    alert('Please enter a valid link');
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                console.log(err);
            }
        });
    },
    getDataFromLinkAuto: function () {
        var link = $("#link").val();
        var oldLink = $("#link").attr('old-data');
        if (link != oldLink) {
            //article.isGetDataFromLinkAuto = true;
            $("#link").attr('old-data', $("#link").val());

            if (isUrl(link, $("#link"))) {
                setTimeout(function () {
                    article.getDataFromLink();
                }, 1000);
            }
            //article.getDataFromLink();
        }
        var showPopup = false;
        if (!oldLink && !!link && $('#hiddenAttachmentName').val()) {
            showPopup = true;
        }
        article.autosetNewsletterArticleLink(showPopup);
    },
    getDataFromLink: function () {
        var link = $("#link").val();
        if (!link) {
            return;
        }

        toggleLoading();
        $.ajax({
            url: article.getDataFromLinkUrl,
            data: { id: article.getId(), link: link },
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }

                if (result.success) {
                    article.clearForm(true);
                    article.resetForm();
                    $("#title").val(result.title);
                    $("#title").blur();
                    $("#summary").val(result.summary);
                    $("#summary").blur();

                    if (result.picture) {
                        $('#divPictureContainer').show();
                        $('#imgArticle').prop('src', '/UploadedPictures/' + result.picture);
                        $('#hiddenPictureName').val(result.picture);
                    }

                    if (result.articleDate) {
                        $('#articleDate').datepicker('setDate', result.articleDate);
                    }

                    if (result.sitename) {
                        $('#sitename').val(result.sitename);
                    }
                    if (result.organisation) {
                        $('#organisation').val(result.organisation);
                    }
                    if (result.author) {
                        $('#author').val(result.author);
                        $("#author").blur();
                    }

                    if (!!result.tagIds && result.tagIds.length > 0) {
                        article.setSelectedTags(result.tagIds);
                        if (result.id && result.id > 0) {
                            $('#id').val(result.id);
                            article.showSuccessfullyMessage();
                            article.isAutoSaved = true;
                        }
                    }

                    if (!article.idAfterPull && result.id > 0) {
                        article.idAfterPull = result.id;
                    }
                    //article.setSelectedTags(result.tagIds);
                } else if (!result.existingLink) {
                    //bootbox.alert("Can't retrieve the data");
                    alert("Can't retrieve the data");
                }
            },
            error: function (err) {
                toggleLoading();
                article.isLoadingPage = false;
                if (redirectLogin(err.responseText)) {
                    return;
                }
                console.log(err);
                if (err.responseText.indexOf("There is already an open DataReader associated with this Command which must be closed first") >= 0) {
                    article.getDataFromLink();
                }
                //alert("Can't retrieve the data");
            }
        });
    },
    getTagIds: function (isForced, id) {
        var title = $("#title").val();
        var oldTitle = $("#title").attr('old-data');
        if (isForced || !((!title && !oldTitle) || (title.trim() == oldTitle.trim()))) {
            article.isGetTagIds = true;
            //console.log('getTagIds');

            $("#title").attr('old-data', title);
            //console.log(article.saveTimeOut);
            toggleLoading();
            $.ajax({
                url: 'Article/GetTagsByMapNames',
                data: { mapNames: title },
                type: "GET",
                dataType: 'json',
                contentType: "application/json;charset=utf-8",
                success: function (result) {
                    toggleLoading();
                    if (redirectLogin(result)) {
                        return;
                    }

                    if (result.success) {
                        //article.setSelectedTags(result.tagIds);
                        if (!!id) {
                            if (!!result.tagIds && result.tagIds.length > 0 && result.tagIds.indexOf(id) >= 0) {
                                if (article.tagIds.indexOf(id) < 0) {
                                    article.tagIds.push(id);
                                    article.setSelectedTags(article.tagIds);
                                }
                            } else if (article.tagIds.indexOf(id) >= 0) {
                                article.tagIds.splice(article.tagIds.indexOf(id), 1);
                                article.setSelectedTags(article.tagIds);
                            }
                        } else if (!!result.tagIds && result.tagIds.length > 0) {
                            article.setSelectedTags(result.tagIds);
                        }
                    }
                    //else if (!result.existingLink) {
                    //    //bootbox.alert("Can't retrieve the data");
                    //    alert("Can't retrieve the data");
                    //}
                    //console.log('getTagIds 2 ' + article.isSaved);

                    if (article.isSaved) {
                        article.saveData();
                    } else {
                        article.isGetTagIds = false;
                    }
                },
                error: function (err) {
                    toggleLoading();
                    article.isLoadingPage = false;
                    if (redirectLogin(err.responseText)) {
                        return;
                    }
                    console.log(err);
                }
            });
        }
        //article.getTagIdsTimeout = setTimeout(function () {

        //}, 10);
    },
    showData: function () {
        //if ($('#modal .modal-dialog .model-content-article-send-mail').length > 0) {
        //    $('.model-content-article-send-mail').hide().remove().insertAfter($('#modal'));
        //}

        //if (!$('.model-content-article').is(':visible')) {
        //    $('#modal .modal-dialog').css('width', '600px');
        //    $('#modal .modal-dialog').append($('.model-content-article').show());
        //}
        //$('#modalArticleInput').modal({
        //    show: true
        //});
    },

    clearForm: function (isFromLink) {
        //$('#subject').val('');
        //$('#articleDate').val('');
        //$('#articleDate').datepicker('setDate', new Date());
        //$('#divArticleDate').datepicker('setDate', new Date());
        //$('#articleDate').val($.datepicker.formatDate("dd/mm/yy", new Date()));
        $('#articleDate').datepicker('setDate', new Date());

        $('#title').val('');
        $("#title").attr('old-data', '');
        if (!isFromLink) {
            $('#id').val('');
            $('#link').val('');
            $("#link").attr('old-data', '');
            //$('#link').data('previousValue', '');
        }

        $('#summary').val('');
        $('#divPictureContainer').hide();
        $('#author').val('');
        $('#sitename').val('');
        $('#organisation').val('');
        //$('#brokerMessage').val('');
        $('#hiddenPictureName').val(null);
        $("#FileUpload").val(null);

        $('.modal-body #isDeclined').prop('checked', false);
        $('.modal-body #isDeclined').prop("disabled", false);

        //$("#ulCreateArticleTags").data("ui-tagit").setSelectedTags([]);
        article.setSelectedTags([]);

        $("#selectDoNotSend option").prop('selected', null);
        article.updateDoNotSendControl();
        $(".histories-detail-container").hide();
        //$('.modal-body .checkbox-user-type').prop('checked', false);
        //$('.modal-body .checkbox-client-type').prop('checked', false);

        //$('.modal-body .checkbox-client-type').each(function () { //iterate all listed checkbox items
        //    this.checked = false;
        //});

        //$('.modal-body .checkbox-recipient-type').each(function () { //iterate all listed checkbox items
        //    if (data.RecipientTypesList.indexOf($(this).val()))
        //        this.checked = true; //change ".checkbox" checked status
        //});

    },

    createData: function (link) {
        article.isEditingPopup = true;
        article.idAfterPull = article.id = 0;
        article.showData();
        article.clearForm();
        //$('#modal').modal();

        $('#modalArticleInput').modal({
            show: true,
            //keyboard: false
        });
        article.validate();
        article.resetForm();
        if (link) {
            $('#link').val(link);
            $('#link').blur();
        }

        $("#divAttachment").hide();
        $("#hiddenAttachmentName").val(null);

        $("#modalArticleInput-Title").text("Create Article");
        setTimeout(function () {
            $('#link').focus();
        }, 1000);
        article.isEditingPopup = false;
    },

    editData: function (id) {
        //	Get first selected id
        //var id = article.getFirstIdChecked();
        article.idAfterPull = article.id = id;
        article.isEditingPopup = true;
        toggleLoading();
        $.ajax({
            url: article.editUrl,
            data: { "id": id },
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                $("#FileUpload").val(null);
                if (redirectLogin(result)) {
                    return;
                }
                $("#modalArticleInput-Title").text("Edit Article");
                if (result && result.Id > 0) {
                    article.showData();
                    //$('#modal').modal();
                    article.validate();
                    article.resetForm();
                    $('#id').val(result.Id);
                    //$('#subject').val(result.Subject);
                    //
                    //$("#divArticleDate").datepicker("setDate", result.ArticleDateDisplay);
                    $('#articleDate').datepicker('setDate', result.ArticleDateDisplay);
                    //$('#articleDate').val(result.ArticleDateDisplay);
                    $("#title").attr('old-data', result.Title);
                    $('#title').val(result.Title);

                    $('#link').attr('old-data', result.Link);
                    $('#link').val(result.Link);
                    //$('#link').data('previousValue', result.Link);

                    $('#summary').val(result.Summary);
                    if (result.Picture) {
                        $('#divPictureContainer').show();
                        $('#imgArticle').prop('src', '/UploadedPictures/' + result.Picture);
                        $('#hiddenPictureName').val(result.Picture);
                    } else {
                        $('#divPictureContainer').hide();
                        $('#hiddenPictureName').val(null);
                    }

                    $('#author').val(result.Author);
                    $('#sitename').val(result.SiteName);
                    $('#organisation').val(result.Organisation);
                    //$('#brokerMessage').val(result.BrokerMessage);
                    $('#isDeclined').prop('checked', result.IsDeclined);
                    $('#isDeclined').prop("disabled", !!result.LastSentDisplay);

                    //$("input:radio[name=ArticleTypeId][value=" + result.ArticleTypeId + "]").prop('checked', true);
                    //$("#ulCreateArticleTags").data("ui-tagit").setSelectedTags(result.TagIds);
                    article.tagIds = result.TagIds;
                    article.setSelectedTags(result.TagIds);

                    var clientTypes = result.DoNotSendClientTypeIds ? result.DoNotSendClientTypeIds : [];
                    //$('.modal-body .checkbox-client-type').each(function () { //iterate all listed checkbox items
                    //    if (clientTypes && clientTypes.length > 0 && clientTypes.indexOf(parseInt($(this).val())) >= 0)
                    //        this.checked = true; //change ".checkbox" checked status
                    //    else this.checked = false;
                    //});
                    var userTypes = result.DoNotSendUserTypeIds ? result.DoNotSendUserTypeIds : [];
                    //$('.modal-body .checkbox-user-type').each(function () { //iterate all listed checkbox items
                    //    if (userTypes && userTypes.length > 0 && userTypes.indexOf(parseInt($(this).val())) >= 0)
                    //        this.checked = true; //change ".checkbox" checked status
                    //    else this.checked = false;
                    //});
                    $("#selectDoNotSend option").each(function () {
                        //alert(this.text + ' ' + this.value);
                        var value = parseInt(this.value);
                        this.selected = '';
                        if (value > article.startClientId) {
                            if (clientTypes.indexOf(value - article.startClientId) >= 0) {
                                this.selected = 'selected';
                            }
                        } else {
                            if (userTypes.indexOf(value) >= 0) {
                                this.selected = 'selected';
                            }
                        }
                    });
                    article.updateDoNotSendControl();
                    article.setNewsletterArticleLink(result.IsNewsletterArticleLink);
                    article.setUploadAttachment(result.Attachment);

                    if (result.Histories && result.Histories.length > 0) {
                        $(".histories-detail-container").show();
                        $(".histories-detail").html('');
                        $("#tmplArticleHistory").tmpl(result.Histories).appendTo(".histories-detail");
                    } else {
                        $(".histories-detail-container").hide();
                    }

                    setTimeout(function () {
                        $('#title').focus();
                    }, 1000);
                }
                article.isEditingPopup = false;
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                article.isEditingPopup = false;
                //alert(err.error);
            }
        });
    },
    uploadArticleImageButton: function () {
        $("#FileUpload").trigger('click');
    },
    findImageButton: function () {
        var googleLink = "https://www.google.com.au/search?hl=en&authuser=0&tbm=isch&source=hp&q=" + $("#title").val();
        window.open(googleLink, '_blank');
    },
    uploadArticleImage: function () {
        //if ($('#frm').valid()) {
        article.uploadFile('#FileUpload', article.uploadPictureUrl, function (result) {
            if (result && result.picture) {
                $('#divPictureContainer').show();
                $('#imgArticle').prop('src', '/UploadedPictures/' + result.picture);
                $('#hiddenPictureName').val(result.picture);
            }
        });
    },

    saveData: function (keepPopup) {
        if (article.saveTimeOut) {
            clearTimeout(article.saveTimeOut);
        }
        console.log('saveData keepPopup' + keepPopup);
        if (article.isGetTagIds) {
            article.isGetTagIds = false;
            article.isSaved = true;
            console.log('saveData 2');
            return;
        }

        article.saveTimeOut = setTimeout(function () {
            article.saveItem(keepPopup);
            //}
        }, 300);
        //console.log(article.saveTimeOut);
    },
    saveItem: function (keepPopup) {
        toggleLoading();
        $.ajax({
            url: article.addUrl,// + '?filename=' + filename,
            type: 'POST',
            data: $('#frm').serialize(),
            success: function (result) {
                article.isSaved = false;
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    if (keepPopup) {
                        article.isAutoSaved = true;
                        setTimeout(function () {
                            article.showSuccessfullyMessage();
                        }, 200);
                    } else {
                        article.ignoredSaveArticle = true;
                        $('#modalArticleInput').modal('hide');
                        article.reloadPage(true, result.id);
                        $("#searchText").focus();
                    }
                } else {
                    alert(result.error);
                }
            },
            error: function (err) {
                article.isSaved = false;
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                console.log(err);
                //bootbox.alert("Can't retrieve the data");
                alert("Can't retrieve the data");
            }
        });
    },
    showSuccessfullyMessage: function () {
        $('#modalMessage').modal({
            show: true
        });
        setTimeout(function () {
            $('#modalMessage').modal('hide');
        }, 1000);
    },
    showToOne: function () {
        $('.send-to-one-container').toggle();
    },

    updateDoNotSendControl() {
        var control = $("#selectDoNotSend").data('chosen');
        if (control) {
            $("#selectDoNotSend").trigger('chosen:updated.chosen');
        } else {
            //$("#selectDoNotSend").chosen('destroy');
            $("#selectDoNotSend").parent().find('.chosen-container.chosen-container-multi').remove();
            $("#selectDoNotSend").chosen({ default_multiple_text: "Select multi values", width: "80%", display_selected_options: false }).change(function (event) {
                //alert($("#selectRecipientType").chosen().val());
                //article.enableSendToAllButton();
                article.setDataDoNotSend($("#selectDoNotSend").chosen().val());
            });
        }
    },

    updateRecipientTypeControl() {
        $("#selectRecipientType option").each(function () {
            //alert(this.text + ' ' + this.value);
            if (article.selectedRecipientTypeIds && article.selectedRecipientTypeIds.indexOf(this.value) >= 0) {
                this.selected = 'selected';
            } else {
                this.selected = '';
            }
        });

        var control = $("#selectRecipientType").data('chosen');
        if (control) {
            $("#selectRecipientType").trigger('chosen:updated.chosen');
        } else {
            //$("#selectRecipientType").chosen('destroy');
            $("#selectRecipientType").parent().find('.chosen-container.chosen-container-multi').remove();
            $("#selectRecipientType").chosen({ default_multiple_text: "Select multi values", width: "100%", display_selected_options: false }).change(function (event) {
                //alert();
                article.selectedRecipientTypeIds = $("#selectRecipientType").chosen().val();
                article.enableSendToAllButton(article.selectedRecipientTypeIds);
            });
        }

    },

    setDataDoNotSend: function (list) {
        if (!list || list.length == 0) {
            $('#DoNotUserTypeIds').val(null);
            $('#DoNotClientTypeIds').val(null);
            return;
        }

        //list = value.split(','),
        var userTypeIds = [], clientTypeIds = [];
        for (var i = 0; i < list.length; i++) {
            var item = parseInt(list[i]);
            if (item > article.startClientId) {
                clientTypeIds.push(item - article.startClientId);
            } else {
                userTypeIds.push(item);
            }
        }
        $('#DoNotUserTypeIds').val(userTypeIds.join(','));
        $('#DoNotClientTypeIds').val(clientTypeIds.join(','));
    },
    setSelectedTags: function (tagIds) {
        var tagItElement = $("#ulCreateArticleTags").data("ui-tagit");
        if (tagItElement) {
            tagItElement.setSelectedTags(tagIds);
        } else {
            if (typeof article.createTagControl.destroy === 'function') {
                article.createTagControl.destroy();//.tagit("destroy");
            }
            article.createTagIt(tagIds);
        }
        //article.addTagLinks(tagIds);
    },
    //addTagLinks: function (tagIds) {
    //    var tags = [];
    //    for (var i = 0; i < article.availableTags.length; i++) {
    //        if (article.availableTags[i].Id != 100 && tagIds.indexOf(article.availableTags[i].Id) >= 0) {
    //            tags.push({ Id: article.availableTags[i].Id, Name: 'Keywords for the Tag ' + article.availableTags[i].Name });
    //        }
    //    }

    //    if (tags.length == 0) {
    //        tags.push({ Id: 0, Name: 'Edit Tags' })
    //    } else {
    //        tags.push({ Id: 0, Name: 'See All Tags' })
    //    }
    //    $("#divEditTagLinks").html('');

    //    $("#tmplTagLink").tmpl(tags).appendTo("#divEditTagLinks");
    //},
    createTagIt: function (selectedTagIds) {
        article.createTagControl = $("#ulCreateArticleTags").tagit({
            readOnly: true,
            tagSource: $('.div-tags #TagIds'),
            isMultiSelect: true,
            labelClass: 'tagit-custom-label',
            availableTags: article.availableTags,
            selectedTags: selectedTagIds,
            onTagChanged: article.setSelectedTagIds,
            onTagRightClicked: article.showTagInputPopup,
            //onTagChanged: article.addTagLinks
        });
    },
    setSelectedTagIds: function (tagIds) {
        article.tagIds = tagIds;
    },
    showTagInputPopup: function (item) {
        article.isShowingTagPopup = true;
        setTimeout(function () {
            $('#modalTagInput').modal('show');
        }, 300);
        $('#modalTagInput-Title').html('Edit Keywords for the Tag <b>' + item.Name + '</b>');
        $('#name').val(item.Name);
        if (item.MapNameList) {
            item.MapNameList += ', ';
        }
        $('#mapNames').val(item.MapNameList);
        $('#orderNumber').val(item.OrderNumber);

        $('#mapNames').focus();
        setTimeout(function () { $('#mapNames').focus(); }, 500);
        article.tagItem = item;
    },
    validateTagMapNames: function () {
        $('#labelMapNames').removeClass('hidden');
        if ($('#mapNames').val()) {
            $('#labelMapNames').addClass('hidden');
        }
    },

    saveTagData: function () {
        var mapNames = $('#mapNames').val();
        if (article.tagItem.MapNameList != mapNames) {
            article.tagItem.MapNames = mapNames;
            toggleLoading();
            $.ajax({
                url: '/Tag/Create',// + '?filename=' + filename,
                type: 'POST',
                data: { model: article.tagItem },
                success: function (result) {
                    toggleLoading();
                    if (redirectLogin(result)) {
                        return;
                    }
                    if (result.success) {
                        //$('#modal').hide();
                        $('.tagit-item-' + article.tagItem.Id).attr('item', JSON.stringify(result.item));
                        $('#modalMessage').modal({
                            show: true
                        });
                        article.getTagIds(true, article.tagItem.Id);
                        setTimeout(function () {
                            $('#modalMessage').modal('hide');
                        }, 1000);
                    } else {
                        alert(result.error);
                    }
                },
                error: function (err) {
                    toggleLoading();
                    if (redirectLogin(err.responseText)) {
                        return;
                    }
                    console.log(err);
                }
            });
        }
    },
    setFilterSelectedTags: function (tagIds) {
        var tagItElement = $("#ulFilterArticleTags").data("ui-tagit");
        if (tagItElement) {
            tagItElement.setSelectedTags(tagIds);
        } else {
            $("#ulFilterArticleTags").tagit({
                readOnly: true,
                tagSource: $('#FilterTagIds'),
                showSelectAll: true,
                onTagChanged: article.searchTags,
                availableTags: article.filterAvailableTags,
                selectedTags: tagIds
            });
        }
    },

    //updateSubject: function () {
    //    var title = $('#title').val();
    //    if (!$('#subject').val() && title) {
    //        $('#subject').val(title);
    //        $('#subject').blur();
    //    }
    //},
    resetForm: function () {
        try {
            article.form.resetForm();
        } catch (e) {
            console.log(e);
        }
    },
    deleteData: function (id) {
        //var items = article.getAllChecked();
        //var ids = "";

        //confirm("Are you sure want to delete this article ?", function (result) {
        if (confirm("Are you sure want to delete this article ?")) {
            toggleLoading();
            $.ajax({
                url: article.deleteUrl,
                data: { "id": id },
                type: "GET",
                dataType: 'json',
                contentType: "application/json;charset=utf-8",
                success: function (result) {
                    toggleLoading();
                    if (redirectLogin(result)) {
                        return;
                    }
                    article.isDeleted = true;
                    article.reloadPage();
                    //if (data != null) {
                    //    article.reloadPage();
                    //}
                },
                error: function (err) {
                    toggleLoading();
                    if (redirectLogin(err.responseText)) {
                        return;
                    }
                    //alert(err.error);
                }
            });
        }
    },

    deletePicture: function () {
        //	Get first selected id
        //var id = article.getFirstIdChecked();

        //confirm("Are you sure want to delete the picture ?", function (result) {
        if (confirm("Are you sure want to delete the picture ?")) {
            toggleLoading();
            $.ajax({
                url: article.deletePictureUrl,
                data: { "id": article.getId(), "pictureName": $('#hiddenPictureName').val() },
                type: "GET",
                dataType: 'json',
                contentType: "application/json;charset=utf-8",
                success: function (result) {
                    toggleLoading();
                    if (redirectLogin(result)) {
                        return;
                    }
                    $('#hiddenPictureName').val(null);
                    $('#divPictureContainer').hide();
                },
                error: function (err) {
                    toggleLoading();
                    if (redirectLogin(err.responseText)) {
                        return;
                    }
                    //alert(err.error);
                }
            });
        }
        //});
    },

    reloadPage: function (isResetTag, id) {
        var scrollTop = 0;
        if (isResetTag) {
            if (!article.id || article.id <= 0) {
                $("#searchText").val(null);
                article.filter.tagIds = [0];
                article.setFilterSelectedTags(article.filter.tagIds);
                article.filter.id = id;
            } else {
                scrollTop = $(window).scrollTop();
                $("#aJustSaved").prop("href", "/Article/Index/" + id).show();
                if (article.timeout) {
                    clearTimeout(article.timeout);
                }
                article.timeout = setTimeout(function () {
                    $("#aJustSaved").hide();
                }, 1000 * 63);
            }
        }

        article.filter.ids = article.getAllChecked();
        $("#articleSortable .ui-sortable-handle").remove();
        article.filter.pageCount = article.filter.pageIndex;
        article.filter.pageIndex = 1;
        article.isLoadingPage = true;
        article.getData(function () {
            if (article.filter.ids && article.filter.ids.length > 0) {
                var isChecked = false;
                //for (var i = article.filter.ids.length - 1; i >= 0; i--) {
                //    if ($('.checkbox-' + article.filter.ids[i]).length > 0) {
                //        $('.checkbox-' + article.filter.ids[i]).click();
                //        isChecked = true;
                //    }
                //}
                for (var i = 0; i < article.filter.ids.length; i++) {
                    if ($('.checkbox-' + article.filter.ids[i]).length > 0) {
                        $('.checkbox-' + article.filter.ids[i]).click();
                        isChecked = true;
                    }
                }
                if (!isChecked) {
                    $('#btnNext').hide();
                    $(".selected-row-container").css('border-bottom', '');
                    $(".selected-row-container").css('margin-bottom', '');
                }
            }
            article.filter.ids = [];
            article.isLoadingPage = true;
            $(window).scrollTop(scrollTop);
            article.filter.pageIndex = article.filter.pageCount;
            article.filter.pageCount = 1;
            article.isLoadingPage = false;
        });
    },

    getFirstIdChecked: function () {
        var items = $('.container .checkbox:checked');
        if (items.length > 0) {
            return parseInt($(items[0]).val());
        }
        return "";
    },

    getAllChecked: function () {
        var result = $(".container .checkbox:checked").map(function () {
            return parseInt($(this).val());
        }).get();
        if (!result) {
            result = [];
        }
        return result;
    },

    //enableButtons: function () {
    //    if (!article.getFirstIdChecked()) {
    //        $('#btnNext').prop('disabled', true);
    //    } else {
    //        $('#btnNext').prop('disabled', false);
    //    }
    //},

    selectItem: function (that) {
        //article.enableButtons();
        var dataId = $(that).val();
        var newClass = 'item-' + dataId;
        if ($(that).is(':checked')) {
            $("." + newClass).prev().find('div.row').addClass("first-item-of-day");
            $("." + newClass).find('div.row').removeClass("first-item-of-day");
            $("#articleSortable").append($(that).closest('.item'));
            //$(that).closest('.row-body').appendTo('<li class="ui-state-default"></li>').appendTo("#article-sortable");
            //$(that).closest('.row-body').appendTo("#article-sortable").insertAfter($('.row-header'));
        } else {
            $("#articleUnsortable").prepend($("." + newClass));
        }
        //article.filter.pageIndex = 1;
        //$("ul#articleSortable li .row-body").css('border-top', "");
        //$("ul#articleUnsortable li .row-body").css('border-top', "");
        if ($("#articleSortable li").length > 0) {
            $('#btnNext').show();
            $(".selected-row-container").css('border-bottom', '3px solid #468847');
            $(".selected-row-container").css('margin-bottom', '10px');
            //$("ul#articleSortable li:first-child div.row-body").css('border-top', '0');
        } else {
            $('#btnNext').hide();
            $(".selected-row-container").css('border-bottom', '');
            $(".selected-row-container").css('margin-bottom', '');
            //$("ul#articleUnsortable li:first-child .row-body").css('border-top', "");
        }

        $("#articleSortable").sortable('refresh');
    },

    showEmailPopup: function () {
        //if ($('#modal .modal-dialog .model-content-article').length > 0) {
        //    $('.model-content-article').hide().remove().insertAfter($('#modal'));
        //}

        //if (!$('.model-content-article-send-mail').is(':visible')) {
        //    $('#modal .modal-dialog').css('width', '760px');
        //    $('#modal .modal-dialog').append($('.model-content-article-send-mail').show());
        //}
        //$('#modalSendEmail').modal({
        //    show: true
        //});
    },

    sendEmailPopup: function () {
        //article.showEmailPopup();
        $('#scheduledDate').val(moment(new Date()).format("DD/MM/YYYY"));
        $('#scheduledTime').val(moment(new Date()).format("HH:mm"));
        //$('#modal').modal();
        article.isSelectedCompanyImage = true;
        article.selectedUserIndex = 0;
        $("#aCompanyImage").css({ color: "green" });
        article.updateRecipientTypeControl();
        article.getEmailData();
        //article.getPrimaryImage(function () {
        //    article.getEmailTemplate();
        //});
    },

    enableSendToAllButton: function (recipientTypeIds) {
        if (!recipientTypeIds || !$('#scheduledDate').val()) {
            //$('#btnSendTest').prop('disabled', true);
            $('#btnSendToAll').attr('disabled', true);
        } else {
            //$('#btnSendTest').prop('disabled', false);
            $('#btnSendToAll').removeAttr('disabled');
        }
    },
    enableSendButton: function (isEnabled) {
        if (article.enableSendButtonTimeout) {
            clearTimeout(article.enableSendButtonTimeout);
        }
        article.enableSendButtonTimeout = setTimeout(function () {
            var singularBroker = $('#singularBroker'),
                singularClient = $('#singularClient'),
                allClientsOfSingularBroker = $('#allClientsOfSingularBroker');
            if (!isEnabled && (!singularBroker.prop('data-id') || singularBroker.prop('old-value') != singularBroker.val().trim())
                && (!singularClient.prop('data-id') || singularClient.prop('old-value') != singularClient.val().trim())
                && (!allClientsOfSingularBroker.prop('data-id') || allClientsOfSingularBroker.prop('old-value') != allClientsOfSingularBroker.val().trim())) {
                $('#btnSend').attr('disabled', true);
                console.log('disabled');
            } else {
                $('#btnSend').removeAttr('disabled');
                console.log('enabled');
            }
        }, 100)
    },
    getEmailData: function () {
        var ids = article.getAllChecked();
        toggleLoading();
        $.ajax({
            url: article.getEmailDataUrl,
            data: JSON.stringify({ "ids": ids.join(',') }),
            type: "POST",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    if (!result.emailTemplate) {
                        $('#divEmailTemplateReview').html("<span style='color: #882222;'>The current user has not enough conditions as a sender for reviewing email template. Please change the user information or click Next to preview other senders' template.</span>");
                    } else {
                        $('#divEmailTemplateReview').html(result.emailTemplate);
                    }

                    article.primaryImages = result.primaryImages;
                    article.primaryImageControl.source(result.primaryImages, 0);
                    //if (article.primaryImageControl) {
                    //    article.primaryImageControl.source(result.primaryImages, 0);
                    //} else {
                    //    article.primaryImageControl = $('#divPrimaryImage').imageGallery({ source: result.primaryImages });
                    //}

                    article.users = result.users;
                } else {
                    //bootbox.alert("Can't retrieve the data");
                    alert("Can't retrieve the data");
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                console.log(err);
                //bootbox.alert("Can't retrieve the data");
                //alert("Can't retrieve the data");
            }
        });
    },

    getEmailTemplate: function (userId) {
        var ids = article.getAllChecked();
        toggleLoading();
        $.ajax({
            url: article.getEmailTemplateUrl,
            data: JSON.stringify({
                "ids": ids.join(','),
                userId: userId,
                primaryImageName: article.primaryImageControl.getSelectedItem().Name,
                isSelectedCompanyImage: article.isSelectedCompanyImage,
            }),
            type: "POST",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    $('#divEmailTemplateReview').html(result.emailTemplate);
                } else {
                    //bootbox.alert("Can't retrieve the data");
                    alert("Can't retrieve the data");
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                console.log(err);
                //bootbox.alert("Can't retrieve the data");
                //alert("Can't retrieve the data");
            }
        });
    },

    setCheckedMailRecipientTypeIds: function (userTypeIds, clientTypeIds) {
        //var recipientTypeIds = $("#selectRecipientType").chosen().val();
        //return recipientTypeIds;
        if (article.selectedRecipientTypeIds && article.selectedRecipientTypeIds.length > 0) {
            for (var i = 0; i < article.selectedRecipientTypeIds.length; i++) {
                var value = parseInt(article.selectedRecipientTypeIds[i]);
                if (value > article.startClientId) {
                    clientTypeIds.push(value - article.startClientId);
                } else {
                    userTypeIds.push(value);
                }
            }
        }
    },

    startTimer: function (popupElementName, duration, callback) {
        if (article.SendTimeout) {
            clearInterval(article.SendTimeout);
            $('#divSendTimeOut').remove();
        }
        var popupName = '#modalSendEmail';
        if (popupName != popupElementName) {
            $(popupElementName).modal('hide');
        }
        var popup = $(popupName).find('.modal-header').append('<div id="divSendTimeOut" style="display:inline-block;color: white;padding-left: 100px;">The newsletter will be sent in <span id="time"></span> seconds.' +
            '&nbsp;<a href="javascript:void(0)" style="text-decoration-line: underline;color: #921709;" onclick="article.cancelSendMail()">Undo</a></div>');
        article.SendTimeout = StartTimer(duration, '#time', callback);
    },

    cancelSendMail: function () {
        if (article.SendTimeout) {
            $('#divSendTimeOut').remove();
            clearInterval(article.SendTimeout);
        }
    },

    sendTest: function () {
        var ids = article.getAllChecked();
        request = {
            ArticleIds: ids,
            IsSelectedCompanyImage: article.isSelectedCompanyImage,
            PrimaryImageName: article.primaryImageControl.getSelectedItem().Name,
        };
        toggleLoading();
        $.ajax({
            url: article.sendTestUrl,
            type: 'POST',
            data: { request: request },
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    alert(result.message);
                } else {
                    alert(result.error);
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                //alert(err.error);
            }
        });
    },

    sendToAll: function () {
        //<div style="display: inline-block">The newsletter will be sent in <span id="time">15</span> seconds. <a href="javascript:void(0)" onclick="article.cancelSendMail()">Undo</a></div>
        toggleLoading();
        var ids = article.getAllChecked(), userTypeIds = [], clientTypeIds = [];
        //var userTypeIds = article.getCheckedMailUserTypeIds();
        //var clientTypeIds = article.getCheckedMailClientTypeIds();
        article.setCheckedMailRecipientTypeIds(userTypeIds, clientTypeIds);

        request = {
            UserTypeIds: userTypeIds,
            ClientTypeIds: clientTypeIds,
            ArticleIds: ids,
            ScheduledTime: $('#scheduledDate').val() + ' ' + $('#scheduledTime').val(),
            IsSelectedCompanyImage: article.isSelectedCompanyImage,
            PrimaryImageName: article.primaryImageControl.getSelectedItem().Name,
        };

        $.ajax({
            url: article.sendToAllUrl,
            type: 'POST',
            data: { request: request },
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }

                if (result.success) {
                    alert(result.message);
                    $('#modalSendEmail').modal('hide');
                    article.reloadPage();
                } else {
                    alert(result.error);
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                //alert(err.error);
            }
        });
    },

    sendToOne: function () {
        toggleLoading();
        var singularBroker = $('#singularBroker'),
            singularClient = $('#singularClient'),
            allClientsOfSingularBroker = $('#allClientsOfSingularBroker'),
            request = {
                SingleBrokerId: singularBroker.prop('old-value') != singularBroker.val().trim() ? 0 : singularBroker.prop('data-id'),
                SingleClientId: singularClient.prop('old-value') != singularClient.val().trim() ? 0 : singularClient.prop('data-id'),
                AllClientsOfSingularBrokerId: allClientsOfSingularBroker.prop('old-value') != allClientsOfSingularBroker.val().trim() ? 0 : allClientsOfSingularBroker.prop('data-id'),
                ScheduledTime: $('#scheduledDate').val() + ' ' + $('#scheduledTime').val(),
                ArticleIds: article.getAllChecked(),
                IsSelectedCompanyImage: article.isSelectedCompanyImage,
                PrimaryImageName: article.primaryImageControl.getSelectedItem().Name,
            };

        $.ajax({
            url: article.sendToOneUrl,
            type: 'POST',
            data: { request: request },
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }

                if (result.success) {
                    alert(result.message);
                    $('#singularBroker').val('').prop('data-id', '').prop('old-value', '')
                    $('#singularClient').val('').prop('data-id', '').prop('old-value', '')
                    $('#allClientsOfSingularBroker').val('').prop('data-id', '').prop('old-value', '')
                    $('#modalSendToOne').modal('hide');
                    setTimeout(function () {
                        $('#modalSendEmail').modal('hide');
                        article.reloadPage();
                    }, 10);
                } else {
                    alert(result.error);
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                //alert(err.error);
            }
        });
    },

    validate: function () {
        var validator = $('#frm').data('validator');
        if (!validator) {
            article.form = $('#frm').validate({
                ignore: [],
                rules: {
                    //'subject': {
                    //    required: true,
                    //},
                    'title': {
                        required: true,
                    },
                    'articleDate': {
                        required: true,
                    },
                    'link': {
                        required: true,
                        customerUrl: true,
                        remote: {
                            url: article.checkExistLinkUrl,
                            type: "post",
                            data: {
                                id: function () {
                                    return article.getId();
                                },
                                link: function () {
                                    return $('#link').val();
                                },
                            },
                            complete: function (xhr) {
                                console.log(xhr)
                            }
                        }
                    },
                    'summary': {
                        required: true
                    },
                    'TagIds': {
                        required: true
                    },
                },
                messages: {
                    //'subject': 'Please enter Subject',
                    'articleDate': 'Please select Article Date',
                    'title': 'Please enter Title',
                    'link': {
                        required: 'Please enter valid Link',
                        customerUrl: 'Please enter valid Link',
                        //remote: 'This link existed. Please enter other Link',
                    },
                    'summary': 'Please enter Summary',
                    'TagIds': 'Please select one or more Tag(s)',
                },
                errorPlacement: function (error, element) {
                    if (element.attr("name") == "TagIds")
                        error.insertAfter("#ulCreateArticleTags");
                    else if (element.attr("name") == "link")
                        error.insertAfter("#btnGetDataFromLink");
                    else
                        error.insertAfter(element);
                },
                submitHandler: function (form) {
                    // do other things for a valid form
                    //alert(JSON.stringify(form));
                    article.saveData()
                }
            });
        }
    },
    changeCompanyImage: function () {
        var primaryImage = '', isCompanyImage = false;
        if (article.isSelectedCompanyImage) {
            article.isSelectedCompanyImage = false;
            $("#aCompanyImage").css({ color: 'red' });
            primaryImage = article.primaryImageControl.getSelectedItem().Name;
        } else {
            article.isSelectedCompanyImage = true;
            $("#aCompanyImage").css({ color: 'green' });
            primaryImage = article.getCompanyImage();
            if (!primaryImage) {
                primaryImage = article.primaryImageControl.getSelectedItem().Name;
            } else {
                isCompanyImage = true;
            }
        }
        article.setPrimaryImage(primaryImage, isCompanyImage);
    },
    setPrimaryImage: function (primaryImage, isCompanyImage) {
        var companyImage = article.getCompanyImage();
        if (isCompanyImage || !article.isSelectedCompanyImage || !companyImage || primaryImage == companyImage) {
            var path = isCompanyImage ? "/UploadedCompanyImages/" : "/UploadedPrimaryImages/";
            var host = $("#divPrimaryImageEmail img").attr('data-src');
            $("#divPrimaryImageEmail img").prop('src', host + path + primaryImage);
        }
    },
    getCompanyImage: function () {
        if (article.users && article.users.length > 0) {
            return article.users[article.selectedUserIndex].CompanyImage;
        }
        return null;
    },
    changePrimaryImage: function (item) {
        article.setPrimaryImage(item.Name, false);
    },
    createPrimaryImageControl: function () {
        if (!article.primaryImageControl) {
            article.primaryImageControl = $('#divPrimaryImage').imageGallery({
                addImageFunc: article.addPrimaryImage,
                onImageChanged: article.changePrimaryImage,
                onOpenList: article.showPrimaryList,
            }).imageGallery("instance");;
        }
        return article.primaryImageControl;
    },
    addPrimaryImage: function (isFromSendingMail) {
        article.isFromSendingMail = isFromSendingMail;
        $("#FileUploadPrimaryImage").trigger('click');
    },

    uploadPrimaryImage: function (callback) {
        article.uploadFile('#FileUploadPrimaryImage', article.uploadPrimaryImageUrl, function (result) {
            if (article.isFromSendingMail) {
                article.isFromSendingMail = false;
                article.primaryImageControl.addNewItem(result.item);
                //if (article.primaryImageControl.addNewItem) {
                //}
            }
            //if (typeof callback === 'function') {
            //    callback(item);
            //}
        });
    },

    deletePrimaryImage: function (id, event) {
        if (id == 1) {
            alert("The default primary image can't be deleted.");
            return false;
        }

        if (confirm("Are you sure want to delete this primary image ?")) {
            toggleLoading();
            $.ajax({
                url: 'Article/DeletePrimaryImage',
                data: { "id": id },
                type: "GET",
                dataType: 'json',
                contentType: "application/json;charset=utf-8",
                success: function (result) {
                    toggleLoading();
                    if (redirectLogin(result)) {
                        return;
                    }

                    article.setSelectedPrimaryImage(id);
                },
                error: function (err) {
                    toggleLoading();
                    if (redirectLogin(err.responseText)) {
                        return;
                    }
                    //alert(err.error);
                }
            });
        }
        event.stopPropagation();
        return false;
    },
    setSelectedPrimaryImage: function (id) {
        var index = getIndexFromArray(article.primaryImages, 'Id', id);
        if (index >= 0) {
            var selectedItem = article.primaryImageControl.getSelectedItem();
            article.primaryImages.splice(index, 1);

            index = selectedItem.Id == id ? 0 : getIndexFromArray(article.primaryImages, 'Id', selectedItem.Id);
            article.primaryImageControl.source(article.primaryImages, index);
            article.showPrimaryList(article.primaryImages[index].Id);
        }
    },
    selectPrimaryImage: function (id) {
        $('#primaryImage div.image-item').removeClass('selected-image-item');
        $('#primaryImage div#item-' + id).addClass('selected-image-item');
        article.primaryImageControl.source(article.primaryImages, getIndexFromArray(article.primaryImages, 'Id', id));
    },
    showPrimaryList: function (selectedId) {
        var scrollTop = $('#modalPrimaryImage .modal-body').scrollTop();
        $('#primaryImage').html('');
        $('#tmplPrimaryImageList').tmpl({ data: article.primaryImages, selectedId: selectedId }).appendTo('#primaryImage');

        setTimeout(function () {
            $('#modalPrimaryImage .modal-body').scrollTop(scrollTop);
        }, 100);
    },

    retrieveLastSave: function () {
        toggleLoading();
        $.ajax({
            url: 'Article/LoadArticles',
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                $(".model-content-article .model-title").text("Edit Article");
                if (result.success) {
                    if (result.data && result.data.length > 0) {
                        var ids = article.getAllChecked();
                        //for (var i = ids.length - 1; i >= 0; i--) {
                        //    if ($('.checkbox-' + ids[i]).length > 0) {
                        //        $('.checkbox-' + ids[i]).click();
                        //    }
                        //}
                        for (var i = 0; i <= ids.length - 1; i++) {
                            if ($('.checkbox-' + ids[i]).length > 0) {
                                $('.checkbox-' + ids[i]).click();
                            }
                        }

                        $("#tmplArticle").tmpl(article.filterData(result.data)).appendTo("#articleSortable");
                        $("#articleSortable li .checkbox").prop('checked', true);

                        $('#btnNext').show();
                        $(".selected-row-container").css('border-bottom', '3px solid #468847');
                        $(".selected-row-container").css('margin-bottom', '10px');

                        for (var i = 0; i < result.data.length; i++) {
                            $("#articleUnsortable li.item-" + result.data[i].Id).remove();
                        }
                    }
                } else {
                    console.log(result);
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                //alert(err.error);
            }
        });
    },
    saveSelectedArticles: function () {
        var ids = article.getAllChecked();
        if (!!ids && ids.length > 0) {
            toggleLoading();
            $.ajax({
                url: 'Article/SaveSelectedArticles',
                data: JSON.stringify({ "ids": ids }),
                type: "POST",
                dataType: 'json',
                contentType: "application/json;charset=utf-8",
                success: function (result) {
                    toggleLoading();
                    if (redirectLogin(result)) {
                        return;
                    }
                    if (result.success) {
                        alert('Selected Articles are saved successfully.');
                    } else {
                        console.log(result);
                        alert(result.error);
                    }
                },
                error: function (err) {
                    toggleLoading();
                    if (redirectLogin(err.responseText)) {
                        return;
                    }
                    //alert(err.error);
                }
            });
        }
    },

    changeUser: function () {
        if ($("#divLogo img").length == 0) {
            article.getEmailTemplate(article.users[article.selectedUserIndex++].Id);
            return;
        }
        if (article.selectedUserIndex >= article.users.length - 1) {
            article.selectedUserIndex = 0;
        } else {
            article.selectedUserIndex++;
        }

        var user = article.users[article.selectedUserIndex];
        article.isSelectedCompanyImage = !article.isSelectedCompanyImage;
        article.changeCompanyImage();
        $("#divLogo img").prop('src', '/UploadedLogos/' + user.Logo).css('float', user.LogoPositionTypeName);
        $("#divViewOnline a").css('float', user.LogoPositionTypeName == 'right' ? 'left' : 'right');
        $(".primary-color-background").css({ 'background-color': user.PrimaryColor });
        $(".second-color-background").css({ 'background-color': user.SecondaryColor });
        $(".second-color").css({ 'color': user.SecondaryColor });
        article.showUserSocialIcon('#aGooglePlusLink', user.GooglePlusLink, user.SecondaryColor);
        article.showUserSocialIcon('#aFacebookLink', user.FacebookLink, user.SecondaryColor);
        article.showUserSocialIcon('#aTwitterLink', user.TwitterLink, user.SecondaryColor);
        article.showUserSocialIcon('#aLinkedinLink', user.LinkedinLink, user.SecondaryColor);
        article.showUserSocialIcon('#aWebsiteLink', user.WebsiteLink, user.SecondaryColor);

        !user.LeftFooter ? $("#divFooterLeftFooter").hide() : $("#divFooterLeftFooter").show();
        !user.Address ? $("#divFooterAddress").hide() : $("#divFooterAddress").show();
        !user.ABN ? $("#divFooterABN").hide() : $("#divFooterABN").show();

        $("#divFooterLeftFooter").text(user.LeftFooter);
        $("#divFooterAddress").text(user.Address);
        $("#divFooterABN").text('ABN: ' + user.ABN);
    },

    showUserSocialIcon: function (name, link, color) {
        if (link) {
            var img = $(name).show().prop('href', link).find('img'),
                src = img.prop('src');
            img.prop('src', src.substr(0, src.length - 10) + color.substr(1) + '.png');
        } else {
            $(name).hide();
        }
    },

    //changeSubject: function (that) {
    //    var target = $(that);//.closest('a');
    //    //console.log('changeSubject');
    //    //console.log(that);
    //    article.ArticleTimeout = setTimeout(function () {
    //        target.html(target.attr('data-title')).css('font-style', 'normal');
    //        //target.find('#spanTitle').show();
    //        //target.find('#spanSubject').hide();
    //    }, 1000);
    //},

    //changeTitle: function (that) {
    //    //console.log('changeTitle');
    //    //console.log(that);
    //    if (article.ArticleTimeout) {
    //        clearTimeout(article.ArticleTimeout);
    //    }

    //    var target = $(that);//.closest('a');
    //    target.html(target.attr('data-subject')).css('font-style', 'italic');

    //    //target.find('#spanSubject').show();
    //    //target.find('#spanTitle').hide();
    //},
    showArticleSendHistory: function (id) {
        //	Get first selected id
        //var id = article.getFirstIdChecked();
        article.id = id;
        toggleLoading();
        $.ajax({
            url: 'Article/ArticleSentHistories',
            data: { "id": id },
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                $(".model-content-article .model-title").text("Edit Article");
                if (result.success) {
                    //$('#modalArticleInput').modal({
                    //    show: true
                    //});

                    $(".article-sent-history-detail").html('');
                    $("#tmplArticleSentHistory").tmpl(result.histories).appendTo(".article-sent-history-detail");
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                //alert(err.error);
            }
        });
    },
    setAuthorFromLastArticle: function () {
        toggleLoading();
        $.ajax({
            url: 'Article/GetAuthorFromLastArticle',
            //data: { "id": id },
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    $('#author').val(result.author);
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                //alert(err.error);
            }
        });
    },
    setSiteNameFromLastArticle: function () {
        toggleLoading();
        $.ajax({
            url: 'Article/GetSiteNameFromLastArticle',
            //data: { "id": id },
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    $('#sitename').val(result.siteName);
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                //alert(err.error);
            }
        });
    },
    showSpellfixDictionaryPopup: function () {
        //article.spellfixData = data = [
        //    { Id: 1, CurrentText: 'a, A', ProperText: 'a' },
        //    { Id: 2, CurrentText: 'NSW, nsw', ProperText: 'NSW' },
        //    { Id: 3, CurrentText: 'ATO, ato, Ato', ProperText: 'ATO' },
        //    { Id: 4, CurrentText: 'St. Andrews, st. Andrews, St. Andrews', ProperText: 'St. Andrews' },
        //    { Id: 5, CurrentText: 'Sydney morning herald, Sydney Morning Herald', ProperText: 'SMH' }
        //];
        article.setSpellfixDictionaryData();
        setTimeout(function () {
            $('#modalSpellfixDictionary').modal('show');
        }, 500);
    },
    setTitle: function () {
        toggleLoading();
        $.ajax({
            url: 'Article/GetTitle',
            data: { "title": $('#title').val() },
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    $('#title').val(result.title);
                    article.getTagIds();
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                //alert(err.error);
            }
        });
    },
    setSpellfixDictionaryData: function () {
        toggleLoading();
        $.ajax({
            url: 'Article/GetSpellfixDictionaries',
            //data: { "id": id },
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    article.resetSpellfixDictionaryData();

                    article.spellfixData = result.data;
                    $.each(result.data, function (i, item) {
                        $('#selectCurrentText').append($('<option>', {
                            value: item.Id,
                            text: item.FormatCurrentText,
                            //alt: item.ProperText,
                            title: item.ProperText
                        }));
                    });
                    $('#divSpellfixDictionaryList').html('');
                    $("#tmplSpellfixDictionary").tmpl(result.data).appendTo('#divSpellfixDictionaryList');
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                //alert(err.error);
            }
        });
    },
    currentText_keydown: function (evt) {
        var stroke = (ref = evt.which) != null ? ref : evt.keyCode;
        switch (stroke) {
            case 9:
            case 13:
                setTimeout(function () {
                    $('#properText').focus();
                }, 100);
                break;
        }
    },
    properText_keydown: function (evt) {
        var stroke = (ref = evt.which) != null ? ref : evt.keyCode;
        switch (stroke) {
            //case 9:
            case 13:
                article.saveSpellfixDictionary();
                $(evt.target).blur();
                break;
        }
    },
    editCurrentText: function () {
        $('.select2').hide();
        $('#aEditCurrentText').hide();
        $('#aUndoCurrentText').show();
        $('#currentText').show().focus();
    },
    resetSpellfixDictionaryData: function () {
        $('#buttonSaveSpellfixDictionary').prop('disabled', true);
        $('#aEditCurrentText').hide();
        $('#aUndoCurrentText').hide();
        $('#currentText').val('').hide();
        $('#properText').val('');
        $('.select2').show();
        $('#selectCurrentText').empty();
        $('#selectCurrentText').append($('<option>', {
            value: 0,
            //alt: '',
            title: '',
            text: '---Select Current Text---'
        }));
    },
    undoCurrentText_click: function () {
        $('.select2').show();
        $('#currentText').hide();
        $('#aEditCurrentText').hide();
        $('#aUndoCurrentText').hide();
        article.setCurrentTextValue(0);
    },
    undoCurrentText: function () {
        //$('#currentText').val($('#selectCurrentText option:selected').text()).show();
        if (!!article.newCurrentText) {
            $("#selectCurrentText option[value='" + article.newCurrentText + "']").remove();
        }
        //if ($('#aEditCurrentText').is(":visible")) {
        //    $('#aEditCurrentText').hide();
        //    $('#aUndoCurrentText').hide();
        //    //$('#currentText').val($('#selectCurrentText option:selected').text()).show();
        //    $("#selectCurrentText option[value='" + article.newCurrentText + "']").remove();
        //} else {
        //    $('.select2-container').show();
        //    $('#aEditCurrentText').show();
        //    $('#currentText').hide();
        //    if (article.newCurrentText) {
        //        $('#aUndoCurrentText').show();
        //    } else {
        //        $('#aUndoCurrentText').hide();
        //    }
        //}
    },
    setCurrentTextValue: function (id) {
        $('#selectCurrentText').val(id).trigger('change');
    },
    setSelectedItemSpellfixDictionary: function () {
        var value = $('#selectCurrentText').val();
        if (!value || value == 0) {
            $('#buttonSaveSpellfixDictionary').prop('disabled', true);
        } else {
            $('#buttonSaveSpellfixDictionary').prop('disabled', false);
            article.editCurrentText();
        }
        //setTimeout(function () {
        //    article.editCurrentText();
        //}, 300);

        var option = $('#selectCurrentText option:selected');
        $('#currentText').val(option.text())
        if (option.val() === option.text()) {
            article.newItemSpellfixDictionary(option.text());
            return;
        }
        if (!!article.newCurrentText) {
            article.undoCurrentText();
            article.newCurrentText = '';
        }

        $('#aEditCurrentText').show();
        $('#properText').val(option.attr('title'));
        $('#spellfixDictionaryId').val(value);
    },
    newItemSpellfixDictionary: function (currentText) {
        article.newCurrentText = currentText;
        $('#spellfixDictionaryId').val('');
        $('#properText').val('');
        $('#aEditCurrentText').show();
        $('#aUndoCurrentText').show();
        setTimeout(function () {
            $('#properText').focus();
        }, 300);
    },
    saveSpellfixDictionary: function () {
        if ($('#buttonSaveSpellfixDictionary').prop('disabled')) return;
        //$('#buttonSaveSpellfixDictionary').prop('disabled', true);

        var id = $('#spellfixDictionaryId').val();
        if (!id) {
            id = 0;
        }
        var item = {
            Id: id,
            CurrentText: $('#currentText').val(),
            ProperText: $('#properText').val(),
        };

        toggleLoading();
        $.ajax({
            url: 'Article/CreateSpellfixDictionary',
            data: JSON.stringify({ model: item }),
            type: "POST",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    $('#modalMessage').modal({
                        show: true
                    });
                    setTimeout(function () {
                        $('#modalMessage').modal('hide');
                        $('#modalSpellfixDictionary').modal('hide');
                    }, 1000);
                    //article.setSpellfixDictionaryData();
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                //alert(err.error);
            }
        });
    },
    deleteSpellfixDictionary: function (id) {
        if (confirm("Are you sure want to delete this item?")) {
            toggleLoading();
            $.ajax({
                url: 'Article/DeleteSpellfixDictionary',
                data: { id: id },
                type: "GET",
                dataType: 'json',
                contentType: "application/json;charset=utf-8",
                success: function (result) {
                    toggleLoading();
                    if (redirectLogin(result)) {
                        return;
                    }
                    if (result.success) {
                        //$('#sitename').val(result.siteName);
                        article.setSpellfixDictionaryData();
                    }
                },
                error: function (err) {
                    toggleLoading();
                    if (redirectLogin(err.responseText)) {
                        return;
                    }
                    //alert(err.error);
                }
            });
        }
    },
    updateOrderByDateClick: function (id, changeOrder) {
        if (article.updateOrderByDateClickTimeout) {
            clearTimeout(article.updateOrderByDateClickTimeout);
        }

        //console.log('updateOrderByDateClick 1');
        if (article.isUpdateOrderByDateDblClick) return;
        //console.log('updateOrderByDateClick 2');

        article.updateOrderByDateClickTimeout = setTimeout(function () {
            //console.log('updateOrderByDateClickTimeout 1');
            if (!article.isUpdateOrderByDateDblClick) {
                //console.log('updateOrderByDateClickTimeout 2');
                article.updateOrderByDate(id, changeOrder);
            }
            article.isUpdateOrderByDateDblClick = false;
        }, 500);
    },
    updateOrderByDateDblClick: function (id, changeOrder) {
        //console.log('updateOrderByDateDblClick 1');
        if (article.updateOrderByDateClickTimeout) {
            //console.log('updateOrderByDateDblClick updateOrderByDateClickTimeout 1');
            clearTimeout(article.updateOrderByDateClickTimeout);
        }
        if (article.isUpdateOrderByDateDblClick) return;
        article.isUpdateOrderByDateDblClick = true;
        article.updateOrderByDate(id, changeOrder);
        //console.log('updateOrderByDateClickTimeout 2');
    },
    updateOrderByDate: function (id, changeOrder) {
        //toggleLoading();
        $.ajax({
            url: 'Article/UpdateOrderByDate',
            data: { id: id, changeOrder: changeOrder },
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                //toggleLoading();
                article.isUpdateOrderByDateDblClick = false;
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    $('li.ui-sortable-handle.item-auto-hide').removeClass('item-auto-hide');
                    var li = $('li.item-' + id).addClass('item-auto-hide');
                    
                    if (result.changedItemCount < 0) {                                   
                        if ($('li.item-' + id).length &&
                            $(li.nextAll()[-result.changedItemCount - 1]).length) {   
                            var sortedDate = $('li.item-' + id).data("item-date");
                            if (sortedDate == $(li.nextAll()[-result.changedItemCount - 1]).data("item-date")) {                                
                                var next = $(li.nextAll()[-result.changedItemCount - 1]);

                                if (next.find('div.row.first-item-of-day').length > 0) {
                                    li.find('div.row').addClass("first-item-of-day");
                                    next.find('div.row').removeClass("first-item-of-day");
                                }
                                next.after(li.detach());
                            }
                        }
                    } else if (result.changedItemCount > 0) {                        
                        if (li.find('div.row.first-item-of-day').length > 0) {
                            li.prev().find('div.row').addClass("first-item-of-day");
                            li.find('div.row').removeClass("first-item-of-day");
                        }                        
                        if ($('li.item-' + id).length &&
                            $(li.prevAll()[result.changedItemCount - 1]).length) {      
                            var sortedDate = $('li.item-' + id).data("item-date");
                            if (sortedDate == $(li.prevAll()[result.changedItemCount - 1]).data("item-date")) {                                
                                var prev = $(li.prevAll()[result.changedItemCount - 1]);
                                prev.before(li.detach());
                            }
                        }
                    }
                    //setTimeout(function () {
                    //    $('li.item-' + id).removeClass('item-auto-hide');
                    //}, 1000);
                    //$('#sitename').val(result.siteName);
                    //article.setSpellfixDictionaryData();
                }
            },
            error: function (err) {
                article.isUpdateOrderByDateDblClick = false;
                //toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                //alert(err.error);
            }
        });
    },
    getId: function () {
        if (!article.id || article.id <= 0) {
            if (!article.idAfterPull) return 0;

            return article.idAfterPull;
        }
        return article.id;

    },
    showHideUpOption: function (el, mode) {
        if (mode === "show") {
            setTimeout(function () {
                article.mouse(el);
                $('#showUpInfo').css({ top: toppos, left: leftpos }).fadeIn(100);
               // $("#showUpInfo").show();
            }, 2000)
        } else {
            setTimeout(function () {
                $("#showUpInfo").hide();
            }, 5000)
        }
    },
    showHideDownOption: function (el, mode) {
        if (mode === "show") {
            setTimeout(function () {
                //Calculate the position before showing data to user
                article.mouse(el);
                $('#showDownInfo').css({ top: toppos, left: leftpos }).fadeIn(100);
                //$("#showDownInfo").show();
            }, 2000)
        } else {
            setTimeout(function () {
                $("#showDownInfo").hide();
            }, 5000)
        }
    },

    mouseEvent: function (e) {
        this.x = e.pageX;
        this.y = e.pageY;
    },

    mouse: function (e) {
        var kdheight = $(document).scrollTop();
        this.mouseEvent(e);
        leftpos = this.x + 10;
        toppos =  this.y - kdheight + 10;
    },

    updateOrderByDateWithSpecifiedOrder: function (id, changeOrder) {       
        alert(id);
        article.updateOrderByDate(id, changeOrder);
    }
}
