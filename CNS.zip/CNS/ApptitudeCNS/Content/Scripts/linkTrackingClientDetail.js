﻿var linkTrackingClientDetail = {
    pageIndex: 1,
    pageSize: 100,
    count: 0,
    getListUrl: '',
    isLoadingPage: false,
    sortBy: 'ClickedDate',
    sortTypeBy: 'desc',
    getData: function () {
        if (linkTrackingClientDetail.pageIndex > 1 && (linkTrackingClientDetail.pageIndex - 1) * linkTrackingClientDetail.pageSize >= linkTrackingClientDetail.count) {
            linkTrackingClientDetail.isLoadingPage = false;
            return;
        }
        if (linkTrackingClientDetail.pageIndex == 1) {
            $(".row-body").remove();
        }

        toggleLoading();
        $.ajax({
            url: linkTrackingClientDetail.getListUrl,
            data: { "pageIndex": linkTrackingClientDetail.pageIndex, linkId: linkTrackingClientDetail.linkId, sortByName: linkTrackingClientDetail.sortBy + ' ' + linkTrackingClientDetail.sortTypeBy },
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                linkTrackingClientDetail.isLoadingPage = false;
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    $("#aLink").prop('href', result.url);
                    $("#aLink").text(result.url);
                    linkTrackingClientDetail.count = result.count;
                    linkTrackingClientDetail.pageSize = linkTrackingClientDetail.pageSize;
                    $("#spanCount").text(linkTrackingClientDetail.count);
                    $("#tmpllinkTrackingClientDetail")
                        .tmpl(result.data)
                        .appendTo("#linkTrackingClientDetailGrid");
                }
            },
            error: function (err) {
                toggleLoading();
                linkTrackingClientDetail.isLoadingPage = false;
                if (redirectLogin(err.responseText)) {
                    return;
                } else {
                    alert(err.error);
                }
            }
        });
    },
    onScroll: function (event) {
        if (linkTrackingClientDetail.isLoadingPage || (linkTrackingClientDetail.pageIndex * linkTrackingClientDetail.pageSize >= linkTrackingClientDetail.count)) {
            return;
        }

        var controlHeight = window.innerHeight, //controlHeight = $("#linkTrackingClientDetailGrid")[0].clientHeight,
            linkTrackingClientDetailScrollTop = $('#linkTrackingClientDetailScroll')[0] ? $('#linkTrackingClientDetailScroll')[0].offsetTop : 0,
            scrollTop = window.pageYOffset || document.documentElement.scrollTop;

        if (linkTrackingClientDetailScrollTop <= controlHeight + scrollTop + linkTrackingClientDetailScrollTop * 0.3) {
            linkTrackingClientDetail.isLoadingPage = true;
            linkTrackingClientDetail.pageIndex++;
            linkTrackingClientDetail.getData();
        }
    },

    onSort: function (sortBy) {
        var asc = 'asc', desc = 'desc';
        if (sortBy == linkTrackingClientDetail.sortBy) {
            linkTrackingClientDetail.sortTypeBy = linkTrackingClientDetail.sortTypeBy == asc ? desc : asc;
        } else {
            linkTrackingClientDetail.sortBy = sortBy;
            linkTrackingClientDetail.sortTypeBy = sortBy == 'ClickedDate' ? desc : asc;
        }
        linkTrackingClientDetail.isLoadingPage = true;
        linkTrackingClientDetail.pageIndex = 1;
        $(".row-body").remove();
        linkTrackingClientDetail.getData();
    },
}

