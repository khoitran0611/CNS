﻿var currenPage = 1;
var Profile = {
    logo: '',
    companyImage: ''
};

UploadUserLogo = function () {
    // Checking whether FormData is available in browser
    if (window.FormData !== undefined) {

        var fileUpload = $("#FileUpload").get(0);
        var files = fileUpload.files;

        if (!files || files.length == 0) {
            //alert('Please select a valid picture.')
            return;
        }
        // Create FormData object
        var fileData = new FormData();

        // Looping over all files and add it to FormData object
        for (var i = 0; i < files.length; i++) {
            fileData.append(files[i].name, files[i]);
        }

        // Adding one more key to FormData object
        //fileData.append('username', ‘Manas’);

        toggleLoading();
        $.ajax({
            url: '/User/UploadUserLogo/' + Profile.id,
            type: "POST",
            contentType: false, // Not to set any content header
            processData: false, // Not to process data
            data: fileData,
            success: function (result) {
                $("#FileUpload").val(null);
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                Profile.logo = result.logo;
                SetLogo();
                //$('#hiddenLogoName').val(result.picture);
                //alert(result.message);
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                alert(err.error);
                //if (confirm(err.error + ". Do you want to save without picture or not?")) {
                //    callback();
                //}
            }
        });
    } else {
        alert("FormData is not supported.");
    }
}

SetLogo = function () {
    if (Profile.logo) {
        $('#divLogoContainer').show();
        $('#imgLogo').prop('src', '/UploadedLogos/' + Profile.logo);
        $('#hiddenLogoName').val(Profile.logo);
    } else {
        $('#divLogoContainer').hide();
        $('#hiddenLogoName').val(null);
    }
}

DeleteLogo= function () {
    //	Get first selected id
    //var id = article.getFirstIdChecked();

    //confirm("Are you sure want to delete the picture ?", function (result) {
    if (confirm("Are you sure want to delete this Logo?")) {
        toggleLoading();
        $.ajax({
            url: '/User/DeleteLogo',
            data: { "id": !Profile.id ? 0 : Profile.id, "logoName": $('#hiddenLogoName').val() },
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                $('#hiddenLogoName').val(null);
                $('#divLogoContainer').hide();
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                //alert(err.error);
            }
        });
    }
    //});
}

UploadUserCompanyImage = function () {
    // Checking whether FormData is available in browser
    if (window.FormData !== undefined) {

        var fileUpload = $("#FileUploadCompanyImage").get(0);
        var files = fileUpload.files;

        if (!files || files.length == 0) {
            //alert('Please select a valid picture.')
            return;
        }
        // Create FormData object
        var fileData = new FormData();

        // Looping over all files and add it to FormData object
        for (var i = 0; i < files.length; i++) {
            fileData.append(files[i].name, files[i]);
        }

        // Adding one more key to FormData object
        //fileData.append('username', ‘Manas’);

        toggleLoading();
        $.ajax({
            url: '/User/UploadUserCompanyImage/' + Profile.id,
            type: "POST",
            contentType: false, // Not to set any content header
            processData: false, // Not to process data
            data: fileData,
            success: function (result) {
                $("#FileUploadCompanyImage").val(null);
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                Profile.companyImage = result.companyImage;
                SetCompanyImage();
                //$('#hiddenCompanyImageName').val(result.picture);
                //alert(result.message);
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                alert(err.error);
                //if (confirm(err.error + ". Do you want to save without picture or not?")) {
                //    callback();
                //}
            }
        });
    } else {
        alert("FormData is not supported.");
    }
}

SetCompanyImage = function () {
    if (Profile.companyImage) {
        $('#divCompanyImageContainer').show();
        $('#imgCompanyImage').prop('src', '/UploadedCompanyImages/' + Profile.companyImage);
        $('#hiddenCompanyImageName').val(Profile.companyImage);
    } else {
        $('#divCompanyImageContainer').hide();
        $('#hiddenCompanyImageName').val(null);
    }
}

DeleteCompanyImage = function () {
    //	Get first selected id
    //var id = article.getFirstIdChecked();

    //confirm("Are you sure want to delete the picture ?", function (result) {
    if (confirm("Are you sure want to delete this Primary Image?")) {
        toggleLoading();
        $.ajax({
            url: '/User/DeleteCompanyImage',
            data: { "id": !Profile.id ? 0 : Profile.id, "companyImageName": $('#hiddenCompanyImageName').val() },
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                $('#hiddenCompanyImageName').val(null);
                $('#divCompanyImageContainer').hide();
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                //alert(err.error);
            }
        });
    }
    //});
}

ChangeBpUserLink = function () {
    var value = $('#BpUserId').val();
    if (value) {
        $('#aBpUserLink').show().attr('href', Profile.linkTemplate + value);
    } else {
        $('#aBpUserLink').hide();
    }
}

function SaveUser() {
    var frm = $('#frmUserDetail').serialize();

    $.ajax({
        url: '/User/CreateUser',
        type: 'POST',
        data: frm,
        success: function (data) {
            var isSuccessful = (data['success']);
            var isAdmin = data.isAdmin;
            var url = data.url;

            if (isSuccessful) {
                showModalPopup('Information', 'User has been saved successfully',
                    {
                        Text: "Close", Func: function () {
                            RedirectDefualtSide(isAdmin, url);
                        }
                    }, null);
                clearValidationErrors();
            }
            else {
                var errors = data['errors'];
                displayValidationErrors(errors);
            }
        },
        error: function (err) {
            alert('Cannot save user since ' + err.error);
        }
    });
}

function PreviewSample() {
    var frm = $('#frmUserDetail').serialize();

    $.ajax({
        url: '/User/PreviewSample',
        type: 'POST',
        data: frm,
        success: function (data) {
            var isSuccessful = (data['success']);
            //var isAdmin = data.isAdmin;
            //var url = data.url;

            if (isSuccessful) {
                $('#Id').val(data.id);
                if (data.emailTemplate) {
                    $('#modal').modal();
                    $('#divEmailTemplateReview').html(data.emailTemplate);
                }

                if (data.message) {
                    alert(data.message);
                    //showModalPopup('Warning', data.message,
                    //    {
                    //        Text: "Close"
                    //    }, null);
                } 

                //showModalPopup('Information', 'User has been saved successfully',
                //    {
                //        Text: "Close", Func: function () {
                //            RedirectDefualtSide(isAdmin, url);
                //        }
                //    }, null);
                //if (data.message) {
                //    showModalPopup('Warning', data.message,
                //    {
                //        Text: "Close"
                //    }, null);
                //} else {
                //    RedirectDefualtSide(isAdmin, url);
                //}
                clearValidationErrors();
            } else {
                var errors = data['errors'];
                displayValidationErrors(errors);
            }
        },
        error: function (err) {
            alert('Cannot save user since ' + err.error);
        }
    });
}

function SendSample() {
    var frm = $('#frmUserDetail').serialize();

    $.ajax({
        url: '/User/SendSample',
        type: 'POST',
        data: frm,
        success: function (data) {
            var isSuccessful = (data['success']);
            var isAdmin = data.isAdmin;
            var url = data.url;

            if (isSuccessful) {
                //showModalPopup('Information', 'User has been saved successfully',
                //    {
                //        Text: "Close", Func: function () {
                //            RedirectDefualtSide(isAdmin, url);
                //        }
                //    }, null);
                if (data.message) {
                    alert(data.message);
                    //showModalPopup('Warning', data.message,
                    //    {
                    //        Text: "Close"
                    //    }, null);
                } else {
                    RedirectDefualtSide(isAdmin, url);
                }
                //clearValidationErrors();
            }
            else {
                var errors = data['errors'];
                displayValidationErrors(errors);
            }
        },
        error: function (err) {
            alert('Cannot save user since ' + err.error);
        }
    });
}

function RedirectDefualtSide(isAdmin, url) {
    if (isAdmin) {
        window.location.href = url ? url : '/User/Users';
    }
    else {
        window.location.href = '/';
    }
}

function chkRole_Change(src) {
    var chkRoles = $('.list-role input[type="checkbox"]:checked');
    var ids = '';
    for (var i = 0; i < chkRoles.length; i++) {
        ids = ids + ',' + $(chkRoles[i]).data('role-id');
        //ids.push($(chkRoles[i]).data('role-id'));
    }
    $('#RoleIds').val(ids);

}

function radioBrokerType_Change(that) {
    $("#UserTypeId").val(that.value);
}

TogglePinned = function (source, userHistoryId) {
    $(source).toggleClass('pinned');
    var pinned = $(source).hasClass('pinned');
    var userId = $('#user-id').val();

    $.ajax({
        url: '/User/SetUserHistoryPinned',
        type: 'POST',
        dataType: "json",
        data: { userHistoryId: userHistoryId, pinned: pinned },
        success: function (data) {
            if (data.success) {
                GetUserHistories(userId);
            }
        }
    });
}

GetUserHistories = function (userId) {
    toggleLoading();
    $.ajax({
        url: '/User/GetUserHistories',
        type: 'POST',
        dataType: "json",
        data: { userId: userId },
        success: function (data) {
            if (data.success) {
                $('.user_histories_list').html(data.Html);
            }
        },
        complete: function () {
            toggleLoading();
        }
    });
}



DeleteUserHistory = function (userHistoryId) {
    showModalPopup('Delete Client', 'Do you want to delete ?', null, {
        Text: "Delete", Func: function () {
            var userId = $('#user-id').val();
            $.ajax({
                url: '/User/DeleteHistories',
                type: 'POST',
                dataType: "json",
                data: { userHistoryId: userHistoryId },
                success: function (data) {
                    if (data.success) {
                        GetUserHistories(userId);
                    }
                }
            });
        }
    });
}

EditUserHistory = function (userHistoryId) {
    var clientId = $('#user-id').val();

    toggleLoading();
    $.ajax({
        url: '/User/UserHistory',
        type: 'GET',
        dataType: "json",
        data: { userId: clientId, userHistoryId: userHistoryId },
        success: function (data) {
            if (data.success) {
                closeModalPopup();
                showModalPopup('User History', data.Html, null, { Text: "Save", Func: SaveUserHistory });
            }
        },
        complete: function () {
            toggleLoading();
        }
    });
}

SaveUserHistory = function () {
    var frm = $('#frmUserHistoryDetail').serialize();

    $.ajax({
        url: '/User/UserHistory',
        type: 'POST',
        data: frm,
        success: function (data) {
            var isSuccessful = (data['success']);

            if (isSuccessful) {
                GetUserHistories(data.userId);
            }
            else {
                var errors = data['errors'];
                displayValidationErrors(errors);
            }
        }
    });
}