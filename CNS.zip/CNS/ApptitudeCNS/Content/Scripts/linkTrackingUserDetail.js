﻿var linkTrackingUserDetail = {
    pageIndex: 1,
    pageSize: 100,
    count: 0,
    getListUrl: '',
    isLoadingPage: false,
    sortBy: 'ClickedDate',
    sortTypeBy: 'desc',
    getData: function () {
        if (linkTrackingUserDetail.pageIndex > 1 && (linkTrackingUserDetail.pageIndex - 1) * linkTrackingUserDetail.pageSize >= linkTrackingUserDetail.count) {
            linkTrackingUserDetail.isLoadingPage = false;
            return;
        }
        if (linkTrackingUserDetail.pageIndex == 1) {
            $(".row-body").remove();
        }

        toggleLoading();
        $.ajax({
            url: linkTrackingUserDetail.getListUrl,
            data: { "pageIndex": linkTrackingUserDetail.pageIndex, linkId: linkTrackingUserDetail.linkId, sortByName: linkTrackingUserDetail.sortBy + ' ' + linkTrackingUserDetail.sortTypeBy },
            type: "GET",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                toggleLoading();
                linkTrackingUserDetail.isLoadingPage = false;
                if (redirectLogin(result)) {
                    return;
                }
                if (result.success) {
                    $("#aLink").prop('href', result.url);
                    $("#aLink").text(result.url);
                    linkTrackingUserDetail.count = result.count;
                    linkTrackingUserDetail.pageSize = linkTrackingUserDetail.pageSize;
                    $("#spanCount").text(linkTrackingUserDetail.count);
                    $("#tmpllinkTrackingUserDetail")
                        .tmpl(result.data)
                        .appendTo("#linkTrackingUserDetailGrid");
                }
            },
            error: function (err) {
                toggleLoading();
                linkTrackingUserDetail.isLoadingPage = false;
                if (redirectLogin(err.responseText)) {
                    return;
                } else {
                    alert(err.error);
                }
            }
        });
    },
    onScroll: function (event) {
        if (linkTrackingUserDetail.isLoadingPage || (linkTrackingUserDetail.pageIndex * linkTrackingUserDetail.pageSize >= linkTrackingUserDetail.count)) {
            return;
        }

        var controlHeight = window.innerHeight, //controlHeight = $("#linkTrackingUserDetailGrid")[0].clientHeight,
            linkTrackingUserDetailScrollTop = $('#linkTrackingUserDetailScroll')[0] ? $('#linkTrackingUserDetailScroll')[0].offsetTop : 0,
            scrollTop = window.pageYOffset || document.documentElement.scrollTop;

        if (linkTrackingUserDetailScrollTop <= controlHeight + scrollTop + linkTrackingUserDetailScrollTop * 0.3) {
            linkTrackingUserDetail.isLoadingPage = true;
            linkTrackingUserDetail.pageIndex++;
            linkTrackingUserDetail.getData();
        }
    },

    onSort: function (sortBy) {
        var asc = 'asc', desc = 'desc';
        if (sortBy == linkTrackingUserDetail.sortBy) {
            linkTrackingUserDetail.sortTypeBy = linkTrackingUserDetail.sortTypeBy == asc ? desc : asc;
        } else {
            linkTrackingUserDetail.sortBy = sortBy;
            linkTrackingUserDetail.sortTypeBy = sortBy == 'ClickedDate' ? desc : asc;
        }
        linkTrackingUserDetail.isLoadingPage = true;
        linkTrackingUserDetail.pageIndex = 1;
        $(".row-body").remove();
        linkTrackingUserDetail.getData();
    },
}

