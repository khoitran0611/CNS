﻿var articleBroker = {
    Validate: function (id, status) {
        var link = $('#link').val();
        if (!link && !$('#brokerMessage').val()) {
            $('#labelMessage').show();
            $('#labelMessage').text('Please enter Link or Broker Message');  
            return;
        }
        id = $('#id').val();
        articleBroker.CheckExistLink(id, link);
    },
    CheckExistLink: function (id, link) {
        toggleLoading();
        $.ajax({
            url: '/Article/CheckExistLink',// + '?filename=' + filename,
            type: 'POST',
            data: { "id": id, "link": link },
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }

                $('#labelMessage').hide();
                if (result != "true") {
                    $('#labelMessage').show().css({ 'color': 'red' });
                    $('#labelMessage').text(result);
                } else {
                    $('#labelMessage').text(null);
                    articleBroker.SaveData();
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                console.log(err);
                //bootbox.alert("Can't retrieve the data");
                //alert("Can't save the data");
            }
        });
    },
    SaveData: function () {
        toggleLoading();
        $.ajax({
            url: '/Article/Broker',// + '?filename=' + filename,
            type: 'POST',
            data: $('#frm').serialize(),
            success: function (result) {
                toggleLoading();
                if (redirectLogin(result)) {
                    return;
                }
                //showModalPopup('Information', 'Article has been saved successfully',
                //    {
                //        Text: "Close", Func: function () {
                //            $('#labelMessage').show().css({ 'color': 'blue' });
                //            $('#labelMessage').text('Saved data successfully.');
                //        }
                //    }, null);

                if (result.success) {
                    if (!result.id) {
                        result.id = 0;
                    }
                    $('#id').val(result.id);
                    showModalPopup('Information', 'Article has been saved successfully',
                        {
                            Text: "Close", Func: function () {
                                $('#labelMessage').show().css({ 'color': 'blue' });
                                $('#labelMessage').text('Save data successfully.');
                            }
                        }, null);

                } else {
                    alert(result.error);
                    location.reload(true);
                }
            },
            error: function (err) {
                toggleLoading();
                if (redirectLogin(err.responseText)) {
                    return;
                }
                console.log(err);
                //bootbox.alert("Can't retrieve the data");
                alert("Can't save the data");
            }
        });
    },
    DeleteData: function (id) {
        if (!id || id <= 0) {
            $('#link').val('');
            $('#brokerMessage').val('');
            return;
        }
        //confirm("Are you sure want to delete this article ?", function (result) {
        if (confirm("Are you sure want to delete this article ?")) {
            toggleLoading();
            $.ajax({
                url: '/Article/DeleteBroker',
                data: { "id": id },
                type: "GET",
                dataType: 'json',
                contentType: "application/json;charset=utf-8",
                success: function (result) {
                    toggleLoading();
                    $('#id').val('0');
                    $('#link').val('');
                    $('#brokerMessage').val('');
                    //$('#labelMessage').show();
                    //$('#labelMessage').text('');
                    //location.reload();
                    //if (data != null) {
                    //    article.reloadPage();
                    //}
                },
                error: function (err) {
                    toggleLoading();
                    if (redirectLogin(err.responseText)) {
                        return;
                    }
                    //alert(err.error);
                }
            });
        }
    },
}

