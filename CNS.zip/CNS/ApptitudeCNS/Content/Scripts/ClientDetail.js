﻿$(document).ready(function () {
    var date = $(".client_birthday").val();
    var year = (new Date()).getFullYear();
    $(".client_birthday").datepicker
        ({
            dateFormat: 'dd/mm/yy',
            showStatus: true,
            showWeeks: true,
            highlightWeek: true,
            changeMonth: true,
            changeYear: true,
            yearRange: '1900:' + year,
            numberOfMonths: 1,
            showAnim: "scale",
            showOptions: {
                origin: ["top", "left"]
            }
        }).val(date);

    ///For the create user and profile page
    $('.email-subscribe , .sms-subscribe').tristate({
        checked: true,
        unchecked: false,
        indeterminate: null,
        change: function (state, value) {
            var id = $(this).data("hidden-val");
            $('#' + id).val(state);
        }
    });

    $('#FirstName').blur(function () {
        if (!$("#Salutation").val()) {
            $("#Salutation").val($('#FirstName').val());
        }        
    });
});

SaveClient = function () {
    //var frm = new FormData($('#frmClientDetail')[0]);
    var frm = $('#frmClientDetail').serialize();

    $.ajax({
        url: '/Client/ClientDetail',
        type: 'POST',
        data: frm,
        success: function (data) {
            var isSuccessful = (data['success']);

            if (isSuccessful) {
                //showModalPopup('Information', 'Client has been saved successfully', null, null);
                alert('Client has been saved successfully')

                location.reload();
            }
            else {
                var errors = data['errors'];
                displayValidationErrors(errors);
            }
        }
    });
}

SetEmailStatus = function (that, id) {
    var div = $(that).closest('div');
    if (!div.hasClass('email-status-disabled')) {
        $('.email-status').removeClass('email-status-selected');
        div.addClass('email-status-selected');
        $('#EmailSubscribe').val(id);
    }
}

TogglePinned = function (source, clientHistoryId) {
    $(source).toggleClass('pinned');
    var pinned = $(source).hasClass('pinned');
    var clientId = $('#client-id').val();

    $.ajax({
        url: '/Client/SetClientHistoryPinned',
        type: 'POST',
        dataType: "json",
        data: { clientHistoryId: clientHistoryId, pinned: pinned },
        success: function (data) {
            if (data.success) {
                GetClientHistories(clientId);
            }
        }
    });
}

GetClientHistories = function (clientId) {
    toggleLoading();
    $.ajax({
        url: '/Client/GetClientHistories',
        type: 'POST',
        dataType: "json",
        data: { clientId: clientId },
        success: function (data) {
            if (data.success) {
                $('.client_histories_list').html(data.Html);
            }
        },
        complete: function () {
            toggleLoading();
        }
    });
}

DeleteClientHistory = function (clientHistoryId) {
    showModalPopup('Delete Client', 'Do you want to delete ?', null, {
        Text: "Delete", Func: function () {
            var clientId = $('#client-id').val();
            $.ajax({
                url: '/Client/DeleteHistories',
                type: 'POST',
                dataType: "json",
                data: { clientHistoryId: clientHistoryId },
                success: function (data) {
                    if (data.success) {
                        GetClientHistories(clientId);
                    }
                }
            });
        }
    });
}

EditClientHistory = function (clientHistoryId) {
    var clientId = $('#client-id').val();

    toggleLoading();
    $.ajax({
        url: '/Client/ClientHistory',
        type: 'GET',
        dataType: "json",
        data: { clientId: clientId, clientHistoryId: clientHistoryId },
        success: function (data) {
            if (data.success) {
                closeModalPopup();
                showModalPopup('Client History', data.Html, null, { Text: "Save", Func: SaveClientHistory });
            }
        },
        complete: function () {
            toggleLoading();
        }
    });
}

SaveClientHistory = function () {
    var frm = $('#frmClientHistoryDetail').serialize();

    $.ajax({
        url: '/Client/ClientHistory',
        type: 'POST',
        data: frm,
        success: function (data) {
            var isSuccessful = (data['success']);

            if (isSuccessful) {
                GetClientHistories(data.clientId);
            }
            else {
                var errors = data['errors'];
                displayValidationErrors(errors);
            }
        }
    });
}

ShowMailTrackingDetail = function (mailTrackingId) {
    toggleLoading();
    $.ajax({
        url: '/MailTracking/GetEmailContent',
        data: { id: mailTrackingId },
        type: "GET",
        dataType: 'json',
        contentType: "application/json;charset=utf-8",
        success: function (result) {
            toggleLoading();
            if (redirectLogin(result)) {
                return;
            }
            if (result.success) {
                //$('#modal').modal();
                $(".modal-body").html(result.data);
                //showModalPopup('Mail Content', result.data, null, null);
            }
        },
        error: function (err) {
            toggleLoading();
            mailTracking.isLoadingPage = false;
            if (redirectLogin(err.responseText)) {
                return;
            } else {
                alert(err.error);
            }
        }
    });
}
