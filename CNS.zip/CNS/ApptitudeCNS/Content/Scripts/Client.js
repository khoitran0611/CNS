﻿var SortAndPagging = { pageIndex: 1, sortFieldName: '', orderBy: '', filterModel: { SearchText: '', ClientFilterType: 0, SearchLevel: 0, UserId: 0, EmailSubscribes: [1] } }
var Client = {};

RegisterChkTristate = function () {

    $('.email-subscribe , .sms-subscribe').tristate({
        checked: true,
        unchecked: false,
        indeterminate: null,
        change: function (state, value) {
            var $clientItem = $(this).parents('.row.list-items');
            var clientId = $clientItem.data('client-id');
            var email = $clientItem.find('.email-subscribe').val();
            var sms = $clientItem.find('.sms-subscribe').val();

            $.ajax({
                url: '/Client/UpdateEmailAndSmsSubscribe',
                type: 'POST',
                data: { clientId: clientId, email: email, sms: sms },
                success: function (data) {
                    var isSuccessful = (data['success']);

                    if (!isSuccessful) {
                        alert('Error :' + data.Message);
                    }
                }
            });
        }
    });
}

EditClient = function (target, clientId) {
    $.ajax({
        url: '/Client/ClientDetail',
        type: 'GET',
        data: { clientId: clientId },
        success: function (data) {
            showModalPopup('Edit Client', data, null, { Text: "Save", Func: SaveClient, KeepOpen: true });
            $('#frmClientDetail .email-subscribe ,#frmClientDetail .sms-subscribe').tristate({
                checked: true,
                unchecked: false,
                indeterminate: null,
                change: function (state, value) {
                    var id = $(this).data("hidden-val");
                    $('#frmClientDetail #' + id).val(state);
                }
            });

            var year = (new Date()).getFullYear();
            $("#frmClientDetail .datePicker").datepicker
                ({
                    dateFormat: 'dd/mm/yy',
                    showTimepicker: false,
                    viewMode: 'days',
                    showStatus: true,
                    showWeeks: true,
                    highlightWeek: true,
                    changeMonth: true,
                    changeYear: true,
                    yearRange: '1900:' + year,
                    numberOfMonths: 1,
                    showAnim: "scale",
                    showOptions: {
                        origin: ["top", "left"]
                    }
                });

            $('#FirstName').blur(function () {
                if (!$("#Salutation").val()) {
                    $("#Salutation").val($('#FirstName').val());
                }
            });
        }
    });
}

SaveClient = function () {

    var frm = $('#frmClientDetail').serialize();

    $.ajax({
        url: '/Client/ClientDetail',
        type: 'POST',
        data: $('#frmClientDetail').serialize(),
        success: function (data) {
            var isSuccessful = (data['success']);

            if (isSuccessful) {
                closeModalPopup();
                alert('Client has been saved successfully')
                //showModalPopup('Information', 'User has been saved successfully', null, null);
                GetClient(1, '', SortAndPagging.orderBy, SortAndPagging.filterModel, true);
            }
            else {
                var errors = data['errors'];
                displayValidationErrors(errors);
            }
        }
    });
}

SetEmailStatusFilter = function (that, id) {
    var div = $(that).closest('div'),
        index = SortAndPagging.filterModel.EmailSubscribes.indexOf(id);
    if (index >= 0) {
        div.removeClass('email-status-selected');
        SortAndPagging.filterModel.EmailSubscribes.splice(index, 1);
    } else {
        div.addClass('email-status-selected');
        SortAndPagging.filterModel.EmailSubscribes.push(id);
    }
    GetClient(1, SortAndPagging.sortFieldName, SortAndPagging.orderBy, SortAndPagging.filterModel, true);
}

SetEmailStatus = function (that, id) {
    var div = $(that).closest('div');

    if (!div.hasClass('email-status-disabled')) {
        $('.client-detail .email-status').removeClass('email-status-selected');
        div.addClass('.client-detail email-status-selected');
        $('#EmailSubscribe').val(id);
    }
}

DeleteClient = function (clientId) {
    showModalPopup('Delete User', 'Do you want to delete ?', null, {
        Text: "Delete", Func: function () {
            $.ajax({
                url: '/Client/Delete',
                type: 'POST',
                dataType: "json",
                data: { id: clientId },
                success: function (data) {
                    if (data.Status) {
                        //refresh the user list
                        GetClient(
                            1,
                            SortAndPagging.sortFieldName,
                            SortAndPagging.orderBy,
                            SortAndPagging.filterModel,
                            true);
                    }
                },
                error: function (err) {
                    alert('Cannot delete client since ' + err.error);
                }
            });
        }
    });



}

SearchClient = function () {
    var $filterItems = $('.filter-items');

    var currentSearchText = $filterItems.find('.search-text').val();
    var preSearchText = SortAndPagging.filterModel.SearchText;

    SortAndPagging.filterModel.ClientFilterType = $filterItems.find('.client-type').val();


    if (currentSearchText == preSearchText && currentSearchText != '') {
        SortAndPagging.filterModel.SearchLevel = 1;
    } else {
        SortAndPagging.filterModel.SearchLevel = 0;
    }

    SortAndPagging.filterModel.SearchText = currentSearchText;
    GetClient(1, SortAndPagging.sortFieldName, SortAndPagging.orderBy, SortAndPagging.filterModel, true, function () {
        Client.clickedSearch = true;
        $('#buttonSearch').html("Search Further");
        //if (SortAndPagging.filterModel.SearchText != '') {
        //    $filterItems.find('.search-level').removeClass('hidden');
        //}
        //else {
        //    $filterItems.find('.search-level').addClass('hidden')
        //}
    });
}

ChangeSearchText = function () {
    //catchEnterKey(event, SearchClient);

    if (!Client.clickedSearch) return;

    var $filterItems = $('.filter-items');
    var currentSearchText = $filterItems.find('.search-text').val();
    var preSearchText = SortAndPagging.filterModel.SearchText;
    if (currentSearchText.trim() == preSearchText.trim()) {
        $('#buttonSearch').html("Search Further");
    } else {
        $('#buttonSearch').html("Search");
    }
}

GetClient = function (pageIndex, sortFieldName, orderBy, clientFilter, isForceRefresh, successFunc) {
    toggleLoading();
    $.ajax({
        url: '/Client/GetClients',
        type: 'POST',
        dataType: "json",
        data: { pageIndex: pageIndex, sortFieldName: sortFieldName, orderBy: orderBy, filter: clientFilter },
        success: function (data) {
            if (data.Status) {
                if (successFunc != null && typeof successFunc === 'function') {
                    successFunc();
                }
                var $clientsPanel = $('#client_list');
                if (isForceRefresh) {
                    $clientsPanel.find('.row.list-items').remove();
                }
                $clientsPanel.append(data.Html);
                SortAndPagging.pageIndex = pageIndex;
                SortAndPagging.sortFieldName = sortFieldName;
                SortAndPagging.orderBy = orderBy;
                SortAndPagging.count = data.TotalItem;
                SortAndPagging.pageSize = data.PageSize;
                RegisterChkTristate();
                $('.total-item .items').html(data.TotalItem);
            }
        },
        complete: function () {
            Client.isLoadingPage = false;
            toggleLoading();
        }

    });
}

sortByHeader = function (target) {
    var $target = $(target);
    var pageIndex = 1;
    var sortFieldName = $target.data('field-name');
    var orderBy = $target.data('order-by');
    var clientFilter = SortAndPagging.filterModel;

    GetClient(pageIndex, sortFieldName, orderBy, clientFilter, true, function () {
        orderBy == 'asc' ? $target.data('order-by', 'desc') : $target.data('order-by', 'asc');
    })
}

ShowClientDetail = function (clientId) {
    showModalPopup('Client Detail', 'TO BE CONTINUE', null, null);
}

SendMassEmail = function () {
    var selectedClient = $('#client_list').find('.mass-email:checked');
    if (selectedClient.length > 0) {
        var $massEmail = $('.mass-email-container').clone();
        $massEmail.find('.mass-email-panel').addClass('popup');
        $massEmail.find('input , textarea').val('');
        //$massEmail.find('textarea').text(data.user.BrokerMessage != null ? data.user.BrokerMessage : '');
        $massEmail.find('textarea').text('');
        showModalPopup('Send Mass Email', $massEmail.html(), null, { Text: "Send", Func: CreateMassEmails }, CreateSendMassEmailInterface);

        //$.ajax({
        //    url: '/Client/GetCurrentUser',
        //    type: 'GET',
        //    dataType: "json",
        //    success: function (data) {
        //        if (data.success) {
        //            var $massEmail = $('.mass-email-container').clone();
        //            $massEmail.find('.mass-email-panel').addClass('popup');
        //            $massEmail.find('input , textarea').val('');
        //            //$massEmail.find('textarea').text(data.user.BrokerMessage != null ? data.user.BrokerMessage : '');
        //            $massEmail.find('textarea').text('');
        //            showModalPopup('Send Mass Email', $massEmail.html(), null, { Text: "Send", Func: CreateMassEmails }, CreateSendMassEmailInterface);
        //        }
        //    },
        //    complete: function () {
        //        toggleLoading();
        //    }
        //});
    }
}

CreateSendMassEmailInterface = function () {
    $(".mass-email-panel.popup .datePicker.date").datepicker
        ({
            dateFormat: 'dd/mm/yy',
            showStatus: true,
            showWeeks: true,
            highlightWeek: true,
            numberOfMonths: 1,
            showAnim: "scale",
            showOptions: {
                origin: ["top", "left"]
            }
        })
    //$(".mass-email-panel.popup .datePicker.time").datetimepicker
    //    ({
    //        format: 'HH:mm'
    //    })
    $(".mass-email-panel.popup .datePicker.date").val(moment(new Date()).format("DD/MM/YYYY"));
    $(".mass-email-panel.popup .datePicker.time").val(moment(new Date()).format("HH:mm"));

    //Get list client email un subscribe
    var selectedClient = $('#client_list').find('.mass-email:checked');
    var clientIds = [];
    var clientUnSubscribe = [];
    for (var i = 0; i < selectedClient.length; i++) {
        var $clientItem = $(selectedClient[i]).parents('.list-items');
        var emailSubscribe = $clientItem.find('.fa-check-circle').length > 0;
        if (emailSubscribe == true) {
            var id = $clientItem.data('client-id');
            clientIds.push(id);
        }
        else {
            var name = $clientItem.find('.full-name').html();
            clientUnSubscribe.push(name);
        }

        if (clientUnSubscribe.length > 0) {
            $('.mass-email-panel.popup .warning-client-unsubscribe').html(clientUnSubscribe.join() + ' unsubscribe(s) email.Other clients should receive the email');
        }

        $('.mass-email-panel.popup .hidden-data').data('selected-ids', clientIds);
    }

}

CreateMassEmails = function () {
    var clientIds = $('.mass-email-panel.popup .hidden-data').data('selected-ids');

    var $massEmail = $('.mass-email-panel.popup');
    var subject = $massEmail.find('.subject-text').val();
    var content = $massEmail.find('.content-text').val();
    var isNow = $massEmail.find('.is-now').is(":checked");
    var scheduleDate = $(".mass-email-panel.popup .datePicker.date").val() + " " + $(".mass-email-panel.popup .datePicker.time").val();

    toggleLoading();
    $.ajax({
        url: '/Client/SendMassEmail',
        type: 'POST',
        dataType: "json",
        data: { subject: subject, content: content, clientIds: clientIds, isNow: isNow, scheduleDate: scheduleDate },
        success: function (data) {
            if (data.success) {
                closeModalPopup();
                showModalPopup("Information", "The email is added to system sending schedule successfully.", null, null, null);
            }
        },
        complete: function () {
            toggleLoading();
        }
    });
}

chkMassAllEmails = function (targer) {
    $('#client_list input.mass-email[type="checkbox"]').prop('checked', $(targer).prop('checked'));
}

FilterClientTypeChange = function () {
    var $filterItems = $('.filter-items');

    SortAndPagging.filterModel.ClientFilterType = $filterItems.find('.client-type').val();

    GetClient(1, SortAndPagging.sortFieldName, SortAndPagging.orderBy, SortAndPagging.filterModel, true);
}

ToggleScheduleDate = function () {
    var $scheduleDate = $('.mass-email-panel.popup .schedule-date');
    if (typeof $scheduleDate !== 'undefined' && $scheduleDate != null) {
        $scheduleDate.toggleClass('hidden');
    }
}

FilterByUser = function (target) {
    var userId = $(target).val();
    SortAndPagging.filterModel.UserId = userId;
    GetClient(1, SortAndPagging.sortFieldName, SortAndPagging.orderBy, SortAndPagging.filterModel, true);
}
