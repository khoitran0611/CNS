﻿/*
* jQuery UI Image Gallery!
*
* @version v1.0 (09/2018)
*/
(function ($) {

    $.widget('ui.imageGallery', {
        options: {
            selectedIndex: 0,
            viewIndex: 0,
            source: [],
            iconPrev: '<i class="fas fa-caret-left" style="font-size: 48px;"></i>',
            iconNext: '<i class="fas fa-caret-right" style="font-size: 48px;"></i>',
            iconAdd: '<i class="fas fa-plus" style="font-size: 32px;"></i>',
            iconList: '<i class="far fa-folder-open" style="font-size: 24px;"></i>',
            addImageFunc: null,
            onImageChanged: null,
            onOpenList: null,
            itemTemplateName: '#tmplPrimaryImage',
            itemWidth: 92,
        },

        _create: function () {
            // for handling static scoping inside callbacks
            var that = this;
            this.prevElement = '<div class="image-gallery-prev"><a href="javascript:void(0)">' + this.options.iconPrev + '</a></div>';
            this.nextElement = '<div class="image-gallery-next"><a href="javascript:void(0)">' + this.options.iconNext + '</a></div>';
            this.openListElement = '<div class="image-gallery-open-list"><a data-toggle="modal" href="#modalPrimaryImage" >' + this.options.iconList + '</a></div>';
            //this.addElement = '<div class="image-gallery-add"><a href="#" class="dropdown-toggle" role="button" id="dropdownPrimaryImageMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">' + this.options.iconAdd + '</a>' +
            //    '<ul class="dropdown-menu" id="divPrimaryImageMenu" aria-labelledby="dropdownPrimaryImageMenuLink">' +
            //    '  <li class="dropdown-item"><a href="javascript:void(0)">Add Primary Image</a></li>' +
            //    '</ul></div >';
            this.addElement = '<div class="image-gallery-add"><a href="javascript:void(0)">' + this.options.iconAdd + '</a>';
            this.imageList = $('<div class="image-gallery-list-container"><ul class="image-gallery-list"></ul></div>');

            this.element
                .append(this.prevElement)
                .append(this.addElement)
                .append(this.imageList)
                .append(this.nextElement)
                .append(this.openListElement)
                .append('<div style="clear:both;"></div>')
                .addClass('image-gallery')
                .addClass('ui-widget ui-widget-content ui-corner-all')
                .on('click', 'div.image-gallery-prev a', function (e) {
                    if (!that.options.source || that.options.viewIndex == 0) return;

                    that.options.viewIndex -= 5;
                    that._showData();
                }).on('click', 'div.image-gallery-next a', function (e) {
                    if (!that.options.source || that.options.viewIndex + 5 >= that.options.source.length) return;

                    that.options.viewIndex += 5;
                    that._showData();
                //}).on('click', 'div.image-gallery-add ul.dropdown-menu li a', function (e) {
                }).on('click', 'div.image-gallery-open-list a', function (e) {
                    if (typeof that.options.onOpenList === 'function') {
                        that.options.onOpenList(that.options.source[that.options.selectedIndex].Id);
                    }
                //}).on('click', 'div.image-gallery-add ul.dropdown-menu li a', function (e) {
                }).on('click', 'div.image-gallery-add a', function (e) {
                    if (typeof that.options.addImageFunc === 'function') {
                        that.options.addImageFunc(true);
                    }
                }).on('click', 'div.image-gallery-list-container ul.image-gallery-list li', function (e) {
                    var target = $(e.target).closest('li');
                    var id = parseInt(target.attr('data-id'));
                    that.options.selectedIndex = that._getIndex(id);
                    that.selectItem(that.options.selectedIndex);
                    
                    if (typeof that.options.onImageChanged === 'function') {
                        that.options.onImageChanged(that.options.source[that.options.selectedIndex]);
                    }
                }).on('mouseenter', 'div.image-gallery-list-container ul.image-gallery-list li img', function (e) {
                    var target = $(e.target).closest('li');
                    var maxWidth = 92 * 5;
                    if (that.options.viewIndex <= that.options.selectedIndex && that.options.viewIndex + 4 >= that.options.selectedIndex) {
                        maxWidth = 472;
                    }

                    if (!target.hasClass('selected-image-item')) {
                        maxWidth += 12;
                    } 
                    that.imageList.css({ maxWidth: maxWidth - 3 })
                }).on('mouseleave', 'div.image-gallery-list-container ul.image-gallery-list li img', function (e) {
                    var target = $(e.target).closest('li');
                    var maxWidth = 92 * 5;
                    if (that.options.viewIndex <= that.options.selectedIndex && that.options.viewIndex + 4 >= that.options.selectedIndex) {
                        maxWidth = 472;
                    }
                    that.imageList.css({ maxWidth: maxWidth - 3 })
                });    

            this.imageList.css({ width: this.options.itemWidth * this.options.source.length + 24 });
            $(this.options.itemTemplateName).tmpl(this.options.source).appendTo(this.imageList.find('ul').html('').css({ width: this.options.itemWidth * this.options.source.length + 24 }));
            this.selectItem(this.options.selectedIndex);

            this.imageList.find('ul').addClass('ui-widget ui-widget-content ui-corner-all');
        },
        addNewItem: function (item) {
            if (this.options.source && this.options.source.length > 0) {
                this.options.selectedIndex++;
            }
            this.options.source.unshift(item);
            this.source(this.options.source)
        },
        source: function (source, index) {
            // No value passed, act as a getter.
            if (source === undefined) {
                return this.options.source;

                // Value passed, act as a setter.
            } else {
                this.options.source = source;
                if (index >= 0) {
                    this.options.selectedIndex = index;
                    this.options.viewIndex = 5 * Math.floor(index / 5);
                } else {
                    this.options.selectedIndex = 0;
                    this.options.viewIndex = 0;
                }
                this.imageList.css({ width: this.options.itemWidth * this.options.source.length + 24 });
                //var list = this.imageList.find('ul').html('');
                $(this.options.itemTemplateName).tmpl(this.options.source).appendTo(this.imageList.find('ul').html('').css({ width: this.options.itemWidth * this.options.source.length + 24 }));
                this.selectItem(this.options.selectedIndex);

                if (typeof this.options.onImageChanged === 'function') {
                    this.options.onImageChanged(this.options.source[this.options.selectedIndex]);
                }
            }
        },
        selectItem(selectedIndex) {
            if (!this.options.source || this.options.source.length == 0) return;

            var item = this.options.source[selectedIndex];
            this.imageList.find('ul li').removeClass('selected-image-item')
            this.imageList.find('ul li#item-' + item.Id).addClass('selected-image-item');
            this._showData();
        },
        getSelectedItem() {
            if (!this.options.source || this.options.source.length == 0) return null;
            return this.options.source[this.options.selectedIndex];
        },
        _showData: function () {
            var selectedWidth = 0, maxWidth = 92 * 5;
            if (this.options.viewIndex <= this.options.selectedIndex && this.options.viewIndex + 4 >= this.options.selectedIndex) {
                maxWidth = 472;
            } else if (this.options.viewIndex > 0 && this.options.viewIndex > this.options.selectedIndex) {
                selectedWidth = 12;
            }
            this.imageList.css({ maxWidth: maxWidth - 3 }).find('ul').css({ left: -(selectedWidth + this.options.viewIndex * this.options.itemWidth) });
        },
        _getIndex: function (id) {
            for (var i = 0; i < this.options.source.length; i++) {
                if (this.options.source[i].Id == id) {
                    return i;
                }
            }
            return -1;
        },
        destroy: function () {
            $.Widget.prototype.destroy.call(this);
            this.element.removeData('imageGallery').html('');
            return this;
        },
    });
})(jQuery);