﻿$(document).ready(function () {
    $.ajaxSetup({ cache: false, timeout: 0 });
    $('.fieldset-header').bind("click", function () {
        $(this).next().slideToggle("slow");
    });

});

///Show the information message
function showModalPopup(heading, formContent, CloseButton, OkButton, FuncCallBack) {
    html = '<div id="dynamicModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="confirm-modal" aria-hidden="true">';
    html += '<div class="modal-dialog">';
    html += '<div class="modal-content">';
    html += '<div class="modal-header">';
    html += '<a class="close" data-dismiss="modal">x</a>';
    html += '<div class="modal-title">' + heading + '</div>'
    html += '</div>';
    html += '<div class="modal-body">';
    html += formContent;
    html += '</div>';
    html += '<div class="modal-footer">';
    if (OkButton !== null && typeof OkButton !== 'undefined') {
        var keep_open = 'data-dismiss="modal"';
        if (OkButton.KeepOpen == true) {
            keep_open = '';
        }
        html += '<button type="button" class="btn ok" ' + keep_open + '>' + OkButton.Text + '</button>';
    }
    if (CloseButton !== null && typeof CloseButton !== 'undefined') {
        html += '<button type="button" class="btn cancel" data-dismiss="modal">' + CloseButton.Text + '</button>';
    }
    else {
        html += '<button type="button" class="btn cancel" data-dismiss="modal">Close</button>';
    }

    html += '</div>';  // content
    html += '</div>';  // dialog
    html += '</div>';  // footer
    html += '</div>';  // modalWindow
    $('body').append(html);
    var $dynamicModal = $("#dynamicModal");
    var modal = $dynamicModal.modal();
    //$dynamicModal.modal('show');

    if (typeof FuncCallBack !== 'undefined' && typeof FuncCallBack === "function") {
        FuncCallBack();
    }

    $dynamicModal.on('hidden.bs.modal', function (e) {
        $(this).remove();
    });

    if (CloseButton != null && typeof CloseButton !== 'undefined' && typeof CloseButton.Func === "function") {
        $($dynamicModal.find('.btn.cancel')[0]).bind({
            'click': function () {
                CloseButton.Func();
            }
        });
    }

    if (OkButton != null && typeof OkButton !== 'undefined' && typeof OkButton.Func === "function") {
        $($dynamicModal.find('.btn.ok')[0]).bind({
            'click': function () {
                OkButton.Func();
            }
        });
    }
    return modal;
}

function closeModalPopup() {
    //var $dynamicModal = $("#dynamicModal");
    //$dynamicModal.modal('hide');
    //$("#dynamicModal .btn.cancel").click();
    if ($('#dynamicModal').length > 0) {
        $('#dynamicModal').remove();
    }
    if ($('.modal-backdrop').length > 0) {
        $('.modal-backdrop').remove();
    }
    $("body").removeClass("modal-open");
}

function GetCheckedBoxTristate(val) {
    if (val != null) {
        return val.Value ? "checked=checked" : string.Empty;
    } else {
        return "indeterminate=1";
    }
}

function toggleLoading(message) {
    $("#overlay").toggle();
    if (message) {
        $(".loader-message").show();
        $(".loader-message .message").text(message);
        $("#overlay .loader").hide();
    } else {
        $(".loader-message").hide();
        $(".loader-message .message").text('');
        $("#overlay .loader").show();
    }
}

function displayValidationErrors(errors) {
    var $ul = $('div.validation-summary-valid.text-danger > ul');

    $ul.empty();
    if (!errors) return;

    $.each(errors, function (idx, errorMessage) {
        $ul.append('<li>' + errorMessage + '</li>');
    });
}
function clearValidationErrors() {
    var $ul = $('div.validation-summary-valid.text-danger > ul');

    $ul.empty();


} function clearValidationErrors() {
    var $ul = $('div.validation-summary-valid.text-danger > ul');

    $ul.empty();
}

function redirectLogin(responseText) {
    if (responseText && typeof responseText.indexOf === 'function' && responseText.indexOf('<html>') > 0 && responseText.indexOf('Login') > 0) {
        location.reload();
        return true;
    }
    return false;
}

function RedirectDefualtSide(isAdmin) {
    if (isAdmin) {
        window.location.href = '/User/Users';
    }
    else {
        window.location.href = '/';
    }
}
var ctrlPress = false;
function catchEnterKey(event, callback) {
    if (event.keyCode == '13' && typeof callback === 'function') {
        callback();
    } 
    //Ctrl+V + URL
    if (ctrlPress && event.keyCode == 86 && typeof callback === 'function') {
        if (isUrl($("#searchText").val().trim())) {
            callback();
        }
    } 
}
function catchCtrlV(e) {
    e = e || window.event;
    var key = e.which || e.keyCode; // keyCode detection
    ctrlPress = e.ctrlKey ? e.ctrlKey : ((key === 17) ? true : false); // ctrl detection
}
function isUrl(val, element) {
    if (!val || val.length < 5) { return false; }

    // if user has not entered http:// https:// or ftp:// assume they mean http://
    if (!/^(https?|ftp):\/\//i.test(val)) {
        val = 'http://' + val; // set both the value
    }
    // now check if valid url
    // http://docs.jquery.com/Plugins/Validation/Methods/url
    // contributed by Scott Gonzalez: http://projects.scottsplayground.com/iri/
    var result = /^(https?|s?ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=|]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=|]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=|]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=|]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=|]|:|@)|\/|\?)*)?$/i.test(val);
    if (result && element) {
        element.val(val);
    }
    return result;
}

function AllowNumeric(that, event) {
    //var numb = $(that).val().match(/\d/g);
    //numb = numb.join("");
    $(that).val($(that).val().replace(/[^0-9]/g, ""));
    //if ((event.which < 48 || event.which > 57)) {
    //    event.preventDefault();
    //}
}

function TitleCase(that) {
    if (!that.value || !that.value.trim()) return;

    var str = that.value.trim();
    var splitStr = str.replace(/,/g, ', ').replace(/  /g, ' ').toLowerCase().split(' ');
    for (var i = 0; i < splitStr.length; i++) {
        // You do not need to check if i is larger than splitStr length, as your for does that for you
        // Assign it back to the array
        splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
    }
    // Directly return the joined string
    that.value = splitStr.join(' ');
}

function StartTimer(duration, displayElementName, callback) {
    var timer = duration, seconds;
    var display = document.querySelector(displayElementName);
    var timeout = setInterval(function () {
        //minutes = parseInt(timer / 60, 10)
        seconds = parseInt(timer % 60, 10);

        //minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = seconds;

        if (timer-- == 0) {
            $('#divSendTimeOut').remove();
            clearInterval(timeout);
            callback();
        }
    }, 1000);
    return timeout;
}

function getIndexFromArray(array, field, value) {
    if (!array) return -1;
    for (var i = 0; i < array.length; i++) {
        if (array[i][field] == value) {
            return i;
        }
    }
    return -1;
}