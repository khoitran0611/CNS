﻿using ApptitudeCNS.Application.Users;
using ApptitudeCNS.Infrastructure.Persistence.DbContext;
using Autofac;
using Autofac.Integration.Mvc;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using System.Configuration;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using ApptitudeCNS.Core;
using ApptitudeCNS.Infrastructure.Persistence.Repositories;
using ApptitudeCNS.Application.Articles;
using ApptitudeCNS.Application.MailTrackings;
using ApptitudeCNS.Application.Clients;
using Bp.Infrastructure.Persistence.Repositories;
using ApptitudeCNS.Core.IRepository;
using ApptitudeCNS.Application.Rates;
using ApptitudeCNS.Application.Rates.Jobs;
using Autofac.Extras.Quartz;
using ApptitudeCNS.Infrastructure.Email.Services;
using InfoCorp.Ico.Senc.Infrastructure.Logging;
using System.Web.Hosting;
using System.IO;
using ApptitudeCNS.Infrastructure.Sms.Services;
using ApptitudeCNS.Application.ClientHistories;
using ApptitudeCNS.Application.MailLinks;
using ApptitudeCNS.Application.LinkTrackings;
using ApptitudeCNS.Application.UserMailTrackings;
using ApptitudeCNS.Application.PrimaryImages;
using ApptitudeCNS.Application.Tags;
using ApptitudeCNS.Application.SpellfixDictionaries;

namespace ApptitudeCNS.App_Start
{
    public class DependencyRegistrarConfig
    {
        public static void RegisterDependencies(ContainerBuilder builder)
        {
            // Controller
            builder.RegisterControllers(typeof(MvcApplication).Assembly);

            // Miscs
            builder.RegisterModule(new QuartzAutofacFactoryModule());
            builder.RegisterModule(new QuartzAutofacJobsModule(typeof(SendLowestLendersJob).Assembly));
            builder.RegisterType<JobScheduler>().AsSelf();

            // Infrastructure
            builder.RegisterType<EmailService>().As<IEmailService>().InstancePerLifetimeScope();
            //builder.RegisterType<EmailSender>().As<IEmailSender>().InstancePerLifetimeScope();
            builder.Register<ISmsService>(n => new TransmitSmsService(
                ConfigurationManager.AppSettings["SmsApiKey"],
                ConfigurationManager.AppSettings["SmsApiSecret"])).InstancePerLifetimeScope();
            builder.Register<ILogger>(n => new Log4NetLogger(Path.Combine(HostingEnvironment.ApplicationPhysicalPath, "log4net.config"))).SingleInstance();

            // Data layer
            builder.Register<IDbContext>(c => new EfDbContext(ConfigurationManager.ConnectionStrings["CNS"].ConnectionString)).InstancePerLifetimeScope();
            builder.RegisterGeneric(typeof(EfGenericRepository<>)).As(typeof(IGenericRepository<>)).InstancePerLifetimeScope();
            builder.RegisterType<UserRepository>().As<IUserRepository>().InstancePerLifetimeScope();
            builder.RegisterType<RoleRepository>().As<IRoleRepository>().InstancePerLifetimeScope();
            builder.Register<IRateRepository>(n => new RateRepository(new EfDbContext(ConfigurationManager.ConnectionStrings["OneSource"].ConnectionString))).InstancePerLifetimeScope();

            // Application layer
            builder.RegisterType<UserApp>().As<IUserApp>().InstancePerLifetimeScope();
            builder.RegisterType<ClientApp>().As<IClientApp>().InstancePerLifetimeScope();
            builder.RegisterType<RoleApp>().As<IRoleApp>().InstancePerLifetimeScope();
            builder.RegisterType<ArticleApp>().As<IArticleApp>().InstancePerLifetimeScope();
            builder.RegisterType<MailTrackingApp>().As<IMailTrackingApp>().InstancePerLifetimeScope();
            builder.RegisterType<UserMailTrackingApp>().As<IUserMailTrackingApp>().InstancePerLifetimeScope();
            builder.RegisterType<RateAppService>().As<IRateAppService>().InstancePerLifetimeScope();
            builder.RegisterType<ClientHistoryApp>().As<IClientHistoryApp>().InstancePerLifetimeScope();
            builder.RegisterType<LinkTrackingApp>().As<ILinkTrackingApp>().InstancePerLifetimeScope();
            builder.RegisterType<UserHistoryApp>().As<IUserHistoryApp>().InstancePerLifetimeScope();
            builder.RegisterType<PrimaryImageApp>().As<IPrimaryImageApp>().InstancePerLifetimeScope();
            builder.RegisterType<TagApp>().As<ITagApp>().InstancePerLifetimeScope();
            builder.Register(n => new RateSettings
            {
                SenderId = long.Parse(ConfigurationManager.AppSettings["SystemUserId"]),
                AndrewNumbers = ConfigurationManager.AppSettings["AndrewNumbers"].Split(','),
                AndrewSmsMessage = ConfigurationManager.AppSettings["AndrewSmsMessage"],
                RateDelta = decimal.Parse(ConfigurationManager.AppSettings["RateDelta"])
            }).InstancePerLifetimeScope();
            builder.Register<IBpAggregatorRepository>(n => new BpAggregatorRepository(new EfDbContext(ConfigurationManager.ConnectionStrings["OneSource"].ConnectionString))).InstancePerLifetimeScope();
            builder.Register<IBpNoiseWordRepository>(n => new BpNoiseWordRepository(new EfDbContext(ConfigurationManager.ConnectionStrings["OneSource"].ConnectionString))).InstancePerLifetimeScope();

            builder.RegisterType<MailLinkApp>().As<IMailLinkApp>().InstancePerLifetimeScope();
            builder.RegisterType<SpellfixDictionaryApp>().As<ISpellfixDictionaryApp>().InstancePerLifetimeScope();
        }
    }
}