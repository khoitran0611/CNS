﻿using ApptitudeCNS.App_Start;
using ApptitudeCNS.Application.MailLinks;
using ApptitudeCNS.Application.Users;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Infrastructure.IoC;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using ApptitudeCNS.Infrastructure.Persistence.DbContext;
using Autofac;
using Autofac.Integration.Mvc;
using InfoCorp.Ico.Senc.Infrastructure.Logging;
using Quartz.Impl;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;

namespace ApptitudeCNS
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            var builder = new ContainerBuilder();
            DependencyRegistrarConfig.RegisterDependencies(builder);
            var container = EngineContext.Current.ConfigureServices(builder);
            //var autofacDependencyResolver = new AutofacDependencyResolver(container);
            //autofacDependencyResolver
            DependencyResolver.SetResolver(new AutofacDependencyResolver(container));

            Database.SetInitializer<EfDbContext>(null);
            EngineContext.Current.Resolve<JobScheduler>().Start();
            ModelBinders.Binders.Add(typeof(DateTime), new CustomDateModelBinder());
        }

        void Application_BeginRequest(object sender, EventArgs e)
        {
            var app = (HttpApplication)sender;
            var url = app.Context.Request.Url.ToString();

            if (!url.ToLower().Contains("content/images/blank.png?") ||
                url.ToLower().Contains("{mailid}") || url.ToLower().Contains("{usermailid}")) return;

            try
            {
                var mailLinkApp = EngineContext.Current.Resolve<IMailLinkApp>();
                mailLinkApp.ReadMail(CommonHelper.GetLong(Encryption.Base64DecodeUrl(app.Context.Request["Id"])));
                mailLinkApp.ReadUserMail(CommonHelper.GetLong(Encryption.Base64DecodeUrl(app.Context.Request["UserMailId"])));
            }
            catch (Exception ex)
            {
                var logger = EngineContext.Current.Resolve<ILogger>();
                logger.LogError(ex.ToString());
            }
            //app.Context.Request.Url.OriginalString
        }

        void Application_PostAuthenticateRequest(object sender, EventArgs e)
        {
            var app = (HttpApplication)sender;
            var url = app.Context.Request.Url.ToString().ToLower();

            if (url.Contains("bootstrap?") || url.Contains("jquery?") ||
                url.Contains("jqueryval?") ||
                url.EndsWith(".png") ||
                url.EndsWith(".css") || url.Contains(".css?") ||
                url.EndsWith(".js") || url.Contains(".js?")) return;

            HttpContextBase context = new HttpContextWrapper(HttpContext.Current);
            RouteData rd = RouteTable.Routes.GetRouteData(context);

            if (rd == null) return;

            var ctx = HttpContext.Current;

            if (ctx != null && ctx.Request != null && ctx.Request.IsAuthenticated)// && (Thread.CurrentPrincipal == null || Thread.CurrentPrincipal.Identity == null))
            {
                string[] roles = LookupRolesForUser(ctx.User.Identity.Name);
                GenericPrincipal newUser = null;
                if (roles.Length > 0)
                {
                    newUser = new GenericPrincipal(ctx.User.Identity, roles);
                }
                else
                {
                    newUser = new GenericPrincipal(ctx.User.Identity, new string[] { CNSConstant.Broker });
                }
                ctx.User = Thread.CurrentPrincipal = newUser;
            }
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            var error = Server.GetLastError();
            var logger = EngineContext.Current.Resolve<ILogger>();
            logger.LogError(error.ToString());
            Server.ClearError();
            Response.ContentType = "text/plain";
            Response.Write(error ?? (object)"unknown");
            Response.End();
        }

        private string[] LookupRolesForUser(string email)
        {
            //var user = EngineContext.Current.Resolve<IUserApp>().FindUserWithRoleByEmail(email);
            //if (user != null && user.Roles.Count > 0)
            //{
            //    return user.Roles.Select(r => r.RoleName).ToArray();
            //    //HttpContext.Current.Cache[email] = user.Roles.Select(r => r.RoleName).ToArray();
            //    //return HttpContext.Current.Cache[email] as string[];
            //}
            //return new string[0];

            string[] result = new string[0];
            var cache = CacheHandler.Get<string[]>(email, out result);

            if (!cache || (result == null || result.Length == 0))
            {
                var user = EngineContext.Current.Resolve<IUserApp>().FindUserWithRoleByEmail(email);
                if (user != null && user.Roles.Count > 0)
                {
                    result = user.Roles.Select(r => r.RoleName).ToArray();
                    CacheHandler.Add(result, email);
                    //HttpContext.Current.Cache[email] = user.Roles.Select(r => r.RoleName).ToArray();
                    //return HttpContext.Current.Cache[email] as string[];
                }
            }
            return result ?? new string[0];
            //return result;  // Alternatively throw an exception
        }
    }

    public class CustomDateModelBinder : DefaultModelBinder
    {
        public override object BindModel
        (ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            var displayFormat = bindingContext.ModelMetadata.DisplayFormatString;
            var value = bindingContext.ValueProvider.GetValue(bindingContext.ModelName);

            if (!string.IsNullOrEmpty(displayFormat) && value != null)
            {
                DateTime date;
                displayFormat = displayFormat.Replace
                ("{0:", string.Empty).Replace("}", string.Empty);
                if (DateTime.TryParseExact(value.AttemptedValue, displayFormat,
                CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
                {
                    return date;
                }
                else
                {
                    bindingContext.ModelState.AddModelError(
                        bindingContext.ModelName,
                        string.Format("{0} is an invalid date format", value.AttemptedValue)
                    );
                }
            }

            return base.BindModel(controllerContext, bindingContext);
        }
    }
}
