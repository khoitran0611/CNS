﻿using ApptitudeCNS.Application.Rates.Jobs;
using Autofac;
using Autofac.Extras.Quartz;
using Quartz;
using System;
using System.Configuration;

namespace ApptitudeCNS
{
    public class JobScheduler
    {
        public JobScheduler(IScheduler scheduler)
        {
            _scheduler = scheduler;
        }

        private readonly IScheduler _scheduler;

        public void Start()
        {
#if (!DEBUG)
            IJobDetail lowestLendersJob = JobBuilder.Create<SendLowestLendersJob>()
            .WithIdentity("LowestLendersJob", "RateJob")
            .Build();

            ITrigger lowestLendersTrigger = TriggerBuilder.Create()
                .WithIdentity("LowestLendersTrigger", "RateTrigger")
                //.StartAt(DateTime.Now.AddSeconds(10))
                .WithCronSchedule(ConfigurationManager.AppSettings["LowestLendersJobSchedule"])
                .StartNow()
                .Build();

            _scheduler.ScheduleJob(lowestLendersJob, lowestLendersTrigger);

            IJobDetail smsJob = JobBuilder.Create<SendAndrewSmsJob>()
           .WithIdentity("SmsJob", "RateJob")
           .Build();

            ITrigger smsTrigger = TriggerBuilder.Create()
                .WithIdentity("SmsTrigger", "RateTrigger")
                //.StartAt(DateTime.Now.AddSeconds(10))
                .WithCronSchedule(ConfigurationManager.AppSettings["SmsJobSchedule"])
                .StartNow()
                .Build();

            _scheduler.ScheduleJob(smsJob, smsTrigger);

            _scheduler.Start();
#endif
        }
    }
}