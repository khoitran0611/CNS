﻿using ApptitudeCNS.Infrastructure.IoC;
using System.Runtime.CompilerServices;

namespace ApptitudeCNS.Infrastructure.IoC
{
    public class EngineContext
    {
        [MethodImpl(MethodImplOptions.Synchronized)]
        public static IEngine Create()
        {
            if (Singleton<IEngine>.Instance == null)
                Singleton<IEngine>.Instance = new AppEngine();

            return Singleton<IEngine>.Instance;
        }

        public static void Replace(IEngine engine)
        {
            Singleton<IEngine>.Instance = engine;
        }

        public static IEngine Current
        {
            get
            {
                if (Singleton<IEngine>.Instance == null)
                {
                    Create();
                }

                return Singleton<IEngine>.Instance;
            }
        }
    }
}
