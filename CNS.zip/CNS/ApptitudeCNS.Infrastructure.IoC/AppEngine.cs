﻿using ApptitudeCNS.Infrastructure.IoC;
using Autofac;
using System;
using System.Collections.Generic;

namespace ApptitudeCNS.Infrastructure.IoC
{
    public class AppEngine : IEngine
    {
        private IContainer _container;

        public virtual IContainer Container => _container;

        public IContainer ConfigureServices(ContainerBuilder containerBuilder)
        {
            containerBuilder.RegisterInstance(this).As<IEngine>().SingleInstance();
            _container = containerBuilder.Build();
            return _container;
        }

        public T Resolve<T>() where T : class
        {

            return _container.Resolve<T>();
        }

        public object Resolve(Type type)
        {
            return _container.Resolve(type);
        }

        public IEnumerable<T> ResolveAll<T>()
        {
            return _container.Resolve<IEnumerable<T>>();
        }
    }
}
