﻿using Autofac;
using System;
using System.Collections.Generic;

namespace ApptitudeCNS.Infrastructure.IoC
{
    public interface IEngine
    {
        IContainer ConfigureServices(ContainerBuilder containerBuilder);

        T Resolve<T>() where T : class;

        object Resolve(Type type);

        IEnumerable<T> ResolveAll<T>();
    }
}
