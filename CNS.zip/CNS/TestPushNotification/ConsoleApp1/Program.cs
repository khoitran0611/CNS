﻿using Newtonsoft.Json.Linq;
using PushSharp.Apple;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            var failed = 0;
            var succeeded = 0;

            System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;
            var certificateFilePath = "C:\\Brokerpedia\\Certificates\\iOSPushRentokil\\Certificates.p12";
            //var certificateFilePath = "C:\\Brokerpedia\\Certificates\\iOSPushRentokil\\ck.pem";
            var certificatePassword = ""; // We keep password empty
            //var certificatePassword = "monkey9andrew"; // We keep password empty
            var config = new ApnsConfiguration(ApnsConfiguration.ApnsServerEnvironment.Sandbox, certificateFilePath, certificatePassword, true);
            var broker = new ApnsServiceBroker(config);
            broker.OnNotificationFailed += (notification, exception) =>
            {
                failed++;
                Console.WriteLine(exception);
                Console.ReadLine();
            };
            broker.OnNotificationSucceeded += (notification) =>
            {
                Console.WriteLine("success");
                succeeded++;
            };
            broker.Start();

            //foreach (var dt in Settings.Instance.ApnsDeviceTokens)
            //{
            //    attempted++;
            //    broker.QueueNotification(new ApnsNotification
            //    {
            //        DeviceToken = dt,
            //        Payload = JObject.Parse("{ \"aps\" : { \"alert\" : \"Hello PushSharp!\" } }")
            //    });
            //}
            //Queue a notification to send
            broker.QueueNotification(new ApnsNotification
            {
                DeviceToken = "fbdfa853adb81c51712161c9645d79c73e022769812103382d4c0225dd88289a",
                Payload = JObject.Parse("{\"aps\":{\"alert\":\"huy test\",\"badge\":3}}")
            });

            broker.Stop();

            // Configuration (NOTE: .pfx can also be used here)
            //var appleCert = File.ReadAllBytes("C:\\Brokerpedia\\Certificates\\iOSPushRentokil\\Cert.p12");

            //var config = new ApnsConfiguration(ApnsConfiguration.ApnsServerEnvironment.Sandbox,
            //    appleCert, "", true);

            //// Create a new broker
            //var apnsBroker = new ApnsServiceBroker(config);

            //// Wire up events
            //apnsBroker.OnNotificationFailed += (notification, aggregateEx) =>
            //{

            //    aggregateEx.Handle(ex =>
            //    {

            //        // See what kind of exception it was to further diagnose
            //        if (ex is ApnsNotificationException notificationException)
            //        {

            //            // Deal with the failed notification
            //            var apnsNotification = notificationException.Notification;
            //            var statusCode = notificationException.ErrorStatusCode;

            //            Console.WriteLine($"Apple Notification Failed: ID={apnsNotification.Identifier}, Code={statusCode}");

            //        }
            //        else
            //        {
            //            // Inner exception might hold more useful information like an ApnsConnectionException			
            //            Console.WriteLine($"Apple Notification Failed for some unknown reason : {ex.InnerException}");
            //        }

            //        // Mark it as handled
            //        return true;
            //    });
            //};

            //apnsBroker.OnNotificationSucceeded += (notification) =>
            //{
            //    Console.WriteLine("Apple Notification Sent!");
            //};

            //// Start the broker
            //apnsBroker.Start();

            //// Queue a notification to send
            //apnsBroker.QueueNotification(new ApnsNotification
            //{
            //    DeviceToken = "d595ce3172c78543708e828321e2143d3444489d698c44dd25570ff95e0826a9",
            //    Payload = JObject.Parse("{\"aps\":{\"alert\":\"huy test\",\"badge\":2}}")
            //});

            //// Stop the broker, wait for it to finish   
            //// This isn't done after every message, but after you're
            //// done with the broker
            //apnsBroker.Stop();
        }

        private void Create() { }
    }
}
