﻿using System;

namespace InfoCorp.Ico.Senc.Infrastructure.Logging
{
    public class LogEntry
    {
        public readonly LoggingEventType Severity;
        public readonly string Message;

        public LogEntry(LoggingEventType severity, string message)
        {
            if (message == null) throw new ArgumentNullException(nameof(message));
            if (message == string.Empty) throw new ArgumentException("empty", nameof(message));

            Severity = severity;
            Message = message;
        }
    }
}
