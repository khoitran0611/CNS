﻿namespace InfoCorp.Ico.Senc.Infrastructure.Logging
{
    public enum LoggingEventType
    {
        Debug,
        Information,
        Warning,
        Error,
        Fatal
    }
}
