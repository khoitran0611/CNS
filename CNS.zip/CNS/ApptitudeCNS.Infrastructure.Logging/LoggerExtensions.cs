﻿using Newtonsoft.Json;

namespace InfoCorp.Ico.Senc.Infrastructure.Logging
{
    public static class LoggerExtensions
    {
        public static void LogDebug(this ILogger logger, string message)
        {
            logger.Log(new LogEntry(LoggingEventType.Debug, message));
        }

        public static void LogInfo(this ILogger logger, string message)
        {
            logger.Log(new LogEntry(LoggingEventType.Information, message));
        }

        public static void LogWarn(this ILogger logger, string message)
        {
            logger.Log(new LogEntry(LoggingEventType.Warning, message));
        }

        public static void LogError(this ILogger logger, string message)
        {
            logger.Log(new LogEntry(LoggingEventType.Error, message));
        }

        public static void LogFatal(this ILogger logger, string message)
        {
            logger.Log(new LogEntry(LoggingEventType.Fatal, message));
        }

        public static void LogDebugStart(this ILogger logger, string methodName)
        {
            logger.Log(new LogEntry(LoggingEventType.Debug, methodName + " Start!"));
        }

        public static void LogDebugEnd(this ILogger logger, string methodName)
        {
            logger.Log(new LogEntry(LoggingEventType.Debug, methodName + " End!"));
        }

        public static void LogDebugParam(this ILogger logger, object param)
        {
            logger.Log(new LogEntry(LoggingEventType.Debug, "Parameter: " + JsonConvert.SerializeObject(param)));
        }
    }
}
