﻿using System;
using System.IO;

namespace InfoCorp.Ico.Senc.Infrastructure.Logging
{
    public class Log4NetLogger : ILogger
    {
        private readonly log4net.ILog _logger = log4net.LogManager.GetLogger(typeof(Log4NetLogger));

        public Log4NetLogger(string configFileNamePath)
        {
            log4net.Config.XmlConfigurator.Configure(File.OpenRead(configFileNamePath));
        }

        public void Log(LogEntry entry)
        {
            switch (entry.Severity)
            {
                case LoggingEventType.Debug:
                    _logger.Debug(entry.Message);
                    break;
                case LoggingEventType.Information:
                    _logger.Info(entry.Message);
                    break;
                case LoggingEventType.Warning:
                    _logger.Warn(entry.Message);
                    break;
                case LoggingEventType.Error:
                    _logger.Error(entry.Message);
                    break;
                case LoggingEventType.Fatal:
                    _logger.Fatal(entry.Message);
                    break;
                default:
                    throw  new Exception("Unknown Error!");
            }
        }
    }
}
