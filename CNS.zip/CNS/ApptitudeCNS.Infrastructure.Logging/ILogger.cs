﻿namespace InfoCorp.Ico.Senc.Infrastructure.Logging
{
    public interface ILogger
    {
        void Log(LogEntry entry);
    }
}
