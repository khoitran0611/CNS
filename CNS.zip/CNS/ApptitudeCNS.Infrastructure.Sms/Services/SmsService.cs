﻿namespace ApptitudeCNS.Infrastructure.Sms.Services
{
    public class TransmitSmsService : ISmsService
    {
        public TransmitSmsService(string apiKey, string apiSecret)
        {
            _apiKey = apiKey;
            _apiSecret = apiSecret;
        }

        private readonly string _apiKey;
        private readonly string _apiSecret;

        public string SendSms(string message, string[] toNumbers, string fromNumber = "Brokerpedia")
        {
            TransmitSms.TransmitSmsWrapper wrapper = new TransmitSms.TransmitSmsWrapper(_apiKey, _apiSecret, "https://api.transmitsms.com/");
            var response = wrapper.SendSms(message, toNumbers, fromNumber, null, null, null, null, 15);
            return response?.Error?.Code == "SUCCESS" ? "SUCCESS" : string.IsNullOrWhiteSpace(response?.Error?.Description) ? "ERROR" : response?.Error?.Description;
        }
    }
}
