﻿namespace ApptitudeCNS.Infrastructure.Sms.Services
{
    public interface ISmsService
    {
        string SendSms(string message, string[] toNumbers, string fromNumber = "Brokerpedia");
    }
}
