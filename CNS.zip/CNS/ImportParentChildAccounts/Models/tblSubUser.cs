using System;
using System.Collections.Generic;

namespace ImportParentChildAccounts.Models
{
    public partial class tblSubUser
    {
        public long SubUserId { get; set; }
        public long ParentUserId { get; set; }
        public long? BpUserId { get; set; }
        public string ExternalUserID { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MobilePhone { get; set; }
        public long? WholeSalerID { get; set; }
        public System.DateTime? CreatedDate { get; set; }
        public System.DateTime? LastUpdatedDate { get; set; }
        public bool IsDeleted { get; set; }
    }
}
