using System;
using System.Collections.Generic;

namespace ImportParentChildAccounts.Models
{
    public partial class UserHistory
    {
        public long UserHistoryID { get; set; }
        public long UserID { get; set; }
        public System.DateTime LogDate { get; set; }
        public string Page { get; set; }
        public string PageReferral { get; set; }
        public string IPAdress { get; set; }
        public string UserAgent { get; set; }
        public string OldContent { get; set; }
        public string NewContent { get; set; }
        public int TriggerEvent { get; set; }
        public string InfoColumnName { get; set; }
        public long Author { get; set; }
        public string Notes { get; set; }
        public bool IsPinnedNote { get; set; }
    }
}
