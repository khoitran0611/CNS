﻿using Dapper;
using ImportParentChildAccounts.Models;
using NLog;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImportParentChildAccounts
{
    class ImportData
    {
        public ILogger Logger { get; set; }
        private IDbConnection db = new SqlConnection(ConfigurationManager.ConnectionStrings["OneSource"].ConnectionString);

        public void ImportBrokerpediaUsers()
        {
            var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"Brokerpedia Parent Accounts (Existing B users) 070818.xlsx");
            var users = new List<tblUser>();
            var subUsers = new List<tblSubUser>();
            using (var package = new ExcelPackage(new FileInfo(filePath)))
            {
                // column A = parentId
                // column B = userid
                // column C = firstname
                // column D = lastname
                // column E = Email
                using (var sheet = package.Workbook.Worksheets[1])
                {
                    var start = sheet.Dimension.Start;
                    var end = sheet.Dimension.End;
                    var emptyRow = new List<int>();
                    long oldParentId = 0;
                    for (int row = start.Row + 1; row <= end.Row; row++)
                    {
                        if (emptyRow.Count >= 3 &&
                            emptyRow[emptyRow.Count - 1] == emptyRow[emptyRow.Count - 2] + 1 &&
                            emptyRow[emptyRow.Count - 1] == emptyRow[emptyRow.Count - 3] + 2)
                        {
                            break;
                        }

                        if (string.IsNullOrWhiteSpace(sheet.Cells[row, 1].Text) || string.IsNullOrWhiteSpace(sheet.Cells[row, 2].Text))
                        {
                            emptyRow.Add(row);
                            continue;
                        }
                        var parentId = GetLong(sheet.Cells[row, 1].Text);
                        users.Add(new tblUser
                        {
                            ParentId = parentId,
                            UserID = GetLong(sheet.Cells[row, 2].Text)
                        });

                        //if (parentId != oldParentId)
                        //{
                        //    oldParentId = parentId;
                        //    users.Add(new tblUser
                        //    {
                        //        ParentId = parentId,
                        //        UserID = GetLong(sheet.Cells[row, 2].Text)
                        //    });
                        //}
                        //else
                        //{
                        //    subUsers.Add(new tblSubUser
                        //    {
                        //        ParentUserId = parentId,
                        //        Email = sheet.Cells[row, 5].Text,
                        //        FirstName = sheet.Cells[row, 3].Text,
                        //        LastName = sheet.Cells[row, 4].Text,
                        //        BpUserId = GetLong(sheet.Cells[row, 2].Text)
                        //    });
                        //}
                    }
                }
            }

            Logger.Info($"users count = {users.Count}");
            db.Execute("UPDATE dbo.tblUser SET ParentId = NULL");
            foreach (var item in users.GroupBy(x => x.ParentId))
            {
                if (item.Count() > 1)
                {
                    var userIds = string.Join(",", item.Select(x => x.UserID));
                    db.Execute($@"DECLARE @ParentId BIGINT 
                            SELECT TOP 1 @ParentId = UserID FROM dbo.tblUser WHERE UserID IN ({userIds}) ORDER BY LastLoginTime DESC, CreatedDate DESC, UserID DESC
                            UPDATE dbo.tblUser SET ParentId = @ParentId WHERE UserID IN ({userIds}) AND UserID <> @ParentId");
                }
            }
            
            //Logger.Info($"subUsers count = {subUsers.Count}");
            //Logger.Info(subUsers[0]);
            //db.Execute(@"INSERT dbo.tblSubUser(Email, FirstName, LastName, BpUserId, ParentUserId, CreatedDate)
            //                        SELECT @Email, @FirstName, @LastName, @BpUserId, UserId, '2018-08-03' FROM dbo.tblUser WHERE ParentId = @ParentUserId", subUsers);
            //db.Execute(@"Update dbo.tblUser SET ParentId = @ParentId WHERE UserID = @UserID", users);
            //db.Execute(@"Update su SET ExternalUserId = u.ExternalUserId, MobilePhone = u.MobilePhone, WholeSalerID = u.WholeSalerID, 
            //                            Email = u.Email, FirstName = u.FirstName, LastName = u.LastName, CreatedDate = ISNULL(u.CreatedDate, '2018-08-03') FROM dbo.tblSubUser su JOIN dbo.tblUser u ON su.BpUserId = u.UserID;
            //            --Update u SET IsDeleted = 1 FROM dbo.tblUser u JOIN dbo.tblSubUser su ON su.BpUserId = u.UserID");
        }

        public void ImportMFAAHistoryNotes()
        {
            //var filePath = @"C:\Users\huytq\Downloads\MFAA duplicates history note to be added 030818.xlsx";
            var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"MFAA duplicates history note to be added 030818.xlsx");
            var userHistories = new List<UserHistory>();
            using (var package = new ExcelPackage(new FileInfo(filePath)))
            {
                // column A = parentId
                // column B = userid
                // column C = firstname
                // column D = lastname
                // column E = Email
                using (var sheet = package.Workbook.Worksheets[1])
                {
                    var start = sheet.Dimension.Start;
                    var end = sheet.Dimension.End;
                    var emptyRow = new List<int>();
                    for (int row = start.Row + 1; row <= end.Row; row++)
                    {
                        if (emptyRow.Count >= 3 &&
                            emptyRow[emptyRow.Count - 1] == emptyRow[emptyRow.Count - 2] + 1 &&
                            emptyRow[emptyRow.Count - 1] == emptyRow[emptyRow.Count - 3] + 2)
                        {
                            break;
                        }

                        if (string.IsNullOrWhiteSpace(sheet.Cells[row, 1].Text))
                        {
                            emptyRow.Add(row);
                            continue;
                        }
                        userHistories.Add(new UserHistory
                        {
                            Notes = sheet.Cells[row, 5].Text,
                            UserID = GetLong(sheet.Cells[row, 1].Text)
                        });
                    }
                }
            }

            db.Execute(@"INSERT dbo.UserHistory
                                ( UserID ,
                                  LogDate ,
                                  Page ,
                                  PageReferral ,
                                  IPAdress ,
                                  UserAgent ,
                                  TriggerEvent ,
                                  Author ,
                                  Notes ,
                                  IsPinnedNote
                                )
                        SELECT  UserID , -- UserID - bigint
                                  '2018-08-03' , -- LogDate - datetime
                                  N'ImportFromExcel' , -- Page - nvarchar(200)
                                  N'ImportFromExcel' , -- PageReferral - nvarchar(200)
                                  N'40.115.78.221' , -- IPAdress - nvarchar(200)
                                  N'ImportFromExcels' , -- UserAgent - nvarchar(200)
                                  105 , -- TriggerEvent - int
                                  88895622 , -- Author - bigint
                                  @Notes , -- Notes - nvarchar(max)
                                  0  -- IsPinnedNote - bit
                                FROM dbo.tblUser WHERE ParentId = @UserID", userHistories);
        }

        public void ImportMFAAToUsers()
        {
            //var filePath = @"C:\Users\huytq\Downloads\MFAA new Accounts to be Added 070818.xlsx";
            var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"MFAA new Accounts to be Added 070818.xlsx");
            var users = new List<tblUser>();
            var hashtable = new Dictionary<string, string>();
            hashtable.Add("outsourcefinancial", "Outsource Financial");
            using (var package = new ExcelPackage(new FileInfo(filePath)))
            {
                // column A = parentId
                // column B = userid
                // column C = firstname
                // column D = lastname
                // column E = Email
                using (var sheet = package.Workbook.Worksheets[1])
                {
                    var start = sheet.Dimension.Start;
                    var end = sheet.Dimension.End;
                    var emptyRow = new List<int>();
                    for (int row = start.Row + 1; row <= end.Row; row++)
                    {
                        if (emptyRow.Count >= 3 &&
                            emptyRow[emptyRow.Count - 1] == emptyRow[emptyRow.Count - 2] + 1 &&
                            emptyRow[emptyRow.Count - 1] == emptyRow[emptyRow.Count - 3] + 2)
                        {
                            break;
                        }

                        if (string.IsNullOrWhiteSpace(sheet.Cells[row, 1].Text))
                        {
                            emptyRow.Add(row);
                            continue;
                        }
                        users.Add(new tblUser
                        {
                            ParentId = GetLong(sheet.Cells[row, 1].Text),
                            FirstName = sheet.Cells[row, 2].Text,
                            LastName = sheet.Cells[row, 3].Text,
                            CompanyName = sheet.Cells[row, 4].Text,
                            WorkAddress2 = sheet.Cells[row, 5].Text,
                            State = sheet.Cells[row, 6].Text,
                            Email = sheet.Cells[row, 7].Text,
                            OfficeNumber = sheet.Cells[row, 8].Text,
                            MobilePhone = sheet.Cells[row, 9].Text,
                            AggregratorNameAdminUpdate = sheet.Cells[row, 10].Text,
                            SubWholeSalerName = sheet.Cells[row, 11].Text,
                            WholeSalerName = hashtable.ContainsKey(sheet.Cells[row, 12].Text) ? hashtable[sheet.Cells[row, 12].Text] : sheet.Cells[row, 12].Text,
                        });
                    }
                }
            }

            db.Execute(@"INSERT INTO [dbo].[tblUser]
                                           ([ExternalUserID]
                                           ,[Title]
                                           ,[Gender]
                                           ,[UserName]
                                           ,[Password]
                                           ,[FirstName]
                                           ,[LastName]
                                           ,[Role]
                                           ,[Birthday]
                                           ,[CompanyName]
                                           ,[CompanyWebsite]
                                           ,[OfficeNumber]
                                           ,[WorkAddress1]
                                           ,[WorkAddress2]
                                           ,[Postcode]
                                           ,[State]
                                           ,[CountryID]
                                           ,[Email]
                                           ,[MobilePhone]
                                           ,[WholeSalerID]
                                           ,[SecretQuestionID]
                                           ,[Answer]
                                           ,[Status]
                                           ,[Deleted]
                                           ,[ItemsPerPage]
                                           ,[EnrollNewsletter]
                                           ,[FontSize]
                                           ,[AlertFeedback]
                                           ,[AlertBDMChange]
                                           ,[FavouriteAdded]
                                           ,[Logins]
                                           ,[FirstLoginTime]
                                           ,[LastLoginTime]
                                           ,[AllowWelcomeScreen]
                                           ,[AllowInactivityRemindingScreen]
                                           ,[ShowHintForAd]
                                           ,[AllowLoginPopup]
                                           ,[AggregratorName]
                                           ,[City]
                                           ,[ActiveTo]
                                           ,[ActiveFrom]
                                           ,[InTrialPeriod]
                                           ,[ReferralSourceCode]
                                           ,[DeactivatedDate]
                                           ,[DeactivatedBy]
                                           ,[DeactivatedReason]
                                           ,[CreatedDate]
                                           ,[ExpandResultsByDefault]
                                           ,[ExpandCondenseOption]
                                           ,[UserConversationContent]
                                           ,[Password2]
                                           ,[AggregratorNameAdminUpdate]
                                           ,[State_SystemAssgined]
                                           ,[State_SystemAssgined_BitShifted]
                                           ,[State_TempUnsure_BitShifted]
                                           ,[State_Default_BitShifted]
                                           ,[MemberNumber]
                                           ,[ChildCouponCodeName]
                                           ,[ExternalPartnerID]
                                           ,[DefaultBankAccountNo]
                                           ,[GST_Registered]
                                           ,[ChildCouponWordID]
                                           ,[Title2]
                                           ,[BOQNumber]
                                           ,[BankAccountBankName]
                                           ,[BankAccountBSB]
                                           ,[BankAccountName]
                                           ,[BankAccountNumber]
                                           ,[IvoryTower]
                                           ,[CPDPointStartDate]
                                           ,[NoteForChanges]
                                           ,[DoNotShowInfoUpdatePopup]
                                           ,[LinkedUserID1]
                                           ,[LinkedUserID2]
                                           ,[LinkedUserID3]
                                           ,[LinkedUserID4]
                                           ,[LinkedUserID5]
                                           ,[LinkedUser1_Date]
                                           ,[LinkedUser2_Date]
                                           ,[LinkedUser3_Date]
                                           ,[LinkedUser4_Date]
                                           ,[LinkedUser5_Date]
                                           ,[NoLGE]
                                           ,[NoLGE_Reason]
                                           ,[UserGroupID]
                                           ,[ReferrerName]
                                           ,[BPTermsVer]
                                           ,[IsDeletedToReferrer]
                                           ,[AggregatorTemp]
                                           ,[MobilePhoneMAF]
                                           ,[FirstNameMAF]
                                           ,[LastNameMAF]
                                           ,[EmailMAF]
                                           ,[LastUpdatedDate]
                                           ,[LastUpdatedDateMAF]
                                           ,[LastMobilePhone]
                                           ,[SubWholeSalerID],[ParentID])
                                     SELECT NULL
                                           ,''
                                           ,''
                                           ,CASE WHEN NOT EXISTS (SELECT 1 FROM dbo.tblUser WHERE LTRIM(RTRIM(UserName)) = @Email) THEN LOWER(@Email)
WHEN NOT EXISTS (SELECT 1 FROM dbo.tblUser WHERE LTRIM(RTRIM(UserName)) = @FirstName + @LastName) THEN LOWER(@FirstName + @LastName)
WHEN NOT EXISTS (SELECT 1 FROM dbo.tblUser WHERE LTRIM(RTRIM(UserName)) = @FirstName + @LastName + '1') THEN LOWER(@FirstName + @LastName + '1')
WHEN NOT EXISTS (SELECT 1 FROM dbo.tblUser WHERE LTRIM(RTRIM(UserName)) = @FirstName + @LastName + '2') THEN LOWER(@FirstName + @LastName + '2')
WHEN NOT EXISTS (SELECT 1 FROM dbo.tblUser WHERE LTRIM(RTRIM(UserName)) = @FirstName + @LastName + '3') THEN LOWER(@FirstName + @LastName + '3')
WHEN NOT EXISTS (SELECT 1 FROM dbo.tblUser WHERE LTRIM(RTRIM(UserName)) = @FirstName + @LastName + '4') THEN LOWER(@FirstName + @LastName + '4')
WHEN NOT EXISTS (SELECT 1 FROM dbo.tblUser WHERE LTRIM(RTRIM(UserName)) = @FirstName + @LastName + '5') THEN LOWER(@FirstName + @LastName + '5')
WHEN NOT EXISTS (SELECT 1 FROM dbo.tblUser WHERE LTRIM(RTRIM(UserName)) = @FirstName + @LastName + '6') THEN LOWER(@FirstName + @LastName + '6')
WHEN NOT EXISTS (SELECT 1 FROM dbo.tblUser WHERE LTRIM(RTRIM(UserName)) = @FirstName + @LastName + '7') THEN LOWER(@FirstName + @LastName + '7')
WHEN NOT EXISTS (SELECT 1 FROM dbo.tblUser WHERE LTRIM(RTRIM(UserName)) = @FirstName + @LastName + '8') THEN LOWER(@FirstName + @LastName + '8')
WHEN NOT EXISTS (SELECT 1 FROM dbo.tblUser WHERE LTRIM(RTRIM(UserName)) = @FirstName + @LastName + '9') THEN LOWER(@FirstName + @LastName + '9')
ELSE LOWER(@FirstName + @LastName + '1111') END
                                           ,''
                                           ,@FirstName
                                           ,@LastName
                                           ,3
                                           ,NULL
                                           ,@CompanyName
                                           ,NULL
                                           ,@OfficeNumber
                                           ,NULL
                                           ,@WorkAddress2
                                           ,NULL
                                           ,@State
                                           ,NULL
                                           ,@Email
                                           ,@MobilePhone
                                           ,CASE WHEN @WholeSalerName = '0' THEN @WholeSalerName ELSE (SELECT TOP 1 WholeSalerID AS Id FROM dbo.tblWholeSaler WHERE LTRIM(RTRIM(Name)) = @WholeSalerName) END
                                           ,0
                                           ,''
                                           ,1
                                           ,0
                                           ,100
                                           ,0
                                           ,100
                                           ,0
                                           ,0
                                           ,0
                                           ,0
                                           ,NULL
                                           ,NULL
                                           ,1
                                           ,1
                                           ,0
                                           ,1
                                           ,''
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,0
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,'2018-08-03'
                                           ,0
                                           ,''
                                           ,NULL
                                           ,NULL
                                           ,@AggregratorNameAdminUpdate
                                           ,0
                                           ,0
                                           ,0
                                           ,0
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,0
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,0
                                           ,NULL
                                           ,NULL
                                           ,0
                                           ,0
                                           ,0
                                           ,0
                                           ,0
                                           ,0
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,0
                                           ,NULL
                                           ,0
                                           ,NULL
                                           ,0
                                           ,0
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,NULL
                                           ,(SELECT TOP 1 WholeSalerID AS Id FROM dbo.tblWholeSaler WHERE LTRIM(RTRIM(Name)) = @SubWholeSalerName), @ParentId", users);
        }

        #region Private Methods
        private long GetLong(object value, long defaultValue = 0)
        {
            if (value == null || string.IsNullOrWhiteSpace(value.ToString())) return defaultValue;
            try
            {
                return long.Parse(value.ToString().Trim());
            }
            catch
            {
            }
            return defaultValue;
        }

        #endregion
    }
}
