﻿using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImportParentChildAccounts
{
    class Program
    {
        private static readonly ILogger Logger = LogManager.GetCurrentClassLogger();
        static void Main(string[] args)
        {
            try
            {
                Logger.Info("Start");
                var importData = new ImportData();
                importData.Logger = Logger;
                importData.ImportBrokerpediaUsers();
                //importData.ImportMFAAHistoryNotes();
                //importData.ImportMFAAToUsers();
            }
            catch (Exception ex)
            {
                Logger.Error(ex.ToString());
            }
        }
    }
}