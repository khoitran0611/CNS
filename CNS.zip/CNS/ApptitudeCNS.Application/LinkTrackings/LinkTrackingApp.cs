﻿using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.LinkTrackings
{
    public class LinkTrackingApp : ILinkTrackingApp
    {
        private IGenericRepository<LinkTracking> LinkTrackingRespository { get; }
        private IGenericRepository<URLTracking> URLTrackingRespository { get; }
        private IGenericRepository<Client> ClientRespository { get; }
        private IGenericRepository<User> UserRespository { get; }
        private IGenericRepository<Article> ArticleRespository { get; }

        public LinkTrackingApp(IGenericRepository<LinkTracking> linkTrackingRespository,
            IGenericRepository<URLTracking> urlTrackingRespository,
            IGenericRepository<Client> clientRespository,
            IGenericRepository<User> userRespository,
            IGenericRepository<Article> articleRespository)
        {
            LinkTrackingRespository = linkTrackingRespository;
            URLTrackingRespository = urlTrackingRespository;
            ClientRespository = clientRespository;
            UserRespository = userRespository;
            ArticleRespository = articleRespository;
        }

        public List<LinkTrackingViewModel> GetList(int pageIndex, int pageSize, string sortFieldName)
        {
            //join ct in ClientTypeRespository.Entities on m.ClientId equals ct.ClientId
            var result = (from url in URLTrackingRespository.EntitiesNoTracking
                          join l in LinkTrackingRespository.EntitiesNoTracking on url.Id equals l.LinkId
                          join c in ClientRespository.EntitiesNoTracking on l.ClientId equals c.Id into gc
                          from client in gc.DefaultIfEmpty()
                          join u in UserRespository.EntitiesNoTracking on l.UserId equals u.Id into gu
                          from user in gu.DefaultIfEmpty()
                          join a in ArticleRespository.EntitiesNoTracking on url.Id equals a.URLTrackingId into ga
                          from article in ga.DefaultIfEmpty()
                          where (client == null || !client.IsDeleted) && (user == null || (!user.IsDeleted && user.SendSampleEmailType == null))
                          group new { url, client, user, article } by new { url.Id, url.ReturnedURL, url.CreatedDate, url.LastClickedDate } into ag
                          //orderby m.ScheduledTime descending
                          select new LinkTrackingViewModel
                          {
                              Id = ag.Key.Id,
                              Subject = ag.FirstOrDefault().article.Title.Trim() ?? ag.Key.ReturnedURL,
                              Link = ag.Key.ReturnedURL,
                              CreatedDate = ag.Key.CreatedDate,
                              LastClickedDate = ag.Key.LastClickedDate,
                              ClientClickCount = ag.Count(x => x.client != null && x.client.Id > 0),
                              UserClickCount = ag.Count(x => x.user != null && x.user.Id > 0)
                          });

            switch (sortFieldName)
            {
                case "LastClickedDate asc":
                    result = result.OrderBy(x => x.LastClickedDate);
                    break;
                case "Link asc":
                    result = result.OrderBy(x => x.Subject);
                    break;
                case "Link desc":
                    result = result.OrderByDescending(x => x.Subject);
                    break;
                case "ClientClickCount asc":
                    result = result.OrderBy(x => x.ClientClickCount);
                    break;
                case "ClientClickCount desc":
                    result = result.OrderByDescending(x => x.ClientClickCount);
                    break;
                case "UserClickCount asc":
                    result = result.OrderBy(x => x.UserClickCount);
                    break;
                case "UserClickCount desc":
                    result = result.OrderByDescending(x => x.UserClickCount);
                    break;
                default:
                    result = result.OrderByDescending(x => x.LastClickedDate);
                    break;
            }
            var data = result.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
            //var articles = ArticleRespository.GetAll().Where(x => data.Any(y => y.Id == x.URLTrackingId)).ToList();
            //Parallel.ForEach(data, x => x.Subject = articles.LastOrDefault(y => y.URLTrackingId == x.Id)?.Title ?? x.Link);

            return data;
        }

        public long GetCount()
        {
            var result = (from url in URLTrackingRespository.Entities
                          join l in LinkTrackingRespository.EntitiesNoTracking on url.Id equals l.LinkId
                          join c in ClientRespository.EntitiesNoTracking on l.ClientId equals c.Id into gc
                          from client in gc.DefaultIfEmpty()
                          join u in UserRespository.EntitiesNoTracking on l.UserId equals u.Id into gu
                          from user in gu.DefaultIfEmpty()
                          where (client == null || !client.IsDeleted) && (user == null || (!user.IsDeleted && user.SendSampleEmailType == null))
                          group url by new
                          {
                              url.Id,
                              url.ReturnedURL,
                              url.CreatedDate
                          } into url
                          //orderby m.ScheduledTime descending
                          select 1).LongCount();
            return result;
        }

        public List<LinkTrackingDetailViewModel> GetClientDetailList(int pageIndex, int pageSize, long linkId, string sortFieldName)
        {
            //join ct in ClientTypeRespository.Entities on m.ClientId equals ct.ClientId
            var result = (from l in LinkTrackingRespository.Entities
                          join c in ClientRespository.Entities on l.ClientId equals c.Id
                          where !c.IsDeleted && l.LinkId == linkId
                          select new LinkTrackingDetailViewModel
                          {
                              Id = c.Id,
                              FirstName = c.FirstName,
                              LastName = c.LastName,
                              //FullName = (c.FirstName + " " + c.LastName).Trim(),
                              Email = c.Email,
                              Phone = c.Phone,
                              ClickedDate = l.ClickedDate
                          });

            switch (sortFieldName)
            {
                case "ClickedDate asc":
                    result = result.OrderBy(x => x.ClickedDate);
                    break;
                case "FullName asc":
                    result = result.OrderBy(x => (x.FirstName + " " + x.LastName).Trim());
                    break;
                case "FullName desc":
                    result = result.OrderByDescending(x => (x.FirstName + " " + x.LastName).Trim());
                    break;
                case "Email asc":
                    result = result.OrderBy(x => x.Email);
                    break;
                case "Email desc":
                    result = result.OrderByDescending(x => x.Email);
                    break;
                case "Phone asc":
                    result = result.OrderBy(x => x.Phone);
                    break;
                case "Phone desc":
                    result = result.OrderByDescending(x => x.Phone);
                    break;
                default:
                    result = result.OrderByDescending(x => x.ClickedDate);
                    break;
            }
            return result.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
        }

        public long GetClientDetailCount(long linkId)
        {
            var result = (from l in LinkTrackingRespository.Entities
                          join c in ClientRespository.Entities on l.ClientId equals c.Id
                          where !c.IsDeleted && l.LinkId == linkId
                          select 1).LongCount();
            return result;
        }

        public List<LinkTrackingDetailViewModel> GetUserDetailList(int pageIndex, int pageSize, long linkId, string sortFieldName)
        {
            //join ct in ClientTypeRespository.Entities on m.ClientId equals ct.ClientId
            var result = (from l in LinkTrackingRespository.Entities
                          join u in UserRespository.Entities on l.UserId equals u.Id
                          where !u.IsDeleted && l.LinkId == linkId && u.SendSampleEmailType == null
                          select new LinkTrackingDetailViewModel
                          {
                              Id = u.Id,
                              FirstName = u.FirstName,
                              LastName = u.LastName,
                              InternalIdentifier = u.InternalIdentifier,
                              //FullName = (u.FirstName + " " + u.LastName).Trim(),
                              Email = u.Email,
                              Phone = u.Phone,
                              ClickedDate = l.ClickedDate
                          });

            switch (sortFieldName)
            {
                case "ClickedDate asc":
                    result = result.OrderBy(x => x.ClickedDate);
                    break;
                case "FullName asc":
                    result = result.OrderBy(x => (x.FirstName + " " + x.LastName).Trim());
                    break;
                case "FullName desc":
                    result = result.OrderByDescending(x => (x.FirstName + " " + x.LastName).Trim());
                    break;
                case "Email asc":
                    result = result.OrderBy(x => x.Email);
                    break;
                case "Email desc":
                    result = result.OrderByDescending(x => x.Email);
                    break;
                case "Phone asc":
                    result = result.OrderBy(x => x.Phone);
                    break;
                case "Phone desc":
                    result = result.OrderByDescending(x => x.Phone);
                    break;
                default:
                    result = result.OrderByDescending(x => x.ClickedDate);
                    break;
            }
            return result.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
        }
        public long GetUserDetailCount(long linkId)
        {
            var result = (from l in LinkTrackingRespository.Entities
                          join u in UserRespository.Entities on l.UserId equals u.Id
                          where !u.IsDeleted && l.LinkId == linkId
                          select 1).LongCount();
            return result;
        }

        public string GetLink(long id)
        {
            var result = (from u in URLTrackingRespository.Entities
                          join l in LinkTrackingRespository.Entities on u.Id equals l.LinkId
                          where u.Id == id
                          select u.ReturnedURL).FirstOrDefault();
            return result;

        }
    }
}
