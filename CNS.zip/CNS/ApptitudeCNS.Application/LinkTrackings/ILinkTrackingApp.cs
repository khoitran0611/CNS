﻿using ApptitudeCNS.Application.ViewModel;
using System.Collections.Generic;

namespace ApptitudeCNS.Application.LinkTrackings
{
    public interface ILinkTrackingApp
    {
        List<LinkTrackingViewModel> GetList(int pageIndex, int pageSize, string sortFieldName);
        long GetCount();

        List<LinkTrackingDetailViewModel> GetClientDetailList(int pageIndex, int pageSize, long linkId, string sortFieldName);
        long GetClientDetailCount(long linkId);

        List<LinkTrackingDetailViewModel> GetUserDetailList(int pageIndex, int pageSize, long linkId, string sortFieldName);
        long GetUserDetailCount(long linkId);

        string GetLink(long id);
    }
}
