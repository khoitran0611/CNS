﻿using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.PrimaryImages
{
    public class PrimaryImageApp : IPrimaryImageApp
    {
        private IGenericRepository<PrimaryImage> PrimaryImageRespository { get; }

        public PrimaryImageApp(IGenericRepository<PrimaryImage> primaryImageRespository)
        {
            PrimaryImageRespository = primaryImageRespository;
        }

        public List<PrimaryImageViewModel> GetList()
        {
            return PrimaryImageRespository.EntitiesNoTracking.Where(x => !x.IsDeleted).OrderByDescending(x => x.CreatedDate).AsEnumerable()
                .Select(x => AutoMapperGenericsHelper<PrimaryImage, PrimaryImageViewModel>.FullCopy(x)).ToList();
        }

        public PrimaryImageViewModel Save(PrimaryImage item)
        {
            PrimaryImageRespository.Create(item);
            PrimaryImageRespository.SaveChanges();
            return AutoMapperGenericsHelper<PrimaryImage, PrimaryImageViewModel>.FullCopy(item);
        }

        public PrimaryImage GetLastItem()
        {
            return PrimaryImageRespository.EntitiesNoTracking.Where(x => !x.IsDeleted).OrderByDescending(x => x.CreatedDate).FirstOrDefault() ?? new PrimaryImage();
        }

        public PrimaryImage FindBy(long id)
        {
            return PrimaryImageRespository.EntitiesNoTracking.Where(x => !x.IsDeleted && x.Id == id).FirstOrDefault() ?? new PrimaryImage();
        }

        public void Delete(long id, long userId)
        {
            var existItem = PrimaryImageRespository.FindBy(id);
            existItem.UpdatedUserId = userId;
            existItem.UpdatedDate = DateTime.Now;
            existItem.IsDeleted = true;
            PrimaryImageRespository.Update(existItem);
            PrimaryImageRespository.SaveChanges();
        }
    }
}
