﻿using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;

namespace ApptitudeCNS.Application.PrimaryImages
{
    public interface IPrimaryImageApp
    {
        List<PrimaryImageViewModel> GetList();
        PrimaryImage GetLastItem();
        PrimaryImage FindBy(long id);
        PrimaryImageViewModel Save(PrimaryImage item);
        void Delete(long id, long userId);
    }
}
