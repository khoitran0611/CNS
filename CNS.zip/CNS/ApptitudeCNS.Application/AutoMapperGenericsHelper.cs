﻿using ApptitudeCNS.Helpers;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application
{
    public class AutoMapperGenericsHelper<TSource, TDestination>
    {
        public static IList<TDestination> FullCopyList(IList<TSource> model)
        {
            var config = new MapperConfiguration(cfg => cfg.CreateMap<TSource, TDestination>());
            var mapper = config.CreateMapper();
            return mapper.Map<IList<TDestination>>(model);
        }

        public static TDestination FullCopy(TSource model)
        {
            var config = new MapperConfiguration(cfg => cfg.CreateMap<TSource, TDestination>());
            var mapper = config.CreateMapper();
            return mapper.Map<TDestination>(model);
        }

        public static TDestination FullCopy(TSource model, TDestination destination, Action<IMappingOperationOptions<TSource, TDestination>> opts = null)
        {
            var config = new MapperConfiguration(cfg => cfg.CreateMap<TSource, TDestination>());
            var mapper = config.CreateMapper();
            if (opts == null)
                return mapper.Map<TSource, TDestination>(model, destination);
            return mapper.Map<TSource, TDestination>(model, destination, opts);
        }
    }
}
