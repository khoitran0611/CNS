﻿using ApptitudeCNS.Helpers;
using System;

namespace ApptitudeCNS.Application.Response
{
    public class ImportClientsResponse
    {
        public ImportClientsResponse()
        {
        }

        public int AddedCount { get; set; }
        public int UpdatedCount { get; set; }
        //public string ErrorMessage { get; set; }

        public string Message
        {
            get
            {
                return $"{AddedCount} clients are added <br /> {UpdatedCount} clients are updated.";
            }
        }
    }
}
