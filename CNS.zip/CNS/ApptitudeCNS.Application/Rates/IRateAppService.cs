﻿namespace ApptitudeCNS.Application.Rates
{
    public interface IRateAppService
    {
        void SendLowestLenders();

        void SendAndrewSms();
    }
}
