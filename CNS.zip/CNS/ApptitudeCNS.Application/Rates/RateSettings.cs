﻿namespace ApptitudeCNS.Application.Rates
{
    public class RateSettings
    {
        public long SenderId { get; set; }

        public string[] AndrewNumbers { get; set; }
        public string AndrewSmsMessage { get; set; }

        public decimal RateDelta { get; set; }
    }
}
