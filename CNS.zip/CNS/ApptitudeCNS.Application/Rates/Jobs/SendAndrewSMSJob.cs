﻿using System;
using System.Threading.Tasks;
using InfoCorp.Ico.Senc.Infrastructure.Logging;
using Quartz;

namespace ApptitudeCNS.Application.Rates.Jobs
{
    public class SendAndrewSmsJob : IJob
    {
        public SendAndrewSmsJob(IRateAppService rateAppService, ILogger logger)
        {
            _rateAppService = rateAppService;
            _logger = logger;
        }

        private IRateAppService _rateAppService;
        private ILogger _logger;

        public Task Execute(IJobExecutionContext context)
        {
            _logger.LogDebugStart(nameof(SendAndrewSmsJob));

            try
            {
                _rateAppService.SendAndrewSms();
            }
            catch (Exception ex)
            {
                _logger.LogWarn(ex.ToString());
            }

            _logger.LogDebugEnd(nameof(SendAndrewSmsJob));
            return Task.CompletedTask;
        }
    }
}
