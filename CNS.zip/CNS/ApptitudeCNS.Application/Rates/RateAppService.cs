﻿using ApptitudeCNS.Application.MailTrackings;
using ApptitudeCNS.Core.IRepository;
using ApptitudeCNS.Infrastructure.Email.Domain.EmailTemplates;
using ApptitudeCNS.Infrastructure.Email.Services;
using ApptitudeCNS.Infrastructure.Sms.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ApptitudeCNS.Application.Rates
{
    public class RateAppService : IRateAppService
    {
        public RateAppService(IRateRepository rateRepository, IEmailService emailService, ISmsService smsService, IMailTrackingApp mailTrackingApp, RateSettings rateSettings)
        {
            _rateRepository = rateRepository;
            _emailService = emailService;
            _smsService = smsService;
            _mailTrackingApp = mailTrackingApp;
            _rateSettings = rateSettings;
        }

        private readonly IRateRepository _rateRepository;
        private readonly IEmailService _emailService;
        private readonly ISmsService _smsService;
        private readonly IMailTrackingApp _mailTrackingApp;
        private readonly RateSettings _rateSettings;

        public void SendLowestLenders()
        {
            var lowestLenders = _rateRepository.GetTop12LowestLenders();
            var lowestLenderViewModels = lowestLenders.GroupBy(n => n.LenderId).Select(n =>
            {
                var lowestLenderViewModel = new LowestLenderViewModel();
                foreach (var lowestLenderRateType in n)
                {
                    lowestLenderViewModel.LenderName = lowestLenderRateType.LenderName;
                    switch (lowestLenderRateType.RateType)
                    {
                        case 1:
                            lowestLenderViewModel.VariableRate = new RateCellViewModel { Value = lowestLenderRateType.FinalCurrent };
                            break;
                        case 5:
                            lowestLenderViewModel.FixedRate1Y = new RateCellViewModel { Value = lowestLenderRateType.FinalCurrent };
                            break;
                        case 6:
                            lowestLenderViewModel.FixedRate2Y = new RateCellViewModel { Value = lowestLenderRateType.FinalCurrent };
                            break;
                        case 7:
                            lowestLenderViewModel.FixedRate3Y = new RateCellViewModel { Value = lowestLenderRateType.FinalCurrent };
                            break;
                        case 8:
                            lowestLenderViewModel.FixedRate4Y = new RateCellViewModel { Value = lowestLenderRateType.FinalCurrent };
                            break;
                        case 9:
                            lowestLenderViewModel.FixedRate5Y = new RateCellViewModel { Value = lowestLenderRateType.FinalCurrent };
                            break;
                        default:
                            throw new Exception("Implementation Error!");
                    }
                }

                return lowestLenderViewModel;
            }).ToList();

            // Normalize null
            lowestLenderViewModels.ForEach(n =>
            {
                if (n.VariableRate == null) n.VariableRate = new NullRateCellViewModel();
                if (n.FixedRate1Y == null) n.FixedRate1Y = new NullRateCellViewModel();
                if (n.FixedRate2Y == null) n.FixedRate2Y = new NullRateCellViewModel();
                if (n.FixedRate3Y == null) n.FixedRate3Y = new NullRateCellViewModel();
                if (n.FixedRate4Y == null) n.FixedRate4Y = new NullRateCellViewModel();
                if (n.FixedRate5Y == null) n.FixedRate5Y = new NullRateCellViewModel();
            });

            SetRedForLenders(lowestLenderViewModels);

            var lowestLendersViewModel = new LowestLendersViewModel(lowestLenderViewModels);

            string emailHtml = _emailService.GetEmailHtml(lowestLendersViewModel);

            _mailTrackingApp.SendLowestRateToAll(_rateSettings.SenderId, lowestLendersViewModel.Subject, emailHtml);
        }

        public void SendAndrewSms()
        {
            var lowestLenders = _rateRepository.GetTop12LowestLenders();
            var lenderGroups = lowestLenders.GroupBy(n => n.LenderId);

            decimal rateDelta = lenderGroups.LastOrDefault().Min(n => n.FinalCurrent) - lenderGroups.FirstOrDefault().Min(n => n.FinalCurrent);
            if (rateDelta > _rateSettings.RateDelta)
            {
                _smsService.SendSms(_rateSettings.AndrewSmsMessage, _rateSettings.AndrewNumbers);
            }
        }

        private void SetRedForLenders(IList<LowestLenderViewModel> lowestLenderViewModels)
        {
            foreach (var lowestLenderViewModel in lowestLenderViewModels)
            {
                var minRateCell = GetRateList(lowestLenderViewModel).OrderBy(n => n.Value).FirstOrDefault();
                minRateCell.HasRedColor = true;
            }
        }

        private IList<RateCellViewModel> GetRateList(LowestLenderViewModel lowestLenderViewModel)
        {
            return new List<RateCellViewModel>() {
                    lowestLenderViewModel.VariableRate,
                    lowestLenderViewModel.FixedRate1Y,
                    lowestLenderViewModel.FixedRate2Y,
                    lowestLenderViewModel.FixedRate3Y,
                    lowestLenderViewModel.FixedRate4Y,
                    lowestLenderViewModel.FixedRate5Y
                };
        }
    }
}
