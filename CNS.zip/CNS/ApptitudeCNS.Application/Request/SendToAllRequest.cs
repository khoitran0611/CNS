﻿using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.Request
{
    public class SendToAllRequest
    {
        public SendToAllRequest()
        {
            Status = EnumEmailStatusType.Unsent;
        }

        public long SenderId { get; set; }
        //public long CreatedUserId { get; set; }
        public long[] ArticleIds { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }
        public DateTime ScheduledTime { get; set; }
        public EnumEmailStatusType Status { get; set; } //enum(1:unsent, 2:sent, 3:failed, 4:Read, 5:Clicked)
        public EnumEmailType TypeId { get; set; } //enum(1:broker message, 2:article, 3: lowest rates)

        public int[] UserTypeIds { get; set; }
        public int[] ClientTypeIds { get; set; }

        public bool IsSelectedCompanyImage { get; set; }
        public string PrimaryImageName { get; set; }

        public string Url { get; set; }
    }
}
