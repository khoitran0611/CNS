﻿using ApptitudeCNS.Helpers;
using System;

namespace ApptitudeCNS.Application.Request
{
    public class EmailTemplateBodyRequest
    {
        public EmailTemplateBodyRequest()
        {
            Subject = string.Empty;
        }

        public long SenderId { get; set; }
        public long ClientId { get; set; }
        public long UserId { get; set; }
        public long[] ArticleIds { get; set; }

        public bool IsPreSent { get; set; }
        public long NewsLetterEmailId { get; set; }

        public bool IsSelectedCompanyImage { get; set; }
        public string PrimaryImageName { get; set; }

        public string Url { get; set; }

        public bool isUsedBrokerMessage { get; set; }
        public string brokerMessage { get; set; }

        public string Subject { get; set; }
    }
}
