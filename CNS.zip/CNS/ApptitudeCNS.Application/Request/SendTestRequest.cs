﻿using ApptitudeCNS.Helpers;
using System;

namespace ApptitudeCNS.Application.Request
{
    public class SendTestRequest
    {
        public SendTestRequest()
        {
            Status = EnumEmailStatusType.Unsent;
        }

        public long SenderId { get; set; }
        public long ClientId { get; set; }
        public long[] ArticleIds { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }
        public DateTime ScheduledTime { get; set; }

        public bool IsSelectedCompanyImage { get; set; }
        public string PrimaryImageName { get; set; }

        public EnumEmailStatusType Status { get; set; } //enum(1:unsent, 2:sent, 3:failed, 4:Read, 5:Clicked)
        public EnumEmailType TypeId { get; set; } //enum(1:broker message, 2:article, 3: lowest rates)

        public string Url { get; set; }
    }
}
