﻿using ApptitudeCNS.Helpers;
using System;

namespace ApptitudeCNS.Application.Request
{
    public class NewsLetterEmailRequest
    {
        public NewsLetterEmailRequest()
        {
        }

        public long Id { get; set; }
        public string ArticleIds { get; set; }

        public string BrokerMessage { get; set; }
        public string Url { get; set; }

        public bool IsSelectedCompanyImage { get; set; }
        public string PrimaryImageName { get; set; }
    }
}
