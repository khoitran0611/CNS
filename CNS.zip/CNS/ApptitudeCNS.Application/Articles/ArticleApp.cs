﻿using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.Tags;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Core.IRepository;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.Articles
{
    public class ArticleApp : IArticleApp
    {
        private IGenericRepository<Article> ArticleRespository { get; }
        private IGenericRepository<ArticleTag> ArticleTagRespository { get; }
        private IGenericRepository<ArticleAttachment> ArticleAttachmentRespository { get; }
        private IGenericRepository<ManualArticleTag> ManualArticleTagRespository { get; }
        private IGenericRepository<Tag> TagRespository { get; }
        private IGenericRepository<ArticleDoNotSendUserType> ArticleDoNotSendUserTypeRespository { get; }
        private IGenericRepository<ArticleDoNotSendClientType> ArticleDoNotSendClientTypeRespository { get; }
        private IGenericRepository<ArticleHistory> ArticleHistoryRespository { get; }
        private IGenericRepository<URLTracking> URLTrackingRespository { get; }
        private IGenericRepository<RecipientType> RecipientTypeRespository { get; }
        private IGenericRepository<User> UserRespository { get; }
        private IGenericRepository<NewsLetterEmail> NewsLetterEmailRespository { get; }
        private IGenericRepository<ArticleSentHistory> ArticleSentHistoryRespository { get; }
        //private IGenericRepository<ArticleType> ArticleTypeRespository { get; }
        private IGenericRepository<SystemConfig> SystemConfigRespository { get; }
        private IBpNoiseWordRepository BpNoiseWordRepository { get; }

        private ITagApp TagApp { get; }

        public ArticleApp(IGenericRepository<Article> articleRespository,
            IGenericRepository<URLTracking> urlTrackingRespository,
            IGenericRepository<RecipientType> recipientTypeRespository,
            IGenericRepository<ArticleHistory> articleHistoryRespository,
            IGenericRepository<ArticleTag> articleTagRespository,
            IGenericRepository<ArticleAttachment> articleAttachmentRespository,
            IGenericRepository<ManualArticleTag> manualArticleTagRespository,
            IGenericRepository<Tag> tagRespository,
            IGenericRepository<ArticleDoNotSendUserType> articleDoNotSendUserTypeRespository,
            IGenericRepository<ArticleDoNotSendClientType> articleDoNotSendClientTypeRespository,
            IGenericRepository<User> userRespository,
            IGenericRepository<NewsLetterEmail> newsLetterEmailRespository,
            IGenericRepository<ArticleSentHistory> articleSentHistoryRespository,
            IGenericRepository<SystemConfig> systemConfigRespository,
            ITagApp tagApp,
            IBpNoiseWordRepository bpNoiseWordRepository)
        {
            ArticleRespository = articleRespository;
            URLTrackingRespository = urlTrackingRespository;
            RecipientTypeRespository = recipientTypeRespository;
            ArticleHistoryRespository = articleHistoryRespository;
            ArticleTagRespository = articleTagRespository;
            ArticleAttachmentRespository = articleAttachmentRespository;
            ManualArticleTagRespository = manualArticleTagRespository;
            TagRespository = tagRespository;
            ArticleDoNotSendUserTypeRespository = articleDoNotSendUserTypeRespository;
            ArticleDoNotSendClientTypeRespository = articleDoNotSendClientTypeRespository;
            UserRespository = userRespository;
            NewsLetterEmailRespository = newsLetterEmailRespository;
            ArticleSentHistoryRespository = articleSentHistoryRespository;
            SystemConfigRespository = systemConfigRespository;
            TagApp = tagApp;
            BpNoiseWordRepository = bpNoiseWordRepository;
        }

        public List<ArticleViewModel> GetArticleList(ArticleFilterViewModel filter)
        {
            // only return an item when id > 0
            //if (filter.id > 0)
            //{
            //    var data = new List<ArticleViewModel>();
            //    var item = FindBy(filter.id);
            //    if (item.Id > 0)
            //    {
            //        data.Add(item);
            //    }
            //    return data;
            //}

            //if (filter.tagIds == null || filter.tagIds.Length == 0) return new List<ArticleViewModel>();
            //if (filter.recipientTypeIds == null || filter.recipientTypeIds.Length == 0) return new List<ArticleViewModel>();

            if (string.IsNullOrWhiteSpace(filter.searchText))
            {
                filter.searchText = string.Empty;
            }
            else
            {
                filter.searchText = filter.searchText.Trim();
            }

            //var articleTagIds = filter.tagIds.Length == CommonHelper.GetListForEnum<EnumArticleTagType>().Count ? new List<int>() : filter.tagIds.ToList();
            var articleTagIds = filter.tagIds == null ? new List<int>() : filter.tagIds.Any(x => x == 0) ? TagRespository.FindBy(x => !x.IsDeleted).Select(x => x.Id).ToList() : filter.tagIds.ToList();
            //var articleTagIds = filter.tagIds == null ? new List<int>() : filter.tagIds.ToList();
            var ids = filter.ids == null || filter.ids.Length == 0 ? new List<long>() : filter.ids.ToList();
            //var articleTypes = CommonHelper.GetListForEnum<EnumArticleType>();

            var result = (from a in ArticleRespository.EntitiesNoTracking
                          join at in ArticleTagRespository.EntitiesNoTracking on a.Id equals at.ArticleId into gat
                          from atg in gat.DefaultIfEmpty()
                          join aa in ArticleAttachmentRespository.EntitiesNoTracking on a.Id equals aa.ArticleId into gaa
                          from aag in gaa.DefaultIfEmpty()
                          join u in URLTrackingRespository.EntitiesNoTracking on a.URLTrackingId equals u.Id into gu
                          from ug in gu.DefaultIfEmpty()
                          where !a.IsDeleted && (!filter.isNew || a.LastSent == null) &&
                                (ids.Contains(a.Id) || //(filter.articleType == 0 || filter.articleType == a.ArticleTypeId) &&
                                filter.id == a.Id ||
                                (filter.id <= 0 && (articleTagIds.Contains(atg.TagId))))
                          select new { a, atg, ug, aag }).AsEnumerable();

            if (filter.isSearchAdvanced)
            {
                //var words = new List<string>(filter.searchText.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));
                //foreach (var word in words)
                //{
                //    result = result.Where(x =>  (x.a.Subject.Contains(word)));
                //}

                //result = result.Where(x => (filter.searchText == string.Empty || words.Any(y => x.a.Subject.IndexOf(y, StringComparison.OrdinalIgnoreCase) >= 0)));

                filter.searchText = RemoveNoiseWords(filter.searchText);
                //var words = filter.searchText.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                result = result.Where(x => (filter.searchText == string.Empty ||
                                //(x.a.Subject != null && words.Any(y => x.a.Subject.IndexOf(y, StringComparison.OrdinalIgnoreCase) >= 0)) ||
                                (CommonHelper.CheckWords(filter.searchText,
                                string.Join(" ", x.a.Title, x.ug?.ReturnedURL, x.a.Author, x.a.SiteName, x.a.Summary, x.a.Organisation, x.aag?.OriginalName).Replace("_", " ")))));

                //result = result.Where(x => (filter.searchText == string.Empty ||
                //                //(x.a.Subject != null && words.Any(y => x.a.Subject.IndexOf(y, StringComparison.OrdinalIgnoreCase) >= 0)) ||
                //                (x.a.Title != null && words.Any(y => x.a.Title.IndexOf(y, StringComparison.OrdinalIgnoreCase) >= 0)) ||
                //                (x.ug.ReturnedURL != null && words.Any(y => x.ug.ReturnedURL.IndexOf(y, StringComparison.OrdinalIgnoreCase) >= 0)) ||
                //                (x.a.Author != null && words.Any(y => x.a.Author.IndexOf(y, StringComparison.OrdinalIgnoreCase) >= 0)) || 
                //                (x.a.SiteName != null && words.Any(y => x.a.SiteName.IndexOf(y, StringComparison.OrdinalIgnoreCase) >= 0)) ||
                //                (x.a.Summary != null && words.Any(y => x.a.Summary.IndexOf(y, StringComparison.OrdinalIgnoreCase) >= 0))));
            }
            else
            {
                result = result.Where(x => (filter.searchText == string.Empty ||
                                //x.a.Subject.IndexOf(filter.searchText, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                x.a.Title.IndexOf(filter.searchText, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                x.ug?.ReturnedURL.IndexOf(filter.searchText, StringComparison.OrdinalIgnoreCase) >= 0));
            }

            //, x.Where(y => y.atg != null).Select(y => y.atg.TagId).Distinct()
            var result2 = (from x in result
                           group new { x.a, x.atg, x.ug, x.aag } by new { x.a.Id, x.a.ArticleDate } into ag
                           //orderby ag.Key.ArticleDate descending, ag.Key.Id descending
                           select new { Article = ag.FirstOrDefault().a, Url = ag.FirstOrDefault().ug, Attachment = ag.FirstOrDefault().aag, ArticleTagIds = ag.Where(x => x.atg != null).Select(x => x.atg.TagId).Distinct() });

            //var result2 = result.GroupBy(x => new { x.a.Id, x.a.ArticleDate })
            //    .Select(x => new { x.FirstOrDefault(y => y.a), x.FirstOrDefault(y => y.u) });
            //, new { x.a.Id, x.a.ArticleDate }) into ag
            //orderby ag.Key.ArticleDate descending, ag.Key.Id descending
            //                      select new { Article = ag.FirstOrDefault().a, Url = ag.FirstOrDefault().u, ArticleTagIds = ag.Where(x => x.atg != null).Select(x => x.atg.TagId).Distinct() });
            //        .Select(u, ArticleTags = atg }).AsEnumerable().
            //        GroupBy(r => new { r.Article.Id
            //}, (key, g) => new { g.First().Article, g.First().Url, ArticleTagIds = g.Where(x => x.ArticleTags != null).Select(x => x.ArticleTags.TagId).Distinct() })

            //var result = (from a in ArticleRespository.EntitiesNoTracking
            //              join at in ArticleTagRespository.EntitiesNoTracking on a.Id equals at.ArticleId into gat
            //              from atg in gat.DefaultIfEmpty()
            //              join u in URLTrackingRespository.EntitiesNoTracking on a.URLTrackingId equals u.Id
            //              where !a.IsDeleted && (!filter.isNew || a.LastSent == null) &&
            //                    (ids.Contains(a.Id) || //(filter.articleType == 0 || filter.articleType == a.ArticleTypeId) &&
            //                    filter.id == a.Id ||
            //                    (filter.id <= 0 && (articleTagIds.Contains(atg.TagId)) &&
            //                    (filter.searchText == string.Empty || a.Subject.Contains(filter.searchText) ||
            //                    a.Title.Contains(filter.searchText) || u.ReturnedURL.Contains(filter.searchText) ||
            //                    (filter.isSearchAdvanced && (a.Author.Contains(filter.searchText) ||
            //                        a.SiteName.Contains(filter.searchText) || a.Summary.Contains(filter.searchText))))))
            //              group new { a, atg, u } by new { a.Id, a.ArticleDate } into ag
            //              //orderby ag.Key.ArticleDate descending, ag.Key.Id descending
            //              select new { Article = ag.FirstOrDefault().a, Url = ag.FirstOrDefault().u, ArticleTagIds = ag.Where(x => x.atg != null).Select(x => x.atg.TagId).Distinct() });
            //.Select( u, ArticleTags = atg }).AsEnumerable().
            //GroupBy(r => new { r.Article.Id }, (key, g) => new { g.First().Article, g.First().Url, ArticleTagIds = g.Where(x => x.ArticleTags != null).Select(x => x.ArticleTags.TagId).Distinct() }).
            //.Skip((filter.pageIndex - 1) * ArticleConstants.PAGE_SIZE)
            //.Take(ArticleConstants.PAGE_SIZE * filter.pageCount).AsEnumerable();

            //switch (filter.sortBy)
            //{
            //    case "Id desc":
            //        result2 = result2.OrderByDescending(x => x.Article.Id);
            //        break;
            //    default:
            //        result2 = result2.OrderByDescending(x => x.Article.ArticleDate).ThenByDescending(x => x.Article.Id);
            //        break;
            //}
            result2 = result2.OrderByDescending(x => x.Article.ArticleDate.Value.Date).ThenByDescending(x => x.Article.OrderByDate);

            var data = result2.Skip((filter.pageIndex - 1) * ArticleConstants.PAGE_SIZE)
                          .Take(ArticleConstants.PAGE_SIZE * filter.pageCount + 1)//.AsEnumerable()
                          .Select(x => FullCopy(x.Article, x.Url, x.ArticleTagIds, x.Attachment)).ToList();

            SetFirstItemOfDay(data);
            ids = ids.Where(x => !data.Any(y => y.Id == x)).ToList();
            if (ids.Count > 0)
            {
                data.AddRange(FindBy(ids.ToArray()));
            }

            //select new ArticlesViewModel(a, u)).ToList();
            //select FullCopy()).ToList();
            //select FullCopy(a, u)).ToList();

            return data;
        }

        public ArticleCountViewModel GetCount(ArticleFilterViewModel filter)
        {
            var result = new ArticleCountViewModel();

            // only return an item when id > 0
            if (filter.id > 0)
            {
                var item = FindBy(filter.id);
                result.All = item.Id > 0 ? 1 : 0;
                result.New = item.Id > 0 && !item.LastSent.HasValue ? 1 : 0;
                return result;
            }

            if (filter.tagIds == null || filter.tagIds?.Length == 0) return result;

            if (string.IsNullOrWhiteSpace(filter.searchText))
            {
                filter.searchText = string.Empty;
            }
            else
            {
                filter.searchText = filter.searchText.Trim();
            }

            //var articleTagIds = filter.tagIds.Length == CommonHelper.GetListForEnum<EnumArticleTagType>().Count ? new List<int>() : filter.tagIds.ToList();
            //var articleTagIds = filter.tagIds?.ToList() ?? new List<int>();
            var articleTagIds = filter.tagIds == null ? new List<int>() : filter.tagIds.Any(x => x == 0) ? TagRespository.FindBy(x => !x.IsDeleted).Select(x => x.Id).ToList() : filter.tagIds.ToList();

            var data = (from a in ArticleRespository.EntitiesNoTracking
                        join at in ArticleTagRespository.EntitiesNoTracking on a.Id equals at.ArticleId into gat
                        from atg in gat.DefaultIfEmpty()
                        join u in URLTrackingRespository.EntitiesNoTracking on a.URLTrackingId equals u.Id into gu
                        from ug in gu.DefaultIfEmpty()
                        join aa in ArticleAttachmentRespository.EntitiesNoTracking on a.Id equals aa.ArticleId into gaa
                        from aag in gaa.DefaultIfEmpty()
                        where !a.IsDeleted && //(filter.articleType == 0 || filter.articleType == a.ArticleTypeId) &&
                                (articleTagIds.Contains(atg.TagId))
                        select new { a, ug, aag }).AsEnumerable();
            //select a.Id).Distinct().Count();

            if (filter.isSearchAdvanced)
            {
                //var words = new List<string>(filter.searchText.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));
                //foreach (var word in words)
                //{
                //    result = result.Where(x =>  (x.a.Subject.Contains(word)));
                //}

                //result = result.Where(x => (filter.searchText == string.Empty || words.Any(y => x.a.Subject.IndexOf(y, StringComparison.OrdinalIgnoreCase) >= 0)));

                filter.searchText = RemoveNoiseWords(filter.searchText);
                data = data.Where(x => (filter.searchText == string.Empty ||
                                //(x.a.Subject != null && words.Any(y => x.a.Subject.IndexOf(y, StringComparison.OrdinalIgnoreCase) >= 0)) ||
                                (CommonHelper.CheckWords(filter.searchText,
                                string.Join(" ", x.a.Title, x.ug?.ReturnedURL, x.a.Author, x.a.SiteName, x.a.Summary, x.a.Organisation, x.aag?.OriginalName).Replace("_", " ")))));
                //var words = filter.searchText.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                //data = data.Where(x => (filter.searchText == string.Empty ||
                //                //(x.a.Subject != null && words.Any(y => x.a.Subject.IndexOf(y, StringComparison.OrdinalIgnoreCase) >= 0)) ||
                //                (x.a.Title != null && words.Any(y => x.a.Title.IndexOf(y, StringComparison.OrdinalIgnoreCase) >= 0)) ||
                //                (x.u.ReturnedURL != null && words.Any(y => x.u.ReturnedURL.IndexOf(y, StringComparison.OrdinalIgnoreCase) >= 0)) ||
                //                (x.a.Author != null && words.Any(y => x.a.Author.IndexOf(y, StringComparison.OrdinalIgnoreCase) >= 0)) ||
                //                (x.a.SiteName != null && words.Any(y => x.a.SiteName.IndexOf(y, StringComparison.OrdinalIgnoreCase) >= 0)) ||
                //                (x.a.Summary != null && words.Any(y => x.a.Summary.IndexOf(y, StringComparison.OrdinalIgnoreCase) >= 0))));
            }
            else
            {
                data = data.Where(x => (filter.searchText == string.Empty ||
                                //x.a.Subject.IndexOf(filter.searchText, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                x.a.Title.IndexOf(filter.searchText, StringComparison.OrdinalIgnoreCase) >= 0 || x.ug?.ReturnedURL.IndexOf(filter.searchText, StringComparison.OrdinalIgnoreCase) >= 0));
            }

            var data2 = data.ToList();

            result.All = data.Select(x => x.a.Id).Distinct().Count();
            result.New = data.Where(x => x.a.LastSent == null).Select(x => x.a.Id).Distinct().Count();
            return result;
        }

        public bool CheckExistLink(long id, string link)
        {
            if (string.IsNullOrWhiteSpace(link)) return false;
            link = link.Trim().ToLower();
            var url = URLTrackingRespository.FindBy(x => link.Equals(x.ReturnedURL, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            if (url != null && ArticleRespository.EntitiesNoTracking.Any(x => x.URLTrackingId == url.Id && x.Id != id && !x.IsDeleted))
            {
                return true;
            }
            return false;
        }

        public ArticleViewModel FindBy(long id)
        {
            var result = (from a in ArticleRespository.EntitiesNoTracking
                              //join rt in RecipientTypeRespository.Entities on a.ArticleTypeId equals rt.Id
                          //join u in URLTrackingRespository.EntitiesNoTracking on a.URLTrackingId equals u.Id
                          join u in URLTrackingRespository.EntitiesNoTracking on a.URLTrackingId equals u.Id into gu
                          from ug in gu.DefaultIfEmpty()
                          join aa in ArticleAttachmentRespository.EntitiesNoTracking on a.Id equals aa.ArticleId into gaa
                          from aag in gaa.DefaultIfEmpty()
                          where !a.IsDeleted && a.Id == id
                          select new { Article = a, Url = ug, Attachment = aag }).FirstOrDefault();
            //select new ArticlesViewModel(a, u)).ToList();
            //select FullCopy()).ToList();
            //select FullCopy(a, u)).ToList();
            //return result;
            var item = result == null ? new ArticleViewModel() : FullCopy(result.Article, result.Url, null, result.Attachment, true);
            item.Histories = ArticleHistoryRespository.FindBy(x => !x.IsDeleted && x.ArticleId == item.Id).OrderByDescending(x => x.Id)
                .Select(x => AutoMapperGenericsHelper<ArticleHistory, ArticleHistoryViewModel>.FullCopy(x)).ToArray();
            return item;
        }

        public List<ArticleViewModel> FindBy(long[] ids)
        {
            var idList = ids.ToList();
            var result = (from a in ArticleRespository.EntitiesNoTracking
                              //join rt in RecipientTypeRespository.Entities on a.RecipientTypeId equals rt.Id
                          //join u in URLTrackingRespository.EntitiesNoTracking on a.URLTrackingId equals u.Id
                          join u in URLTrackingRespository.EntitiesNoTracking on a.URLTrackingId equals u.Id into gu
                          from ug in gu.DefaultIfEmpty()
                          join aa in ArticleAttachmentRespository.EntitiesNoTracking on a.Id equals aa.ArticleId into gaa
                          from aag in gaa.DefaultIfEmpty()
                          where !a.IsDeleted && idList.Contains(a.Id)
                          select new { Article = a, Url = ug, Attachment = aag }).ToList();
            //select new ArticlesViewModel(a, u)).ToList();
            //select FullCopy()).ToList();
            //select FullCopy(a, u)).ToList();
            return result.Select(x => FullCopy(x.Article, x.Url, null, x.Attachment)).SortBy(ids, c => c.Id).ToList();
        }

        public List<long> GetIds(long[] ids, long userId)
        {
            var idList = ids.ToList();
            var result = (from a in ArticleRespository.EntitiesNoTracking
                          where idList.Contains(a.Id) && a.CreatedUserId == userId
                          select a.Id).ToList();
            return result;
        }

        public ArticleViewModel FindByBrokerId(long brokerId)
        {
            var query = (from a in ArticleRespository.EntitiesNoTracking
                         where !a.IsDeleted && a.CreatedUserId == brokerId
                         select a).AsEnumerable();
            var result = query.LastOrDefault() ?? new Article();
            if (result.Id <= 0 || result.IsDeclined == true || result.Status > (int)EnumArticleStatusType.Reviewing)
            {
                result = new Article();
            }
            result.BrokerMessage = UserRespository.FindBy(brokerId).BrokerMessage;
            //select new ArticlesViewModel(a, u)).ToList();
            //select FullCopy()).ToList();
            //select FullCopy(a, u)).ToList();
            //return result;
            return FullCopy(result, null, null, null);
        }

        public Article GetArticleByBrokerId(long brokerId)
        {
            var query = (from a in ArticleRespository.EntitiesNoTracking
                         where !a.IsDeleted && a.CreatedUserId == brokerId
                         select a).AsEnumerable();
            return query.LastOrDefault() ?? new Article();
        }

        public NewsLetterEmailsViewModel GetNewsLetterEmails(long newsLetterEmailId, long currentUserId)
        {
            var result = new NewsLetterEmailsViewModel();

            var newsLetterEmailItem = NewsLetterEmailRespository.EntitiesNoTracking.FirstOrDefault(x => x.Id == newsLetterEmailId && x.UserId == currentUserId);// .FindBy(newsLetterEmailId);
            if (newsLetterEmailItem != null && newsLetterEmailItem.IsChangable)
            {
                result.Item = newsLetterEmailItem;
                var articleIds = newsLetterEmailItem.ArticleIds.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(x => CommonHelper.GetLong(x)).ToArray();
                result.Articles = FindBy(articleIds);
                return result;
            }
            result.Articles = new List<ArticleViewModel>();
            result.Item = new NewsLetterEmail();
            return result;
        }

        public bool SaveNewsLetterEmail(NewsLetterEmailRequest request, long currentUserId)
        {
            var newsLetterEmailItem = NewsLetterEmailRespository.EntitiesNoTracking.FirstOrDefault(x => x.Id == request.Id && x.UserId == currentUserId);// .FindBy(newsLetterEmailId);
            if (newsLetterEmailItem != null && newsLetterEmailItem.IsChangable)
            {
                //var articleIds = newsLetterEmailItem.ArticleIds.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(x => CommonHelper.GetLong(x)).ToArray();
                //return FindBy(articleIds);
                if (newsLetterEmailItem.ArticleIds != request.ArticleIds)
                {
                    newsLetterEmailItem.ArticleIds = request.ArticleIds;
                    newsLetterEmailItem.UpdatedDate = DateTime.Now;
                    NewsLetterEmailRespository.Update(newsLetterEmailItem);
                    NewsLetterEmailRespository.SaveChanges();

                    return true;
                }
            }
            return false;
            //return new List<ArticleViewModel>();
        }


        //public IEnumerable<RecipientType> GetRecipientTypes()
        //{
        //    return RecipientTypeRespository.GetAll();
        //}

        public long Create(ArticleViewModel model)
        {
            var article = AutoMapperGenericsHelper<ArticleViewModel, Article>.FullCopy(model);
            //var urlTracking = new URLTracking
            //{
            //    ReturnedURL = model.Link
            //};
            //URLTrackingRespository.Create(urlTracking);
            //URLTrackingRespository.SaveChanges();

            article.URLTrackingId = CreateOrUpdateURLTracking(model.Link);
            article.OrderByDate = GetNextOrderByDate(article.ArticleDate);
            ArticleRespository.Create(article);
            ArticleRespository.SaveChanges();

            //Save history
            if (!string.IsNullOrWhiteSpace(model.HistoryNote))
            {
                ArticleHistoryRespository.Create(new ArticleHistory
                {
                    ArticleId = article.Id,
                    IsSystemAutogen = true,
                    TypeId = (int)EnumHistoryType.Other,
                    Content = model.HistoryNote,
                    CreatedUserId = article.CreatedUserId
                });
                ArticleHistoryRespository.SaveChanges();
            }

            var articleTags = model.TagIds?.Select(x => new ArticleTag
                {
                    ArticleId = article.Id,
                    TagId = x
                }).ToList();

            if (articleTags == null || articleTags.Count == 0)
            {
                articleTags.Add(new ArticleTag { ArticleId = article.Id, TagId = 100 });
            }
            ArticleTagRespository.CreateRange(articleTags);
            ArticleTagRespository.SaveChanges();
            TagApp.UpdateManualArticleTags(article.Id, article.Title, model.TagIds);

            model.DoNotSendUserTypeIds = model.DoNotSendUserTypeIds ?? new List<int>();
            var articleDoNotSendUserTypes = model.DoNotSendUserTypeIds.Select(x => new ArticleDoNotSendUserType
            {
                ArticleId = article.Id,
                UserTypeId = x
            });
            ArticleDoNotSendUserTypeRespository.CreateRange(articleDoNotSendUserTypes);
            ArticleDoNotSendUserTypeRespository.SaveChanges();

            model.DoNotSendClientTypeIds = model.DoNotSendClientTypeIds ?? new List<int>();
            var articleDoNotSendClientTypes = model.DoNotSendClientTypeIds.Select(x => new ArticleDoNotSendClientType
            {
                ArticleId = article.Id,
                ClientTypeId = x
            });
            ArticleDoNotSendClientTypeRespository.CreateRange(articleDoNotSendClientTypes);
            ArticleDoNotSendClientTypeRespository.SaveChanges();

            if (model.Attachment != null)
            {
                model.Attachment.ArticleId = article.Id;
                ArticleAttachmentRespository.Create(model.Attachment);
                ArticleAttachmentRespository.SaveChanges();
            }
            //var articleTypes = model.RecipientTypes.Select(x => new ArticleType
            //{
            //    ArticleId = article.Id,
            //    TypeId = x
            //});
            //ArticleTypeRespository.CreateRange(articleTypes);
            //ArticleTypeRespository.SaveChanges();
            return article.Id;
        }

        public void Update(ArticleViewModel model)
        {
            var existItem = ArticleRespository.FindBy(model.Id);
            model.CreatedDate = existItem.CreatedDate.Value;
            model.CreatedUserId = existItem.CreatedUserId;

            var oldUrlTrackingId = existItem.URLTrackingId;
            existItem.URLTrackingId = CreateOrUpdateURLTracking(model.Link);

            if (oldUrlTrackingId != existItem.URLTrackingId)
            {
                model.LastSent = existItem.LastSent;
                model.Status = existItem.Status;
                model.HistoryNote = $"Make one up including the {model.Link}.";
            }

            if (model.IsDeclined == true && existItem.IsDeclined != true)
            {
                model.HistoryNote = string.IsNullOrWhiteSpace(model.HistoryNote) ?
                    $"Admin declined the article." :
                    $"{model.HistoryNote}{Environment.NewLine}Admin declined the article.";
            }

            existItem = AutoMapperGenericsHelper<ArticleViewModel, Article>.FullCopy(model, existItem);

            ArticleRespository.Update(existItem);
            ArticleRespository.SaveChanges();

            var existTypes = ArticleTagRespository.FindBy(x => x.ArticleId == model.Id);
            if (existTypes.Count() != model.TagIds.Count || !existTypes.All(x => model.TagIds.Contains(x.TagId)))
            {
                ArticleTagRespository.DeleteRange(existTypes);

                var articleTags = model.TagIds.Select(x => new ArticleTag
                {
                    ArticleId = model.Id,
                    TagId = x
                }).ToList();
                if (articleTags == null || articleTags.Count == 0)
                {
                    articleTags.Add(new ArticleTag { ArticleId = model.Id, TagId = 100 });
                }
                ArticleTagRespository.CreateRange(articleTags);
                ArticleTagRespository.SaveChanges();
            }
            TagApp.UpdateManualArticleTags(model.Id, model.Title, model.TagIds);

            var existUserTypes = ArticleDoNotSendUserTypeRespository.FindBy(x => x.ArticleId == model.Id);
            model.DoNotSendUserTypeIds = model.DoNotSendUserTypeIds ?? new List<int>();
            if (existUserTypes.Count() != model.DoNotSendUserTypeIds.Count || !existUserTypes.All(x => model.DoNotSendUserTypeIds.Contains(x.UserTypeId)))
            {
                ArticleDoNotSendUserTypeRespository.DeleteRange(existUserTypes);

                var articleDoNotSendUserTypes = model.DoNotSendUserTypeIds.Select(x => new ArticleDoNotSendUserType
                {
                    ArticleId = model.Id,
                    UserTypeId = x
                });
                ArticleDoNotSendUserTypeRespository.CreateRange(articleDoNotSendUserTypes);
                ArticleDoNotSendUserTypeRespository.SaveChanges();
            }

            var existClientTypes = ArticleDoNotSendClientTypeRespository.FindBy(x => x.ArticleId == model.Id);
            model.DoNotSendClientTypeIds = model.DoNotSendClientTypeIds ?? new List<int>();
            if (existClientTypes.Count() != model.DoNotSendClientTypeIds.Count || !existClientTypes.All(x => model.DoNotSendClientTypeIds.Contains(x.ClientTypeId)))
            {
                ArticleDoNotSendClientTypeRespository.DeleteRange(existClientTypes);

                var articleDoNotSendClientTypes = model.DoNotSendClientTypeIds.Select(x => new ArticleDoNotSendClientType
                {
                    ArticleId = model.Id,
                    ClientTypeId = x
                });
                ArticleDoNotSendClientTypeRespository.CreateRange(articleDoNotSendClientTypes);
                ArticleDoNotSendClientTypeRespository.SaveChanges();
            }

            // Update attachment
            if (model.Attachment != null)
            {
                var attachment = ArticleAttachmentRespository.FindBy(x => x.ArticleId == model.Id).FirstOrDefault();
                if (attachment == null)
                {
                    model.Attachment.ArticleId = model.Id;
                    ArticleAttachmentRespository.Create(model.Attachment);
                }
                else
                {
                    attachment.Name = model.Attachment.Name;
                    attachment.OriginalName = model.Attachment.OriginalName;
                    attachment.OriginalFile = model.Attachment.OriginalFile;
                    ArticleAttachmentRespository.Update(attachment);
                }
                ArticleAttachmentRespository.SaveChanges();
            }
            else
            {
                var attachment = ArticleAttachmentRespository.FindBy(x => x.ArticleId == model.Id).FirstOrDefault();
                if (attachment != null)
                {
                    ArticleAttachmentRespository.Delete(attachment);
                    ArticleAttachmentRespository.SaveChanges();
                }
            }

            //Save history
            if (!string.IsNullOrWhiteSpace(model.HistoryNote))
            {
                ArticleHistoryRespository.Create(new ArticleHistory
                {
                    ArticleId = model.Id,
                    IsSystemAutogen = true,
                    TypeId = (int)EnumHistoryType.Other,
                    Content = model.HistoryNote,
                    CreatedUserId = model.UpdatedUserId
                });
                ArticleHistoryRespository.SaveChanges();
            }
        }

        public void DeleteAttachment(long id, long userId)
        {
            var attachment = ArticleAttachmentRespository.FindBy(x => x.ArticleId == id).FirstOrDefault();
            if (attachment != null)
            {
                var article = ArticleRespository.FindBy(x => x.Id == id).FirstOrDefault();
                if (article != null)
                {
                    article.IsNewsletterArticleLink = false;
                    ArticleRespository.Update(article);
                    ArticleRespository.SaveChanges();
                }
                ArticleAttachmentRespository.Delete(attachment);
                ArticleAttachmentRespository.SaveChanges();
            }
        }
        public void UpdatePictureArticle(ArticleViewModel model)
        {
            var existItem = ArticleRespository.FindBy(model.Id);
            //var article = AutoMapperGenericsHelper<ArticlesViewModel, Article>.FullCopy(model, existItem, );
            existItem.Picture = model.Picture;
            existItem.UpdatedDate = model.UpdatedDate;
            existItem.UpdatedUserId = model.UpdatedUserId;

            ArticleRespository.Update(existItem);
            ArticleRespository.SaveChanges();
        }

        public void UpdateStatusArticles(List<long> articleIds, EnumArticleStatusType status)
        {
            var list = ArticleRespository.Entities.Where(x => articleIds.Contains(x.Id)).AsEnumerable();
            foreach (var item in list)
            {
                if (item.Status <= (int)EnumArticleStatusType.Reviewing ||
                    (status == EnumArticleStatusType.Sent && item.Status == (int)EnumArticleStatusType.Reviewing))
                {
                    item.Status = (int)status;
                    ArticleRespository.Update(item);
                }
            }
            ArticleRespository.SaveChanges();
        }

        public void UpdateLastSentArticles(SendToAllRequest request)
        {
            var articleIds = request.ArticleIds.ToList();
            articleIds.RemoveAt(articleIds.Count - 1);

            // long[] ids, DateTime lastSent
            var existItems = ArticleRespository.FindBy(x => articleIds.Any(y => y == x.Id));
            foreach (var item in existItems)
            {
                item.LastSent = request.ScheduledTime;
                if (request.UserTypeIds != null)
                {
                    item.SentUserTypeIds = string.Join(",", request.UserTypeIds);
                }
                if (request.ClientTypeIds != null)
                {
                    item.SentClientTypeIds = string.Join(",", request.ClientTypeIds);
                }
                ArticleRespository.Update(item);
            }
            ArticleRespository.SaveChanges();
        }

        public void UpdateLastSentArticles(SendToOneRequest request)
        {
            var articleIds = request.ArticleIds.ToList();
            articleIds.RemoveAt(articleIds.Count - 1);

            // long[] ids, DateTime lastSent
            var existItems = ArticleRespository.FindBy(x => articleIds.Any(y => y == x.Id));
            foreach (var item in existItems)
            {
                item.LastSent = request.ScheduledTime;
                ArticleRespository.Update(item);
            }
            ArticleRespository.SaveChanges();
        }

        public void DeleteRange(long[] ids, long userId)
        {
            var existItems = ArticleRespository.Entities.Where(x => ids.Any(y => y == x.Id));
            //var article = AutoMapperGenericsHelper<ArticlesViewModel, Article>.FullCopy(model, existItem, );

            Parallel.ForEach(existItems, existItem =>
            {
                existItem.UpdatedDate = DateTime.Now;
                existItem.IsDeleted = true;
                ArticleRespository.Update(existItem);
            });
            ArticleRespository.SaveChanges();
        }

        public void Delete(long id, long userId)
        {
            var existItem = ArticleRespository.FindBy(id);
            existItem.UpdatedUserId = userId;
            existItem.UpdatedDate = DateTime.Now;
            existItem.IsDeleted = true;
            ArticleRespository.Update(existItem);
            ArticleRespository.SaveChanges();
        }

        public List<string> GetArticlePictureList()
        {
            return (from a in ArticleRespository.EntitiesNoTracking
                        //join rt in RecipientTypeRespository.Entities on a.RecipientTypeId equals rt.Id
                    //join u in URLTrackingRespository.EntitiesNoTracking on a.URLTrackingId equals u.Id
                    where a.Picture != "" && a.Picture != null
                    select a.Picture).ToList();
        }

        public List<ArticleSentHistoryViewModel> GetArticleSentHistories(long articleId)
        {
            var result = ArticleSentHistoryRespository.EntitiesNoTracking.Where(x => !x.IsDeleted && x.ArticleId == articleId).AsEnumerable()
                .GroupBy(x => new { x.ArticleId, x.CreatedDate }).Select(x => FullCopy(x.Key.ArticleId, x.Key.CreatedDate, x.Select(y => y.RecipientTypeId))).ToList();
            return result;
        }

        public long[] GetInactiveArticles(List<long> ids)
        {
            return ArticleRespository.EntitiesNoTracking.Where(x => ids.Contains(x.Id) && (x.IsDeleted || x.IsDeclined == true)).Select(x => x.Id).ToArray();
        }

        public List<ArticleViewModel> LoadArticles()
        {
            var keyName = ArticleConstants.SELECTED_ARTICLE_LIST_NAME;
            var item = SystemConfigRespository.FindBy(x => !x.IsDeleted && x.KeyName == keyName).AsEnumerable().FirstOrDefault();
            if (item == null || string.IsNullOrWhiteSpace(item.Value))
                return null;

            //var user = bpAggregatorRepository.
            var articleIds = item.Value.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(x => CommonHelper.GetLong(x.Trim())).ToArray();
            return FindBy(articleIds).Where(x => x.IsDeclined != true).ToList();
        }

        public void SaveSelectedArticles(long[] ids, long userId)
        {
            var keyName = ArticleConstants.SELECTED_ARTICLE_LIST_NAME;
            var item = SystemConfigRespository.FindBy(x => !x.IsDeleted && x.KeyName == keyName).AsEnumerable().FirstOrDefault();
            if (item == null)
            {
                item = new SystemConfig
                {
                    KeyName = keyName,
                    Name = keyName,
                    Value = string.Join(",", ids),
                    CreatedDate = DateTime.Now,
                    CreatedUserId = userId
                };
                SystemConfigRespository.Create(item);
            }
            else
            {
                item.Value = string.Join(",", ids);
                item.UpdatedDate = DateTime.Now;
                item.UpdatedUserId = userId;
                SystemConfigRespository.Update(item);
            }

            SystemConfigRespository.SaveChanges();
        }

        public string GetAuthorFromLastArticle()
        {
            return (from a in ArticleRespository.EntitiesNoTracking
                    where a.Author != "" && a.Author != null
                    orderby a.UpdatedDate descending
                    select a.Author).FirstOrDefault();
        }

        public string GetSiteNameFromLastArticle()
        {
            return (from a in ArticleRespository.EntitiesNoTracking
                    where a.SiteName != "" && a.SiteName != null
                    orderby a.UpdatedDate descending
                    select a.SiteName).FirstOrDefault();
        }

        public int UpdateOrderByDate(long id, int changeOrder, long userId)
        {
            var item = ArticleRespository.FindBy(id);
            List<Article> list = null;
            var changeValue = 0;
            var change = 0;
            if (changeOrder > 0)
            {
                changeValue = -1;
                list = ArticleRespository.FindBy(x => !x.IsDeleted && DbFunctions.TruncateTime(x.ArticleDate) == DbFunctions.TruncateTime(item.ArticleDate) && item.OrderByDate < x.OrderByDate).OrderBy(x => x.OrderByDate).Take(changeOrder).ToList();
                change = list.Count;
            }
            else
            {
                changeValue = 1;
                list = ArticleRespository.FindBy(x => !x.IsDeleted && DbFunctions.TruncateTime(x.ArticleDate) == DbFunctions.TruncateTime(item.ArticleDate) && item.OrderByDate > x.OrderByDate).OrderByDescending(x => x.OrderByDate).Take(Math.Abs(changeOrder)).ToList();
                change = -list.Count;
            }

            if (list.Count == 0) return 0;

            item.OrderByDate = list[list.Count - 1].OrderByDate;

            ArticleRespository.Update(item);
            foreach (var article in list)
            {
                article.OrderByDate += changeValue;
                ArticleRespository.Update(article);
            }
            ArticleRespository.SaveChanges();
            return change;
        }
        #region Private methods
        private void SetFirstItemOfDay(List<ArticleViewModel>  list)
        {
            for (int i = 0; i < list.Count - 1; i++)
            {
                if (list[i].ArticleDate.Value.Date != list[i + 1].ArticleDate.Value.Date)
                {
                    list[i].IsFirstItemOfDay = true;
                }
            }

            if (list.Count > 1)
            {
                list.RemoveAt(list.Count - 1);
            }
        }
        private ArticleSentHistoryViewModel FullCopy(long articleId, DateTime createdDate, IEnumerable<int> recipientTypeIds)
        {
            return new ArticleSentHistoryViewModel
            {
                ArticleId = articleId,
                CreatedDate = createdDate,
                TypeIds = recipientTypeIds.ToArray(),
                TypeNames = string.Join(", ", recipientTypeIds.Select(x => GetRecipientTypeName(x)))
            };
        }

        private string GetRecipientTypeName(int id)
        {
            if (id < 1001)
            {
                var userType = (EnumUserType)id;
                return userType.GetDescription();
            }
            var clientType = (EnumClientType)(id - 1000);
            return clientType.GetDescription();
        }

        private ArticleViewModel FullCopy(Article article, URLTracking urlTracking, IEnumerable<int> articleTags, ArticleAttachment attachment, bool isFull = false)
        {
            var result = AutoMapperGenericsHelper<Article, ArticleViewModel>.FullCopy(article);
            if (urlTracking == null && article.URLTrackingId > 0)
            {
                urlTracking = URLTrackingRespository.FindBy(article.URLTrackingId.Value);
            }
            result.Link = urlTracking?.ReturnedURL;
            result.LinkId = urlTracking?.Id;
            result.Attachment = attachment;

            //result.TagIds = ((articleTags?.Any(x => x?.TagId > 0) ?? false) ? articleTags.Select(x => x.TagId).ToList() : null) ?? new List<int>();
            if (articleTags != null)
            {
                result.TagIds = (articleTags.Any() ? articleTags.ToList() : null) ?? new List<int>();
            }
            if (isFull)
            {
                if (articleTags == null)
                {
                    result.TagIds = ArticleTagRespository.EntitiesNoTracking.Where(x => x.ArticleId == article.Id).Select(x => x.TagId).ToList();
                }
                result.DoNotSendUserTypeIds = ArticleDoNotSendUserTypeRespository.EntitiesNoTracking.Where(x => x.ArticleId == article.Id).Select(x => x.UserTypeId).ToList();
                result.DoNotSendClientTypeIds = ArticleDoNotSendClientTypeRespository.EntitiesNoTracking.Where(x => x.ArticleId == article.Id).Select(x => x.ClientTypeId).ToList();
            }
            //var test = ArticleSentHistoryRespository.EntitiesNoTracking.Where(x => !x.IsDeleted && x.ArticleId == article.Id).ToList();
            result.IsArticleSendHistory = ArticleSentHistoryRespository.EntitiesNoTracking.Any(x => !x.IsDeleted && x.ArticleId == article.Id);//.AsEnumerable().Any();
            return result;
        }

        private long CreateOrUpdateURLTracking(string link)
        {
            if (string.IsNullOrWhiteSpace(link)) return 0;

            var urlTracking = URLTrackingRespository.Entities.FirstOrDefault(x => x.ReturnedURL == link);
            if (urlTracking != null)
            {
                return urlTracking.Id;
            }

            urlTracking = new URLTracking
            {
                ReturnedURL = link,
                CreatedDate = DateTime.Now
            };
            URLTrackingRespository.Create(urlTracking);
            URLTrackingRespository.SaveChanges();

            return urlTracking.Id;
        }

        private string RemoveNoiseWords(string searchText)
        {
            var result = searchText;
            var noiseWords = BpNoiseWordRepository.GetBpNoiseWords();
            foreach (var item in noiseWords)
            {
                result = CommonHelper.ReplaceWord(item.Name, result);
            }
            return string.IsNullOrWhiteSpace(result) ? searchText : result;
            //var words = searchText.Split(new char[] { ' ', ',', '.', '?' }, StringSplitOptions.RemoveEmptyEntries)
            //    .Where(x => !noiseWords.Any(y => x.Equals(y.Name, StringComparison.OrdinalIgnoreCase))).ToArray();

            //return words;
        }

        private int GetNextOrderByDate(DateTime? date)
        {
            var list = ArticleRespository.FindBy(x => !x.IsDeleted && DbFunctions.TruncateTime(x.ArticleDate) == DbFunctions.TruncateTime(date)).ToList();
            if (list == null || list.Count == 0) return 1;
            return list.Max(x => x.OrderByDate) + 1;
        }
        #endregion

    }
}
