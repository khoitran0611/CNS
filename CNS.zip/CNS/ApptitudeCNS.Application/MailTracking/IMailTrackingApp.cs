﻿using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;

namespace ApptitudeCNS.Application.MailTracking
{
    public interface IMailTrackingApp
    {
        List<MailTrackingViewModel> GetMailTrackingList(int pageIndex, int pageSize, List<int> types, string searchText, string sortFieldName);
        long GetCount(int pageIndex, List<int> types, string searchText);

        //IEnumerable<IdName> GetMailTypes();
        Client GetClientById(long id);

        string GetSubjectTemplate(long[] ids);
        string GetEmailTemplateBody(EmailTemplateBodyRequest request);

        void SendTest(SendTestRequest request);

        void SendLowestRateToAll(long senderId, string subject, string content);
        void SendToAll(SendToAllRequest request);

        List<MailSendingViewModel> GetMailSendingList();
        void SendMassEmail(long userId, string subject, string content, long[] clientIds, DateTime scheduleDate);
        void UpdateMailSendingList(List<MailSendingViewModel> list);

        void UnsubscribeClient(long clientId, long mailId);
    }
}
