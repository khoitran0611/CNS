﻿using ApptitudeCNS.Application.Articles;
using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Infrastructure.Email.Domain.EmailTemplates;
using ApptitudeCNS.Infrastructure.Email.Services;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.MailTracking
{
    public class MailTrackingApp : IMailTrackingApp
    {
        private IGenericRepository<EmailTracking> MailTrackingRespository { get; }
        private IGenericRepository<User> UserRespository { get; }
        private IGenericRepository<Client> ClientRespository { get; }
        private IGenericRepository<ClientType> ClientTypeRespository { get; }
        //private IGenericRepository<EmailStatus> EmailStatusRespository { get; }
        //private IGenericRepository<EmailType> EmailTypeRespository { get; }
        private IGenericRepository<UserHistory> UserHistoryRespository { get; }
        private IGenericRepository<ClientHistory> ClientHistoryRespository { get; }
        private IEmailService EmailService { get; }
        private IArticleApp ArticleApp { get; }

        public MailTrackingApp(IGenericRepository<EmailTracking> mailTrackingRespository, IGenericRepository<User> userRespository,
            IGenericRepository<Client> clientRespository, IGenericRepository<ClientType> clientTypeRespository,
            IGenericRepository<UserHistory> userHistoryRespository, IGenericRepository<ClientHistory> clientHistoryRespository,
            IEmailService emailService, IArticleApp articleApp)
        {
            MailTrackingRespository = mailTrackingRespository;
            UserRespository = userRespository;
            ClientRespository = clientRespository;
            ClientTypeRespository = clientTypeRespository;
            //EmailStatusRespository = emailStatusRespository;
            //EmailTypeRespository = emailTypeRespository;
            UserHistoryRespository = userHistoryRespository;
            ClientHistoryRespository = clientHistoryRespository;
            EmailService = emailService;
            ArticleApp = articleApp;
        }

        public List<MailTrackingViewModel> GetMailTrackingList(int pageIndex, int pageSize, List<int> types, string searchText, string sortFieldName)
        {
            if (string.IsNullOrWhiteSpace(searchText))
            {
                searchText = string.Empty;
            }
            else
            {
                searchText = searchText.Trim();
            }

            //join ct in ClientTypeRespository.Entities on m.ClientId equals ct.ClientId
            var result2 = (from m in MailTrackingRespository.Entities
                           join u in UserRespository.Entities on m.SenderId equals u.Id
                           join c in ClientRespository.Entities on m.ClientId equals c.Id
                           join b in UserRespository.Entities on c.UserId equals b.Id
                           //join ms in EmailStatusRespository.Entities on m.Status equals ms.Id
                           //join mt in GetMailTypes() on m.TypeId equals mt.Id
                           join t in types on m.TypeId equals t
                           where !u.IsDeleted && !c.IsDeleted && !b.IsDeleted && // (types != null && types.Contains(m.TypeId)) &&
                                 (searchText == string.Empty ||
                                 m.Subject.Contains(searchText) || m.Content.Contains(searchText) ||
                                 (u.FirstName + " " + u.LastName).Contains(searchText) || u.Email.Contains(searchText) ||
                                 (c.FirstName + " " + c.LastName).Contains(searchText) || c.Email.Contains(searchText))
                           //orderby m.ScheduledTime descending
                           select new
                           {
                               MailTracking = m,
                               User = u,
                               Client = c,
                               Broker = b,
                               //Status = ms
                               //Type = mt
                           }).AsEnumerable();

            //result = result.Join(GetMailTypes(), r => r.MailTracking.TypeId, mt => mt.Id, (r, mt) => new
            //{
            //    r.MailTracking,
            //    r.User,
            //    r.Client,
            //    r.Status,
            //    Type = mt
            //});
            //var tempp = result2.ToList();
            var result = (from m in result2
                          join mt in CommonHelper.GetListForEnum<EnumEmailType>() on m.MailTracking.TypeId equals mt.Id
                          join ms in CommonHelper.GetListForEnum<EnumEmailStatusType>() on m.MailTracking.Status equals ms.Id
                          select new
                          {
                              m.MailTracking,
                              m.User,
                              m.Client,
                              m.Broker,
                              Status = ms,
                              Type = mt
                          });

            switch (sortFieldName)
            {
                case "ScheduledTime asc":
                    result = result.OrderBy(x => x.MailTracking.ScheduledTime);
                    break;
                case "Subject asc":
                    result = result.OrderBy(x => x.MailTracking.Subject);
                    break;
                case "Subject desc":
                    result = result.OrderByDescending(x => x.MailTracking.Subject);
                    break;
                case "CreatedByName asc":
                    result = result.OrderBy(x => (x.User.FirstName + " " + x.User.LastName));
                    break;
                case "CreatedByName desc":
                    result = result.OrderByDescending(x => (x.User.FirstName + " " + x.User.LastName));
                    break;
                case "BrokerName asc":
                    result = result.OrderBy(x => (x.Broker.FirstName + " " + x.Broker.LastName));
                    break;
                case "BrokerName desc":
                    result = result.OrderByDescending(x => (x.Broker.FirstName + " " + x.Broker.LastName));
                    break;
                case "RecipientName asc":
                    result = result.OrderBy(x => (x.Client.FirstName + " " + x.Client.LastName));
                    break;
                case "RecipientName desc":
                    result = result.OrderByDescending(x => (x.Client.FirstName + " " + x.Client.LastName));
                    break;
                case "StatusName asc":
                    result = result.OrderBy(x => x.MailTracking.Status);
                    break;
                case "StatusName desc":
                    result = result.OrderByDescending(x => x.MailTracking.Status);
                    break;
                case "TypeName asc":
                    result = result.OrderBy(x => x.Type.Name);
                    break;
                case "TypeName desc":
                    result = result.OrderByDescending(x => x.Type.Name);
                    break;
                case "SentDate asc":
                    result = result.OrderBy(x => x.MailTracking.ScheduledTime);
                    break;
                default:
                    result = result.OrderByDescending(x => x.MailTracking.ScheduledTime);
                    break;
            }
            //select new MailTrackingsViewModel(a, u)).ToList();
            //select FullCopy()).ToList();
            //select FullCopy(a, u)).ToList();
            //return result;
            //var temp = result.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
            //var temp2 = temp.Select(x => new MailTrackingViewModel
            //{
            //    Id = x.MailTracking.Id,
            //    SentDate = x.MailTracking.ScheduledTime,
            //    Subject = x.MailTracking.Subject,
            //    RecipientName = $"{x.Client.FirstName} {x.Client.LastName}",
            //    SenderName = $"{x.User.FirstName} {x.User.LastName}",
            //    SenderId = x.User.Id,
            //    RecipientId = x.Client.Id,
            //    TypeName = x.Type.Name,
            //    StatusName = x.Status.Name
            //}).ToList();
            return result.Select(x => new MailTrackingViewModel
            {
                Id = x.MailTracking.Id,
                SentDate = x.MailTracking.ScheduledTime,
                Subject = x.MailTracking.Subject,
                CreatedByName = $"{x.User.FirstName} {x.User.LastName}",
                CreatedById = x.User.Id,
                BrokerName = $"{x.Broker.FirstName} {x.Broker.LastName}",
                BrokerId = x.Broker.Id,
                RecipientName = $"{x.Client.FirstName} {x.Client.LastName}",
                RecipientId = x.Client.Id,
                TypeName = x.Type.Name,
                StatusName = x.Status.Name
            }).ToList();
        }

        public long GetCount(int pageIndex, List<int> types, string searchText)
        {
            if (string.IsNullOrWhiteSpace(searchText))
            {
                searchText = string.Empty;
            }
            else
            {
                searchText = searchText.Trim();
            }

            return (from m in MailTrackingRespository.Entities
                    join u in UserRespository.Entities on m.SenderId equals u.Id
                    join c in ClientRespository.Entities on m.ClientId equals c.Id
                    join t in types on m.TypeId equals t
                    where !u.IsDeleted && !c.IsDeleted && // (types != null && types.Contains(m.TypeId)) &&
                          (searchText == string.Empty ||
                          m.Subject.Contains(searchText) || m.Content.Contains(searchText) ||
                          (u.FirstName + " " + u.LastName).Contains(searchText) || u.Email.Contains(searchText) ||
                          (c.FirstName + " " + c.LastName).Contains(searchText) || c.Email.Contains(searchText))
                    //orderby m.ScheduledTime descending
                    select 1).LongCount();
        }

        //public IEnumerable<IdName> GetMailTypes()
        //{
        //    return Enum.GetValues(typeof(EnumEmailType)).Cast<EnumEmailType>().Select(x => new IdName { Id = (int)x, Name = x.ToString() }).ToList();
        //    //return EmailTypeRespository.GetAll().ToList();//.Entities.ToList();
        //}

        //public IEnumerable<IdName> GetMailStatuses()
        //{
        //    return Enum.GetValues(typeof(EnumEmailStatusType)).Cast<EnumEmailStatusType>().Select(x => new IdName { Id = (int)x, Name = x.ToString() }).ToList();
        //    //return EmailTypeRespository.GetAll().ToList();//.Entities.ToList();
        //}

        public Client GetClientById(long id)
        {
            return ClientRespository.FindBy(id);
        }

        public string GetSubjectTemplate(long[] ids)
        {
            var item = ArticleApp.FindBy(ids[0]);
            return item?.Subject;
        }

        public string GetEmailTemplateBody(EmailTemplateBodyRequest request)
        {
            var articles = ArticleApp.FindBy(request.ArticleIds).SortBy(request.ArticleIds, c => c.Id);
            var user = UserRespository.FindBy(request.SenderId);
            var client = ClientRespository.FindBy(request.ClientId);
            var mailArticles = articles.Select(x => AutoMapperGenericsHelper<ArticleViewModel, MailArticleViewModel>.FullCopy(x)).ToList();
            var data = new MailArticlesViewModel(mailArticles)
            {
                PrimaryColor = user?.PrimaryColor ?? "blue",
                SecondaryColor = user?.SecondaryColor ?? "red",
                Salutation = client?.Salutation,
                Url = request.Url,
                ClientId = client.Id
            };
            var result = EmailService.GetEmailHtml(data);
            return result;
        }

        public void SendTest(SendTestRequest request)
        {
            //var body = EmailService.GetEmailHtml<MailArticleViewModel>();
            //var client = ClientRespository.FindBy(request.ClientId);
            request.Content = GetEmailTemplateBody(AutoMapperGenericsHelper<SendTestRequest, EmailTemplateBodyRequest>.FullCopy(request));
            request.Subject = GetSubjectTemplate(request.ArticleIds);
            var item = AutoMapperGenericsHelper<SendTestRequest, EmailTracking>.FullCopy(request);

            MailTrackingRespository.Create(item);
            MailTrackingRespository.SaveChanges();
        }

        public void SendLowestRateToAll(long senderId, string subject, string content)
        {
            var clients = (from u in UserRespository.Entities
                           join c in ClientRespository.Entities on u.Id equals c.UserId
                           join ct in ClientTypeRespository.Entities on c.Id equals ct.ClientId
                           where !u.IsDeleted && !c.IsDeleted
                               && u.EmailSubscribe.HasValue && u.EmailSubscribe.Value
                               && c.EmailSubscribe.HasValue && c.EmailSubscribe.Value
                           select c).Distinct().ToList();

            if (clients.Count > 0)
            {
                UserHistoryRespository.Create(new UserHistory
                {
                    Content = subject,
                    TypeId = (int)EnumHistoryType.Email,
                    IsSystemAutogen = true,
                    CreatedDate = DateTime.Now,
                    UserId = senderId
                });

                UserHistoryRespository.SaveChanges();
            }

            IList<EmailTracking> emailTrackings = new List<EmailTracking>();
            clients.ForEach(n => emailTrackings.Add(new EmailTracking
            {
                SenderId = senderId,
                ClientId = n.Id,
                Subject = subject,
                Content = content,
                ScheduledTime = DateTime.Now,
                Status = 1,
                TypeId = 3
            }));

            MailTrackingRespository.CreateRange(emailTrackings);
            MailTrackingRespository.SaveChanges();
        }

        public void SendToAll(SendToAllRequest request)
        {
            var recipientTypeIds = request.RecipientTypeIds.ToList();
            var mailTrackings = (from u in UserRespository.Entities
                                 join c in ClientRespository.Entities on u.Id equals c.UserId
                                 join ct in ClientTypeRespository.Entities on c.Id equals ct.ClientId
                                 where !u.IsDeleted && !c.IsDeleted && u.EmailSubscribe.HasValue && u.EmailSubscribe.Value &&
                                     c.EmailSubscribe.HasValue && c.EmailSubscribe.Value && recipientTypeIds.Contains(ct.TypeId)
                                 //(request.RecipientTypeIds != null && request.RecipientTypeIds.Any(x => x == ct.TypeId))
                                 select c).Distinct().ToList();

            request.Subject = GetSubjectTemplate(request.ArticleIds);
            var mailTrackingList = mailTrackings.Select(x => FullCopy(request, x)).ToList();
            if (mailTrackingList.Count > 0)
            {
                UserHistoryRespository.Create(new UserHistory
                {
                    Content = request.Subject,
                    TypeId = (int)EnumHistoryType.Email,
                    IsSystemAutogen = true,
                    CreatedDate = DateTime.Now,
                    UserId = request.SenderId
                });
                UserHistoryRespository.SaveChanges();
            }
            MailTrackingRespository.CreateRange(mailTrackingList);
            MailTrackingRespository.SaveChanges();

            ArticleApp.UpdateLastSentArticles(request.ArticleIds, request.ScheduledTime);
        }
        public void SendMassEmail(long userId , string subject , string content, long[] clientIds , DateTime scheduleDate)
        {
            var mailTrackingList = clientIds.Select(c => new EmailTracking()
            {
                ClientId = c,                
                ScheduledTime = scheduleDate,
                SenderId = userId,
                TypeId = (int)EnumEmailType.BrokerMessage,
                Status = (int)EnumEmailStatusType.Unsent,
                Content = content,
                Subject = subject
            })
            .ToList();

            MailTrackingRespository.CreateRange(mailTrackingList);
            MailTrackingRespository.SaveChanges();

            if (mailTrackingList.Count > 0)
            {
                //Log user history
                UserHistoryRespository.Create(new UserHistory
                {
                    Content = subject,
                    TypeId = (int)EnumHistoryType.Email,
                    IsSystemAutogen = true,
                    CreatedDate = DateTime.Now,
                    UserId = userId
                });
                UserHistoryRespository.SaveChanges();

                //Update last send mass email
                var user = UserRespository.FindBy(userId);
                if(user != null)
                {
                    user.LastSendMassEmail = DateTime.Now;
                    UserRespository.Update(user);
                    UserRespository.SaveChanges();
                }
            }
        }

        public List<MailSendingViewModel> GetMailSendingList()
        {
            var result = (from m in MailTrackingRespository.EntitiesNoTracking
                          join c in ClientRespository.EntitiesNoTracking on m.ClientId equals c.Id
                          join b in UserRespository.EntitiesNoTracking on c.UserId equals b.Id
                          where !c.IsDeleted && !b.IsDeleted && m.Status == (int)EnumEmailStatusType.Unsent && m.ScheduledTime <= DateTime.Now
                          select new
                          {
                              MailTracking = m,
                              Client = c,
                              Broker = b
                          }).AsEnumerable();

            return result.Select(x => new MailSendingViewModel
            {
                Id = x.MailTracking.Id,
                Subject = x.MailTracking.Subject,
                Content = x.MailTracking.Content,
                BrokerName = $"{x.Broker.FirstName} {x.Broker.LastName}".Trim(),
                BrokerEmail = x.Broker.Email,
                RecipientName = $"{x.Client.FirstName} {x.Client.LastName}".Trim(),
                RecipientEmail = x.Client.Email,
                TypeId = (EnumEmailType)x.MailTracking.TypeId,
                Status = (EnumEmailStatusType)x.MailTracking.Status
            }).ToList();
        }

        public void UpdateMailSendingList(List<MailSendingViewModel> list)
        {
            foreach (var item in list)
            {
                var mailTracking = MailTrackingRespository.FindBy(item.Id);
                mailTracking.Status = (int)item.Status;
                mailTracking.ErrorNote = item.ErrorNote;
                MailTrackingRespository.Update(mailTracking);

                ClientHistoryRespository.Create(new ClientHistory
                {
                    Content = item.Subject,
                    ClientId = item.Id,
                    TypeId = (int)EnumHistoryType.Email,
                    IsSystemAutogen = true,
                    CreatedDate = DateTime.Now,
                    UpdatedDate = DateTime.Now,
                    CreatedUserId = ConfigManager.SystemUserId
                });
            }
            MailTrackingRespository.SaveChanges();
            ClientHistoryRespository.SaveChanges();
        }

        public void UnsubscribeClient(long clientId, long mailId)
        {
            var mailTrackingItem = MailTrackingRespository.FindBy(mailId);
            var clientItem = ClientRespository.FindBy(clientId);

            if (mailTrackingItem != null)
            {
                if (mailTrackingItem.Status == (int)EnumEmailStatusType.Unsent)
                {
                    mailTrackingItem.Status = (int)EnumEmailStatusType.Sent;
                    MailTrackingRespository.Update(mailTrackingItem);
                    MailTrackingRespository.SaveChanges();
                }
            }

            if (clientItem != null)
            {
                clientItem.EmailSubscribe = false;
                ClientRespository.Update(clientItem);
                ClientRespository.SaveChanges();

                ClientHistoryRespository.Create(new ClientHistory
                {
                    Content = "Client unsubscribed the email",
                    ClientId = clientId,
                    TypeId = (int)EnumHistoryType.Email,
                    IsSystemAutogen = true,
                    CreatedDate = DateTime.Now,
                    UpdatedDate = DateTime.Now,
                    CreatedUserId = ConfigManager.SystemUserId
                });
                ClientHistoryRespository.SaveChanges();
            }
        }

        #region Private method
        private EmailTracking FullCopy(SendToAllRequest request, Client client)
        {
            var emailTemplateBodyRequest = AutoMapperGenericsHelper<SendToAllRequest, EmailTemplateBodyRequest>.FullCopy(request);
            emailTemplateBodyRequest.ClientId = client.Id;
            request.Content = GetEmailTemplateBody(emailTemplateBodyRequest);

            var result = AutoMapperGenericsHelper<SendToAllRequest, EmailTracking>.FullCopy(request);
            result.ClientId = client.Id;
            return result;
        }

        #endregion
    }
}
