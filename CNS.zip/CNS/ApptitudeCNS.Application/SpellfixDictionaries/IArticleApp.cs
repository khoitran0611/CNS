﻿using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;

namespace ApptitudeCNS.Application.Articles
{
    public interface IArticleApp
    {
        List<ArticleViewModel> GetArticleList(ArticleFilterViewModel filter);
        ArticleCountViewModel GetCount(ArticleFilterViewModel filter);
        bool CheckExistLink(long id, string link);
        ArticleViewModel FindBy(long id);
        ArticleViewModel FindByBrokerId(long brokerId);
        Article GetArticleByBrokerId(long brokerId);
        NewsLetterEmailsViewModel GetNewsLetterEmails(long newsLetterEmailId, long currentUserId);
        bool SaveNewsLetterEmail(NewsLetterEmailRequest request, long currentUserId);

        List<ArticleViewModel> FindBy(long[] ids);
        //IEnumerable<RecipientType> GetRecipientTypes();
        List<long> GetIds(long[] ids, long userId);

        long Create(ArticleViewModel model);
        void UpdatePictureArticle(ArticleViewModel model);
        void Update(ArticleViewModel model);

        void UpdateStatusArticles(List<long> articleIds, EnumArticleStatusType status);

        void UpdateLastSentArticles(SendToAllRequest request);
        void UpdateLastSentArticles(SendToOneRequest request);
        void Delete(long id, long userId);
        void DeleteRange(long[] ids, long userId);

        List<string> GetArticlePictureList();

        List<ArticleSentHistoryViewModel> GetArticleSentHistories(long articleId);

        long[] GetInactiveArticles(List<long> ids);
    }
}
