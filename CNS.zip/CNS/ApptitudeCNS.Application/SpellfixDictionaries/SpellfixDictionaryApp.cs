﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;

namespace ApptitudeCNS.Application.SpellfixDictionaries
{
    public class SpellfixDictionaryApp : ISpellfixDictionaryApp
    {
        private IGenericRepository<SpellfixDictionary> SpellfixDictionaryRespository { get; }
        public SpellfixDictionaryApp(IGenericRepository<SpellfixDictionary> spellfixDictionaryRespository)
        {
            SpellfixDictionaryRespository = spellfixDictionaryRespository;
        }

        public List<SpellfixDictionaryViewModel> GetList()
        {
            return SpellfixDictionaryRespository.FindBy(x => !x.IsDeleted).OrderBy(x => x.CurrentText).Select(x => AutoMapperGenericsHelper<SpellfixDictionary, SpellfixDictionaryViewModel>.FullCopy(x)).ToList();
        }

        //public bool CheckExistName(long id, string name)
        //{
        //    if (string.IsNullOrWhiteSpace(name)) return false;
        //    name = name.Trim();
        //    var item = SpellfixDictionaryRespository.FindBy(x => x.Id != id && !x.IsDeleted && x.ProperText.Equals(name, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
        //    if (item != null)
        //    {
        //        return true;
        //    }
        //    return false;
        //}

        public long Create(SpellfixDictionaryViewModel model)
        {
            var oldItem = SpellfixDictionaryRespository.FindBy(x => x.ProperText == model.ProperText && 
            !x.IsDeleted).FirstOrDefault();
            if (oldItem != null)
            {
                model.Id = oldItem.Id;
                model.CurrentText = $"{oldItem.CurrentText},{model.CurrentText}";
                Update(model);
                return model.Id;
            }

            model.CurrentText = string.Join(",", model.CurrentText.Split(new string[] { Environment.NewLine, ",", "\n" }, StringSplitOptions.RemoveEmptyEntries)
                .Where(x => !string.IsNullOrWhiteSpace(x)).Select(x => x.Trim()).Distinct());
            var item = AutoMapperGenericsHelper<SpellfixDictionaryViewModel, SpellfixDictionary>.FullCopy(model);
            SpellfixDictionaryRespository.Create(item);
            SpellfixDictionaryRespository.SaveChanges();
            return item.Id;
        }

        public void Update(SpellfixDictionaryViewModel model)
        {
            var deleteItem = SpellfixDictionaryRespository.FindBy(x => x.ProperText == model.ProperText && x.Id != model.Id && !x.IsDeleted).FirstOrDefault();
            if (deleteItem != null)
            {
                model.CurrentText = $"{deleteItem.CurrentText},{model.CurrentText}";
                Delete(deleteItem.Id, model.UpdatedUserId);
            }

            model.CurrentText = string.Join(",", model.CurrentText.Split(new string[] { Environment.NewLine, ",", "\n" }, StringSplitOptions.RemoveEmptyEntries)
                .Where(x => !string.IsNullOrWhiteSpace(x)).Select(x => x.Trim()).Distinct());

            var oldItem = SpellfixDictionaryRespository.FindBy(model.Id);
            oldItem.CurrentText = model.CurrentText;
            oldItem.ProperText = model.ProperText;
            oldItem.UpdatedDate = DateTime.Now;
            oldItem.UpdatedUserId = model.UpdatedUserId;

            SpellfixDictionaryRespository.Update(oldItem);
            SpellfixDictionaryRespository.SaveChanges();
        }

        public void Delete(long id, long userId)
        {
            var item = SpellfixDictionaryRespository.FindBy(id);
            item.IsDeleted = true;
            SpellfixDictionaryRespository.Update(item);
            SpellfixDictionaryRespository.SaveChanges();
        }

        public string GetProperTextTitle(string title)
        {
            var result = SentenceCase(title);
            var list = SpellfixDictionaryRespository.FindBy(x => !x.IsDeleted).ToList();
            var regex = new Regex("");
            //var words = $" { CommonHelper.GetWord(result) } ";
            foreach (var item in list)
            {
                var currentWords = item.CurrentText.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (var currentWord in currentWords)
                {
                    result = CommonHelper.ReplaceWord(currentWord, result, item.ProperText ?? string.Empty);
                    //var word = $"\\b{ Regex.Escape(currentWord)}\\b";
                    //if (word[2] == '\\')
                    //{
                    //    word = word.Substring(2);
                    //}
                    //if (word[word.Length - 3] == '\\')
                    //{
                    //    word = word.Substring(0, word.Length - 2);
                    //}
                    ////word = Regex.Escape(word);
                    //result = Regex.Replace(result, word, item.ProperText ?? string.Empty, RegexOptions.IgnoreCase);
                    //if (words.Contains(word))
                    //{
                    //    result = result.Replace(currentWord, item.ProperText);
                    //}
                }
            }
            return result.Trim();
        }

        private string SentenceCase(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return string.Empty;

            var sentence = input.ToLower();
            var index = 0;
            while (!Char.IsLetterOrDigit(sentence[index]))
            {
                index++;
            }
            var result = sentence.ToCharArray();
            result[index] = char.ToUpper(sentence[index]);

            return new string(result);
        }
    }
}
