﻿using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;

namespace ApptitudeCNS.Application.Tags
{
    public interface ITagApp
    {
        List<TagViewModel> GetList();
        List<IdName> GetTagList();
        List<int> GetTagsByMapNames(string mapNames);
        bool CheckExistName(int id, string name);
        int Create(TagViewModel model);
        void Update(TagViewModel model);
        void Delete(int id, long userId, int newTagId);
    }
}
