﻿using ApptitudeCNS.Application.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.SpellfixDictionaries
{
    public interface ISpellfixDictionaryApp
    {
        List<SpellfixDictionaryViewModel> GetList();
        //List<IdName> GetTagList();
        //bool CheckExistName(long id, string name);
        long Create(SpellfixDictionaryViewModel model);
        void Update(SpellfixDictionaryViewModel model);
        //void Delete(int id, long userId, int newTagId);
        void Delete(long id, long userId);
        string GetProperTextTitle(string title);
    }
}
