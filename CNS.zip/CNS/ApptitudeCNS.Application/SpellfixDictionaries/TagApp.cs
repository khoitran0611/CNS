﻿using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.Tags;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.Tags
{
    public class TagApp : ITagApp
    {
        private IGenericRepository<ArticleTag> ArticleTagRespository { get; }
        private IGenericRepository<Tag> TagRespository { get; }

        public TagApp(IGenericRepository<ArticleTag> articleTagRespository,
            IGenericRepository<Tag> tagRespository)
        {
            ArticleTagRespository = articleTagRespository;
            TagRespository = tagRespository;
        }


        public List<TagViewModel> GetList()
        {
            return TagRespository.FindBy(x => !x.IsDeleted).OrderBy(x => x.OrderNumber).ThenBy(x => x.Name).Select(x => AutoMapperGenericsHelper<Tag, TagViewModel>.FullCopy(x)).ToList();
        }

        public List<IdName> GetTagList()
        {
            return TagRespository.FindBy(x => !x.IsDeleted).OrderBy(x => x.OrderNumber).ThenBy(x => x.Name).Select(x => new IdName
            {
                Id = x.Id,
                Name = x.Name
            }).ToList();
        }

        public List<int> GetTagsByMapNames(string mapNames)
        {
            mapNames = CommonHelper.GetWord(mapNames).ToLower();
            if (string.IsNullOrWhiteSpace(mapNames)) return new List<int>();

            var tags = TagRespository.FindBy(x => !x.IsDeleted);
            return tags.Where(x => x.MapNames.ToLower().Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries)
                .Any(y => mapNames == y || mapNames.StartsWith($"{y} ") || mapNames.EndsWith($" {y}") || mapNames.Contains($" {y} "))).Select(x => x.Id).ToList();
        }

        public bool CheckExistName(int id, string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return false;
            name = name.Trim().ToLower();
            var url = TagRespository.FindBy(x => x.Id != id && !x.IsDeleted && name.Equals(x.Name, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            if (url != null)
            {
                return true;
            }
            return false;
        }

        public int Create(TagViewModel model)
        {
            var tag = AutoMapperGenericsHelper<TagViewModel, Tag>.FullCopy(model);
            TagRespository.Create(tag);
            TagRespository.SaveChanges();
            return tag.Id;
        }

        public void Update(TagViewModel model)
        {
            var oldTag = TagRespository.FindBy(model.Id);
            oldTag.Name = model.Name;
            oldTag.MapNames = model.MapNames;
            oldTag.OrderNumber = model.OrderNumber;
            oldTag.UpdatedDate = DateTime.Now;
            oldTag.UpdatedUserId = model.UpdatedUserId;

            TagRespository.Update(oldTag);
            TagRespository.SaveChanges();
        }

        public void Delete(int id, long userId, int newTagId)
        {
            var oldTag = TagRespository.FindBy(id);
            oldTag.IsDeleted = true;
            TagRespository.Update(oldTag);
            TagRespository.SaveChanges();

            // Update all this tag to new tag
            if (newTagId > 0)
            {
                var articleTags = ArticleTagRespository.FindBy(x => x.TagId == id).ToList();
                articleTags.ForEach(x => {
                    var list = ArticleTagRespository.FindBy(y => y.ArticleId == x.ArticleId).ToList();
                    if (list == null || list.Count <= 1)
                    {
                        x.TagId = newTagId;
                        ArticleTagRespository.Update(x);
                    }
                    else
                    {
                        if (newTagId == TagConstants.NO_TAG || list.Any(y => y.TagId == newTagId))
                        {
                            ArticleTagRespository.Delete(x);
                        }
                        else
                        {
                            x.TagId = newTagId;
                            ArticleTagRespository.Update(x);
                        }
                    }
                    
                });
                ArticleTagRespository.SaveChanges();
            }
        }
    }
}
