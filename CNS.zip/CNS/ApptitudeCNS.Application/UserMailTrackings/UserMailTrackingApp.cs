﻿using ApptitudeCNS.Application.Articles;
using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Infrastructure.Email.Domain.EmailTemplates;
using ApptitudeCNS.Infrastructure.Email.Services;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.UserMailTrackings
{
    public class UserMailTrackingApp : IUserMailTrackingApp
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();
        private IGenericRepository<UserEmailTracking> UserMailTrackingRespository { get; }
        private IGenericRepository<User> UserRespository { get; }
        //private IGenericRepository<Client> ClientRespository { get; }
        //private IGenericRepository<ClientType> ClientTypeRespository { get; }
        private IGenericRepository<EmailStatus> EmailStatusRespository { get; }
        private IGenericRepository<EmailType> EmailTypeRespository { get; }
        private IGenericRepository<UserHistory> UserHistoryRespository { get; }
        //private IGenericRepository<ClientHistory> ClientHistoryRespository { get; }
        //private IEmailService EmailService { get; }
        //private IArticleApp ArticleApp { get; }

        public UserMailTrackingApp(IGenericRepository<UserEmailTracking> userMailTrackingRespository, IGenericRepository<User> userRespository,
            //IGenericRepository<Client> clientRespository, IGenericRepository<ClientType> clientTypeRespository,
            IGenericRepository<EmailStatus> emailStatusRespository, IGenericRepository<EmailType> emailTypeRespository,
            IGenericRepository<UserHistory> userHistoryRespository)//,
                                                                   //IEmailService emailService, IArticleApp articleApp)
        {
            UserMailTrackingRespository = userMailTrackingRespository;
            UserRespository = userRespository;
            //ClientRespository = clientRespository;
            //ClientTypeRespository = clientTypeRespository;
            EmailStatusRespository = emailStatusRespository;
            EmailTypeRespository = emailTypeRespository;
            UserHistoryRespository = userHistoryRespository;
            //ClientHistoryRespository = clientHistoryRespository;
            //EmailService = emailService;
            //ArticleApp = articleApp;
        }

        public List<MailTrackingViewModel> GetMailTrackingList(MailTrackingFilterViewModel filter)//int pageIndex, int pageSize, List<int> types, string searchText, string sortFieldName)
        {
            if (filter.typeIds == null || filter.typeIds.Length == 0) return new List<MailTrackingViewModel>();

            if (string.IsNullOrWhiteSpace(filter.searchText))
            {
                filter.searchText = string.Empty;
            }
            else
            {
                filter.searchText = filter.searchText.Trim();
            }

            if (string.IsNullOrWhiteSpace(filter.clientSearchText))
            {
                filter.clientSearchText = string.Empty;
            }
            else
            {
                filter.clientSearchText = filter.clientSearchText.Trim();
            }

            var typeIds = filter.typeIds.ToList();
            var showSampleEmail = false;
            var typeId = 0;
            if (typeIds.Contains(4))
            {
                showSampleEmail = true;
                if (!typeIds.Contains(2))
                {
                    typeId = 2;
                    typeIds.Add(2);
                }
            }

            //var typeIds = filter.typeIds.ToList();
            var result = (from m in UserMailTrackingRespository.EntitiesNoTracking
                          join u in UserRespository.EntitiesNoTracking on m.SenderId equals u.Id
                          join b in UserRespository.EntitiesNoTracking on m.UserId equals b.Id
                          join ms in EmailStatusRespository.EntitiesNoTracking on m.Status equals ms.Id
                          join mt in EmailTypeRespository.EntitiesNoTracking on m.TypeId equals mt.Id
                          //join t in types on m.TypeId equals t
                          where !u.IsDeleted && !b.IsDeleted && typeIds.Contains(m.TypeId) &&
                                ((showSampleEmail && (b.SendSampleEmailType > 0 || m.TypeId != typeId)) || (!showSampleEmail && b.SendSampleEmailType == null)) && //b.SendSampleEmailType == null &&
                                (filter.searchText == string.Empty ||
                                m.Subject.Contains(filter.searchText) || m.Content.Contains(filter.searchText)) &&
                                (filter.clientSearchText == string.Empty ||
                                ((u.FirstName + " " + u.LastName).Trim() + " (" + u.InternalIdentifier + ")").Contains(filter.clientSearchText) || u.Email.Contains(filter.clientSearchText) || u.SenderEmail.Contains(filter.clientSearchText) ||
                                ((b.FirstName + " " + b.LastName).Trim() + " (" + u.InternalIdentifier + ")").Contains(filter.clientSearchText) || b.Email.Contains(filter.clientSearchText) || b.SenderEmail.Contains(filter.clientSearchText))
                          //orderby m.ScheduledTime descending
                          select new
                          {
                              MailTracking = m,
                              User = u,
                              Client = b,
                              //Broker = b,
                              Status = ms,
                              Type = mt
                          });

            //result = result.Join(GetMailTypes(), r => r.MailTracking.TypeId, mt => mt.Id, (r, mt) => new
            //{
            //    r.MailTracking,
            //    r.User,
            //    r.Client,
            //    r.Status,
            //    Type = mt
            //});
            //var tempp = result2.ToList();
            //var result = (from m in result2
            //              join mt in CommonHelper.GetListForEnum<EnumEmailType>() on m.MailTracking.TypeId equals mt.Id
            //              join ms in CommonHelper.GetListForEnum<EnumEmailStatusType>() on m.MailTracking.Status equals ms.Id
            //              select new
            //              {
            //                  m.MailTracking,
            //                  m.User,
            //                  m.Client,
            //                  m.Broker,
            //                  Status = ms,
            //                  Type = mt
            //              });

            switch (filter.sortBy)
            {
                case "Subject asc":
                    result = result.OrderBy(x => x.MailTracking.Subject);
                    break;
                case "Subject desc":
                    result = result.OrderByDescending(x => x.MailTracking.Subject);
                    break;
                case "CreatedByName asc":
                    result = result.OrderBy(x => (x.User.FirstName + " " + x.User.LastName));
                    break;
                case "CreatedByName desc":
                    result = result.OrderByDescending(x => (x.User.FirstName + " " + x.User.LastName));
                    break;
                //case "BrokerName asc":
                //    result = result.OrderBy(x => (x.Broker.FirstName + " " + x.Broker.LastName));
                //    break;
                //case "BrokerName desc":
                //    result = result.OrderByDescending(x => (x.Broker.FirstName + " " + x.Broker.LastName));
                //    break;
                case "RecipientName asc":
                    result = result.OrderBy(x => (x.Client.FirstName + " " + x.Client.LastName));
                    break;
                case "RecipientName desc":
                    result = result.OrderByDescending(x => (x.Client.FirstName + " " + x.Client.LastName));
                    break;
                case "StatusName asc":
                    result = result.OrderBy(x => x.MailTracking.Status);
                    break;
                case "StatusName desc":
                    result = result.OrderByDescending(x => x.MailTracking.Status);
                    break;
                case "TypeName asc":
                    result = result.OrderBy(x => x.Type.Name);
                    break;
                case "TypeName desc":
                    result = result.OrderByDescending(x => x.Type.Name);
                    break;
                case "SentDate asc":
                    result = result.OrderBy(x => x.MailTracking.ScheduledTime).ThenBy(x => x.MailTracking.Id);
                    break;
                default:
                    result = result.OrderByDescending(x => x.MailTracking.ScheduledTime).ThenByDescending(x => x.MailTracking.Id);
                    break;
            }
            //select new MailTrackingsViewModel(a, u)).ToList();
            //select FullCopy()).ToList();
            //select FullCopy(a, u)).ToList();
            //return result;
            //var temp = result.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
            //var temp2 = temp.Select(x => new MailTrackingViewModel
            //{
            //    Id = x.MailTracking.Id,
            //    SentDate = x.MailTracking.ScheduledTime,
            //    Subject = x.MailTracking.Subject,
            //    RecipientName = $"{x.Client.FirstName} {x.Client.LastName}",
            //    SenderName = $"{x.User.FirstName} {x.User.LastName}",
            //    SenderId = x.User.Id,
            //    RecipientId = x.Client.Id,
            //    TypeName = x.Type.Name,
            //    StatusName = x.Status.Name
            //}).ToList();
            return result.Skip((filter.pageIndex - 1) * MailTrackingConstants.PAGE_SIZE).Take(MailTrackingConstants.PAGE_SIZE).AsEnumerable().Select(x => new MailTrackingViewModel
            {
                Id = x.MailTracking.Id,
                SentDate = x.MailTracking.ScheduledTime,
                Subject = x.MailTracking.Subject,
                //Content = x.MailTracking.Content,
                CreatedByFirstName = x.User.FirstName,
                CreatedByLastName = x.User.LastName,
                CreatedByInternalIdentifier = x.User.InternalIdentifier,
                //CreatedByName = CommonHelper.GetFullname(x.User.FirstName, x.User.LastName, x.User.InternalIdentifier),// $"{x.User.FirstName} {x.User.LastName}",
                CreatedById = x.User.Id,
                //BrokerName = $"{x.Broker.FirstName} {x.Broker.LastName}",
                //BrokerId = x.Broker.Id,
                //RecipientName = CommonHelper.GetFullname(x.Client.FirstName, x.Client.LastName, x.Client.InternalIdentifier),// $"{x.Client.FirstName} {x.Client.LastName}",
                RecipientFirstName = x.Client.FirstName,
                RecipientLastName = x.Client.LastName,
                RecipientEmail = x.Client.SenderEmail,
                SendSampleEmailType = x.Client.SendSampleEmailType,
                BrokerRefNo = x.Client.BpUserId ?? 0,
                RecipientId = x.Client.Id,
                TypeName = x.Type.Name,
                StatusName = x.Status.Name
            }).ToList();
        }

        public long GetCount(MailTrackingFilterViewModel filter)
        {
            if (filter.typeIds == null || filter.typeIds.Length == 0) return 0;

            if (string.IsNullOrWhiteSpace(filter.searchText))
            {
                filter.searchText = string.Empty;
            }
            else
            {
                filter.searchText = filter.searchText.Trim();
            }

            if (string.IsNullOrWhiteSpace(filter.clientSearchText))
            {
                filter.clientSearchText = string.Empty;
            }
            else
            {
                filter.clientSearchText = filter.clientSearchText.Trim();
            }

            //var typeIds = filter.typeIds.ToList();
            var typeIds = filter.typeIds.ToList();
            var showSampleEmail = false;
            var typeId = 0;
            if (typeIds.Contains(4))
            {
                showSampleEmail = true;
                if (!typeIds.Contains(2))
                {
                    typeId = 2;
                    typeIds.Add(2);
                }
            }

            return (from m in UserMailTrackingRespository.EntitiesNoTracking
                    join u in UserRespository.EntitiesNoTracking on m.SenderId equals u.Id
                    join b in UserRespository.EntitiesNoTracking on m.UserId equals b.Id
                    //join c in ClientRespository.EntitiesNoTracking on m.ClientId equals c.Id
                    //join t in types on m.TypeId equals t
                    where !u.IsDeleted && !b.IsDeleted && typeIds.Contains(m.TypeId) && //u.SendSampleEmailType == null && b.SendSampleEmailType == null &&
                          ((showSampleEmail && (b.SendSampleEmailType > 0 || m.TypeId != typeId)) || (!showSampleEmail && b.SendSampleEmailType == null)) && //b.SendSampleEmailType == null &&
                                (filter.searchText == string.Empty ||
                                m.Subject.Contains(filter.searchText) || m.Content.Contains(filter.searchText)) &&
                                (filter.clientSearchText == string.Empty ||
                                (u.FirstName + " " + u.LastName).Contains(filter.clientSearchText) || u.Email.Contains(filter.clientSearchText) || u.SenderEmail.Contains(filter.clientSearchText) ||
                                (b.FirstName + " " + b.LastName).Contains(filter.clientSearchText) || b.Email.Contains(filter.clientSearchText) || b.SenderEmail.Contains(filter.clientSearchText))
                    select 1).LongCount();
        }

        public void SendMassEmail(long userId, string subject, string content, long[] userIds, DateTime scheduleDate, bool isSelectedUsers, int[] brokerTypeIds)
        {
            List<UserEmailTracking> userMailTrackingList = null;
            if (isSelectedUsers)
            {
                userMailTrackingList = userIds.Select(u => new UserEmailTracking()
                {
                    UserId = u,
                    ScheduledTime = scheduleDate,
                    SenderId = userId,
                    TypeId = (int)EnumEmailType.BrokerMessage,
                    Status = (int)EnumEmailStatusType.Unsent,
                    Content = content,
                    Subject = subject
                }).ToList();
            }
            else
            {
                userMailTrackingList = UserRespository.FindBy(x => x.EmailSubscribe == true && brokerTypeIds.Any(y => y == x.UserTypeId)).Select(u => new UserEmailTracking()
                {
                    UserId = u.Id,
                    ScheduledTime = scheduleDate,
                    SenderId = userId,
                    TypeId = (int)EnumEmailType.BrokerMessage,
                    Status = (int)EnumEmailStatusType.Unsent,
                    Content = content,
                    Subject = subject
                }).ToList();
            }

            UserMailTrackingRespository.CreateRange(userMailTrackingList);
            UserMailTrackingRespository.SaveChanges();

            if (userMailTrackingList.Count > 0)
            {
                //Log user history
                UserHistoryRespository.Create(new UserHistory
                {
                    Content = subject,
                    TypeId = (int)EnumHistoryType.Email,
                    IsSystemAutogen = true,
                    CreatedDate = DateTime.Now,
                    UserId = userId,
                    CreatedUserId = userId
                });
                UserHistoryRespository.SaveChanges();
            }
        }

        public List<MailSendingViewModel> GetMailSendingList()
        {
            var result = (from m in UserMailTrackingRespository.EntitiesNoTracking
                          join c in UserRespository.EntitiesNoTracking on m.UserId equals c.Id
                          join b in UserRespository.EntitiesNoTracking on m.SenderId equals b.Id
                          where !c.IsDeleted && (c.IsActive || m.TypeId == (int)EnumEmailType.BrokerMessage) && m.Status == (int)EnumEmailStatusType.Unsent && m.ScheduledTime <= DateTime.Now
                          select new
                          {
                              MailTracking = m,
                              Client = c,
                              Broker = b
                          }).Take(500).AsEnumerable();


            // Update Fail for Unsent when this client is deleted or belongs to inactive/deleted broker
            var mailList = (from m in UserMailTrackingRespository.EntitiesNoTracking
                            join c in UserRespository.EntitiesNoTracking on m.UserId equals c.Id
                            where (c.IsDeleted || (!c.IsActive && m.TypeId == (int)EnumEmailType.BrokerMessage)) && m.Status == (int)EnumEmailStatusType.Unsent && m.ScheduledTime <= DateTime.Now
                            select m).ToList();

            if (mailList.Count > 0)
            {
                foreach (var mailItem in mailList)
                {
                    mailItem.Status = (int)EnumEmailStatusType.Failed;
                    mailItem.ErrorNote = "This user is deleted/inactive.";
                    UserMailTrackingRespository.Update(mailItem);
                }
                UserMailTrackingRespository.SaveChanges();
            }

            return result.Select(x => new MailSendingViewModel
            {
                Id = x.MailTracking.Id,
                Subject = x.MailTracking.Subject,
                Content = x.MailTracking.Content,
                BrokerName = $"{x.Broker.FirstName} {x.Broker.LastName}".Trim(),
                BrokerEmail = x.Broker.SenderEmail,
                BrokerRefNo = x.Client.BpUserId ?? 0,
                SendSampleEmailType = x.Client.SendSampleEmailType,
                RecipientName = $"{x.Client.FirstName} {x.Client.LastName}".Trim(),
                RecipientEmail = x.Client.SenderEmail,
                TypeId = (EnumEmailType)x.MailTracking.TypeId,
                Status = (EnumEmailStatusType)x.MailTracking.Status
            }).ToList();
        }

        public void UpdateMailSendingList(List<MailSendingViewModel> list)
        {
            var retry = 3;
            do
            {
                foreach (var item in list)
                {
                    var mailTracking = UserMailTrackingRespository.FindBy(item.Id);
                    mailTracking.Status = (int)item.Status;
                    mailTracking.ErrorNote = item.ErrorNote;
                    UserMailTrackingRespository.Update(mailTracking);
                    UserHistoryRespository.Create(new UserHistory
                    {
                        Content = item.Subject,
                        UserId = mailTracking.UserId,
                        TypeId = (int)EnumHistoryType.Email,
                        IsSystemAutogen = true,
                        CreatedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        CreatedUserId = ConfigManager.SystemUserId
                    });
                }
                try
                {
                    UserMailTrackingRespository.SaveChanges();
                    UserHistoryRespository.SaveChanges();
                    retry = 0;
                }
                catch (Exception ex)
                {
                    retry--;
                    logger.Error($"UpdateMailSendingList {string.Join(" ", list.Select(x => x.Id))} {ex.ToString()}");
                }
            } while (retry > 0);
        }

        public string GetEmailContent(long id)
        {
            var result = UserMailTrackingRespository.FindBy(id)?.Content;
            //if (!string.IsNullOrWhiteSpace(result))
            //{
            //    result = result.Replace("{MailId}", Encryption.Base64EncodeUrl(id.ToString()));
            //}
            return result;
        }

        public void ClickUserMail(long userMailId)
        {
            var userMailTrackingItem = UserMailTrackingRespository.FindBy(userMailId);
            if (userMailTrackingItem?.Id > 0)
            {
                userMailTrackingItem.Status = (int)EnumEmailStatusType.Clicked;
                userMailTrackingItem.ClickedDate = DateTime.Now;
                UserMailTrackingRespository.Update(userMailTrackingItem);
                UserMailTrackingRespository.SaveChanges();
            }
        }
    }
}
