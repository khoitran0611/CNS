﻿using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;

namespace ApptitudeCNS.Application.UserMailTrackings
{
    public interface IUserMailTrackingApp
    {
        List<MailTrackingViewModel> GetMailTrackingList(MailTrackingFilterViewModel filter);
        long GetCount(MailTrackingFilterViewModel filter);

        ////IEnumerable<IdName> GetMailTypes();
        //Client GetClientById(long id);

        string GetEmailContent(long id);

        //string GetSubjectTemplate(long[] ids);
        //string GetEmailTemplateBody(EmailTemplateBodyRequest request);

        //void SendTest(SendTestRequest request);

        //void SendLowestRateToAll(long senderId, string subject, string content);
        //void SendToAll(SendToAllRequest request);

        //List<MailSendingViewModel> GetMailSendingList();
        //void SendMassEmail(long userId, string subject, string content, long[] clientIds, DateTime scheduleDate);
        void SendMassEmail(long userId, string subject, string content, long[] userIds, DateTime scheduleDate, bool isSelectedUsers, int[] brokerTypeIds);
        List<MailSendingViewModel> GetMailSendingList();
        void UpdateMailSendingList(List<MailSendingViewModel> list);
        void ClickUserMail(long userMailId);
    }
}
