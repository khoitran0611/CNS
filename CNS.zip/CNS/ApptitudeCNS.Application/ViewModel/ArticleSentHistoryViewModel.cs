﻿using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.ViewModel
{
    public class ArticleSentHistoryViewModel
    {
        public long ArticleId { get; set; }
        public DateTime CreatedDate { get; set; }

        public string CreatedDateDisplay
        {
            get
            {
                return CreatedDate.ToString("dd/MM/yyyy HH:mm");
            }
        }

        public int[] TypeIds { get; set; }
        public string TypeNames { get; set; }
    }
}
