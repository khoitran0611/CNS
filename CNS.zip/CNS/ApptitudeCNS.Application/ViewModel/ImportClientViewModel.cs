﻿using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.ViewModel
{
    public class ImportClientViewModel : BaseViewModel
    {
        public ImportClientViewModel() : base()
        {
            //EmailSubscribe = SMSSubscribe = true;
            //CreatedDate = DateTime.Now;
            //RecipientTypes = new List<EnumRecipientType>();
        }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Salutation { get; set; }
        public string Phone { get; set; }
        public int EmailSubscribe { get; set; }
        public bool? SMSSubscribe { get; set; }
        public DateTime? Birthday { get; set; }
        public string BrokerRefNo { get; set; }
        public long UserId { get; set; }

        public long CreatedUserId { get; set; }
        //public DateTime CreatedDate { get; set; }

        //public List<EnumRecipientType> RecipientTypes { get; set; }
    }
}
