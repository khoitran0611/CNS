﻿using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.ViewModel
{
    public class ArticleHistoryViewModel
    {
        public long ArticleId { get; set; }
        public int TypeId { get; set; }
        public string TypeName
        {
            get
            {
                return ((EnumHistoryType)TypeId).GetDescription();
            }
        }

        public string Content { get; set; }
        public bool Pinned { get; set; }
        public string PinnedClass
        {
            get
            {
                return Pinned ? "pinned" : string.Empty;
            }
        }

        public bool IsSystemAutogen { get; set; }
        public long? CreatedUserId { get; set; }
        public DateTime? CreatedDate { get; set; }

        public string CreatedDateDisplay
        {
            get
            {
                if (!CreatedDate.HasValue) return string.Empty;

                return CreatedDate.Value.ToString("dd/MM/yyyy");
            }
        }

        public DateTime? UpdatedDate { get; set; }
    }
}
