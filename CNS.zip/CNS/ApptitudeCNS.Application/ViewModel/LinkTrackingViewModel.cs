﻿using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.ViewModel
{
    public class LinkTrackingViewModel
    {
        public string Subject { get; set; }
        public long Id { get; set; }
        public string Link { get; set; }
        public DateTime CreatedDate { get; set; }

        public string CreatedDateDisplay
        {
            get
            {
                return CreatedDate.ToString("dd/MM/yyyy");
            }
        }

        public DateTime? LastClickedDate { get; set; }
        public string LastClickedDateDisplay
        {
            get
            {
                if (LastClickedDate.HasValue)
                {
                    return LastClickedDate.Value.ToString("dd/MM/yyyy");
                }
                return string.Empty;
            }
        }

        public int ClientClickCount { get; set; }
        public int UserClickCount { get; set; }
    }
}
