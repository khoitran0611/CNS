﻿using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.ViewModel
{
    public class LinkTrackingDetailViewModel
    {
        public long Id { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string InternalIdentifier { get; set; }

        public string FullName
        {
            get
            {
                return CommonHelper.GetFullname(FirstName, LastName, InternalIdentifier);
            }
        }
        public string Email { get; set; }
        public string Phone { get; set; }

        public DateTime ClickedDate { get; set; }
        public string ClickedDateDisplay
        {
            get
            {
                return ClickedDate.ToString("dd/MM/yyyy");
            }
        }

    }
}
