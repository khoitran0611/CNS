﻿using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ApptitudeCNS.Application.ViewModel
{
    public class ClientViewModel : BaseViewModel
    {
        public ClientViewModel() : base()
        {
            SMSSubscribe = false;
            EmailSubscribe = (int)EnumClientEmailStatus.Blank;
            //Birthday = DateTime.Now;
        }
        [Required(ErrorMessage = "Please enter Email Address.")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        [DisplayName("Email(*)")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter First Name.")]
        [DisplayName("First Name(*)")]
        public string FirstName { get; set; }

        //[Required(ErrorMessage = "Please enter Last Name.")]
        [DisplayName("Last Name")]
        public string LastName { get; set; }

        //[Required(ErrorMessage = "Please enter Salutation.")]
        [DisplayName("Salutation")]
        public string Salutation { get; set; }

        public string Phone { get; set; }

        [DisplayName("Email Status")]
        public int EmailSubscribe { get; set; }

        [DisplayName("SMS Subscribe")]
        public bool? SMSSubscribe { get; set; }

        [DisplayFormat(DataFormatString = @"{0:dd\/MM\/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? Birthday { get; set; }

        [DisplayName("Broker Reference No")]
        public string BrokerRefNo { get; set; }

        [DisplayName("Broker User No")]
        public string BrokerUserNo { get; set; }

        public long UserId { get; set; }

        //[DisplayName("Recipient Types")]
        //public List<int> RecipientTypes { get; set; }

        [DisplayName("User Name")]
        public string CreateUserName
        {
            get
            {
                return CommonHelper.GetFullname(UserFirstName, UserLastName, UserInternalIdentifier);
            }
        }

        public string UserFirstName { get; set; }
        public string UserLastName { get; set; }
        public string UserInternalIdentifier { get; set; }


        public string CompanyName { get; set; }

    }
}
