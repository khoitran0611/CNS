﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.ViewModel
{
    public class ArticleFilterViewModel
    {
        public ArticleFilterViewModel()
        {
        }
        public int pageIndex { get; set; }
        public int pageCount { get; set; }

        public string searchText { get; set; }
        //public int articleType { get; set; }
        public bool isSearchAdvanced { get; set; }
        public bool isNew { get; set; }

        public int[] tagIds { get; set; }

        //public int[] recipientTypeIds { get; set; }
        public long id { get; set; }
        public long[] ids { get; set; }

        public string sortBy { get; set; }
    }
}
