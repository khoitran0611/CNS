﻿using ApptitudeCNS.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.ViewModel
{
    public class TagViewModel
    {
        public int Id { get; set; }
        //public string Subject { get; set; }
        public string Name { get; set; }
        public string MapNames { get; set; }

        //public string MapNameHtml
        //{
        //    get
        //    {
        //        return MapNames?.Replace(Environment.NewLine, "<br />");
        //    }
        //}
        public string MapNameList
        {
            get
            {
                return string.Join(", ", MapNames?.Split(new string[] { Environment.NewLine, "," }, StringSplitOptions.RemoveEmptyEntries));//.Replace("'", "&apos;").Replace("\"", "&quot;");
            }
        }

        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public long CreatedUserId { get; set; }
        public long UpdatedUserId { get; set; }
        public int OrderNumber { get; set; }
    }
}
