﻿using ApptitudeCNS.Helpers;
using System;
using System.ComponentModel;

namespace ApptitudeCNS.Application.ViewModel
{
    public class ClientHistoryViewModel : BaseViewModel
    {
        public long ClientId { get; set; }
        public int TypeId { get; set; }

        [DisplayName("Type")]
        public string TypeName
        {
            get
            {
                return ((EnumHistoryType)TypeId).GetDescription();
            }
        }

        public string Content { get; set; }
        public bool Pinned { get; set; }
        public bool IsSystemAutogen { get; set; }
        public long? CreatedUserId { get; set; }
        public string CreatedUserSign { get; set; }
        public string CreatedUserName { get; set; }

        public long? MailTrackingId { get; set; }
    }
}
