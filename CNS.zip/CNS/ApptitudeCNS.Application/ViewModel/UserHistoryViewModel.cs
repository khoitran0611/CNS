﻿using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.ViewModel
{
    public class UserHistoryViewModel : BaseViewModel
    {
        public long UserId { get; set; }
        public int TypeId { get; set; }
        [DisplayName("Type")]
        public string TypeName
        {
            get
            {
                return ((EnumHistoryType)TypeId).GetDescription();
            }
        }
        public string Content { get; set; }
        public bool Pinned { get; set; }
        public bool IsSystemAutogen { get; set; }
        public long? CreatedUserId { get; set; }
        public string CreatedUserSignature { get; set; }
    }
}
