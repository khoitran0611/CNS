﻿using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.ViewModel
{
    public class MailTrackingViewModel
    {
        public long Id { get; set; }
        public DateTime SentDate { get; set; }

        public string Subject { get; set; }
        //public string Content { get; set; }

        public string CreatedByFirstName { get; set; }
        public string CreatedByLastName { get; set; }
        public string CreatedByInternalIdentifier { get; set; }

        public string CreatedByName
        {
            get
            {
                return CommonHelper.GetFullname(CreatedByFirstName, CreatedByLastName, CreatedByInternalIdentifier);
            }
        }

        public string BrokerFirstName { get; set; }
        public string BrokerLastName { get; set; }
        public string BrokerInternalIdentifier { get; set; }
        public string BrokerName
        {
            get
            {
                return CommonHelper.GetFullname(BrokerFirstName, BrokerLastName, BrokerInternalIdentifier);
            }
        }

        public string RecipientFirstName { get; set; }
        public string RecipientLastName { get; set; }
        public string RecipientName
        {
            get
            {
                return CommonHelper.GetFullname(RecipientFirstName, RecipientLastName, string.Empty);
            }
        }
        public string RecipientEmail { get; set; }

        public long CreatedById { get; set; }
        public long BrokerId { get; set; }
        public long RecipientId { get; set; }

        public string TypeName { get; set; } //enum(1:broker message, 2:article, 3: lowest rates)
        public string StatusName { get; set; } //enum(1:unsent, 2:sent, 3:failed, 4:Read, 5:Clicked)
                                               //public string ErrorNote { get; set; }
        public long BrokerRefNo { get; set; }

        public int? SendSampleEmailType { get; set; }

        //public EnumEmailType TypeId { get; set; } //enum(1:broker message, 2:article, 3: lowest rates)
        //public EnumEmailStatusType Status { get; set; } //enum(1:broker message, 2:article, 3: lowest rates)

        public string SentDateDisplay
        {
            get
            {
                return SentDate.ToString("dd/MM/yyyy HH:mm");
            }
        }

        public string Link
        {
            get
            {
                if (SendSampleEmailType == (int)EnumSendSampleEmailType.Brokerpedia && BrokerRefNo > 0)
                {
                    return string.Format(ConfigManager.BpUserEditLink, BrokerRefNo);
                }

                if (SendSampleEmailType == (int)EnumSendSampleEmailType.Proinspect && !string.IsNullOrWhiteSpace(RecipientEmail))
                {
                    return string.Format(ConfigManager.ProinspectUserEditLink, RecipientEmail);
                }

                return string.Empty;
            }
        } //enum(1:broker message, 2:article, 3: lowest rates)
    }
}
