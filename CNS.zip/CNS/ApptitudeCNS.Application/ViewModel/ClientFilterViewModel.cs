﻿namespace ApptitudeCNS.Application.ViewModel
{
    public class ClientFilterViewModel
    {
        public string SearchText { get; set; }
        public int ClientFilterType { get; set; }
        public int SearchLevel { get; set; }
        public long? UserId { get; set; }
        public long[] EmailSubscribes { get; set; }
    }
}
