﻿using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.ViewModel
{
    public class MailTemplateViewModel
    {
        public long[] ArticleIds { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }
    }
}
