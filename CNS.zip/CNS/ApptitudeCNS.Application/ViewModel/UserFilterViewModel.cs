﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.ViewModel
{
    public class UserFilterViewModel
    {
        public UserFilterViewModel()
        {
            RoleIds = new List<long>();
        }
        public List<long> RoleIds { get; set; }
        public string SearchText { get; set; }
        public int SearchLevel { get; set; }
        public int BrokerTypeId { get; set; }
    }
}
