﻿using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.ViewModel
{
    public class MailSendingViewModel
    {
        public long Id { get; set; }
        public long ClientId { get; set; }
        //public DateTime SentDate { get; set; }

        public string Subject { get; set; }
        public string Content { get; set; }

        public string BrokerName { get; set; }
        public string RecipientName { get; set; }

        public string BrokerEmail { get; set; }
        public string RecipientEmail { get; set; }

        public string ErrorNote { get; set; }

        public EnumEmailType TypeId { get; set; } //enum(1:broker message, 2:article, 3: lowest rates)
        public EnumEmailStatusType Status { get; set; } //enum(1:broker message, 2:article, 3: lowest rates)

        public long BrokerRefNo { get; set; }
        public long BrokerUserNo { get; set; }

        public int? SendSampleEmailType { get; set; }
    }
}
