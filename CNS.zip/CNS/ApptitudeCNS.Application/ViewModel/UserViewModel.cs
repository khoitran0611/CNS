﻿using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;


namespace ApptitudeCNS.Application.ViewModel
{
    public class UserViewModel : BaseViewModel
    {
        public UserViewModel() : base()
        {
            IsActive = true;
            EmailSubscribe = SMSSubscribe = false;
        }
        [Required(ErrorMessage = "Please enter Email Address.")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        [DisplayName("Email(*)")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter Password.")]
        [DisplayName("Password(*)")]
        public string Password { get; set; }

        public string PasswordHash { get; set; }

        [Required(ErrorMessage = "Please enter First Name.")]
        [DisplayName("First Name")]
        public string FirstName { get; set; }

        //[Required(ErrorMessage = "Please enter Last Name.")]
        [DisplayName("Last Name")]
        public string LastName { get; set; }

        public string Phone { get; set; }

        public string Company { get; set; }
        public string Signature { get; set; }

        [DisplayName("Primary Color")]
        public string PrimaryColor { get; set; } = CNSConstant.DEFAULT_BROKER_COLOR;

        [DisplayName("Secondary Color")]
        public string SecondaryColor { get; set; } = CNSConstant.DEFAULT_BROKER_COLOR2;

        [Required(ErrorMessage = "Please enter Sender Email.")]
        [DisplayName("Sender Email(*)")]
        public string SenderEmail { get; set; }

        [DisplayName("Email Subscribe")]
        public bool? EmailSubscribe { get; set; }

        [DisplayName("SMS Subscribe")]
        public bool? SMSSubscribe { get; set; }

        //[Required(ErrorMessage = "Please enter Broker Message.")]
        //[DataType(DataType.MultilineText)]
        //[DisplayName("Broker Message")]
        //public string BrokerMessage { get; set; }

        [DisplayName("Active Date From")]
        [DisplayFormat(DataFormatString = @"{0:dd\/MM\/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? ActiveDateFrom { get; set; }

        [DisplayName("Active Date To")]
        [DisplayFormat(DataFormatString = @"{0:dd\/MM\/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? ActiveDateTo { get; set; }

        [DisplayName("Active")]
        public bool IsActive { get; set; }

        public DateTime? LastSendMassEmail { get; set; }

        public string LastSendMassEmailDisplay
        {
            get
            {
                if (LastSendMassEmail.HasValue)
                {
                    return LastSendMassEmail.Value.ToString("dd/MM/yyyy");
                }
                return string.Empty;
            }
        }

        public long CreatedUserId { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Please select a Broker Type.")]
        public int UserTypeId { get; set; }
        public string UserTypeName { get; set; }

        public string BpUserEditLink
        {
            get
            {
                if (BpUserId > 0)
                {
                    return string.Format(ConfigManager.BpUserEditLink, BpUserId);
                }
                return string.Empty;
            }
        }

        public string BpUserEditLinkTemplate
        {
            get
            {
                return string.Format(ConfigManager.BpUserEditLink, string.Empty);
            }
        }

        [DisplayName("BID")]
        public long? BpUserId { get; set; }

        public long? AggregatorId { get; set; }
        public long? SubAggregatorId { get; set; }
        public string Logo { get; set; }
        public string Address { get; set; }
        public string Title { get; set; }

        public string ABN { get; set; }

        [Url(ErrorMessage = "Please enter valid Google+ Url.")]
        [DisplayName("Google+ Url")]
        public string GooglePlusLink { get; set; }

        [Url(ErrorMessage = "Please enter valid Facebook Url.")]
        [DisplayName("Facebook Url")]
        public string FacebookLink { get; set; }

        [Url(ErrorMessage = "Please enter valid Twitter Url.")]
        [DisplayName("Twitter Url")]
        public string TwitterLink { get; set; }

        [Url(ErrorMessage = "Please enter valid Linkedin Url.")]
        [DisplayName("Linkedin Url")]
        public string LinkedinLink { get; set; }

        [Url(ErrorMessage = "Please enter valid Website Url.")]
        [DisplayName("Website Url")]
        public string WebsiteLink { get; set; }

        public string BrokerMessage { get; set; }

        [DisplayName("Company Image")]
        public string CompanyImage { get; set; }

        public int? SendSampleEmailType { get; set; }

        public int? LogoPositionType { get; set; }

        public string LogoPositionTypeName
        {
            get
            {
                if (LogoPositionType == (int)EnumLogoPositionType.Right) return EnumLogoPositionType.Right.ToString().ToLower();
                return EnumLogoPositionType.Left.ToString().ToLower();
            }
        }

        [DisplayName("Internal Identifier")]
        public string InternalIdentifier { get; set; }

        public string Fullname
        {
            get
            {
                return CommonHelper.GetFullname(FirstName, LastName, InternalIdentifier);
            }
        }
    }

    public class UserWithRoleViewModel : UserViewModel
    {
        public List<RoleViewModel> Roles { get; set; }
        public DateTime? LogInDateTime { get; set; }
        public bool IsAdmin { get; set; }
        public int NumOfClient { get; set; }
    }

    public class UserLoginViewModel
    {
        public string Email { get; set; }
        public string Password { get; set; }
        [DisplayName("Remember Me")]
        public bool RememberMe { get; set; }
    }

    public class UserSampleEmailViewModel : BaseViewModel
    {
        public UserSampleEmailViewModel() : base()
        {
            IsActive = true;
            Password = "123456";
            UserTypeId = (int)EnumUserType.Solicitor;
            EmailSubscribe = SMSSubscribe = true;

            FacebookLink = "https://www.sydneyoperahouse.com/";
            GooglePlusLink = "https://www.sydneyoperahouse.com/";
            WebsiteLink = "https://www.sydneyoperahouse.com/";
            LinkedinLink = "https://www.sydneyoperahouse.com/";
            TwitterLink = "https://www.sydneyoperahouse.com/";

            BrokerMessage = "Welcome to our current knowledge bulletin, where we try to enlighten you with information relevant not only to what we do, but also articles that are relevant to our daily lives. Enjoy!";
        }

        [Required(ErrorMessage = "Please enter Email Address.")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        [DisplayName("Email(*)")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter Password.")]
        [DisplayName("Password(*)")]
        public string Password { get; set; }

        public string PasswordHash { get; set; }

        //[Required(ErrorMessage = "Please enter First Name.")]
        [DisplayName("First Name")]
        public string FirstName { get; set; }

        //[Required(ErrorMessage = "Please enter Last Name.")]
        [DisplayName("Last Name")]
        public string LastName { get; set; }

        public string Phone { get; set; }

        public string Company { get; set; }
        public string Signature { get; set; }

        [DisplayName("Primary Color")]
        public string PrimaryColor { get; set; } = CNSConstant.DEFAULT_BROKER_COLOR;

        [DisplayName("Secondary Color")]
        public string SecondaryColor { get; set; } = CNSConstant.DEFAULT_BROKER_COLOR2;

        [Required(ErrorMessage = "Please enter Sender Email.")]
        [DisplayName("Sender Email(*)")]
        public string SenderEmail { get; set; }

        [DisplayName("Email Subscribe")]
        public bool? EmailSubscribe { get; set; }

        [DisplayName("SMS Subscribe")]
        public bool? SMSSubscribe { get; set; }

        [DisplayName("Active")]
        public bool IsActive { get; set; }

        public DateTime? LastSendMassEmail { get; set; }
        public long CreatedUserId { get; set; }

        public int UserTypeId { get; set; }
        public string UserTypeName { get; set; }

        [DisplayName("BID")]
        public long? BpUserId { get; set; }

        public long? AggregatorId { get; set; }
        public long? SubAggregatorId { get; set; }

        [Required(ErrorMessage = "Please upload a Logo.")]
        public string Logo { get; set; }
        public string Address { get; set; }
        public string Title { get; set; }

        public string ABN { get; set; }

        [Url(ErrorMessage = "Please enter valid Google+ Url.")]
        [DisplayName("Google+ Url")]
        public string GooglePlusLink { get; set; }

        [Url(ErrorMessage = "Please enter valid Facebook Url.")]
        [DisplayName("Facebook Url")]
        public string FacebookLink { get; set; }

        [Url(ErrorMessage = "Please enter valid Twitter Url.")]
        [DisplayName("Twitter Url")]
        public string TwitterLink { get; set; }

        [Url(ErrorMessage = "Please enter valid Linkedin Url.")]
        [DisplayName("Linkedin Url")]
        public string LinkedinLink { get; set; }

        [Url(ErrorMessage = "Please enter valid Website Url.")]
        [DisplayName("Website Url")]
        public string WebsiteLink { get; set; }

        [DisplayName("Broker Message")]
        public string BrokerMessage { get; set; }

        [DisplayName("Company Image")]
        //[Required(ErrorMessage = "Please upload a Company Image.")]
        public string CompanyImage { get; set; }

        public int? SendSampleEmailType { get; set; }

        [DisplayName("Logo Position")]
        public int? LogoPositionType { get; set; }
    }

}
