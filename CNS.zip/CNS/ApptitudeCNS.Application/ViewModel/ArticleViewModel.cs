﻿using ApptitudeCNS.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.ViewModel
{
    public class ArticleViewModel
    {
        //public ArticlesViewModel(Article article, URLTracking urlTracking)
        //{
        //    AutoMapperGenericsHelper<Article, ArticlesViewModel>.FullCopy(article, this);
        //    this.URLTracking = urlTracking;
        //}

        public long Id { get; set; }
        //public string Subject { get; set; }
        public string Title { get; set; }
        public DateTime? ArticleDate { get; set; }

        public string ArticleDateDisplay
        {
            get
            {
                return ArticleDate?.ToString("dd/MM/yyyy");
            }
        }

        public string ArticleDateListDisplay
        {
            get
            {
                //DateTime.Today.Mo
                if (ArticleDate == null) return string.Empty;

                var timeSpan = DateTime.Today.Subtract(ArticleDate.Value.Date);
                if (timeSpan.Days == 0)
                {
                    return "today";
                }
                else if (timeSpan.Days == 1)
                {
                    return "yesterday";
                }
                else if (timeSpan.Days < 89 || ArticleDate.Value.Date.AddMonths(3) > DateTime.Today)
                {
                    return $"{timeSpan.Days} days ago";
                }
                else if (timeSpan.Days == 89 && ArticleDate.Value.Date.AddMonths(3) == DateTime.Today)
                {
                    return "3 months ago";
                }

                var monthCount = timeSpan.Days / 30;
                var dayCount = timeSpan.Days % 30;
                var date = ArticleDate.Value.Date.AddMonths(monthCount).AddDays(dayCount);
                if (date < DateTime.Today)
                {
                    monthCount--;
                    //dayCount = DateTime.Today.Subtract(ArticleDate.Date.AddMonths(monthCount)).Days;
                }
                //else if (date > DateTime.Today)
                //{
                //    dayCount = DateTime.Today.Subtract(ArticleDate.Date.AddMonths(monthCount)).Days;
                //    //if (DateTime.Today.Subtract(ArticleDate.Date.AddMonths(monthCount)).Days >= 0)
                //    //{
                //    //    dayCount = DateTime.Today.Subtract(ArticleDate.Date.AddMonths(monthCount)).Days;
                //    //}
                //    //else
                //    //{
                //    //    monthCount--;
                //    //    dayCount = DateTime.Today.Subtract(ArticleDate.Date.AddMonths(monthCount)).Days;
                //    //}
                //}


                dayCount = DateTime.Today.Subtract(ArticleDate.Value.Date.AddMonths(monthCount)).Days;
                if (dayCount < 0)
                {
                    monthCount--;
                    dayCount = DateTime.Today.Subtract(ArticleDate.Value.Date.AddMonths(monthCount)).Days;
                }
                else if (dayCount >= 28 && DateTime.Today.Subtract(ArticleDate.Value.Date.AddMonths(monthCount + 1)).Days >= 0)
                {
                    monthCount++;
                    dayCount = DateTime.Today.Subtract(ArticleDate.Value.Date.AddMonths(monthCount)).Days;
                }

                if (ArticleDate.Value.Date.Day > ArticleDate.Value.Date.AddMonths(monthCount).Day)
                {
                    dayCount += ArticleDate.Value.Date.Day - ArticleDate.Value.Date.AddMonths(monthCount).Day;
                }

                if (dayCount == 0)
                {
                    return $"{monthCount} months ago";
                }
                if (dayCount == 1)
                {
                    return $"{monthCount} months and {dayCount} day ago";
                }
                return $"{monthCount} months and {dayCount} days ago";
                //return ArticleDate.ToString("dd/MM/yyyy");
            }
        }

        public long? LinkId { get; set; }
        public string Link { get; set; }
        public string ShortSummary
        {
            get
            {
                var result = Summary;
                var maxLength = 200;
                if (!string.IsNullOrWhiteSpace(Summary) && result.Length > maxLength)
                {
                    result = result.Substring(0, maxLength);
                    if (result.LastIndexOf(" ") > maxLength - 90)
                    {
                        result = result.Substring(0, result.LastIndexOf(" "));
                    }
                    return $"{result}...";
                }
                return result;
            }
        }
        public string Summary { get; set; }
        public string Picture { get; set; }
        public string Author { get; set; }
        public DateTime? LastSent { get; set; }
        public string LastSentDisplay
        {
            get
            {
                if (LastSent.HasValue)
                    return LastSent.Value.ToString("dd/MM/yyyy");
                return string.Empty;
            }
        }

        public List<int> TagIds { get; set; }
        public List<int> ManualTagIds { get; set; }
        public List<int> DoNotSendUserTypeIds { get; set; }
        public List<int> DoNotSendClientTypeIds { get; set; }
        //public string RecipientTypeNames { get; set; }

        public int ArticleTypeId { get; set; }
        public string ArticleTypeName { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public long CreatedUserId { get; set; }
        public long UpdatedUserId { get; set; }

        public string Organisation { get; set; }
        public string SiteName { get; set; }

        public string BrokerMessage { get; set; }

        //public string DoNotSend { get; set; }

        public string SentUserTypeIds { get; set; }
        public string SentClientTypeIds { get; set; }

        public bool? IsDeclined { get; set; }

        public int? Status { get; set; }

        public string HistoryNote { get; set; }

        public ArticleHistoryViewModel[] Histories { get; set; }

        public bool IsArticleSendHistory { get; set; }

        public bool IsNewsletterArticleLink { get; set; }

        public ArticleAttachment Attachment { get; set; }

        public bool IsFirstItemOfDay { get; set; }
        public string FirstItemOfDayClass
        {
            get
            {
                return IsFirstItemOfDay ? "first-item-of-day" : string.Empty;
            }
        }
    }
}
