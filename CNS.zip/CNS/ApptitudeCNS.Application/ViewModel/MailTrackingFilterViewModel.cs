﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.ViewModel
{
    public class MailTrackingFilterViewModel
    {
        public MailTrackingFilterViewModel()
        {
        }
        public int pageIndex { get; set; }
        public int pageCount { get; set; }

        public string searchText { get; set; }
        public string clientSearchText { get; set; }
        //public int articleType { get; set; }

        public int[] typeIds { get; set; }

        //public int[] recipientTypeIds { get; set; }
        public int recipientId { get; set; }
        public string sortField { get; set; }
        public string sortType { get; set; }

        public string sortBy
        {
            get
            {
                return $"{sortField} {sortType}";
            }
        }
    }
}
