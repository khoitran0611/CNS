﻿using ApptitudeCNS.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.ViewModel
{
    public class ArticlesViewModel
    {
        //public ArticlesViewModel(Article article, URLTracking urlTracking)
        //{
        //    AutoMapperGenericsHelper<Article, ArticlesViewModel>.FullCopy(article, this);
        //    this.URLTracking = urlTracking;
        //}

        public long Id { get; set; }
        public string Subject { get; set; }
        public string Title { get; set; }
        public DateTime ArticleDate { get; set; }

        public string ArticleDateDisplay
        {
            get
            {
                return ArticleDate.ToString("dd/MM/yyyy");
            }
        }
        public long LinkId { get; set; }
        public string Link { get; set; }
        public string ShortSummary
        {
            get
            {
                var result = Summary;
                var maxLength = 105;
                if (!string.IsNullOrWhiteSpace(Summary) && result.Length > maxLength)
                {
                    result = result.Substring(0, maxLength);
                    if (result.LastIndexOf(" ") > maxLength - 90)
                    {
                        result = result.Substring(0, result.LastIndexOf(" "));
                    }
                    return $"{result}...";
                }
                return result;
            }
        }
        public string Summary { get; set; }
        public string Picture { get; set; }
        public string Author { get; set; }
        public DateTime? LastSent { get; set; }
        public string LastSentDisplay
        {
            get
            {
                if (LastSent.HasValue)
                    return LastSent.Value.ToString("dd/MM/yyyy");
                return string.Empty;
            }
        }

        public List<int> RecipientTypes { get; set; }
        public string RecipientTypeNames { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public int CreatedUserId { get; set; }
        public int UpdatedUserId { get; set; }

    }
}
