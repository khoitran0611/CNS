﻿using ApptitudeCNS.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.ViewModel
{
    public class ArticleCountViewModel
    {
        public int All { get; set; }
        public int New { get; set; }
    }
}
