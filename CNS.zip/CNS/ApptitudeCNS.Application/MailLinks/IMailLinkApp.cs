﻿using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;

namespace ApptitudeCNS.Application.MailLinks
{
    public interface IMailLinkApp
    {
        EmailTracking ReadMail(long mailId);
        UserEmailTracking ReadUserMail(long mailId);
        User UnsubscribeClient(long clientId, long mailId);
        string GetLink(long articleId, long linkId, long mailId, long userMailId);
        string GetEmailContent(long mailId, long userMailId);
    }
}
