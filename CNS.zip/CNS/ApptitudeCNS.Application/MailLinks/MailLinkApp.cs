﻿using ApptitudeCNS.Application.Articles;
using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Infrastructure.Email.Domain.EmailTemplates;
using ApptitudeCNS.Infrastructure.Email.Services;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.MailLinks
{
    public class MailLinkApp : IMailLinkApp
    {
        private IGenericRepository<LinkTracking> LinkTrackingRespository { get; }
        private IGenericRepository<EmailTracking> MailTrackingRespository { get; }
        private IGenericRepository<UserEmailTracking> UserMailTrackingRespository { get; }
        private IGenericRepository<Client> ClientRespository { get; }
        private IGenericRepository<ClientHistory> ClientHistoryRespository { get; }
        private IGenericRepository<URLTracking> URLTrackingRespository { get; }
        private IGenericRepository<Article> ArticleRespository { get; }
        private IGenericRepository<User> UserRespository { get; }
        private IGenericRepository<ArticleAttachment> ArticleAttachmentRespository { get; }

        public MailLinkApp(IGenericRepository<LinkTracking> linkTrackingRespository,
            IGenericRepository<EmailTracking> mailTrackingRespository,
            IGenericRepository<Client> clientRespository,
            IGenericRepository<ClientHistory> clientHistoryRespository,
            IGenericRepository<URLTracking> urlTrackingRespository,
            IGenericRepository<UserEmailTracking> userMailTrackingRespository,
            IGenericRepository<Article> articleRespository,
            IGenericRepository<User> userRespository,
            IGenericRepository<ArticleAttachment> articleAttachmentRespository)
        {
            LinkTrackingRespository = linkTrackingRespository;
            MailTrackingRespository = mailTrackingRespository;
            UserMailTrackingRespository = userMailTrackingRespository;
            ClientRespository = clientRespository;
            ClientHistoryRespository = clientHistoryRespository;
            URLTrackingRespository = urlTrackingRespository;
            ArticleRespository = articleRespository;
            UserRespository = userRespository;
            ArticleAttachmentRespository = articleAttachmentRespository;
        }

        public EmailTracking ReadMail(long mailId)
        {
            if (mailId <= 0) return null;
            var mailTrackingItem = MailTrackingRespository.FindBy(mailId);

            if (mailTrackingItem != null)
            {
                if (mailTrackingItem.Status == (int)EnumEmailStatusType.Sent)
                {
                    mailTrackingItem.Status = (int)EnumEmailStatusType.Read;
                    mailTrackingItem.ReadDate = DateTime.Now;
                    MailTrackingRespository.Update(mailTrackingItem);
                    MailTrackingRespository.SaveChanges();

                    ClientHistoryRespository.Create(new ClientHistory
                    {
                        Content = $"Opened [{mailTrackingItem.Subject}]",
                        ClientId = mailTrackingItem.ClientId,
                        TypeId = (int)EnumHistoryType.Email,
                        IsSystemAutogen = true,
                        CreatedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        CreatedUserId = ConfigManager.SystemUserId
                    });
                    ClientHistoryRespository.SaveChanges();
                }
            }
            return mailTrackingItem;
        }

        public UserEmailTracking ReadUserMail(long mailId)
        {
            if (mailId <= 0) return null;

            var mailTrackingItem = UserMailTrackingRespository.FindBy(mailId);

            if (mailTrackingItem != null)
            {
                if (mailTrackingItem.Status == (int)EnumEmailStatusType.Sent)
                {
                    mailTrackingItem.Status = (int)EnumEmailStatusType.Read;
                    mailTrackingItem.ReadDate = DateTime.Now;
                    UserMailTrackingRespository.Update(mailTrackingItem);
                    UserMailTrackingRespository.SaveChanges();
                }
            }
            return mailTrackingItem;
        }

        public User UnsubscribeClient(long clientId, long mailId)
        {
            User result = null;
            var mailTrackingItem = MailTrackingRespository.FindBy(mailId);
            var clientItem = ClientRespository.FindBy(clientId);

            if (mailTrackingItem != null)
            {
                if (mailTrackingItem.Status == (int)EnumEmailStatusType.Sent)
                {
                    mailTrackingItem.Status = (int)EnumEmailStatusType.Read;
                    mailTrackingItem.ReadDate = DateTime.Now;
                    MailTrackingRespository.Update(mailTrackingItem);
                    MailTrackingRespository.SaveChanges();

                    ClientHistoryRespository.Create(new ClientHistory
                    {
                        Content = $"Opened [{mailTrackingItem.Subject}]",
                        ClientId = mailTrackingItem.ClientId,
                        TypeId = (int)EnumHistoryType.Email,
                        IsSystemAutogen = true,
                        CreatedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        CreatedUserId = ConfigManager.SystemUserId
                    });
                    ClientHistoryRespository.SaveChanges();
                }
            }

            if (clientItem != null)
            {
                clientItem.EmailSubscribe = (int)EnumClientEmailStatus.ClientUnsubscribe;
                ClientRespository.Update(clientItem);
                ClientRespository.SaveChanges();

                ClientHistoryRespository.Create(new ClientHistory
                {
                    Content = "Client unsubscribed the email",
                    ClientId = clientId,
                    TypeId = (int)EnumHistoryType.Email,
                    IsSystemAutogen = true,
                    CreatedDate = DateTime.Now,
                    UpdatedDate = DateTime.Now,
                    CreatedUserId = ConfigManager.SystemUserId
                });
                ClientHistoryRespository.SaveChanges();

                result = UserRespository.FindBy(clientItem.UserId);
            }
            return result ?? new User();
        }

        public string GetLink(long articleId, long linkId, long mailId, long userMailId)
        {
            var mailTrackingItem = MailTrackingRespository.FindBy(mailId);
            var userMailTrackingItem = UserMailTrackingRespository.FindBy(userMailId);
            var articleItem = articleId > 0 ? ArticleRespository.FindBy(articleId) : ArticleRespository.FindBy(x => x.URLTrackingId == linkId).FirstOrDefault();
            var linkItem = articleItem.IsNewsletterArticleLink ? URLTrackingRespository.FindBy(articleItem.URLTrackingId.Value) : null;
            var attachmentItem = articleItem.IsNewsletterArticleLink ? null : ArticleAttachmentRespository.FindBy(x => x.ArticleId == articleItem.Id).FirstOrDefault();

            if (mailTrackingItem?.Id > 0)
            {
                mailTrackingItem.Status = (int)EnumEmailStatusType.Clicked;
                mailTrackingItem.ClickedDate = DateTime.Now;
                MailTrackingRespository.Update(mailTrackingItem);
                MailTrackingRespository.SaveChanges();

                SetLastClickedDate(linkItem);

                var subject = ArticleRespository.FindBy(x => x.URLTrackingId == linkId).LastOrDefault()?.Title;
                ClientHistoryRespository.Create(new ClientHistory
                {
                    Content = $"Opened [{subject}] in [{mailTrackingItem.Subject}]",
                    ClientId = mailTrackingItem.ClientId,
                    TypeId = (int)EnumHistoryType.Email,
                    IsSystemAutogen = true,
                    CreatedDate = DateTime.Now,
                    UpdatedDate = DateTime.Now,
                    CreatedUserId = ConfigManager.SystemUserId
                });
                ClientHistoryRespository.SaveChanges();
            }

            if (userMailTrackingItem?.Id > 0)
            {
                userMailTrackingItem.Status = (int)EnumEmailStatusType.Clicked;
                userMailTrackingItem.ClickedDate = DateTime.Now;
                UserMailTrackingRespository.Update(userMailTrackingItem);
                UserMailTrackingRespository.SaveChanges();

                SetLastClickedDate(linkItem);
            }

            if (linkItem?.Id > 0 && (mailTrackingItem?.Id > 0 || userMailTrackingItem?.Id > 0))
            {
                var clientId = mailTrackingItem?.ClientId;
                var userId = userMailTrackingItem?.UserId;
                var linkTracking = LinkTrackingRespository.EntitiesNoTracking.FirstOrDefault(x => x.LinkId == linkItem.Id &&
                    (x.ClientId == clientId && x.UserId == userId));
                if (linkTracking == null)
                {
                    LinkTrackingRespository.Create(new LinkTracking
                    {
                        ClientId = clientId,
                        UserId = userId,
                        LinkId = linkItem.Id,
                        ClickedDate = DateTime.Now
                    });
                    LinkTrackingRespository.SaveChanges();
                }
                return linkItem?.ReturnedURL;
            }

            if (attachmentItem?.Id > 0)// && (mailTrackingItem?.Id > 0 || userMailTrackingItem?.Id > 0))
            {
                //var clientId = mailTrackingItem?.ClientId;
                //var userId = userMailTrackingItem?.UserId;
                //var linkTracking = LinkTrackingRespository.EntitiesNoTracking.FirstOrDefault(x => x.LinkId == linkItem.Id &&
                //    (x.ClientId == clientId && x.UserId == userId));
                //if (linkTracking == null)
                //{
                //    LinkTrackingRespository.Create(new LinkTracking
                //    {
                //        ClientId = clientId,
                //        UserId = userId,
                //        LinkId = linkItem.Id,
                //        ClickedDate = DateTime.Now
                //    });
                //    LinkTrackingRespository.SaveChanges();
                //}
                return $"{ArticleConstants.UPLOADED_ATTACHMENT_FOLDER}/{attachmentItem.Name}";
            }
            return string.Empty;
        }

        public string GetEmailContent(long mailId, long userMailId)
        {
            var mailTrackingItem = ReadMail(mailId);
            var userMailTrackingItem = ReadUserMail(userMailId);
            return mailTrackingItem?.Content ?? userMailTrackingItem?.Content;
        }

        #region Private Methods
        private void SetLastClickedDate(URLTracking url)
        {
            if (url?.Id > 0)
            {
                url.LastClickedDate = DateTime.Now;
                URLTrackingRespository.Update(url);
                URLTrackingRespository.SaveChanges();
            }
        }
        #endregion
    }
}
