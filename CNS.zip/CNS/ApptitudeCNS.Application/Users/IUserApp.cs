﻿using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using System.Collections.Generic;

namespace ApptitudeCNS.Application.Users
{
    public interface IUserApp
    {
        UserViewModel FindByUserId(long id);
        UserViewModel FindByEmail(string email);
        bool LogIn(string email, string password);
        bool ChangePassword(string email, string oldPassword, string newPassword);
        UserViewModel CreateAndUpdate(UserViewModel user , long currentUserId , string historyContent = null, bool isUpdatedBrokerMessage = false);
        List<RoleViewModel> FindRolesByEmail(string userName);
        UserWithRoleViewModel FindUserWithRoleByEmail(string email);
        List<UserViewModel> GetAll();
        List<UserWithRoleViewModel> GetAllWithRole(int pageIndex, int pageSize,string sortFieldName, bool isDesc, UserFilterViewModel filter ,ref long numOfItem);
        void Delete(int id);
        UserViewModel CreateAndUpdateWithRole(UserViewModel user, List<long> roleIds , long currentUserId, bool isUpdatedBrokerMessage = false);
        UserWithRoleViewModel FindUserWithRoleById(int id);
        void UpdateLogoName(UserViewModel item, long currentUserId);
        void UpdateCompanyImageName(UserViewModel item, long currentUserId);

        List<string> GetUserLogoList();

        List<IdName> GetUserList(string term, bool includeClients);

        UserSampleEmailViewModel FindUser(long id, int type);
        long[] GetArticles(int type);
    }
}
