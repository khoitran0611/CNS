﻿using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using System.Collections.Generic;
using System.Linq;
using System.Web.Helpers;
using ApptitudeCNS.Helpers;

namespace ApptitudeCNS.Application.Users
{
    public class UserHistoryApp : IUserHistoryApp
    {
        private IGenericRepository<UserHistory> userHistoryRepository { get; set; }
        private IGenericRepository<User> userRepository { get; set; }

        public UserHistoryApp(IGenericRepository<UserHistory> _userHistoryRepository, IGenericRepository<User> _userRepository)
        {
            userHistoryRepository = _userHistoryRepository;
            userRepository = _userRepository;
        }

        public List<UserHistoryViewModel> FindByUserId(long userId)
        {
            var sql = userHistoryRepository
                            .Entities
                            .Where(uh => !uh.IsDeleted && uh.UserId == userId)
                            .OrderByDescending(uh => new { uh.Pinned, uh.UpdatedDate, uh.CreatedDate })
                            .ToList();
            var createdUserIds = sql.Where(r => r.CreatedUserId.HasValue).Select(r => r.CreatedUserId).Distinct().ToList();
            var createdUserObjs = userRepository.FindBy(u => createdUserIds.Contains(u.Id)).Distinct().ToDictionary(u=> u.Id , u=> u.Signature);

            var result = sql.Select(uh => AutoMapperGenericsHelper<UserHistory, UserHistoryViewModel>.FullCopy(uh)).ToList();
            foreach (var item in result)
            {
                if(item.CreatedUserId.HasValue && createdUserObjs.ContainsKey(item.CreatedUserId.Value))
                {
                    item.CreatedUserSignature = createdUserObjs[item.CreatedUserId.Value];
                }
            }
            return result;
        }
        public List<UserHistoryViewModel> FindByEmail(string email)
        {
            var sqlClients = userHistoryRepository
               .Entities
               .Where(uh => !uh.IsDeleted)
               .Join(userRepository.Entities.Where(u => u.Email.Trim() == email.Trim()), uh => uh.UserId, u => u.Id, (uh, u) => uh)
               .OrderByDescending(uh => new { uh.Pinned, uh.UpdatedDate, uh.CreatedDate }).ToList();

            var createdUserIds = sqlClients.Where(r => r.CreatedUserId.HasValue).Select(r => r.CreatedUserId).ToList();
            var createdUserObjs = userRepository.FindBy(u => createdUserIds.Contains(u.Id)).Distinct().ToDictionary(u => u.Id, u => u.Signature);

            var result = sqlClients.Select(uh => AutoMapperGenericsHelper<UserHistory, UserHistoryViewModel>.FullCopy(uh)).ToList();
            if(createdUserObjs!= null && createdUserObjs.Count() > 0)
            {
                foreach (var item in result)
                {
                    if (item.CreatedUserId.HasValue && item.CreatedUserId.Value > 0)
                    {
                        item.CreatedUserSignature = createdUserObjs[item.CreatedUserId.Value];
                    }
                }
            }
            
            return result;
        }

        public UserHistoryViewModel FindById(long id)
        {
            var result = userHistoryRepository.FindBy(id);
            return AutoMapperGenericsHelper<UserHistory, UserHistoryViewModel>.FullCopy(result);
        }

        public UserHistoryViewModel CreateAndUpdate(UserHistoryViewModel userHistory)
        {
            var his = AutoMapperGenericsHelper<UserHistoryViewModel, UserHistory>.FullCopy(userHistory);
            if (userHistory.Id > 0)
            {
                userHistoryRepository.Update(his);
            }
            else
            {
                userHistoryRepository.Create(his);
            }
            userHistoryRepository.SaveChanges();
            return AutoMapperGenericsHelper<UserHistory, UserHistoryViewModel>.FullCopy(his);
        }

        public void Delete(long id)
        {
            var his = userHistoryRepository.FindBy(c => c.Id == id).FirstOrDefault();
            if (his != null)
            {
                userHistoryRepository.Delete(his);
                userHistoryRepository.SaveChanges();
            }
        }

        public void SetPinned(long id, bool isPinned)
        {
            var his = userHistoryRepository.FindBy(c => c.Id == id).FirstOrDefault();
            if (his != null)
            {
                his.Pinned = isPinned;
                userHistoryRepository.Update(his);
                userHistoryRepository.SaveChanges();
            }
        }

    }
}
