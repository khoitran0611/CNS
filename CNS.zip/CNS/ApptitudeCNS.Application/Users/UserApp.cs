﻿using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using System.Collections.Generic;
using System.Linq;
using System.Web.Helpers;
using ApptitudeCNS.Helpers;
using System;
using ApptitudeCNS.Core.IRepository;

namespace ApptitudeCNS.Application.Users
{
    public class UserApp : IUserApp
    {
        private IGenericRepository<User> userGenericRepository { get; set; }
        private IGenericRepository<Role> roleGenericRepository { get; set; }
        private IGenericRepository<UserRole> userRoleGenericRepository { get; set; }
        private IUserRepository userRepository { get; set; }
        private IRoleRepository roleRepository { get; set; }
        private IGenericRepository<Client> clientGenericRepository { get; set; }
        private IGenericRepository<UserHistory> userHistoryGenericRepository { get; set; }
        private IBpAggregatorRepository bpAggregatorRepository { get; set; }
        private IGenericRepository<SystemConfig> systemConfigRespository { get; }

        public UserApp(
            IGenericRepository<User> _userGenericRepository,
            IUserRepository _userRepository,
            IRoleRepository _roleRepository,
            IGenericRepository<UserRole> _userRoleGenericRepository,
            IGenericRepository<Role> _roleGenericRepository,
            IGenericRepository<Client> _clientGenericRepository,
            IGenericRepository<UserHistory> _userHistoryGenericRepository,
            IBpAggregatorRepository _bpAggregatorRepository,
            IGenericRepository<SystemConfig> _systemConfigRespository
            )
        {
            userGenericRepository = _userGenericRepository;
            userRepository = _userRepository;
            roleRepository = _roleRepository;
            userRoleGenericRepository = _userRoleGenericRepository;
            roleGenericRepository = _roleGenericRepository;
            clientGenericRepository = _clientGenericRepository;
            userHistoryGenericRepository = _userHistoryGenericRepository;
            bpAggregatorRepository = _bpAggregatorRepository;
            systemConfigRespository = _systemConfigRespository;
        }

        public UserViewModel FindByUserId(long id)
        {
            var user = userGenericRepository.FindBy(u => u.Id == id && !u.IsDeleted).FirstOrDefault();
            return AutoMapperGenericsHelper<User, UserViewModel>.FullCopy(user);
        }

        public UserViewModel FindByEmail(string email)
        {
            //var user = userGenericRepository.FindBy(u => u.Email.Trim().ToLower() == email.Trim().ToLower() && !u.IsDeleted).FirstOrDefault();
            var user = userGenericRepository.EntitiesNoTracking.Where(u => u.Email.Trim().ToLower() == email.Trim().ToLower() && !u.IsDeleted && u.SendSampleEmailType == null).FirstOrDefault();
            return AutoMapperGenericsHelper<User, UserViewModel>.FullCopy(user);
        }

        public UserWithRoleViewModel FindUserWithRoleByEmail(string email)
        {
            var user = AutoMapperGenericsHelper<UserViewModel, UserWithRoleViewModel>.FullCopy(FindByEmail(email));
            if (user != null)
            {
                user.Roles = FindRolesByEmail(email);
                user.IsAdmin = user.Roles != null && user.Roles.Count > 0 && user.Roles.Any(r => r.RoleName == CNSConstant.Administrator);
            }

            return user;
        }

        public UserWithRoleViewModel FindUserWithRoleById(int id)
        {
            var user = AutoMapperGenericsHelper<UserViewModel, UserWithRoleViewModel>.FullCopy(FindByUserId(id));
            user.Roles = FindRolesByEmail(user.Email);
            user.IsAdmin = user.Roles != null && user.Roles.Count > 0 && user.Roles.Any(r => r.RoleName == CNSConstant.Administrator);
            return user;
        }

        public List<UserViewModel> GetAll()
        {
            var users = userGenericRepository.FindBy(u => !u.IsDeleted && u.SendSampleEmailType == null).ToList();
            List<UserViewModel> result = new List<UserViewModel>();
            foreach (var item in users)
            {
                result.Add(AutoMapperGenericsHelper<User, UserViewModel>.FullCopy(item));
            }
            return result;
        }

        public List<UserWithRoleViewModel> GetAllWithRole(int pageIndex, int pageSize, string sortFieldName, bool isDesc, UserFilterViewModel filter, ref long numOfCLient)
        {
            List<UserWithRoleViewModel> result = new List<UserWithRoleViewModel>();
            //var users = userGenericRepository.EntitiesNoTracking
            //    .Where(u => !u.IsDeleted && u.SendSampleEmailType == null)
            //    .OrderBy(sortFieldName, isDesc);
            var groupUsers = (from u in userGenericRepository.EntitiesNoTracking
                              join uh in userHistoryGenericRepository.EntitiesNoTracking on u.Id equals uh.UserId into guh
                              from uhg in guh.DefaultIfEmpty()
                              where !u.IsDeleted && u.SendSampleEmailType == null
                              select new { u, uhg });

            var roles = roleGenericRepository.GetAll();

            //var userRoles = userRoleGenericRepository.EntitiesNoTracking
            //    .Join(users, ur => ur.UserId, u => u.Id, (ur, u) => ur)
            //    .ToList();

            if (filter != null)
            {
                if (string.IsNullOrWhiteSpace(filter.SearchText))
                {
                    filter.SearchText = string.Empty;
                }

                groupUsers = groupUsers.Where(d => (filter.BrokerTypeId <= 0 || d.u.UserTypeId == filter.BrokerTypeId) &&
                            (filter.SearchText == string.Empty ||
                            (filter.SearchLevel == 0 && (filter.SearchText == (d.u.FirstName + " " + d.u.LastName).Trim()
                                                            || filter.SearchText == d.u.FirstName
                                                            || filter.SearchText == d.u.LastName
                                                            || filter.SearchText == d.u.Email
                                                            || filter.SearchText == d.u.Phone)) ||
                            (filter.SearchLevel == 1 && ((d.u.FirstName + " " + d.u.LastName).Trim().Contains(filter.SearchText)
                                                             || d.u.FirstName.Contains(filter.SearchText)
                                                             || d.u.LastName.Contains(filter.SearchText)
                                                             || d.u.Email.Contains(filter.SearchText)
                                                             || d.u.Phone.Contains(filter.SearchText)
                                                             || d.uhg.Content.Contains(filter.SearchText)))));

                if (filter.RoleIds.Count > 0)
                {
                    var validUsers = userRoleGenericRepository.EntitiesNoTracking.Where(ur => filter.RoleIds.Contains(ur.RoleId)).Select(ur => ur.UserId).Distinct();
                    groupUsers = groupUsers.Where(ug => validUsers.Contains(ug.u.Id));
                }

                ////Filter : Serach text
                //if (!string.IsNullOrEmpty(filter.SearchText))
                //{
                //    if (filter.SearchLevel == 0)
                //    {
                //        users = users.Where(c =>
                //        (filter.SearchText == (c.FirstName + " " + c.LastName).Trim()
                //        || filter.SearchText == c.FirstName
                //        || filter.SearchText == c.LastName
                //        || filter.SearchText == c.Email
                //        || filter.SearchText == c.Phone));
                //    }
                //    else if (filter.SearchLevel == 1)
                //    {
                //        users = users.Where(c =>
                //         ((c.FirstName + " " + c.LastName).Trim().Contains(filter.SearchText)
                //         || c.FirstName.Contains(filter.SearchText)
                //         || c.LastName.Contains(filter.SearchText)
                //         || c.Email.Contains(filter.SearchText)
                //         || c.Phone.Contains(filter.SearchText)));
                //    }
                //}

                //if (filter.RoleIds.Count > 0)
                //{
                //    var validUsers = userRoles.Where(ur => filter.RoleIds.Contains(ur.RoleId)).Select(ur => ur.UserId).Distinct();
                //    users = users.Where(u => validUsers.Contains(u.Id));
                //}

                //if (filter.BrokerTypeId > 0)
                //{
                //    users = users.Where(u => u.UserTypeId == filter.BrokerTypeId);
                //}
            }

            var users = (from gu in groupUsers.AsEnumerable()
                         group new { gu.u } by new { gu.u.Id } into g
                         select g.FirstOrDefault().u);

            //var tempusers = users.ToList();
            //var userRoles = userRoleGenericRepository.GetAll().Where(x => users.Any(y => y.Id == x.UserId));

            var userRoles = (from ur in userRoleGenericRepository.EntitiesNoTracking.AsEnumerable()
                             join u in users on ur.UserId equals u.Id
                             select ur).ToList();

            //.Join(users, ur => ur.UserId, u => u.Id, (ur, u) => ur)
            //.ToList();
            users = !isDesc ? users.OrderByDescending(x => x.FirstName).ThenByDescending(x => x.LastName) : users.OrderBy(x => x.FirstName).ThenBy(x => x.LastName);

            numOfCLient = users.Count();

            users = users.Skip((pageIndex - 1) * pageSize).Take(pageSize);
            var userAndNumOfCient = clientGenericRepository
                .EntitiesNoTracking.AsEnumerable()
                .Where(c => !c.IsDeleted)
                .Join(users, c => c.UserId, u => u.Id, (c, u) => new { UserId = c.UserId, ClientId = c.Id })
                .GroupBy(t => t.UserId)
                .Select(n => new { UserId = n.Key, Num = n.Count() })
                .ToList();

            var userTypes = CommonHelper.GetListForEnum<EnumUserType>();
            foreach (var item in users)
            {
                var tempt = AutoMapperGenericsHelper<User, UserWithRoleViewModel>.FullCopy(item);
                tempt.Roles = userRoles
                    .Where(ur => ur.UserId == item.Id)
                    .Select(ur => new RoleViewModel { Id = ur.RoleId, RoleName = roles.First(r => r.Id == ur.RoleId).RoleName })
                    .ToList();
                tempt.NumOfClient = userAndNumOfCient.Any(c => c.UserId == item.Id) ?
                    userAndNumOfCient.Where(c => c.UserId == item.Id).FirstOrDefault().Num : 0;
                tempt.IsAdmin = tempt.Roles != null && tempt.Roles.Count > 0 && tempt.Roles.Any(r => r.RoleName == CNSConstant.Administrator);
                tempt.UserTypeName = userTypes.FirstOrDefault(x => x.Id == tempt.UserTypeId)?.Name;
                result.Add(tempt);
            }
            return result;
        }

        public bool LogIn(string email, string password)
        {
            var user = FindByEmail(email);
            return user != null && user.IsActive && Crypto.VerifyHashedPassword(user.PasswordHash, password);
        }

        public bool ChangePassword(string email, string oldPassword, string newPassword)
        {
            var user = userGenericRepository.FindBy(u => u.Email == email).FirstOrDefault();
            if (user != null && Crypto.VerifyHashedPassword(user.PasswordHash, oldPassword))
            {
                user.Password = newPassword;
                user.PasswordHash = Crypto.HashPassword(newPassword);
                userGenericRepository.Update(user);
                userGenericRepository.SaveChanges();
            }
            return true;
        }

        public void UpdateLogoName(UserViewModel item, long currentUserId)
        {
            var existItem = userGenericRepository.FindBy(item.Id);

            var historyContent = existItem.Logo != item.Logo ? $"<p>Changed Logo from \"{existItem.Logo}\" to \"{item.Logo}\"</p>" : "";

            //var article = AutoMapperGenericsHelper<ArticlesViewModel, Article>.FullCopy(model, existItem, );
            existItem.Logo = item.Logo;
            existItem.UpdatedDate = item.UpdatedDate;
            //existItem.UpdatedUserId = model.UpdatedUserId;

            userGenericRepository.Update(existItem);
            userGenericRepository.SaveChanges();

            //Save history
            if (!string.IsNullOrWhiteSpace(historyContent))
            {
                userHistoryGenericRepository.Create(new UserHistory
                {
                    UserId = item.Id,
                    IsSystemAutogen = true,
                    TypeId = (int)EnumHistoryType.Other,
                    Content = historyContent,
                    CreatedDate = DateTime.Now,
                    UpdatedDate = DateTime.Now,
                    CreatedUserId = currentUserId
                });
                userHistoryGenericRepository.SaveChanges();
            }
        }

        public void UpdateCompanyImageName(UserViewModel item, long currentUserId)
        {
            var existItem = userGenericRepository.FindBy(item.Id);

            var historyContent = existItem.CompanyImage != item.CompanyImage ? $"<p>Changed Company Image from \"{existItem.CompanyImage}\" to \"{item.CompanyImage}\"</p>" : "";

            //var article = AutoMapperGenericsHelper<ArticlesViewModel, Article>.FullCopy(model, existItem, );
            existItem.CompanyImage = item.CompanyImage;
            existItem.UpdatedDate = item.UpdatedDate;
            //existItem.UpdatedUserId = model.UpdatedUserId;

            userGenericRepository.Update(existItem);
            userGenericRepository.SaveChanges();

            //Save history
            if (!string.IsNullOrWhiteSpace(historyContent))
            {
                userHistoryGenericRepository.Create(new UserHistory
                {
                    UserId = item.Id,
                    IsSystemAutogen = true,
                    TypeId = (int)EnumHistoryType.Other,
                    Content = historyContent,
                    CreatedDate = DateTime.Now,
                    UpdatedDate = DateTime.Now,
                    CreatedUserId = currentUserId
                });
                userHistoryGenericRepository.SaveChanges();
            }
        }

        public UserViewModel CreateAndUpdate(UserViewModel user, long currentUserId, string historyContent = "", bool isUpdatedBrokerMessage = false)
        {
            User result = null;
            if (user.Id > 0)
            {
                //Find difference 2 object new and old
                result = userGenericRepository.FindBy(user.Id);

                //Update  password hash
                user.PasswordHash = Crypto.HashPassword(user.Password);
                //Keep the original created day
                user.CreatedDate = result.CreatedDate;
                if (!isUpdatedBrokerMessage)
                {
                    user.BrokerMessage = result.BrokerMessage;
                }
                user.LastSendMassEmail = result.LastSendMassEmail;

                var compareResults = ExtensionClass.Compare<User>(result, AutoMapperGenericsHelper<UserViewModel, User>.FullCopy(user));
                var userTypes = CommonHelper.GetListForEnum<EnumUserType>();
                var aggregators = bpAggregatorRepository.GetBpAggregators();
                //var compareResults = ExtensionClass.Compare<UserViewModel>(AutoMapperGenericsHelper<User , UserViewModel>.FullCopy(result), user);
                foreach (var item in compareResults)
                {
                    if (item.Name != "UpdatedDate" && item.Name != "CreatedDate" && item.Name != "Password" && item.Name != "PasswordHash" && item.Name != "Last Sent")
                    {
                        switch (item.Name)
                        {
                            case "UserTypeId":
                                historyContent += $"<p>Changed Broker Type from \"{userTypes.FirstOrDefault(x => x.Id == CommonHelper.GetLong(item.OldValue))?.Name}\" to \"{userTypes.FirstOrDefault(x => x.Id == CommonHelper.GetLong(item.NewValue))?.Name}\"</p>";
                                continue;
                            case "SubAggregatorId":
                                historyContent += $"<p>Changed Sub Aggregator from \"{aggregators.FirstOrDefault(x => x.Id == CommonHelper.GetLong(item.OldValue))?.Name}\" to \"{aggregators.FirstOrDefault(x => x.Id == CommonHelper.GetLong(item.NewValue))?.Name}\"</p>";
                                continue;
                            case "AggregatorId":
                                historyContent += $"<p>Changed Aggregator from \"{aggregators.FirstOrDefault(x => x.Id == CommonHelper.GetLong(item.OldValue))?.Name}\" to \"{aggregators.FirstOrDefault(x => x.Id == CommonHelper.GetLong(item.NewValue))?.Name}\"</p>";
                                continue;
                            case "Logo Position":
                                var oldValue = item.OldValue == null || (int)item.OldValue == 1 ? EnumLogoPositionType.Left.ToString().ToLower() : EnumLogoPositionType.Right.ToString().ToLower();
                                var newValue = item.NewValue == null || (int)item.NewValue == 1 ? EnumLogoPositionType.Left.ToString().ToLower() : EnumLogoPositionType.Right.ToString().ToLower();
                                historyContent += $"<p>Changed {item.Name} from \"{ oldValue }\" to \"{newValue}\"</p>";
                                continue;
                        }
                        if (item.Name == "SMS Subscribe" || item.Name == "Email Subscribe")
                        {
                            historyContent += string.Format("<p>Changed {0} from \"{1}\" to \"{2}\"</p>", item.Name, CommonHelper.GetSubscribeLogName((bool?)item.OldValue), CommonHelper.GetSubscribeLogName((bool?)item.NewValue));
                        }
                        else if (item.OldValue is bool)
                        {
                            historyContent += string.Format("<p>{0} was {1}</p>", item.Name, (bool)item.NewValue ? "checked" : "unchecked");
                        }
                        else
                        {
                            historyContent += string.Format("<p>Changed {0} from \"{1}\" to \"{2}\"</p>", item.Name, item.OldValue != null ? item.OldValue.ToString() : string.Empty, item.NewValue != null ? item.NewValue.ToString() : string.Empty);
                        }
                    }
                }

                AutoMapperGenericsHelper<UserViewModel, User>.FullCopy(user, result);
                userGenericRepository.Update(result);
            }
            else
            {
                result = AutoMapperGenericsHelper<UserViewModel, User>.FullCopy(user);
                result.PasswordHash = Crypto.HashPassword(result.Password);
                userGenericRepository.Create(result);
                historyContent = "Created";
            }

            userGenericRepository.SaveChanges();
            var tempt = AutoMapperGenericsHelper<User, UserViewModel>.FullCopy(result);

            //Save history
            if (!string.IsNullOrWhiteSpace(historyContent))
            {
                userHistoryGenericRepository.Create(new UserHistory
                {
                    UserId = tempt.Id,
                    IsSystemAutogen = true,
                    TypeId = (int)EnumHistoryType.Other,
                    Content = historyContent,
                    CreatedDate = DateTime.Now,
                    UpdatedDate = DateTime.Now,
                    CreatedUserId = currentUserId
                });
                userHistoryGenericRepository.SaveChanges();
            }

            return tempt;
        }

        public UserViewModel CreateAndUpdateWithRole(UserViewModel user, List<long> roleIds, long currentUserId, bool isUpdatedBrokerMessage = false)
        {
            var historyContent = string.Empty;
            roleIds = roleIds.Distinct().OrderBy(r => r).ToList();
            if (user.Id > 0)
            {
                var oldUserRole = userRoleGenericRepository.FindBy(ur => ur.UserId == user.Id).Select(ur => ur.RoleId).OrderBy(r => r).ToList();
                var ismatch = oldUserRole.Count() == roleIds.Count() && oldUserRole.All(o => roleIds.Contains(o));
                //if (ismatch)
                //{
                //    for (int i = 0; i < roleIds.Count(); i++)
                //    {
                //        ismatch = roleIds[i] == oldUserRole[i];
                //    }
                //}
                if (!ismatch)
                {
                    var roles = roleGenericRepository.GetAll();
                    var rolesName = roles.Where(r => roleIds.Contains(r.Id)).Where(r => r.Id != (int)EnumRole.Broker).Select(r => r.RoleName).ToList();
                    if (rolesName.Count() == 0)
                    {
                        historyContent += string.Format("<p>Remove {0} role</p>", CNSConstant.Administrator);
                    }
                    else
                    {
                        historyContent += string.Format("<p>Add {0} role</p>", string.Join(",", rolesName));
                    }
                }
            }
            var newUser = CreateAndUpdate(user, currentUserId, historyContent, isUpdatedBrokerMessage);

            userRoleGenericRepository.DeleteBy(ur => ur.UserId == newUser.Id);
            foreach (var id in roleIds)
            {
                if (id > 0)
                {
                    userRoleGenericRepository.Create(new UserRole() { UserId = newUser.Id, RoleId = id });
                }
            }
            userRoleGenericRepository.SaveChanges();
            return newUser;
        }

        public void Delete(int id)
        {
            var updatedUser = userGenericRepository.FindBy(u => u.Id == id).FirstOrDefault();
            updatedUser.IsDeleted = true;
            userGenericRepository.Update(updatedUser);
            userGenericRepository.SaveChanges();
        }

        public List<RoleViewModel> FindRolesByEmail(string email)
        {
            var roles = roleRepository.FindRolesByUserName(email);
            return roles.Select(r => AutoMapperGenericsHelper<Role, RoleViewModel>.FullCopy(r)).ToList();
        }

        public List<string> GetUserLogoList()
        {
            return userGenericRepository.EntitiesNoTracking.Where(x => x.Logo != "" && x.Logo != null).Select(x => x.Logo).ToList();
        }

        public List<IdName> GetUserList(string term, bool includeClients)
        {
            if (string.IsNullOrWhiteSpace(term) || term.Length < 1) return new List<IdName>();

            var id = CommonHelper.GetLong(term);
            if (!includeClients)
            {
                var result = userGenericRepository.FindBy(u => !u.IsDeleted && u.IsActive && u.EmailSubscribe == true && u.SendSampleEmailType == null &&
                                 u.Logo != null && u.Logo != "" && (id == u.Id || u.FirstName.StartsWith(term) || u.LastName.StartsWith(term) || u.Email.StartsWith(term)))
                                 .OrderBy(x => x.FirstName).ThenBy(x => x.LastName).AsEnumerable();

                return result.Select(x => new IdName { Id = x.Id, Name = $"[{x.Id}] {CommonHelper.GetFullname(x.FirstName, x.LastName, x.InternalIdentifier)}".Trim() }).ToList();

            }

            var result2 = (from u in userGenericRepository.EntitiesNoTracking
                           join c in clientGenericRepository.EntitiesNoTracking on u.Id equals c.UserId
                           //join ct in ClientTypeRespository.Entities on c.Id equals ct.ClientId
                           where !u.IsDeleted && !c.IsDeleted && u.IsActive && u.EmailSubscribe == true &&
                               u.Logo != null && u.Logo != "" &&
                               (id == u.Id || u.FirstName.StartsWith(term) || u.LastName.StartsWith(term) || u.Email.StartsWith(term)) &&
                               c.EmailSubscribe == 1 // && recipientTypeIds.Contains(ct.TypeId)
                                                     //(request.RecipientTypeIds != null && request.RecipientTypeIds.Any(x => x == ct.TypeId))
                           select u)
                     .Distinct().OrderBy(x => x.FirstName).ThenBy(x => x.LastName).AsEnumerable();
            return result2.Select(x => new IdName { Id = x.Id, Name = $"[{x.Id}] {CommonHelper.GetFullname(x.FirstName, x.LastName, x.InternalIdentifier)}".Trim() }).ToList();
        }

        public UserSampleEmailViewModel FindUser(long id, int type)
        {
            //var user = bpAggregatorRepository.
            var bpUser = ((EnumSendSampleEmailType)type) == EnumSendSampleEmailType.Proinspect ? bpAggregatorRepository.GetProinspectUser(id) : bpAggregatorRepository.GetBrokerpediaUser(id);
            var result = AutoMapperGenericsHelper<BpUser, UserSampleEmailViewModel>.FullCopy(bpUser);
            result.Id = 0;
            result.Phone = CommonHelper.GetValue(result.Phone, "0212345678");
            result.ABN = CommonHelper.GetValue(result.ABN, "## ### ### ###");
            result.Address = CommonHelper.GetValue(result.Address, "Sample Address");
            result.Company = CommonHelper.GetValue(result.Company, "Your Company Name");
            result.SendSampleEmailType = type;
            return result;
        }

        public long[] GetArticles(int type)
        {
            var keyName = ((EnumSendSampleEmailType)type).GetDescription();
            var item = systemConfigRespository.FindBy(x => !x.IsDeleted && x.KeyName == keyName).AsEnumerable().FirstOrDefault();
            //var user = bpAggregatorRepository.
            var result = item.Value.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(x => CommonHelper.GetLong(x.Trim())).ToList();
            result.Add(0);
            return result.ToArray();
        }

    }

}
