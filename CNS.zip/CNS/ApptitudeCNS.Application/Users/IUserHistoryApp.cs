﻿using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using System.Collections.Generic;

namespace ApptitudeCNS.Application.Users
{
    public interface IUserHistoryApp
    {
        List<UserHistoryViewModel> FindByUserId(long userId);
        List<UserHistoryViewModel> FindByEmail(string email);
        UserHistoryViewModel FindById(long id);        
        UserHistoryViewModel CreateAndUpdate(UserHistoryViewModel userHistory);
        void Delete(long id);
        void SetPinned(long id, bool isPinned);
    }
}
