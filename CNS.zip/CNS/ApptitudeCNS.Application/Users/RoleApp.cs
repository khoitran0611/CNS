﻿using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using ApptitudeCNS.Infrastructure.Persistence.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.Users
{
    public class RoleApp : IRoleApp
    {
        private IGenericRepository<Role> roleGenericRepository { get; set; }
        private IRoleRepository roleRepository { get; set; }

        public RoleApp(IRoleRepository _roleRepository , IGenericRepository<Role> _roleGenericRepository)
        {
            roleGenericRepository = _roleGenericRepository;
            roleRepository = _roleRepository;
        }
        public List<RoleViewModel> FindRolesByEmail(string email)
        {
            var roles = roleRepository.FindRolesByUserName(email);
            return roles.Select(r => AutoMapperGenericsHelper<Role, RoleViewModel>.FullCopy(r)).ToList();
        }

        public List<RoleViewModel> GetAll()
        {
            var roles = roleGenericRepository.GetAll();
            return roles.Select(r => AutoMapperGenericsHelper<Role, RoleViewModel>.FullCopy(r)).ToList();
        }
    }
}
