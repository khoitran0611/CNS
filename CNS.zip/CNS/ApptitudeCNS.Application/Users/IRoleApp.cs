﻿using ApptitudeCNS.Application.ViewModel;
using System.Collections.Generic;


namespace ApptitudeCNS.Application.Users
{
    public interface IRoleApp
    {
        List<RoleViewModel> FindRolesByEmail(string userName);
        List<RoleViewModel> GetAll();
    }
}
