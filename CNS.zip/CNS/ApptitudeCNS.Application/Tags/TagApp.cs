﻿using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.Tags;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace ApptitudeCNS.Application.Tags
{
    public class TagApp : ITagApp
    {
        private IDbContext DbContext { get; }
        private IGenericRepository<Article> ArticleRespository { get; }
        private IGenericRepository<ArticleTag> ArticleTagRespository { get; }
        private IGenericRepository<ManualArticleTag> ManualArticleTagRespository { get; }
        private IGenericRepository<Tag> TagRespository { get; }

        public TagApp(IDbContext dbContext,
            IGenericRepository<Article> articleRespository,
            IGenericRepository<ArticleTag> articleTagRespository,
            IGenericRepository<ManualArticleTag> manualArticleTagRespository,
            IGenericRepository<Tag> tagRespository)
        {
            DbContext = dbContext;
            ArticleRespository = articleRespository;
            ArticleTagRespository = articleTagRespository;
            ManualArticleTagRespository = manualArticleTagRespository;
            TagRespository = tagRespository;
        }


        public List<TagViewModel> GetList()
        {
            return TagRespository.FindBy(x => !x.IsDeleted).OrderBy(x => x.OrderNumber).ThenBy(x => x.Name).Select(x => AutoMapperGenericsHelper<Tag, TagViewModel>.FullCopy(x)).ToList();
        }

        public List<int> GetTagIdsByMapNames(string mapNames)
        {
            //mapNames = CommonHelper.GetWord(mapNames).ToLower();
            if (string.IsNullOrWhiteSpace(mapNames)) return new List<int>();

            var tags = TagRespository.FindBy(x => !x.IsDeleted);
            //CommonHelper.CheckWords 
            return tags.Where(x => x.MapNames.ToLower().Split(new string[] { Environment.NewLine, ",", "\n" }, StringSplitOptions.RemoveEmptyEntries)
                .Any(y => CommonHelper.CheckWord(y, mapNames))).Select(x => x.Id).ToList();

            //return tags.Where(x => x.MapNames.ToLower().Split(new string[] { Environment.NewLine, ",", "\n" }, StringSplitOptions.RemoveEmptyEntries)
            //    .Any(y => mapNames == CommonHelper.GetWord(y) || mapNames.StartsWith($"{CommonHelper.GetWord(y)} ") ||
            //    mapNames.EndsWith($" {CommonHelper.GetWord(y)}") || mapNames.Contains($" {CommonHelper.GetWord(y)} "))).Select(x => x.Id).ToList();
        }

        public bool CheckExistName(int id, string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return false;
            name = name.Trim().ToLower();
            var url = TagRespository.FindBy(x => x.Id != id && !x.IsDeleted && name.Equals(x.Name, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            if (url != null)
            {
                return true;
            }
            return false;
        }

        public int Create(TagViewModel model)
        {
            model.MapNames = string.Join(",", model.MapNames.Split(new string[] { Environment.NewLine, ",", "\n" }, StringSplitOptions.RemoveEmptyEntries)
                .Where(x => !string.IsNullOrWhiteSpace(x)).Select(x => x.Trim()));

            var tag = AutoMapperGenericsHelper<TagViewModel, Tag>.FullCopy(model);
            TagRespository.Create(tag);
            TagRespository.SaveChanges();
            return tag.Id;
        }

        public void Update(TagViewModel model)
        {
            model.MapNames = string.Join(",", model.MapNames.Split(new string[] { Environment.NewLine, ",", "\n" }, StringSplitOptions.RemoveEmptyEntries)
                .Where(x => !string.IsNullOrWhiteSpace(x)).Select(x => x.Trim()));

            var oldTag = TagRespository.FindBy(model.Id);
            oldTag.Name = model.Name;
            oldTag.MapNames = model.MapNames;
            oldTag.OrderNumber = model.OrderNumber;
            oldTag.UpdatedDate = DateTime.Now;
            oldTag.UpdatedUserId = model.UpdatedUserId;

            TagRespository.Update(oldTag);
            TagRespository.SaveChanges();
        }

        public void DeleteRange(int[] ids, long userId)
        {
            if (ids.Length <= 0) return;
            var idList = ids.ToList();
            var tags = TagRespository.FindBy(x => idList.Contains(x.Id)).ToList();
            tags.ForEach(x =>
            {
                x.IsDeleted = true;
                TagRespository.Update(x);
            });
            TagRespository.SaveChanges();
        }

        public void UpdateManualArticleTags(long articleId, string mapNames, List<int> tagIds)
        {
            var articleTagIds = GetTagIdsByMapNames(mapNames);
            ManualArticleTagRespository.DeleteBy(x => x.ArticleId == articleId);
            var manualArticleTags = new List<ManualArticleTag>();
            tagIds.ForEach(x =>
            {
                if (!articleTagIds.Contains(x))
                {
                    ManualArticleTagRespository.Create(new ManualArticleTag
                    {
                        ArticleId = articleId,
                        IsIncluded = true,
                        TagId = x
                    });
                }
            });
            articleTagIds.ForEach(x =>
            {
                if (!tagIds.Contains(x))
                {
                    ManualArticleTagRespository.Create(new ManualArticleTag
                    {
                        ArticleId = articleId,
                        IsIncluded = false,
                        TagId = x
                    });
                }
            });
            ManualArticleTagRespository.SaveChanges();
        }

        public void UpdateArticleTags()
        {
            var articleTags = ArticleTagRespository.GetAll();
            //ArticleTagRespository.DeleteBy(x => true);
            //DbContext.DatabaseFacade.ExecuteSqlCommand("TRUNCATE TABLE dbo.ArticleTags");
            ArticleRespository.FindBy(x => !x.IsDeleted).ToList().ForEach(a =>
            {
                var tags = articleTags.Where(x => x.ArticleId == a.Id).Select(x => new ArticleTag
                {
                    ArticleId = a.Id,
                    TagId = x.TagId
                });
                //ArticleTagRespository.CreateRange(tags);
                UpdateManualArticleTags(a.Id, a.Title, tags.Select(x => x.TagId).ToList());
            });
            //ArticleTagRespository.SaveChanges();
        }

        public void UpdateAllArticleTags()
        {
            //var articleTags = ArticleTagRespository.GetAll();
            ArticleTagRespository.DeleteBy(x => true);
            //DbContext.DatabaseFacade.ExecuteSqlCommand("TRUNCATE TABLE dbo.ArticleTags");
            ArticleRespository.FindBy(x => !x.IsDeleted).ToList().ForEach(a =>
            {
                var tagIds = GetTagIdsByMapNames(a.Title);
                var manualTagIds = ManualArticleTagRespository.FindBy(x => x.ArticleId == a.Id);
                tagIds.AddRange(manualTagIds.Where(y => y.IsIncluded && !tagIds.Contains(y.TagId)).Select(x => x.TagId));
                tagIds = tagIds.Where(x => !manualTagIds.Any(y => !y.IsIncluded && x == y.TagId)).ToList();
                // Add No Tag If tagIds is empty
                if (tagIds.Count <= 0)
                {
                    tagIds.Add(100);
                }
                var tags = tagIds.Select(x => new ArticleTag
                {
                    ArticleId = a.Id,
                    TagId = x
                }).ToList();
                ArticleTagRespository.CreateRange(tags);
                UpdateManualArticleTags(a.Id, a.Title, tagIds.Where(x => x != 100).ToList());
            });
            ArticleTagRespository.SaveChanges();
        }

        //private List<Tag> GetManualTagsByMapNames(string mapNames)
        //{
        //    mapNames = CommonHelper.GetWord(mapNames).ToLower();
        //    if (string.IsNullOrWhiteSpace(mapNames)) return new List<Tag>();

        //    var tags = TagRespository.FindBy(x => !x.IsDeleted);
        //    return tags.Where(x => x.MapNames.ToLower().Split(new string[] { Environment.NewLine, ",", "\n" }, StringSplitOptions.RemoveEmptyEntries)
        //        .Any(y => mapNames == CommonHelper.GetWord(y) || mapNames.StartsWith($"{CommonHelper.GetWord(y)} ") ||
        //        mapNames.EndsWith($" {CommonHelper.GetWord(y)}") || mapNames.Contains($" {CommonHelper.GetWord(y)} "))).ToList();

        //}

        //private List<Tag> GetTagsByMapNames(string mapNames)
        //{
        //    mapNames = CommonHelper.GetWord(mapNames).ToLower();
        //    if (string.IsNullOrWhiteSpace(mapNames)) return new List<Tag>();

        //    var tags = TagRespository.FindBy(x => !x.IsDeleted);
        //    return tags.Where(x => x.MapNames.ToLower().Split(new string[] { Environment.NewLine, ",", "\n" }, StringSplitOptions.RemoveEmptyEntries)
        //        .Any(y => mapNames == CommonHelper.GetWord(y) || mapNames.StartsWith($"{CommonHelper.GetWord(y)} ") ||
        //        mapNames.EndsWith($" {CommonHelper.GetWord(y)}") || mapNames.Contains($" {CommonHelper.GetWord(y)} "))).ToList();

        //}
        //public void Delete(int id, long userId, int newTagId)
        //{
        //    var oldTag = TagRespository.FindBy(id);
        //    oldTag.IsDeleted = true;
        //    TagRespository.Update(oldTag);
        //    TagRespository.SaveChanges();

        //    // Update all this tag to new tag
        //    if (newTagId > 0)
        //    {
        //        var articleTags = ArticleTagRespository.FindBy(x => x.TagId == id).ToList();
        //        articleTags.ForEach(x => {
        //            var list = ArticleTagRespository.FindBy(y => y.ArticleId == x.ArticleId).ToList();
        //            if (list == null || list.Count <= 1)
        //            {
        //                x.TagId = newTagId;
        //                ArticleTagRespository.Update(x);
        //            }
        //            else
        //            {
        //                if (newTagId == TagConstants.NO_TAG || list.Any(y => y.TagId == newTagId))
        //                {
        //                    ArticleTagRespository.Delete(x);
        //                }
        //                else
        //                {
        //                    x.TagId = newTagId;
        //                    ArticleTagRespository.Update(x);
        //                }
        //            }

        //        });
        //        ArticleTagRespository.SaveChanges();
        //    }
        //}
    }
}
