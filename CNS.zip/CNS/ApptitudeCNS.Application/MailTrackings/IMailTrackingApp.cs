﻿using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;

namespace ApptitudeCNS.Application.MailTrackings
{
    public interface IMailTrackingApp
    {
        List<MailTrackingViewModel> GetMailTrackingList(MailTrackingFilterViewModel filter);
        long GetCount(MailTrackingFilterViewModel filter);

        //IEnumerable<IdName> GetMailTypes();
        Client GetClientById(long id);
        long GetClientIdByUserId(long userId);

        string GetEmailContent(long id);

        void UpdateClientEmailContent(NewsLetterEmailRequest request);

        string GetSubjectTemplate(long[] ids);
        string GetEmailTemplateBody(EmailTemplateBodyRequest request);

        void SendTest(SendTestRequest request);

        void SendLowestRateToAll(long senderId, string subject, string content);
        void SendToAll(SendToAllRequest request);
        void SendToOne(SendToOneRequest request);

        List<MailSendingViewModel> GetMailSendingList();
        void SendMassEmail(long userId, string subject, string content, long[] clientIds, DateTime scheduleDate);
        void UpdateMailSendingList(List<MailSendingViewModel> list);
    }
}
