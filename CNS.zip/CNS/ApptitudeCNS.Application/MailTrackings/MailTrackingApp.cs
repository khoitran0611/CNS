﻿using ApptitudeCNS.Application.Articles;
using ApptitudeCNS.Application.Request;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Infrastructure.Email.Domain.EmailTemplates;
using ApptitudeCNS.Infrastructure.Email.Services;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using static ApptitudeCNS.Helpers.CommonHelper;

namespace ApptitudeCNS.Application.MailTrackings
{
    public class MailTrackingApp : IMailTrackingApp
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();
        private IDbContext DbContext { get; }
        private IGenericRepository<EmailTracking> MailTrackingRespository { get; }
        private IGenericRepository<UserEmailTracking> UserMailTrackingRespository { get; }
        private IGenericRepository<NewsLetterEmail> NewsLetterEmailRespository { get; }
        private IGenericRepository<User> UserRespository { get; }
        private IGenericRepository<Client> ClientRespository { get; }
        //private IGenericRepository<ClientType> ClientTypeRespository { get; }
        private IGenericRepository<EmailStatus> EmailStatusRespository { get; }
        private IGenericRepository<EmailType> EmailTypeRespository { get; }
        private IGenericRepository<UserHistory> UserHistoryRespository { get; }
        private IGenericRepository<ClientHistory> ClientHistoryRespository { get; }
        private IGenericRepository<PrimaryImage> PrimaryImageRespository { get; }
        private IGenericRepository<ArticleSentHistory> ArticleSentHistoryRespository { get; }
        private IEmailService EmailService { get; }
        private IArticleApp ArticleApp { get; }

        public MailTrackingApp(IDbContext dbContext,
            IGenericRepository<EmailTracking> mailTrackingRespository,
            IGenericRepository<UserEmailTracking> userMailTrackingRespository,
            IGenericRepository<NewsLetterEmail> newsLetterEmailRespository,
            IGenericRepository<User> userRespository,
            IGenericRepository<Client> clientRespository, //IGenericRepository<ClientType> clientTypeRespository,
            IGenericRepository<EmailStatus> emailStatusRespository, IGenericRepository<EmailType> emailTypeRespository,
            IGenericRepository<UserHistory> userHistoryRespository, IGenericRepository<ClientHistory> clientHistoryRespository,
            IEmailService emailService, IArticleApp articleApp,
            IGenericRepository<PrimaryImage> primaryImageRespository,
            IGenericRepository<ArticleSentHistory> articleSentHistoryRespository)
        {
            DbContext = dbContext;
            MailTrackingRespository = mailTrackingRespository;
            UserMailTrackingRespository = userMailTrackingRespository;
            NewsLetterEmailRespository = newsLetterEmailRespository;
            UserRespository = userRespository;
            ClientRespository = clientRespository;
            //ClientTypeRespository = clientTypeRespository;
            EmailStatusRespository = emailStatusRespository;
            EmailTypeRespository = emailTypeRespository;
            UserHistoryRespository = userHistoryRespository;
            ClientHistoryRespository = clientHistoryRespository;
            EmailService = emailService;
            ArticleApp = articleApp;
            PrimaryImageRespository = primaryImageRespository;
            ArticleSentHistoryRespository = articleSentHistoryRespository;
        }

        public List<MailTrackingViewModel> GetMailTrackingList(MailTrackingFilterViewModel filter)//int pageIndex, int pageSize, List<int> types, string searchText, string sortFieldName)
        {
            if (filter.typeIds == null || filter.typeIds.Length == 0) return new List<MailTrackingViewModel>();

            //var typeIds = filter.typeIds.ToList();
            //if (typeIds.Contains(4) && !typeIds.Contains(2))
            //{
            //    typeIds.Add(2);
            //}

            var searchTextCondition = string.Empty;
            if (!string.IsNullOrWhiteSpace(filter.searchText))
            {
                var searchText = filter.searchText.Replace("'", "''").Replace("%", "[%]");
                //searchTextCondition = $@"AND ((ISNULL(B.FirstName, '') + ' ' + ISNULL(B.LastName, '')) LIKE N'%{searchText}%' OR B.SenderEmail LIKE N'%{searchText}%'
                //                OR (ISNULL(C.FirstName, '') + ' ' + ISNULL(C.LastName, '')) LIKE N'%{searchText}%' OR C.Email LIKE N'%{searchText}%'
                //                OR  VET.ViewSubject LIKE N'%{searchText}%' OR VET.ViewContent LIKE N'%{searchText}%')";
                searchTextCondition = $@" AND (VET.ViewSubject LIKE N'%{searchText}%' OR VET.ViewContent LIKE N'%{searchText}%')";
            }
            var clientSearchTextCondition = string.Empty;
            if (!string.IsNullOrWhiteSpace(filter.clientSearchText))
            {
                var clientSearchText = filter.clientSearchText.Replace("'", "''").Replace("%", "[%]");
                //searchTextCondition = $@"AND ((ISNULL(B.FirstName, '') + ' ' + ISNULL(B.LastName, '')) LIKE N'%{searchText}%' OR B.SenderEmail LIKE N'%{searchText}%'
                //                OR (ISNULL(C.FirstName, '') + ' ' + ISNULL(C.LastName, '')) LIKE N'%{searchText}%' OR C.Email LIKE N'%{searchText}%'
                //                OR  VET.ViewSubject LIKE N'%{searchText}%' OR VET.ViewContent LIKE N'%{searchText}%')";
                clientSearchTextCondition = $@" AND (LTRIM(RTRIM((ISNULL(B.FirstName, '') + ' ' + ISNULL(B.LastName, ''))) 
                                + ' (' + ISNULL(B.InternalIdentifier, '') + ')') LIKE N'%{clientSearchText}%' 
                                OR B.SenderEmail LIKE N'%{clientSearchText}%' OR B.Email LIKE N'%{clientSearchText}%'
                                OR  (ISNULL(C.FirstName, '') + ' ' + ISNULL(C.LastName, '')) LIKE N'%{clientSearchText}%' 
                                OR C.Email LIKE N'%{clientSearchText}%')";
            }

            var sortBy = string.IsNullOrWhiteSpace(filter.sortField) || filter.sortField == "SentDate" ? $"SentDate {filter.sortType}, Id {filter.sortType}" : filter.sortBy;

            var sqlQuery = $@"SELECT *
                    FROM (SELECT *, ROW_NUMBER() OVER (ORDER BY {sortBy}) RowId
                    FROM
                    (SELECT ET.Id, ET.ScheduledTime AS SentDate, ET.Subject, 
                            LTRIM(ISNULL(U.FirstName, '') + ' ' + ISNULL(U.LastName, '')) CreatedByName, 
                            LTRIM(ISNULL(B.FirstName, '') + ' ' + ISNULL(B.LastName, '')) BrokerName, 
                            LTRIM(ISNULL(C.FirstName, '') + ' ' + ISNULL(C.LastName, '')) RecipientName, 
                            U.FirstName CreatedByFirstName, U.LastName CreatedByLastName, U.InternalIdentifier AS CreatedByInternalIdentifier, 
	                        B.FirstName BrokerFirstName, B.LastName BrokerLastName, B.InternalIdentifier AS BrokerInternalIdentifier, 
	                        C.FirstName RecipientFirstName, C.LastName RecipientLastName, --C.Email AS RecipientEmail,
                            U.Id CreatedById, B.Id BrokerId, C.Id RecipientId, S.Name StatusName, T.Name TypeName
                        FROM dbo.EmailTrackings(NOLOCK) ET
                        JOIN ViewEmailTrackingList VET ON ET.Subject = VET.ViewSubject
                        JOIN dbo.Users(NOLOCK) U ON U.Id = ET.SenderId
                        JOIN dbo.Clients(NOLOCK) C ON C.Id = ET.ClientId
                        JOIN dbo.Users(NOLOCK) B ON B.Id = C.UserId
                        JOIN dbo.EmailStatuses(NOLOCK) S ON S.Id = ET.Status
                        JOIN dbo.EmailTypes(NOLOCK) T ON T.Id = ET.TypeId
                        WHERE ISNULL(U.IsDeleted, 0) = 0 AND ISNULL(C.IsDeleted, 0) = 0 AND ISNULL(B.IsDeleted, 0) = 0
                            {searchTextCondition}{clientSearchTextCondition}
                            AND ET.TypeId IN({string.Join(",", filter.typeIds)})) TEMP) TEMP
                    WHERE RowId > {(filter.pageIndex - 1) * MailTrackingConstants.PAGE_SIZE} AND RowId <= {filter.pageIndex * MailTrackingConstants.PAGE_SIZE}";
            //Skip((filter.pageIndex - 1) * MailTrackingConstants.PAGE_SIZE).Take(MailTrackingConstants.PAGE_SIZE)
            var result = DbContext.DatabaseFacade.SqlQuery<MailTrackingViewModel>(sqlQuery).ToList();
            return result;
            //var result = (from m in MailTrackingRespository.EntitiesNoTracking
            //              join u in UserRespository.EntitiesNoTracking on m.SenderId equals u.Id
            //              join c in ClientRespository.EntitiesNoTracking on m.ClientId equals c.Id
            //              join b in UserRespository.EntitiesNoTracking on c.UserId equals b.Id
            //              join ms in EmailStatusRespository.EntitiesNoTracking on m.Status equals ms.Id
            //              join mt in EmailTypeRespository.EntitiesNoTracking on m.TypeId equals mt.Id
            //              //join t in types on m.TypeId equals t
            //              where !u.IsDeleted && !c.IsDeleted && typeIds.Contains(m.TypeId) &&
            //                    (filter.searchText == string.Empty ||
            //                    m.Subject.Contains(filter.searchText) || m.Content.Contains(filter.searchText) ||
            //                    (u.FirstName + " " + u.LastName).Contains(filter.searchText) || u.Email.Contains(filter.searchText) ||
            //                    (c.FirstName + " " + c.LastName).Contains(filter.searchText) || c.Email.Contains(filter.searchText))
            //              //orderby m.ScheduledTime descending
            //              select new
            //              {
            //                  MailTracking = m,
            //                  User = u,
            //                  Client = c,
            //                  Broker = b,
            //                  Status = ms,
            //                  Type = mt
            //              });

            ////Id = x.MailTracking.Id,
            ////    SentDate = x.MailTracking.ScheduledTime,
            ////    Subject = x.MailTracking.Subject,
            ////    //Content = x.MailTracking.Content,
            ////    CreatedByName = CommonHelper.GetFullname(x.User.FirstName, x.User.LastName, x.User.InternalIdentifier),// $"{x.User.FirstName} {x.User.LastName}",
            ////    CreatedById = x.User.Id,
            ////    BrokerName = CommonHelper.GetFullname(x.Broker.FirstName, x.Broker.LastName, x.Broker.InternalIdentifier),//$"{x.Broker.FirstName} {x.Broker.LastName}",
            ////    BrokerId = x.Broker.Id,
            ////    RecipientName = $"{x.Client.FirstName} {x.Client.LastName}",
            ////    RecipientId = x.Client.Id,
            ////    TypeName = x.Type.Name,
            ////    StatusName = x.Status.Name


            ////string sqlQuery = $@"SELECT MT.Id, 
            ////                    FROM dbo.EmailTrackings (NOLOCK) MT WHERE ChildUserID = ";
            ////var result = DbContext.DatabaseFacade.SqlQuery<MailTrackingViewModel>(sqlQuery).ToList();

            ////result = result.Join(GetMailTypes(), r => r.MailTracking.TypeId, mt => mt.Id, (r, mt) => new
            ////{
            ////    r.MailTracking,
            ////    r.User,
            ////    r.Client,
            ////    r.Status,
            ////    Type = mt
            ////});
            ////var tempp = result2.ToList();
            ////var result = (from m in result2
            ////              join mt in CommonHelper.GetListForEnum<EnumEmailType>() on m.MailTracking.TypeId equals mt.Id
            ////              join ms in CommonHelper.GetListForEnum<EnumEmailStatusType>() on m.MailTracking.Status equals ms.Id
            ////              select new
            ////              {
            ////                  m.MailTracking,
            ////                  m.User,
            ////                  m.Client,
            ////                  m.Broker,
            ////                  Status = ms,
            ////                  Type = mt
            ////              });

            //switch (filter.sortBy)
            //{
            //    case "Subject asc":
            //        result = result.OrderBy(x => x.MailTracking.Subject);
            //        break;
            //    case "Subject desc":
            //        result = result.OrderByDescending(x => x.MailTracking.Subject);
            //        break;
            //    case "CreatedByName asc":
            //        result = result.OrderBy(x => (x.User.FirstName + " " + x.User.LastName));
            //        break;
            //    case "CreatedByName desc":
            //        result = result.OrderByDescending(x => (x.User.FirstName + " " + x.User.LastName));
            //        break;
            //    case "BrokerName asc":
            //        result = result.OrderBy(x => (x.Broker.FirstName + " " + x.Broker.LastName));
            //        break;
            //    case "BrokerName desc":
            //        result = result.OrderByDescending(x => (x.Broker.FirstName + " " + x.Broker.LastName));
            //        break;
            //    case "RecipientName asc":
            //        result = result.OrderBy(x => (x.Client.FirstName + " " + x.Client.LastName));
            //        break;
            //    case "RecipientName desc":
            //        result = result.OrderByDescending(x => (x.Client.FirstName + " " + x.Client.LastName));
            //        break;
            //    case "StatusName asc":
            //        result = result.OrderBy(x => x.MailTracking.Status);
            //        break;
            //    case "StatusName desc":
            //        result = result.OrderByDescending(x => x.MailTracking.Status);
            //        break;
            //    case "TypeName asc":
            //        result = result.OrderBy(x => x.Type.Name);
            //        break;
            //    case "TypeName desc":
            //        result = result.OrderByDescending(x => x.Type.Name);
            //        break;
            //    case "SentDate asc":
            //        result = result.OrderBy(x => x.MailTracking.ScheduledTime).ThenBy(x => x.MailTracking.Id);
            //        break;
            //    default:
            //        result = result.OrderByDescending(x => x.MailTracking.ScheduledTime).ThenByDescending(x => x.MailTracking.Id);
            //        break;
            //}
            ////select new MailTrackingsViewModel(a, u)).ToList();
            ////select FullCopy()).ToList();
            ////select FullCopy(a, u)).ToList();
            ////return result;
            ////var temp = result.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
            ////var temp2 = temp.Select(x => new MailTrackingViewModel
            ////{
            ////    Id = x.MailTracking.Id,
            ////    SentDate = x.MailTracking.ScheduledTime,
            ////    Subject = x.MailTracking.Subject,
            ////    RecipientName = $"{x.Client.FirstName} {x.Client.LastName}",
            ////    SenderName = $"{x.User.FirstName} {x.User.LastName}",
            ////    SenderId = x.User.Id,
            ////    RecipientId = x.Client.Id,
            ////    TypeName = x.Type.Name,
            ////    StatusName = x.Status.Name
            ////}).ToList();
            //return result.Skip((filter.pageIndex - 1) * MailTrackingConstants.PAGE_SIZE).Take(MailTrackingConstants.PAGE_SIZE).AsEnumerable().Select(x => new MailTrackingViewModel
            //{
            //    Id = x.MailTracking.Id,
            //    SentDate = x.MailTracking.ScheduledTime,
            //    Subject = x.MailTracking.Subject,
            //    //Content = x.MailTracking.Content,
            //    CreatedByName = CommonHelper.GetFullname(x.User.FirstName, x.User.LastName, x.User.InternalIdentifier),// $"{x.User.FirstName} {x.User.LastName}",
            //    CreatedById = x.User.Id,
            //    BrokerName = CommonHelper.GetFullname(x.Broker.FirstName, x.Broker.LastName, x.Broker.InternalIdentifier),//$"{x.Broker.FirstName} {x.Broker.LastName}",
            //    BrokerId = x.Broker.Id,
            //    RecipientName = $"{x.Client.FirstName} {x.Client.LastName}",
            //    RecipientId = x.Client.Id,
            //    TypeName = x.Type.Name,
            //    StatusName = x.Status.Name
            //}).ToList();
        }

        public long GetCount(MailTrackingFilterViewModel filter)
        {
            if (filter.typeIds == null || filter.typeIds.Length == 0) return 0;

            //if (string.IsNullOrWhiteSpace(filter.searchText))
            //{
            //    filter.searchText = string.Empty;
            //}
            //else
            //{
            //    filter.searchText = filter.searchText.Trim();
            //}
            var searchTextCondition = string.Empty;
            if (!string.IsNullOrWhiteSpace(filter.searchText))
            {
                var searchText = filter.searchText.Replace("'", "''").Replace("%", "[%]");
                //searchTextCondition = $@"AND ((ISNULL(B.FirstName, '') + ' ' + ISNULL(B.LastName, '')) LIKE N'%{searchText}%' OR B.SenderEmail LIKE N'%{searchText}%'
                //                OR (ISNULL(C.FirstName, '') + ' ' + ISNULL(C.LastName, '')) LIKE N'%{searchText}%' OR C.Email LIKE N'%{searchText}%')";
                //searchTextEmailCondition = $@" AND (VET.ViewSubject LIKE N'%{searchText}%' OR VET.ViewContent LIKE N'%{searchText}%')";
                //searchTextCondition = $@"AND ((ISNULL(B.FirstName, '') + ' ' + ISNULL(B.LastName, '')) LIKE N'%{searchText}%' OR B.SenderEmail LIKE N'%{searchText}%'
                //                OR (ISNULL(C.FirstName, '') + ' ' + ISNULL(C.LastName, '')) LIKE N'%{searchText}%' OR C.Email LIKE N'%{searchText}%'
                //                OR  VET.ViewSubject LIKE N'%{searchText}%' OR VET.ViewContent LIKE N'%{searchText}%')";
                searchTextCondition = $@" AND (VET.ViewSubject LIKE N'%{searchText}%' OR VET.ViewContent LIKE N'%{searchText}%')";
            }
            var clientSearchTextCondition = string.Empty;
            if (!string.IsNullOrWhiteSpace(filter.clientSearchText))
            {
                var clientSearchText = filter.clientSearchText.Replace("'", "''").Replace("%", "[%]");
                //searchTextCondition = $@"AND ((ISNULL(B.FirstName, '') + ' ' + ISNULL(B.LastName, '')) LIKE N'%{searchText}%' OR B.SenderEmail LIKE N'%{searchText}%'
                //                OR (ISNULL(C.FirstName, '') + ' ' + ISNULL(C.LastName, '')) LIKE N'%{searchText}%' OR C.Email LIKE N'%{searchText}%'
                //                OR  VET.ViewSubject LIKE N'%{searchText}%' OR VET.ViewContent LIKE N'%{searchText}%')";
                clientSearchTextCondition = $@" AND (LTRIM(RTRIM((ISNULL(B.FirstName, '') + ' ' + ISNULL(B.LastName, ''))) 
                                + ' (' + ISNULL(B.InternalIdentifier, '') + ')') LIKE N'%{clientSearchText}%' 
                                OR B.SenderEmail LIKE N'%{clientSearchText}%' OR B.Email LIKE N'%{clientSearchText}%'
                                OR  (ISNULL(C.FirstName, '') + ' ' + ISNULL(C.LastName, '')) LIKE N'%{clientSearchText}%' 
                                OR C.Email LIKE N'%{clientSearchText}%')";
            }

            //var typeIds = filter.typeIds.ToList();
            var sqlQuery = $@"SELECT COUNT(1) FROM (SELECT ET.Id
                        FROM dbo.EmailTrackings(NOLOCK) ET
                        JOIN dbo.Clients(NOLOCK) C ON C.Id = ET.ClientId
                        JOIN dbo.Users(NOLOCK) B ON B.Id = C.UserId
                        WHERE ISNULL(C.IsDeleted, 0) = 0 AND ISNULL(B.IsDeleted, 0) = 0
                            {clientSearchTextCondition}
                            AND ET.TypeId IN({string.Join(",", filter.typeIds)})
                        INTERSECT SELECT ET.Id
                        FROM dbo.EmailTrackings(NOLOCK) ET
                        JOIN ViewEmailTrackingList VET ON ET.Subject = VET.ViewSubject
                        WHERE ET.TypeId IN({string.Join(",", filter.typeIds)}) 
                            {searchTextCondition}
                            ) as Temp";
            //Skip((filter.pageIndex - 1) * MailTrackingConstants.PAGE_SIZE).Take(MailTrackingConstants.PAGE_SIZE)
            var result = DbContext.DatabaseFacade.SqlQuery<int>(sqlQuery).ToList();//.SqlQuery<MailTrackingViewModel>(sqlQuery).ToList();
            return result.First();
            //return (from m in MailTrackingRespository.EntitiesNoTracking
            //        join u in UserRespository.EntitiesNoTracking on m.SenderId equals u.Id
            //        join c in ClientRespository.EntitiesNoTracking on m.ClientId equals c.Id
            //        //join t in types on m.TypeId equals t
            //        where !u.IsDeleted && !c.IsDeleted && typeIds.Contains(m.TypeId) &&
            //              (filter.searchText == string.Empty ||
            //              m.Subject.Contains(filter.searchText) || m.Content.Contains(filter.searchText) ||
            //              (u.FirstName + " " + u.LastName).Contains(filter.searchText) || u.Email.Contains(filter.searchText) ||
            //              (c.FirstName + " " + c.LastName).Contains(filter.searchText) || c.Email.Contains(filter.searchText))
            //        select 1).LongCount();
        }

        public string GetEmailContent(long id)
        {
            var result = MailTrackingRespository.FindBy(id)?.Content;
            //if (!string.IsNullOrWhiteSpace(result))
            //{
            //    result = result.Replace("{MailId}", Encryption.Base64EncodeUrl(id.ToString()));
            //}
            return result;
        }

        public void UpdateClientEmailContent(NewsLetterEmailRequest request)
        {
            var mailTrackings = MailTrackingRespository.Entities.Where(x => x.NewLetterEmailId == request.Id).ToList();
            var articleIds = request.ArticleIds.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(x => CommonHelper.GetLong(x)).ToArray();
            var emailTemplateBodyRequest = new EmailTemplateBodyRequest
            {
                ArticleIds = articleIds,
                Url = request.Url,
                IsSelectedCompanyImage = request.IsSelectedCompanyImage,
                PrimaryImageName = request.PrimaryImageName
            };
            var content = string.Empty;
            foreach (var item in mailTrackings)
            {
                emailTemplateBodyRequest.ClientId = item.ClientId;
                emailTemplateBodyRequest.Subject = item.Subject;
                //item.Subject = GetSubjectTemplate(articleIds);
                if (string.IsNullOrWhiteSpace(content))
                {
                    item.Content = content = GetEmailTemplateBody(emailTemplateBodyRequest);
                }
                else
                {
                    item.Content = content;
                }
                MailTrackingRespository.Update(item);
            }
            MailTrackingRespository.SaveChanges();
        }
        //public IEnumerable<IdName> GetMailTypes()
        //{
        //    return Enum.GetValues(typeof(EnumEmailType)).Cast<EnumEmailType>().Select(x => new IdName { Id = (int)x, Name = x.ToString() }).ToList();
        //    //return EmailTypeRespository.GetAll().ToList();//.Entities.ToList();
        //}

        //public IEnumerable<IdName> GetMailStatuses()
        //{
        //    return Enum.GetValues(typeof(EnumEmailStatusType)).Cast<EnumEmailStatusType>().Select(x => new IdName { Id = (int)x, Name = x.ToString() }).ToList();
        //    //return EmailTypeRespository.GetAll().ToList();//.Entities.ToList();
        //}

        public Client GetClientById(long id)
        {
            return ClientRespository.FindBy(id);
        }

        public long GetClientIdByUserId(long userId)
        {
            var result = ClientRespository.EntitiesNoTracking.OrderByDescending(x => x.EmailSubscribe).FirstOrDefault(x => x.UserId == userId && !x.IsDeleted) ?? new Client();
            return result.Id;
        }

        public string GetSubjectTemplate(long[] ids)
        {
            var item = ArticleApp.FindBy(ids[0]);
            return item?.Title;
        }

        public string GetEmailTemplateBody(EmailTemplateBodyRequest request)
        {
            if (request.ArticleIds == null || request.ArticleIds.Length <= 1) return string.Empty;

            var client = ClientRespository.FindBy(request.ClientId);
            var user = UserRespository.FindBy(request.UserId > 0 ? request.UserId : client != null && client.UserId > 0 ? client.UserId : 0);

            if (string.IsNullOrWhiteSpace(user?.Logo))
            {
                return string.Empty;
            }

            var articleIds = request.ArticleIds.ToList();
            articleIds.RemoveAt(articleIds.Count - 1);

            var articles = ArticleApp.FindBy(articleIds.ToArray());
            var mailArticles = articles.Select(x => AutoMapperGenericsHelper<ArticleViewModel, MailArticleViewModel>.FullCopy(x)).ToList();
            var data = new MailArticlesViewModel(mailArticles)
            {
                Url = request.Url,
                IsPreSent = request.IsPreSent,
                NewsLetterEmailId = request.NewsLetterEmailId,
                Subject = request.Subject,
                //Salutation = client.Salutation,
                ClientId = client == null ? 0 : client.Id,
                //BrokerMessage = string.IsNullOrWhiteSpace(request.brokerMessage) ? 
                //    user.BrokerMessage?.Replace("\n", "<br>") : request.brokerMessage.Replace("\n", "<br>"),
                //PrimaryColor = user.PrimaryColor ?? "blue",
                //SecondaryColor = user.SecondaryColor ?? "goldenrod",
                //Logo = user.Logo,
                //Address = user.Address,
                //Company = user.Company,
                //ABN = user.ABN
            };
            data = AutoMapperGenericsHelper<User, MailArticlesViewModel>.FullCopy(user, data);
            data.ArticleImage = GetPrimaryImage(request, user.CompanyImage);
            data.PrimaryColor = data.PrimaryColor ?? CNSConstant.DEFAULT_BROKER_COLOR;
            data.SecondaryColor = data.SecondaryColor ?? CNSConstant.DEFAULT_BROKER_COLOR2;
            data.BrokerMessage = !request.isUsedBrokerMessage ?
                    user.BrokerMessage?.Replace("\n", "<br>") : request.brokerMessage.Replace("\n", "<br>");
            var emailTemplateName = GetArticleEmailTemplateName(mailArticles.Count);
            var result = EmailService.GetEmailHtml(data, emailTemplateName);
            return result;
        }

        public void SendTest(SendTestRequest request)
        {
            //var body = EmailService.GetEmailHtml<MailArticleViewModel>();
            //var client = ClientRespository.FindBy(request.ClientId);
            request.Content = GetEmailTemplateBody(AutoMapperGenericsHelper<SendTestRequest, EmailTemplateBodyRequest>.FullCopy(request));
            request.Subject = GetSubjectTemplate(request.ArticleIds);
            var item = AutoMapperGenericsHelper<SendTestRequest, EmailTracking>.FullCopy(request);

            MailTrackingRespository.Create(item);
            MailTrackingRespository.SaveChanges();
        }

        public void SendLowestRateToAll(long senderId, string subject, string content)
        {
            var clients = (from u in UserRespository.Entities
                           join c in ClientRespository.Entities on u.Id equals c.UserId
                           //join ct in ClientTypeRespository.Entities on c.Id equals ct.ClientId
                           where !u.IsDeleted && !c.IsDeleted && u.IsActive && u.UserTypeId == (int)EnumUserType.Broker
                               && u.EmailSubscribe == true
                               && c.EmailSubscribe == 1
                           select c).ToList();

            if (clients.Count > 0)
            {
                UserHistoryRespository.Create(new UserHistory
                {
                    Content = subject,
                    TypeId = (int)EnumHistoryType.Email,
                    IsSystemAutogen = true,
                    CreatedDate = DateTime.Now,
                    UserId = senderId
                });

                UserHistoryRespository.SaveChanges();
            }

            IList<EmailTracking> emailTrackings = new List<EmailTracking>();
            clients.ForEach(n => emailTrackings.Add(new EmailTracking
            {
                SenderId = senderId,
                ClientId = n.Id,
                Subject = subject,
                Content = content,
                ScheduledTime = DateTime.Now,
                Status = 1,
                TypeId = 3
            }));

            MailTrackingRespository.CreateRange(emailTrackings);
            MailTrackingRespository.SaveChanges();
        }

        public void SendToAll(SendToAllRequest request)
        {
            if (request.ArticleIds == null || request.ArticleIds.Length <= 1) return;

            var userArticles = new Dictionary<long, MailTemplateViewModel>();

            var isCreatedHistory = !SendUserMails(request, userArticles);
            userArticles = new Dictionary<long, MailTemplateViewModel>();
            var newLetterEmails = SendClientUserMails(request, userArticles, isCreatedHistory);
            var articleIds = string.Join(",", request.ArticleIds);
            var articleIdList = request.ArticleIds.ToList();
            if (!userArticles.Any(x => string.Join(",", x.Value.ArticleIds) != articleIds))
            {
                articleIdList.RemoveAt(articleIdList.Count - 1);
            }
            ArticleApp.UpdateStatusArticles(articleIdList, EnumArticleStatusType.Reviewing);
            SendClientMails(request, userArticles, newLetterEmails);

            ArticleApp.UpdateLastSentArticles(request);

            var lastArticleId = request.ArticleIds[request.ArticleIds.Length - 1];
            var now = DateTime.Now;
            var recipientTypeIds = request.UserTypeIds == null ? request.ClientTypeIds.Select(x => x + 1000) :
                request.ClientTypeIds == null ? request.UserTypeIds : request.UserTypeIds.Union(request.ClientTypeIds.Select(x => x + 1000));
            var articleSentHistories = request.ArticleIds.Where(x => x != lastArticleId).SelectMany(x => recipientTypeIds.Select(y =>
            new ArticleSentHistory
            {
                ArticleId = x,
                CreatedDate = now,
                CreatedUserId = request.SenderId,
                IsDeleted = false,
                RecipientTypeId = y
            }));
            ArticleSentHistoryRespository.CreateRange(articleSentHistories);
            ArticleSentHistoryRespository.SaveChanges();
        }

        public void SendToOne(SendToOneRequest request)
        {
            if (request.SingleBrokerId <= 0 && request.SingleClientId <= 0 && request.AllClientsOfSingularBrokerId <= 0) return;

            var userArticles = new Dictionary<long, MailTemplateViewModel>();

            var isCreatedHistory = !SendUserMails(request, userArticles);
            SendClientMails(request, userArticles, isCreatedHistory);
        }

        public void SendMassEmail(long userId, string subject, string content, long[] clientIds, DateTime scheduleDate)
        {
            var mailTrackingList = clientIds.Select(c => new EmailTracking()
            {
                ClientId = c,
                ScheduledTime = scheduleDate,
                SenderId = userId,
                TypeId = (int)EnumEmailType.BrokerMessage,
                Status = (int)EnumEmailStatusType.Unsent,
                Content = content,
                Subject = subject
            })
            .ToList();

            MailTrackingRespository.CreateRange(mailTrackingList);
            MailTrackingRespository.SaveChanges();

            if (mailTrackingList.Count > 0)
            {
                //Log user history
                UserHistoryRespository.Create(new UserHistory
                {
                    Content = subject,
                    TypeId = (int)EnumHistoryType.Email,
                    IsSystemAutogen = true,
                    CreatedDate = DateTime.Now,
                    UserId = userId
                });
                UserHistoryRespository.SaveChanges();

                //Update last send mass email
                var user = UserRespository.FindBy(userId);
                if (user != null)
                {
                    user.LastSendMassEmail = DateTime.Now;
                    UserRespository.Update(user);
                    UserRespository.SaveChanges();
                }
            }
        }

        public List<MailSendingViewModel> GetMailSendingList()
        {
            var result = (from m in MailTrackingRespository.EntitiesNoTracking
                          join c in ClientRespository.EntitiesNoTracking on m.ClientId equals c.Id
                          join b in UserRespository.EntitiesNoTracking on c.UserId equals b.Id
                          where !c.IsDeleted && !b.IsDeleted && b.IsActive && m.Status == (int)EnumEmailStatusType.Unsent && m.ScheduledTime <= DateTime.Now
                          select new
                          {
                              MailTracking = m,
                              Client = c,
                              Broker = b
                          }).Take(500).AsEnumerable();


            // Update Fail for Unsent when this client is deleted or belongs to inactive/deleted broker
            var mailList = (from m in MailTrackingRespository.EntitiesNoTracking
                            join c in ClientRespository.EntitiesNoTracking on m.ClientId equals c.Id
                            join b in UserRespository.EntitiesNoTracking on c.UserId equals b.Id
                            where (c.IsDeleted || b.IsDeleted || !b.IsActive) && m.Status == (int)EnumEmailStatusType.Unsent && m.ScheduledTime <= DateTime.Now
                            select m).ToList();

            if (mailList.Count > 0)
            {
                foreach (var mailItem in mailList)
                {
                    mailItem.Status = (int)EnumEmailStatusType.Failed;
                    mailItem.ErrorNote = "This client is deleted or belongs to inactive/deleted broker";
                    MailTrackingRespository.Update(mailItem);
                }
                MailTrackingRespository.SaveChanges();
            }

            return result.Select(x => new MailSendingViewModel
            {
                Id = x.MailTracking.Id,
                Subject = x.MailTracking.Subject,
                Content = x.MailTracking.Content,
                BrokerName = $"{x.Broker.FirstName} {x.Broker.LastName}".Trim(),
                BrokerEmail = x.Broker.SenderEmail,
                ClientId = x.Client.Id,
                RecipientName = $"{x.Client.FirstName} {x.Client.LastName}".Trim(),
                RecipientEmail = x.Client.Email,
                TypeId = (EnumEmailType)x.MailTracking.TypeId,
                Status = (EnumEmailStatusType)x.MailTracking.Status,
                BrokerRefNo = GetLong(x.Client.BrokerRefNo),
                BrokerUserNo = GetLong(x.Client.BrokerUserNo)
            }).ToList();
        }

        public void UpdateMailSendingList(List<MailSendingViewModel> list)
        {
            var retry = 3;
            do
            {
                List<long> articleIds = new List<long>();
                foreach (var item in list)
                {
                    var mailTracking = MailTrackingRespository.FindBy(item.Id);
                    mailTracking.Status = (int)item.Status;
                    mailTracking.ErrorNote = item.ErrorNote;
                    MailTrackingRespository.Update(mailTracking);

                    ClientHistoryRespository.Create(new ClientHistory
                    {
                        Content = item.Subject,
                        ClientId = mailTracking.ClientId,
                        MailTrackingId = mailTracking.Id,
                        TypeId = (int)EnumHistoryType.Email,
                        IsSystemAutogen = true,
                        CreatedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now,
                        CreatedUserId = ConfigManager.SystemUserId
                    });

                    if (mailTracking.NewLetterEmailId > 0)
                    {
                        var newsLetterEmailItem = NewsLetterEmailRespository.FindBy(mailTracking.NewLetterEmailId.Value);
                        newsLetterEmailItem.IsChangable = false;
                        NewsLetterEmailRespository.Update(newsLetterEmailItem);
                        NewsLetterEmailRespository.SaveChanges();

                        var articleIdList = newsLetterEmailItem?.ArticleIds.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                            .Select(x => CommonHelper.GetLong(x)).ToList();
                        if (articleIdList.Count > 1)
                        {
                            articleIdList.RemoveAt(articleIdList.Count - 1);
                            articleIds.AddRange(articleIdList);
                        }
                    }
                }
                try
                {
                    if (articleIds.Count > 0)
                    {
                        ArticleApp.UpdateStatusArticles(articleIds.Distinct().ToList(), EnumArticleStatusType.Sent);
                    }
                    MailTrackingRespository.SaveChanges();
                    ClientHistoryRespository.SaveChanges();
                    retry = 0;
                }
                catch (Exception ex)
                {
                    retry--;
                    logger.Error($"UpdateMailSendingList {string.Join(" ", list.Select(x => x.Id))} {ex.ToString()}");
                }
            } while (retry > 0);
        }

        #region Private method
        private string GetPrimaryImage(EmailTemplateBodyRequest request, string userCompanyImage)
        {
            if (request.IsSelectedCompanyImage && !string.IsNullOrWhiteSpace(userCompanyImage))
                return $"{ UserConstants.UPLOADED_COMPANY_IMAGE_PHOTO_FOLDER.Substring(1)}/{userCompanyImage}";

            if (!string.IsNullOrWhiteSpace(request.PrimaryImageName))
            {
                return $"{ ArticleConstants.UPLOADED_PRIMARY_IMAGE_FOLDER.Substring(1) }/{request.PrimaryImageName}";
            }

            var item = PrimaryImageRespository.EntitiesNoTracking.Where(x => !x.IsDeleted).OrderByDescending(x => x.CreatedDate).FirstOrDefault() ?? new PrimaryImage();
            return $"{ ArticleConstants.UPLOADED_PRIMARY_IMAGE_FOLDER.Substring(1) }/{item.Name}";
        }
        private bool SendUserMails(SendToAllRequest request, Dictionary<long, MailTemplateViewModel> data, bool isCreatedHistory = true)
        {
            var userTypeIds = request.UserTypeIds?.ToList() ?? new List<int>();
            //var clientTypeIds = request.ClientTypeIds?.ToList() ?? new List<int>();

            var users = (from u in UserRespository.EntitiesNoTracking
                         where !u.IsDeleted && u.IsActive && u.EmailSubscribe == true &&
                             u.Logo != null && u.Logo != "" && u.SendSampleEmailType == null &&
                             userTypeIds.Contains(u.UserTypeId)
                         //(request.RecipientTypeIds != null && request.RecipientTypeIds.Any(x => x == ct.TypeId))
                         select u).ToList();

            if (users.Count == 0) return false;

            GetNewLetterEmails(request, users, data);

            //request.Subject = GetSubjectTemplate(request.ArticleIds);
            var userMailTrackingList = users.Select(x => FullCopy(request, x, data)).ToList();
            return CreateUserMailTrackings(request, userMailTrackingList);
        }

        private List<NewsLetterEmail> SendClientUserMails(SendToAllRequest request, Dictionary<long, MailTemplateViewModel> data, bool isCreatedHistory)
        {
            var clientTypeIds = request.ClientTypeIds?.ToList() ?? new List<int>();

            var users = (from u in UserRespository.EntitiesNoTracking
                         join c in ClientRespository.EntitiesNoTracking on u.Id equals c.UserId
                         //join ct in ClientTypeRespository.Entities on c.Id equals ct.ClientId
                         where !u.IsDeleted && !c.IsDeleted && u.IsActive && u.EmailSubscribe == true &&
                             u.Logo != null && u.Logo != "" &&
                             (clientTypeIds.Contains(u.UserTypeId)) &&
                             c.EmailSubscribe == 1 // && recipientTypeIds.Contains(ct.TypeId)
                         //(request.RecipientTypeIds != null && request.RecipientTypeIds.Any(x => x == ct.TypeId))
                         select u).Distinct().ToList();

            if (users.Count == 0) return new List<NewsLetterEmail>();

            var result = GetNewLetterEmails(request, users, data);
            SaveNewLetterEmails(result);
            //request.Subject = GetSubjectTemplate(request.ArticleIds);
            var userMailTrackingList = users.Select(x => FullCopy(request, x, data, true, result.FirstOrDefault(y => y.UserId == x.Id).Id)).ToList();

            CreateUserMailTrackings(request, userMailTrackingList, isCreatedHistory, false);
            return result;
        }

        private bool CreateUserMailTrackings(SendToAllRequest request, List<UserEmailTracking> userMailTrackingList, bool isCreatedHistory = true, bool isUpdatedLastSent = true)
        {
            if (userMailTrackingList.Count > 0)
            {
                if (isCreatedHistory)
                {
                    UserHistoryRespository.Create(new UserHistory
                    {
                        Content = $"Send NewsLetter: {request.Subject}",
                        TypeId = (int)EnumHistoryType.Email,
                        IsSystemAutogen = true,
                        CreatedDate = DateTime.Now,
                        UserId = request.SenderId,
                        CreatedUserId = request.SenderId
                    });
                    UserHistoryRespository.SaveChanges();
                }

                UserMailTrackingRespository.CreateRange(userMailTrackingList);
                UserMailTrackingRespository.SaveChanges();
                //var articleIds = request.ArticleIds.ToList();
                //articleIds.RemoveAt(articleIds.Count - 1);
                //if (isUpdatedLastSent)
                //{
                //    ArticleApp.UpdateLastSentArticles(request);
                //}
                return true;
            }
            return false;
        }

        private List<NewsLetterEmail> GetNewLetterEmails(SendToAllRequest request, List<User> users, Dictionary<long, MailTemplateViewModel> data)
        {
            //var result = new Dictionary<long, List<long>>();
            var result = new List<NewsLetterEmail>();
            foreach (var user in users)
            {
                if (data.ContainsKey(user.Id))
                {
                    result.Add(new NewsLetterEmail
                    {
                        UserId = user.Id,
                        CreatedDate = DateTime.Now,
                        CreatedUserId = request.SenderId,
                        IsChangable = true,
                        ArticleIds = string.Join(",", data[user.Id].ArticleIds),
                        IsSelectedCompanyImage = request.IsSelectedCompanyImage,
                        PrimaryImageName = request.PrimaryImageName,
                    });
                    continue;
                }

                var userArticles = ArticleApp.GetIds(request.ArticleIds, request.SenderId);
                var articleIds = request.ArticleIds.ToList();
                var index = 0;
                for (int i = 0; i < request.ArticleIds.Length - 1; i++)
                {
                    if (userArticles.Contains(articleIds[i]))
                    {
                        if (index != i)
                        {
                            index++;
                        }
                        else
                        {
                            var temp = articleIds[index];
                            articleIds[index] = articleIds[i];
                            articleIds[i] = temp;
                            index++;
                        }
                    }
                }
                data.Add(user.Id, new MailTemplateViewModel { ArticleIds = articleIds.ToArray() });
                result.Add(new NewsLetterEmail
                {
                    UserId = user.Id,
                    CreatedDate = DateTime.Now,
                    CreatedUserId = request.SenderId,
                    IsChangable = true,
                    ArticleIds = string.Join(",", data[user.Id].ArticleIds),
                    IsSelectedCompanyImage = request.IsSelectedCompanyImage,
                    PrimaryImageName = request.PrimaryImageName,
                });
            }
            return result;
        }

        private void SaveNewLetterEmails(List<NewsLetterEmail> newLetterEmails)
        {
            if (newLetterEmails.Count > 0)
            {
                NewsLetterEmailRespository.CreateRange(newLetterEmails);
                NewsLetterEmailRespository.SaveChanges();
            }
        }

        private void SendClientMails(SendToAllRequest request, Dictionary<long, MailTemplateViewModel> data, List<NewsLetterEmail> newLetterEmails, bool isCreatedHistory = false)
        {
            var clientTypeIds = request.ClientTypeIds?.ToList() ?? new List<int>();

            var mailTrackings = (from u in UserRespository.EntitiesNoTracking
                                 join c in ClientRespository.EntitiesNoTracking on u.Id equals c.UserId
                                 //join ct in ClientTypeRespository.Entities on c.Id equals ct.ClientId
                                 where !u.IsDeleted && !c.IsDeleted && u.IsActive && u.EmailSubscribe == true &&
                                     u.Logo != null && u.Logo != "" &&
                                     (clientTypeIds.Contains(u.UserTypeId)) &&
                                     c.EmailSubscribe == 1 // && recipientTypeIds.Contains(ct.TypeId)
                                 //(request.RecipientTypeIds != null && request.RecipientTypeIds.Any(x => x == ct.TypeId))
                                 select c).ToList();

            if (mailTrackings.Count == 0) return;

            //request.Subject = GetSubjectTemplate(request.ArticleIds);
            var mailTrackingList = mailTrackings.Select(x => FullCopy(request, x, data, newLetterEmails)).ToList();
            if (mailTrackingList.Count > 0)
            {
                if (isCreatedHistory)
                {
                    UserHistoryRespository.Create(new UserHistory
                    {
                        Content = request.Subject,
                        TypeId = (int)EnumHistoryType.Email,
                        IsSystemAutogen = true,
                        CreatedDate = DateTime.Now,
                        UserId = request.SenderId,
                        CreatedUserId = request.SenderId
                    });
                    UserHistoryRespository.SaveChanges();
                }

                MailTrackingRespository.CreateRange(mailTrackingList);
                MailTrackingRespository.SaveChanges();
                //var articleIds = request.ArticleIds.ToList();
                //articleIds.RemoveAt(articleIds.Count - 1);
                //ArticleApp.UpdateLastSentArticles(request);
            }

        }

        private bool SendUserMails(SendToOneRequest request, Dictionary<long, MailTemplateViewModel> data, bool isCreatedHistory = true)
        {
            var users = (from u in UserRespository.EntitiesNoTracking
                         where !u.IsDeleted && u.IsActive && u.EmailSubscribe == true &&
                             u.Logo != null && u.Logo != "" &&
                             request.SingleBrokerId == u.Id
                         //(request.RecipientTypeIds != null && request.RecipientTypeIds.Any(x => x == ct.TypeId))
                         select u).ToList();

            if (users.Count == 0) return false;

            GetNewLetterEmails(request, users, data);

            //request.Subject = GetSubjectTemplate(request.ArticleIds);
            var userMailTrackingList = users.Select(x => FullCopy(request, x, data)).ToList();
            return CreateUserMailTrackings(request, userMailTrackingList);
            //if (userMailTrackingList.Count > 0)
            //{
            //    UserHistoryRespository.Create(new UserHistory
            //    {
            //        Content = request.Subject,
            //        TypeId = (int)EnumHistoryType.Email,
            //        IsSystemAutogen = true,
            //        CreatedDate = DateTime.Now,
            //        UserId = request.SenderId,
            //        CreatedUserId = request.SenderId
            //    });
            //    UserHistoryRespository.SaveChanges();

            //    UserMailTrackingRespository.CreateRange(userMailTrackingList);
            //    UserMailTrackingRespository.SaveChanges();
            //    //var articleIds = request.ArticleIds.ToList();
            //    //articleIds.RemoveAt(articleIds.Count - 1);
            //    ArticleApp.UpdateLastSentArticles(request);

            //    return true;
            //}
            //return false;
        }

        private void SendClientMails(SendToOneRequest request, Dictionary<long, MailTemplateViewModel> data, bool isCreatedHistory = true)
        {
            // Get order article ids by user.
            var users = (from u in UserRespository.EntitiesNoTracking
                         join c in ClientRespository.EntitiesNoTracking on u.Id equals c.UserId
                         //join ct in ClientTypeRespository.Entities on c.Id equals ct.ClientId
                         where !u.IsDeleted && !c.IsDeleted && u.IsActive && u.EmailSubscribe == true &&
                             u.Logo != null && u.Logo != "" &&
                             (c.Id == request.SingleClientId || u.Id == request.AllClientsOfSingularBrokerId) &&
                             c.EmailSubscribe == 1 // && recipientTypeIds.Contains(ct.TypeId)
                                                   //(request.RecipientTypeIds != null && request.RecipientTypeIds.Any(x => x == ct.TypeId))
                         select u).Distinct().ToList();
            GetNewLetterEmails(request, users, data);

            var mailTrackings = (from u in UserRespository.EntitiesNoTracking
                                 join c in ClientRespository.EntitiesNoTracking on u.Id equals c.UserId
                                 //join ct in ClientTypeRespository.Entities on c.Id equals ct.ClientId
                                 where !u.IsDeleted && !c.IsDeleted && u.IsActive && u.EmailSubscribe == true &&
                                     u.Logo != null && u.Logo != "" &&
                                     (c.Id == request.SingleClientId || u.Id == request.AllClientsOfSingularBrokerId) &&
                                     c.EmailSubscribe == 1 // && recipientTypeIds.Contains(ct.TypeId)
                                 //(request.RecipientTypeIds != null && request.RecipientTypeIds.Any(x => x == ct.TypeId))
                                 select c).ToList();

            if (mailTrackings.Count == 0) return;

            //request.Subject = GetSubjectTemplate(request.ArticleIds);
            var mailTrackingList = mailTrackings.Select(x => FullCopy(request, x, data)).ToList();
            if (mailTrackingList.Count > 0)
            {
                if (isCreatedHistory)
                {
                    UserHistoryRespository.Create(new UserHistory
                    {
                        Content = request.Subject,
                        TypeId = (int)EnumHistoryType.Email,
                        IsSystemAutogen = true,
                        CreatedDate = DateTime.Now,
                        UserId = request.SenderId,
                        CreatedUserId = request.SenderId
                    });
                    UserHistoryRespository.SaveChanges();
                }

                MailTrackingRespository.CreateRange(mailTrackingList);
                MailTrackingRespository.SaveChanges();
                //var articleIds = request.ArticleIds.ToList();
                //articleIds.RemoveAt(articleIds.Count - 1);
                //if (isUpdatedLastSent)
                //{
                //    ArticleApp.UpdateLastSentArticles(request);
                //}
            }

        }

        private List<NewsLetterEmail> GetNewLetterEmails(SendToOneRequest request, List<User> users, Dictionary<long, MailTemplateViewModel> data)
        {
            //var result = new Dictionary<long, List<long>>();
            var result = new List<NewsLetterEmail>();
            foreach (var user in users)
            {
                if (data.ContainsKey(user.Id))
                {
                    //result.Add(user.Id, data[user.Id]);
                    //if (isSaved)
                    //{
                    //    newLetterEmails.Add(new NewLetterEmail
                    //    {
                    //        UserId = user.Id,
                    //        CreatedDate = DateTime.Now,
                    //        CreatedUserId = request.SenderId,
                    //        IsChangable = true,
                    //        ArticleIds = string.Join(",", result[user.Id]),
                    //    });
                    //}

                    result.Add(new NewsLetterEmail
                    {
                        UserId = user.Id,
                        CreatedDate = DateTime.Now,
                        CreatedUserId = request.SenderId,
                        IsChangable = true,
                        ArticleIds = string.Join(",", data[user.Id].ArticleIds),
                        IsSelectedCompanyImage = request.IsSelectedCompanyImage,
                        PrimaryImageName = request.PrimaryImageName,
                    });
                    continue;
                }

                var userArticles = ArticleApp.GetIds(request.ArticleIds, request.SenderId);
                var articleIds = request.ArticleIds.ToList();
                var index = 0;
                for (int i = 0; i < request.ArticleIds.Length - 1; i++)
                {
                    if (userArticles.Contains(articleIds[i]))
                    {
                        if (index == i)
                        {
                            index++;
                        }
                        else
                        {
                            var temp = articleIds[index];
                            articleIds[index] = articleIds[i];
                            articleIds[i] = temp;
                            index++;
                        }
                    }
                }
                data.Add(user.Id, new MailTemplateViewModel { ArticleIds = articleIds.ToArray() });
                result.Add(new NewsLetterEmail
                {
                    UserId = user.Id,
                    CreatedDate = DateTime.Now,
                    CreatedUserId = request.SenderId,
                    IsChangable = true,
                    ArticleIds = string.Join(",", data[user.Id].ArticleIds),
                    IsSelectedCompanyImage = request.IsSelectedCompanyImage,
                    PrimaryImageName = request.PrimaryImageName,
                });
            }

            //if (newLetterEmails.Count > 0)
            //{
            //    NewLetterEmailRespository.CreateRange(newLetterEmails);
            //    NewLetterEmailRespository.SaveChanges();
            //}
            return result;
        }

        private bool CreateUserMailTrackings(SendToOneRequest request, List<UserEmailTracking> userMailTrackingList, bool isCreatedHistory = true, bool isUpdatedLastSent = true)
        {
            if (userMailTrackingList.Count > 0)
            {
                if (isCreatedHistory)
                {
                    UserHistoryRespository.Create(new UserHistory
                    {
                        Content = $"Send NewsLetter: {request.Subject}",
                        TypeId = (int)EnumHistoryType.Email,
                        IsSystemAutogen = true,
                        CreatedDate = DateTime.Now,
                        UserId = request.SenderId,
                        CreatedUserId = request.SenderId
                    });
                    UserHistoryRespository.SaveChanges();
                }

                UserMailTrackingRespository.CreateRange(userMailTrackingList);
                UserMailTrackingRespository.SaveChanges();
                //var articleIds = request.ArticleIds.ToList();
                //articleIds.RemoveAt(articleIds.Count - 1);
                //if (isUpdatedLastSent)
                //{
                //    ArticleApp.UpdateLastSentArticles(request);
                //}
                return true;
            }
            return false;
        }

        private EmailTracking FullCopy(SendToAllRequest request, Client client, Dictionary<long, MailTemplateViewModel> data, List<NewsLetterEmail> newLetterEmails)
        {
            var emailTemplateBodyRequest = AutoMapperGenericsHelper<SendToAllRequest, EmailTemplateBodyRequest>.FullCopy(request);
            emailTemplateBodyRequest.ClientId = client.Id;
            emailTemplateBodyRequest.ArticleIds = data[client.UserId].ArticleIds;
            if (string.IsNullOrWhiteSpace(data[client.UserId].Subject))
            {
                request.Subject = data[client.UserId].Subject = GetSubjectTemplate(emailTemplateBodyRequest.ArticleIds);
                request.Content = data[client.UserId].Content = GetEmailTemplateBody(emailTemplateBodyRequest);
            }
            else
            {
                request.Subject = data[client.UserId].Subject;
                request.Content = data[client.UserId].Content;
            }

            var result = AutoMapperGenericsHelper<SendToAllRequest, EmailTracking>.FullCopy(request);
            result.ClientId = client.Id;
            result.NewLetterEmailId = newLetterEmails?.FirstOrDefault(x => x.UserId == client.UserId)?.Id;
            result.ScheduledTime = CommonHelper.GetClientSentDate(result.ScheduledTime);
            result.CreatedDate = DateTime.Now;
            return result;
        }

        private UserEmailTracking FullCopy(SendToAllRequest request, User user, Dictionary<long, MailTemplateViewModel> data, bool isPreSent = false, long? newsLetterEmailId = null)
        {
            var emailTemplateBodyRequest = AutoMapperGenericsHelper<SendToAllRequest, EmailTemplateBodyRequest>.FullCopy(request);
            emailTemplateBodyRequest.UserId = user.Id;
            emailTemplateBodyRequest.ArticleIds = data[user.Id].ArticleIds;
            emailTemplateBodyRequest.IsPreSent = isPreSent;
            emailTemplateBodyRequest.NewsLetterEmailId = newsLetterEmailId ?? 0;
            request.Subject = GetSubjectTemplate(emailTemplateBodyRequest.ArticleIds);
            request.Content = GetEmailTemplateBody(emailTemplateBodyRequest);

            var result = AutoMapperGenericsHelper<SendToAllRequest, UserEmailTracking>.FullCopy(request);
            result.UserId = user.Id;
            result.NewLetterEmailId = newsLetterEmailId;
            result.CreatedDate = DateTime.Now;
            //result.ScheduledTime = CommonHelper.GetClientSentDate(result.ScheduledTime);
            return result;
        }

        private EmailTracking FullCopy(SendToOneRequest request, Client client, Dictionary<long, MailTemplateViewModel> data)
        {
            var emailTemplateBodyRequest = AutoMapperGenericsHelper<SendToOneRequest, EmailTemplateBodyRequest>.FullCopy(request);
            emailTemplateBodyRequest.ClientId = client.Id;
            emailTemplateBodyRequest.ArticleIds = data[client.UserId].ArticleIds;
            if (string.IsNullOrWhiteSpace(data[client.UserId].Subject))
            {
                request.Subject = data[client.UserId].Subject = GetSubjectTemplate(emailTemplateBodyRequest.ArticleIds);
                request.Content = data[client.UserId].Content = GetEmailTemplateBody(emailTemplateBodyRequest);
            }
            else
            {
                request.Subject = data[client.UserId].Subject;
                request.Content = data[client.UserId].Content;
            }

            var result = AutoMapperGenericsHelper<SendToOneRequest, EmailTracking>.FullCopy(request);
            result.ClientId = client.Id;
            result.CreatedDate = DateTime.Now;
            //result.NewLetterEmailId = newLetterEmails?.FirstOrDefault(x => x.UserId == client.UserId)?.Id;
            //result.ScheduledTime = CommonHelper.GetClientSentDate(result.ScheduledTime);
            return result;
        }

        private UserEmailTracking FullCopy(SendToOneRequest request, User user, Dictionary<long, MailTemplateViewModel> data, bool isPreSent = false)
        {
            var emailTemplateBodyRequest = AutoMapperGenericsHelper<SendToOneRequest, EmailTemplateBodyRequest>.FullCopy(request);
            emailTemplateBodyRequest.UserId = user.Id;
            emailTemplateBodyRequest.ArticleIds = data[user.Id].ArticleIds;
            emailTemplateBodyRequest.IsPreSent = isPreSent;
            request.Subject = GetSubjectTemplate(emailTemplateBodyRequest.ArticleIds);
            request.Content = GetEmailTemplateBody(emailTemplateBodyRequest);
            //emailTemplateBodyRequest.NewsLetterEmailId = newsLetterEmailId ?? 0;

            var result = AutoMapperGenericsHelper<SendToOneRequest, UserEmailTracking>.FullCopy(request);
            result.UserId = user.Id;
            result.CreatedDate = DateTime.Now;
            //result.NewLetterEmailId = newsLetterEmailId;
            //result.ScheduledTime = CommonHelper.GetClientSentDate(result.ScheduledTime);
            return result;
        }

        private string GetArticleEmailTemplateName(int count)
        {
            var emailTemplateName = "MailArticles1";
            switch (count)
            {
                case 1:
                //emailTemplateName = "MailArticles1";
                //break;
                case 2:
                case 3:
                case 4:
                case 6:
                    emailTemplateName = "MailArticles2";
                    break;
                //case 5:
                //    emailTemplateName = "MailArticles5";
                //    break;
                case 7:
                case 10:
                    emailTemplateName = "MailArticles7";
                    break;
                //case 8:
                //    emailTemplateName = "MailArticles8";
                //    break;
                case 9:
                    emailTemplateName = "MailArticles9";
                    break;
                default:
                    emailTemplateName = "MailArticles5";
                    break;
            }
            return emailTemplateName;
        }
        #endregion
    }
}
