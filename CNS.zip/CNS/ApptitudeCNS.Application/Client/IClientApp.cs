﻿using ApptitudeCNS.Application.Response;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Helpers;
using System.Collections.Generic;


namespace ApptitudeCNS.Application.Clients
{
    public interface IClientApp
    {
        bool CheckExistEmail(long userId, long id, string email);
        ClientViewModel FindByEmail(string email);
        List<ClientViewModel> FindByUserId(long? userId, int pageIndex, int pageSize, string sortFieldName, bool isDesc, ClientFilterViewModel filter , ref long numOfItem);
        List<ClientViewModel> FindByUserId(long userId);
        ClientViewModel FindById(long id);
        void CreateAndUpdate(ClientViewModel client);
        ImportClientsResponse ImportClients(List<ImportClientViewModel> clients);
        void Delete(int id);
        //List<IdName> GetRecipientTypes();
        void SendSMSBirthday();
        void UpdateEmailAndSmsSubscribe(long clientId, int email, bool? sms);

        List<IdName> GetClientList(string term);
    }
}
