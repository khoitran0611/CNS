﻿using ApptitudeCNS.Application.Response;
using ApptitudeCNS.Application.ViewModel;
using System.Collections.Generic;


namespace ApptitudeCNS.Application.ClientHistories
{
    public interface IClientHistoryApp
    {
        void Delete(long id);
        ClientHistoryViewModel CreateAndUpdate(ClientHistoryViewModel model);
        void SetPinned(long id, bool isPinned);
        List<ClientHistoryViewModel> FindByClientId(long clientId);
        ClientHistoryViewModel FindById(long clientHistoryId);
    }
}
