﻿using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using System.Collections.Generic;
using System.Linq;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Application.Response;
using System;

namespace ApptitudeCNS.Application.ClientHistories
{
    public class ClientHistoryApp : IClientHistoryApp
    {
        private IGenericRepository<ClientHistory> clientHistoryGenericRepository { get; set; }
        private IGenericRepository<User> userGenericRepository { get; set; }

        public ClientHistoryApp(IGenericRepository<ClientHistory> _clientHistoryGenericRepository, IGenericRepository<User> _userGenericRepository)
        {
            clientHistoryGenericRepository = _clientHistoryGenericRepository;
            userGenericRepository = _userGenericRepository;
        }

        public void Delete(long id)
        {
            var his = clientHistoryGenericRepository.FindBy(c => c.Id == id).FirstOrDefault();
            if (his != null)
            {
                clientHistoryGenericRepository.Delete(his);
                clientHistoryGenericRepository.SaveChanges();
            }
        }

        public ClientHistoryViewModel CreateAndUpdate(ClientHistoryViewModel model)
        {
            var his = AutoMapperGenericsHelper<ClientHistoryViewModel, ClientHistory>.FullCopy(model);
            if (model.Id > 0)
            {
                clientHistoryGenericRepository.Update(his);
            }
            else
            {
                clientHistoryGenericRepository.Create(his);
            }
            clientHistoryGenericRepository.SaveChanges();
            return AutoMapperGenericsHelper<ClientHistory, ClientHistoryViewModel>.FullCopy(his);
        }

        public void SetPinned(long id, bool isPinned)
        {
            var his = clientHistoryGenericRepository.FindBy(c => c.Id == id).FirstOrDefault();
            if (his != null)
            {
                his.Pinned = isPinned;
                clientHistoryGenericRepository.Update(his);
                clientHistoryGenericRepository.SaveChanges();
            }
        }

        public List<ClientHistoryViewModel> FindByClientId(long clientId)
        {
            var histories = clientHistoryGenericRepository
                .Entities
                .Where(c => !c.IsDeleted && c.ClientId == clientId)
                .Join(userGenericRepository.Entities, c => c.CreatedUserId, u => u.Id, (c, u) => new { History = c, CreatedUser = u })
                .OrderByDescending(c => new { c.History.Pinned , c.History.UpdatedDate , c.History.CreatedDate});
            var result = new List<ClientHistoryViewModel>();
            foreach (var item in histories)
            {
                var tempt = AutoMapperGenericsHelper<ClientHistory, ClientHistoryViewModel>.FullCopy(item.History);
                tempt.CreatedUserSign = item.CreatedUser.Signature;
                tempt.CreatedUserName = item.CreatedUser.FirstName + " " + item.CreatedUser.LastName;
                result.Add(tempt);
            }
            return result;
        }

        public ClientHistoryViewModel FindById(long clientHistoryId)
        {
            var history = clientHistoryGenericRepository.FindBy(clientHistoryId);
            return AutoMapperGenericsHelper<ClientHistory, ClientHistoryViewModel>.FullCopy(history);
        }
    }
}
