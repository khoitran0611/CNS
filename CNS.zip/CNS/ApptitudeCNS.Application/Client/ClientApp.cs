﻿using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using System.Collections.Generic;
using System.Linq;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Application.Response;
using System;
using ApptitudeCNS.Infrastructure.Sms.Services;

namespace ApptitudeCNS.Application.Clients
{
    public class ClientApp : IClientApp
    {
        private IGenericRepository<Client> clientGenericRepository { get; set; }
        private IGenericRepository<ClientType> clientTypeGenericRepository { get; set; }
        private IGenericRepository<ClientHistory> clientHistoryGenericRepository { get; set; }
        private IGenericRepository<RecipientType> recipientTypeGenericRepository { get; set; }
        private IGenericRepository<User> userGenericRepository { get; set; }
        private ISmsService smsService { get; set; }


        public ClientApp(IGenericRepository<Client> _clientGenericRepository,
            IGenericRepository<ClientType> _clientTypeGenericRepository,
            IGenericRepository<ClientHistory> _clientHistoryGenericRepository,
            IGenericRepository<RecipientType> _recipientTypeGenericRepository,
            IGenericRepository<User> _userGenericRepository,
            ISmsService _smsService)
        {
            clientGenericRepository = _clientGenericRepository;
            clientTypeGenericRepository = _clientTypeGenericRepository;
            clientHistoryGenericRepository = _clientHistoryGenericRepository;
            recipientTypeGenericRepository = _recipientTypeGenericRepository;
            smsService = _smsService;
            userGenericRepository = _userGenericRepository;
        }

        public bool CheckExistEmail(long userId, long id, string email)
        {
            if (string.IsNullOrWhiteSpace(email)) return false;
            email = email.Trim();
            var urls = clientGenericRepository.FindBy(x => !x.IsDeleted && userId == x.UserId && id != x.Id && email.Equals(x.Email, StringComparison.OrdinalIgnoreCase));
            return urls.Any();
        }

        public ClientViewModel FindByEmail(string email)
        {
            ClientViewModel result = null;
            var client = clientGenericRepository.FindBy(c => c.Email == email && !c.IsDeleted).FirstOrDefault();
            if (client != null)
            {
                result = AutoMapperGenericsHelper<Client, ClientViewModel>.FullCopy(client);
            }
            return result;
        }

        public List<ClientViewModel> FindByUserId(long? userId, int pageIndex, int pageSize, string sortFieldName, bool isDesc, ClientFilterViewModel filter, ref long numOfItem)
        {
            List<ClientViewModel> result = new List<ClientViewModel>();
            if (filter != null && (filter.EmailSubscribes == null || filter.EmailSubscribes.Length == 0))
            {
                return result;
            }

            if (string.IsNullOrWhiteSpace(filter.SearchText))
                filter.SearchText = string.Empty;

            var emailSubscribes = filter.EmailSubscribes.ToList();
            var data = (from c in clientGenericRepository.EntitiesNoTracking
                              join u in userGenericRepository.EntitiesNoTracking on c.UserId equals u.Id
                              join ch in clientHistoryGenericRepository.EntitiesNoTracking on c.Id equals ch.ClientId into gch
                              from chg in gch.DefaultIfEmpty()
                              where (!userId.HasValue || c.UserId == userId) && !c.IsDeleted && !u.IsDeleted && emailSubscribes.Contains(c.EmailSubscribe)
                              select new { c, u, chg });
            if (filter != null)
            {
                data = data.Where(d => filter.SearchText == string.Empty ||
                                (filter.SearchLevel == 0 && (filter.SearchText == (d.c.FirstName + " " + d.c.LastName).Trim()
                                                                || filter.SearchText == d.c.FirstName
                                                                || filter.SearchText == d.c.LastName
                                                                || filter.SearchText == d.c.Email
                                                                || filter.SearchText == d.c.Phone
                                                                || filter.SearchText == d.c.Salutation)) ||
                                (filter.SearchLevel == 1 && ((d.c.FirstName + " " + d.c.LastName).Trim().Contains(filter.SearchText)
                                                                 || d.c.FirstName.Contains(filter.SearchText)
                                                                 || d.c.LastName.Contains(filter.SearchText)
                                                                 || d.c.Email.Contains(filter.SearchText)
                                                                 || d.c.Phone.Contains(filter.SearchText)
                                                                 || d.c.Salutation.Contains(filter.SearchText)
                                                                 || d.chg.Content.Contains(filter.SearchText))));
            }
            var sqlClients = (from r in data.AsEnumerable()
                              group new { r.c, r.u } by new { r.c.Id } into g
                              //orderby ag.Key.ArticleDate descending, ag.Key.Id descending
                              select new ClientViewModel
                              {
                                  Birthday = g.FirstOrDefault().c.Birthday,
                                  BrokerRefNo = g.FirstOrDefault().c.BrokerRefNo,
                                  CreatedDate = g.FirstOrDefault().c.CreatedDate,
                                  Email = g.FirstOrDefault().c.Email,
                                  EmailSubscribe = g.FirstOrDefault().c.EmailSubscribe,
                                  FirstName = g.FirstOrDefault().c.FirstName,
                                  Id = g.FirstOrDefault().c.Id,
                                  LastName = g.FirstOrDefault().c.LastName,
                                  Phone = g.FirstOrDefault().c.Phone,
                                  Salutation = g.FirstOrDefault().c.Salutation,
                                  SMSSubscribe = g.FirstOrDefault().c.SMSSubscribe,
                                  UpdatedDate = g.FirstOrDefault().c.UpdatedDate,
                                  UserId = g.FirstOrDefault().c.UserId,
                                  UserFirstName = g.FirstOrDefault().u.FirstName,
                                  UserLastName = g.FirstOrDefault().u.LastName,
                                  UserInternalIdentifier = g.FirstOrDefault().u.InternalIdentifier,
                                  CompanyName = g.FirstOrDefault().u.Company
                              });

            sqlClients = !isDesc ? sqlClients.OrderByDescending(x => x.FirstName).ThenByDescending(x => x.LastName) : sqlClients.OrderBy(x => x.FirstName).ThenBy(x => x.LastName);

            //switch (sortFieldName)
            //{
            //    case "FirstName":
            //        sqlClients = isDesc ? sqlClients.OrderByDescending(x => x.FirstName) : sqlClients.OrderBy(x => x.FirstName);
            //        break;
            //    default:
            //        result2 = result2.OrderByDescending(x => x.Article.ArticleDate).ThenByDescending(x => x.Article.Id);
            //        break;
            //}


            //var sqlClients = clientGenericRepository.EntitiesNoTracking
            //    .Where(c => ((userId.HasValue && c.UserId == userId) || !userId.HasValue) && !c.IsDeleted)
            //    .Join(userGenericRepository.EntitiesNoTracking.Where(u => !u.IsDeleted), c => c.UserId, u => u.Id, (c, u) => new { Client = c, CreatedUser = u })
            //    .Select(c => new ClientViewModel()
            //    {
            //        Birthday = c.Client.Birthday,
            //        BrokerRefNo = c.Client.BrokerRefNo,
            //        CreatedDate = c.Client.CreatedDate,
            //        Email = c.Client.Email,
            //        EmailSubscribe = c.Client.EmailSubscribe,
            //        FirstName = c.Client.FirstName,
            //        Id = c.Client.Id,
            //        LastName = c.Client.LastName,
            //        Phone = c.Client.Phone,
            //        Salutation = c.Client.Salutation,
            //        SMSSubscribe = c.Client.SMSSubscribe,
            //        UpdatedDate = c.Client.UpdatedDate,
            //        UserId = c.Client.UserId,
            //        UserFirstName = c.CreatedUser.FirstName,
            //        UserLastName = c.CreatedUser.LastName,
            //        UserInternalIdentifier = c.CreatedUser.InternalIdentifier,
            //        CompanyName = c.CreatedUser.Company
            //    })
            //    .OrderBy(sortFieldName, isDesc);

            //if (filter != null)
            //{
            //    //Filter : Serach text
            //    if (!string.IsNullOrEmpty(filter.SearchText))
            //    {
            //        if (filter.SearchLevel == 0)
            //        {
            //            sqlClients = sqlClients.Where(c =>
            //            (filter.SearchText == (c.FirstName + " " + c.LastName).Trim()
            //            || filter.SearchText == c.FirstName
            //            || filter.SearchText == c.LastName
            //            || filter.SearchText == c.Email
            //            || filter.SearchText == c.Phone
            //            || filter.SearchText == c.Salutation));
            //        }
            //        else if (filter.SearchLevel == 1)
            //        {
            //            sqlClients = sqlClients.Where(c =>
            //             ((c.FirstName + " " + c.LastName).Trim().Contains(filter.SearchText)
            //             || c.FirstName.Contains(filter.SearchText)
            //             || c.LastName.Contains(filter.SearchText)
            //             || c.Email.Contains(filter.SearchText)
            //             || c.Phone.Contains(filter.SearchText)
            //             || c.Salutation.Contains(filter.SearchText)));
            //        }
            //    }

            //    var emailSubscribes = filter.EmailSubscribes.ToList();
            //    sqlClients = sqlClients.Where(x => emailSubscribes.Contains(x.EmailSubscribe));
            //}

            numOfItem = sqlClients.Count();
            //Sort and paging
            result = sqlClients.Skip((pageIndex - 1) * pageSize)
            .Take(pageSize)
            .ToList();

            return result;
        }

    public List<ClientViewModel> FindByUserId(long userId)
    {
        var clients = clientGenericRepository.FindBy(c => c.UserId == userId && !c.IsDeleted);
        return clients.Select(r => AutoMapperGenericsHelper<Client, ClientViewModel>.FullCopy(r)).ToList();
    }

    public void CreateAndUpdate(ClientViewModel client)
    {
        var historyContent = string.Empty;
        Client source = AutoMapperGenericsHelper<ClientViewModel, Client>.FullCopy(client);

        // Update Salutation = first name if it is empty
        if (string.IsNullOrWhiteSpace(source.Salutation))
        {
            source.Salutation = source.FirstName;
        }
        if (client.Id > 0)
        {
            Client oldClient = clientGenericRepository.FindBy(client.Id);
            source.CreatedDate = oldClient.CreatedDate;
            var compareResults = ExtensionClass.Compare<Client>(oldClient, source);
            AutoMapperGenericsHelper<Client, Client>.FullCopy(source, oldClient);
            clientGenericRepository.Update(oldClient);
            foreach (var item in compareResults)
            {
                if (item.Name != "UpdatedDate" && item.Name != "CreatedDate")
                {
                    if (item.Name == "SMS Subscribe")
                    {
                        historyContent += string.Format("<p>Changed {0} from \"{1}\" to \"{2}\"</p>", item.Name, CommonHelper.GetSubscribeLogName((bool?)item.OldValue), CommonHelper.GetSubscribeLogName((bool?)item.NewValue));
                    }
                    else if (item.Name == "Email Status")
                    {
                        historyContent += string.Format("<p>Changed {0} from \"{1}\" to \"{2}\"</p>", item.Name,
                                                            ((EnumClientEmailStatus)item.OldValue).GetDescription(), ((EnumClientEmailStatus)item.NewValue).GetDescription());

                    }
                    else if (item.OldValue is bool)
                    {
                        historyContent += string.Format("<p>{0} was {1}</p>", item.Name, (bool)item.NewValue ? "checked" : "unchecked");
                    }
                    else
                    {
                        historyContent += string.Format("<p>Changed {0} from \"{1}\" to \"{2}\"</p>", item.Name, item.OldValue != null ? item.OldValue.ToString() : string.Empty, item.NewValue != null ? item.NewValue.ToString() : string.Empty);
                    }
                }
            }

            //Check Recipient Types whether or not change.
            //var oldRecipientTypes = clientTypeGenericRepository.Entities.Where(ct => ct.ClientId == client.Id).Select(ct=> ct.TypeId).OrderBy(c=> c).ToList();
            //var newRecipientTypes = client.RecipientTypes.OrderBy(c=> c).ToList();
            //var ismatch = oldRecipientTypes.Count() == newRecipientTypes.Count() && oldRecipientTypes.Any(o => newRecipientTypes.Contains(o));
            //if(ismatch)
            //{
            //    for (int i = 0; i < newRecipientTypes.Count(); i++)
            //    {
            //        ismatch = newRecipientTypes[i] == oldRecipientTypes[i];
            //    }
            //}

            //if (!ismatch)
            //{
            //    var recipientTypes = recipientTypeGenericRepository.GetAll();
            //    var newRecipientTypesName = recipientTypes.Where(r => client.RecipientTypes.Contains(r.Id)).Select(r => r.Name).ToList();

            //    if (newRecipientTypesName.Count() == 0)
            //    {
            //        historyContent += string.Format("<p>Remove all Recipient Types</p>");
            //    }
            //    else
            //    {
            //        historyContent += string.Format("<p>Change Recipient Types to {0}</p>", string.Join(",", newRecipientTypesName));
            //    }                    
            //}
            //clientTypeGenericRepository.DeleteBy(ct => ct.ClientId == client.Id);
        }
        else
        {
            clientGenericRepository.Create(source);
            historyContent = "Created";
        }
        clientGenericRepository.SaveChanges();
        //clientTypeGenericRepository.CreateRange(client.RecipientTypes.Select(rt => new ClientType { ClientId = source.Id, TypeId = (int)rt }));
        clientTypeGenericRepository.SaveChanges();

        //Save history
        if (!string.IsNullOrEmpty(historyContent))
        {
            clientHistoryGenericRepository.Create(new ClientHistory
            {
                ClientId = client.Id,
                IsSystemAutogen = true,
                TypeId = (int)EnumHistoryType.Other,
                Content = historyContent,
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now,
                CreatedUserId = client.UserId
            });
            clientHistoryGenericRepository.SaveChanges();
        }
    }

    public ClientViewModel FindById(long id)
    {
        ClientViewModel result = null;
        var client = clientGenericRepository.FindBy(c => c.Id == id && !c.IsDeleted).FirstOrDefault();
        if (client != null)
        {
            result = AutoMapperGenericsHelper<Client, ClientViewModel>.FullCopy(client);
            //result.RecipientTypes = clientTypeGenericRepository.FindBy(ct => ct.ClientId == id).Select(ct => ct.TypeId).ToList();
        }
        return result;
    }

    public ImportClientsResponse ImportClients(List<ImportClientViewModel> clients)
    {
        var result = new ImportClientsResponse();
        if (clients == null || clients.Count == 0) return result;

        var userId = clients[0].UserId;
        var emails = clients.Select(c => c.Email).Distinct();
        var data = (from c in clientGenericRepository.GetAll()
                    join cc in clients on c.Email.ToLower() equals cc.Email.ToLower()
                    where c.UserId == userId && !c.IsDeleted
                    select new { ClientsFromDB = c, CurrentClients = cc }).ToList();

        foreach (var item in data)
        {
            var clientHistories = GetClientHistories(item.ClientsFromDB, item.CurrentClients);
            if (clientHistories.Count > 0)// || SetClientTypes(item.ClientsFromDB, item.CurrentClients))
            {
                clientGenericRepository.Update(item.ClientsFromDB);
                if (clientHistories.Count > 0)
                {
                    clientHistoryGenericRepository.CreateRange(clientHistories);
                }
                result.UpdatedCount++;
            }
        }

        var addedImportClients = clients.Where(x => !data.Any(y => y.CurrentClients.Email == x.Email));
        result.AddedCount = addedImportClients.Count();
        var addedClients = addedImportClients.Select(x => AutoMapperGenericsHelper<ImportClientViewModel, Client>.FullCopy(x));
        foreach (var addedClient in addedClients)
        {
            //addedClient.EmailSubscribe = 1;
            if (!string.IsNullOrWhiteSpace(addedClient.Phone))
            {
                addedClient.SMSSubscribe = true;
            }

            clientGenericRepository.Create(addedClient);
            clientGenericRepository.SaveChanges();

            var addedImportClient = addedImportClients.First(x => x.Email == addedClient.Email);
            //clientTypeGenericRepository.CreateRange(addedImportClient.RecipientTypes.Select(x => new ClientType { TypeId = (int)x, ClientId = addedClient.Id }));

            clientHistoryGenericRepository.Create(new ClientHistory
            {
                ClientId = addedClient.Id,
                IsSystemAutogen = true,
                TypeId = (int)EnumHistoryType.Other,
                Content = "Import from excel",
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now,
                CreatedUserId = addedImportClient.CreatedUserId
            });
        }

        clientHistoryGenericRepository.SaveChanges();
        return result;
    }

    private List<ClientHistory> GetClientHistories(Client client, ImportClientViewModel importClient)
    {
        var result = new List<ClientHistory>();
        client.FirstName = SetClientHistory(result, client, "FirstName", client.FirstName, importClient.FirstName, importClient.CreatedUserId);
        client.LastName = SetClientHistory(result, client, "LastName", client.LastName, importClient.LastName, importClient.CreatedUserId);
        client.Salutation = SetClientHistory(result, client, "Salutation", client.Salutation, importClient.Salutation, importClient.CreatedUserId);
        client.Phone = SetClientHistory(result, client, "Phone", client.Phone, importClient.Phone, importClient.CreatedUserId);
        client.Birthday = SetClientHistory(result, client, "Birthday", client.Birthday, importClient.Birthday, importClient.CreatedUserId);
        client.BrokerRefNo = SetClientHistory(result, client, "BrokerRefNo", client.BrokerRefNo, importClient.BrokerRefNo, importClient.CreatedUserId);
        return result;
    }

    private string SetClientHistory(List<ClientHistory> clientHistories, Client client, string fieldName, string oldValue, string newValue, long createdUserId)
    {
        if (!string.IsNullOrWhiteSpace(newValue) && (oldValue == null || !oldValue.Equals(newValue, System.StringComparison.OrdinalIgnoreCase)))
        {
            clientHistories.Add(new ClientHistory
            {
                ClientId = client.Id,
                IsSystemAutogen = true,
                TypeId = (int)EnumHistoryType.Other,
                Content = $"{fieldName}: {oldValue} => {newValue}",
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now,
                CreatedUserId = createdUserId
            });
            return newValue;
        }
        return oldValue;
    }

    private DateTime? SetClientHistory(List<ClientHistory> clientHistories, Client client, string fieldName, DateTime? oldValue, DateTime? newValue, long createdUserId)
    {
        var oldData = oldValue?.ToString("dd/MM/yyyy");
        var newData = newValue?.ToString("dd/MM/yyyy");
        if (oldData != newData)
        {
            clientHistories.Add(new ClientHistory
            {
                ClientId = client.Id,
                IsSystemAutogen = true,
                TypeId = (int)EnumHistoryType.Other,
                Content = $"{fieldName}: {oldData} => {newData}",
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now,
                CreatedUserId = createdUserId
            });
            return newValue;
        }
        return oldValue;
    }

    //private bool SetClientTypes(Client client, ImportClientViewModel importClient)
    //{
    //    var existTypes = clientTypeGenericRepository.FindBy(x => x.ClientId == client.Id);
    //    var emails = existTypes.Select(x => x.TypeId).ToList();

    //    if (emails.Count != importClient.RecipientTypes.Count || !importClient.RecipientTypes.All(x => emails.Contains((int)x)))
    //    {
    //        clientTypeGenericRepository.DeleteRange(existTypes);

    //        var articleTypes = importClient.RecipientTypes.Select(x => new ClientType
    //        {
    //            ClientId = client.Id,
    //            TypeId = (int)x
    //        });
    //        clientTypeGenericRepository.CreateRange(articleTypes);
    //        return true;
    //    }
    //    return false;
    //}

    public void Delete(int id)
    {
        var updatedClient = clientGenericRepository.FindBy(u => u.Id == id).FirstOrDefault();
        updatedClient.IsDeleted = true;
        clientGenericRepository.Update(updatedClient);
        clientGenericRepository.SaveChanges();
    }

    //public List<IdName> GetRecipientTypes()
    //{
    //    return recipientTypeGenericRepository.GetAll().Select(rt => new IdName { Id = rt.Id, Name = rt.Name }).ToList();
    //}

    public void SendSMSBirthday()
    {
        //var day = DateTime.Now.DayOfWeek;
        //var hour = DateTime.Now.Hour;
        //if (((day == DayOfWeek.Saturday || day == DayOfWeek.Sunday) && hour == 11) || (day != DayOfWeek.Saturday && day != DayOfWeek.Sunday && hour == 7)) {
        var list = (from u in userGenericRepository.Entities
                    join c in clientGenericRepository.Entities on u.Id equals c.UserId
                    where !u.IsDeleted && !c.IsDeleted && u.SMSSubscribe.HasValue && u.SMSSubscribe.Value &&
                        c.SMSSubscribe.HasValue && c.SMSSubscribe.Value && !(c.Phone == null || c.Phone.Trim() == string.Empty) &&
                        (c.Birthday.HasValue && c.Birthday.Value.Day == DateTime.Today.Day && c.Birthday.Value.Month == DateTime.Today.Month)
                    select new { Client = c, User = u }).ToList();

        foreach (var item in list)
        {
            var message = $"Happy birthday {item.Client.FirstName} {item.Client.LastName}.";
            var result = "SUCCESS";
            if (!ConfigManager.IsDevEnvironment)
            {
                result = smsService.SendSms(message, PhoneHelper.NormalizePhone(item.Client.Phone.Trim()).ToArray());//, item.User.Phone);
            }

            clientHistoryGenericRepository.Create(new ClientHistory
            {
                ClientId = item.Client.Id,
                IsSystemAutogen = true,
                TypeId = (int)EnumHistoryType.SMS,
                Content = $"Send Birthday Message: {message}, result: {result}",
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now,
                CreatedUserId = ConfigManager.SystemUserId
            });
        }
        clientHistoryGenericRepository.SaveChanges();
        //}

    }

    public void UpdateEmailAndSmsSubscribe(long clientId, int email, bool? sms)
    {
        var client = clientGenericRepository.FindBy(clientId);

        var historyContent = string.Empty;
        //if(client.EmailSubscribe != email)
        //{
        //    historyContent  += string.Format("<p>Changed Email Status from \"{0}\" to \"{1}\"</p>", ((EnumClientEmailStatus)client.EmailSubscribe).GetDescription(), ((EnumClientEmailStatus)email).GetDescription());
        //}
        if (client.SMSSubscribe != sms)
        {
            historyContent += string.Format("<p>Changed SMS Subscribe from \"{0}\" to \"{1}\"</p>", CommonHelper.GetSubscribeLogName(client.SMSSubscribe), CommonHelper.GetSubscribeLogName(sms));
        }

        if (client != null)
        {
            client.SMSSubscribe = sms;
            client.EmailSubscribe = email;
            clientGenericRepository.Update(client);
            clientGenericRepository.SaveChanges();

            //Save history
            if (!string.IsNullOrEmpty(historyContent))
            {
                clientHistoryGenericRepository.Create(new ClientHistory
                {
                    ClientId = client.Id,
                    IsSystemAutogen = true,
                    TypeId = (int)EnumHistoryType.Other,
                    Content = historyContent,
                    CreatedDate = DateTime.Now,
                    UpdatedDate = DateTime.Now,
                    CreatedUserId = client.UserId
                });
                clientHistoryGenericRepository.SaveChanges();
            }
        }
    }

    public List<IdName> GetClientList(string term)
    {
        if (string.IsNullOrWhiteSpace(term) || term.Length < 1) return new List<IdName>();

        var id = CommonHelper.GetLong(term);
        var result = (from u in userGenericRepository.EntitiesNoTracking
                      join c in clientGenericRepository.EntitiesNoTracking on u.Id equals c.UserId
                      //join ct in ClientTypeRespository.Entities on c.Id equals ct.ClientId
                      where !u.IsDeleted && !c.IsDeleted && u.IsActive && u.EmailSubscribe == true &&
                          u.Logo != null && u.Logo != "" &&
                          (id == c.Id || c.FirstName.StartsWith(term) || c.LastName.StartsWith(term) || c.Email.StartsWith(term)) &&
                          c.EmailSubscribe == 1 // && recipientTypeIds.Contains(ct.TypeId)
                                                //(request.RecipientTypeIds != null && request.RecipientTypeIds.Any(x => x == ct.TypeId))
                      select c)
                             .OrderBy(x => x.FirstName).ThenBy(x => x.LastName).AsEnumerable();

        //var result = clientGenericRepository.FindBy(u => !u.IsDeleted && (id == u.Id || u.FirstName.StartsWith(term) || u.LastName.StartsWith(term) || u.Email.StartsWith(term)))

        return result.Select(x => new IdName { Id = x.Id, Name = $"[{x.Id}] {x.FirstName} {x.LastName}".Trim() }).ToList();
    }
}
}
