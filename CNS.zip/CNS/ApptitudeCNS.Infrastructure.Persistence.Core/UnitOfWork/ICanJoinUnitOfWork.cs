﻿using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;

namespace ApptitudeCNS.Infrastructure.Persistence.Core.UnitOfWork
{
    public interface ICanJoinUnitOfWork
    {
        void JoinUnitOfWork(IDbContext context);
    }
}
