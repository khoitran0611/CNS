﻿using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;

namespace ApptitudeCNS.Infrastructure.Persistence.Core.UnitOfWork
{
    public interface IUnitOfWork
    {
        IDbContext Context { get; }

        void Commit();
        void Rollback();
    }
}
