﻿using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;

namespace ApptitudeCNS.Infrastructure.Persistence.Core.UnitOfWork
{
    public class EfUnitOfWork : IUnitOfWork
    {
        public EfUnitOfWork(IDbContext context)
        {
            Context = context;
        }

        public IDbContext Context { get; set; }

        public void Commit()
        {
            Context.SaveChanges();
        }

        public void Rollback()
        {
            Context.Refresh();
        }
    }
}
