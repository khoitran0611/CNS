﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Reflection;

namespace ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase
{
    public class EfDbContextBase : DbContext, IDbContext
    {
        public EfDbContextBase(string connectionString): base(connectionString)
        {
            Database.CommandTimeout = 10 * 60;
        }

        public Database DatabaseFacade
        {
            get
            {
                return Database;
            }
        }

        public DbContext CurrentContext
        {
            get
            {
                return this;
            }
        }

        public new IQueryable<T> Set<T>() where T : class
        {
            return base.Set<T>();
        }

        public void Refresh()
        {
            ChangeTracker.Entries().ToList().ForEach(x => { x.State = EntityState.Detached; });
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // Dynamically load all configuration
            IEnumerable<Type> typesToRegister = GetExecutingAssembly().GetTypes()
                .Where(type => !String.IsNullOrEmpty(type.Namespace))
                .Where(type => type.BaseType != null && type.BaseType.IsGenericType &&
                               (type.BaseType.GetGenericTypeDefinition() == typeof(EntityTypeConfiguration<>)));

            foreach (var type in typesToRegister)
            {
                dynamic configurationInstance = Activator.CreateInstance(type);
                modelBuilder.Configurations.Add(configurationInstance);
            }

            // ...or do it manually below. For example:
            // modelBuilder.Configurations.Add(new LanguageMap());

            base.OnModelCreating(modelBuilder);
        }

        protected virtual Assembly GetExecutingAssembly()
        {
            return Assembly.GetExecutingAssembly();
        }
    }
}