﻿using System.Data.Entity;

namespace ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase
{
    public interface IDbContext
    {
        Database DatabaseFacade { get; }

        DbContext CurrentContext { get; }
        DbSet<T> Set<T>() where T : class;

        int SaveChanges();
        void Refresh();
    }
}
