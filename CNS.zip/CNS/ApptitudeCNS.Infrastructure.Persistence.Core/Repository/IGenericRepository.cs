﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace ApptitudeCNS.Infrastructure.Persistence.Core.Repository
{
    public interface IGenericRepository<T>
    {
        IEnumerable<T> GetAll();
        T FindBy(long id);
        IEnumerable<T> FindBy(Expression<Func<T, bool>> predicate);
        void Create(T entity);
        void CreateRange(IEnumerable<T> list);
        void Update(T entity);
        void Delete(T entity);
        void DeleteRange(IEnumerable<T> list);
        void DeleteBy(Expression<Func<T, bool>> predicate);
        int SaveChanges();
        IQueryable<T> Entities { get; }
        IQueryable<T> EntitiesNoTracking { get; }
    }
}
