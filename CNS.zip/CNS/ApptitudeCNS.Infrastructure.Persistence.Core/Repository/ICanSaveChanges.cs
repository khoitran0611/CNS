﻿namespace ApptitudeCNS.Infrastructure.Persistence.Core.Repository
{
    public interface ICanSaveChanges
    {
        int SaveChanges();
    }
}
