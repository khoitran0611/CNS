﻿using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using ApptitudeCNS.Infrastructure.Persistence.Core.UnitOfWork;

namespace ApptitudeCNS.Infrastructure.Persistence.Core.Repository
{
    // May use generic repository
    public abstract class RepositoryBase : ICanSaveChanges, ICanJoinUnitOfWork
    {
        protected IDbContext Context;

        protected RepositoryBase(IDbContext context)
        {
            Context = context;
        }

        public int SaveChanges()
        {
            return Context.SaveChanges();
        }

        public void JoinUnitOfWork(IDbContext context)
        {
            Context = context;
        }
    }
}
