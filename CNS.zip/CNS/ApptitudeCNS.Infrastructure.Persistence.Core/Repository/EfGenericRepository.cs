﻿using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using ApptitudeCNS.Infrastructure.Persistence.Core.UnitOfWork;

namespace ApptitudeCNS.Infrastructure.Persistence.Core.Repository
{
    public class EfGenericRepository<T> : ICanSaveChanges, ICanJoinUnitOfWork, IGenericRepository<T> where T : class //EntityBase
    {
        private IDbContext _dbContext;
        private readonly DbSet<T> _dbSet;

        public EfGenericRepository(IDbContext dbContext)
        {
            _dbContext = dbContext;
            _dbSet = dbContext.Set<T>();
        }

        public IEnumerable<T> GetAll()
        {
            return _dbSet.ToList();
        }

        public T FindBy(long id)
        {
            return _dbSet.Find(id);
        }

        public IEnumerable<T> FindBy(Expression<Func<T, bool>> predicate)
        {
            return _dbSet.Where(predicate);
        }

        public void Create(T entity)
        {
            _dbSet.Add(entity);
        }

        public void CreateRange(IEnumerable<T> list)
        {
            _dbSet.AddRange(list);
        }

        public void Update(T entity)
        {
            _dbSet.Attach(entity);
            _dbContext.CurrentContext.Entry(entity).State = EntityState.Modified;
        }

        public void Delete(T entity)
        {
            _dbSet.Remove(entity);
        }

		 public void DeleteRange(IEnumerable<T> list)
        {
            _dbSet.RemoveRange(list);
        }
		public void DeleteBy(Expression<Func<T, bool>> predicate)
        {
            var ids = _dbSet.Where(predicate).ToList();
            foreach (var item in ids)
            {
                _dbSet.Remove(item);
            }            
        }

       public IQueryable<T> Entities => _dbSet;
       public IQueryable<T> EntitiesNoTracking => _dbSet.AsNoTracking();

        public int SaveChanges()
        {
            return _dbContext.SaveChanges();
        }

        public void JoinUnitOfWork(IDbContext context)
        {
            _dbContext = context;
        }
    }
}
