﻿using System;
using System.Linq;
using ApptitudeCNS.Infrastructure.Persistence.Core.UnitOfWork;

namespace ApptitudeCNS.Infrastructure.Persistence.Core.Repository
{
    public static class Extensions
    {
        public static void JoinUnitOfWork<T>(this T repository, IUnitOfWork unitOfWork)
        {
            if (!repository.GetType().GetInterfaces().Contains(typeof(ICanJoinUnitOfWork)))
            {
                throw new Exception("Repository must implement " + nameof(ICanJoinUnitOfWork));
            }

            var uowRepository = (ICanJoinUnitOfWork)repository;
            uowRepository.JoinUnitOfWork(unitOfWork.Context);
        }
    }
}
