﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestartWindows
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var filename = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "restartWindows.bat");
                if (File.Exists(filename))
                {
                    //System.Diagnostics.Process process = new System.Diagnostics.Process();
                    //System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
                    //startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                    //startInfo.FileName = "cmd.exe";
                    //startInfo.Arguments = File.ReadAllText(filename);
                    //process.StartInfo = startInfo;

                    File.Delete(filename);
                    //process.Start();
                    Process.Start("shutdown", "/r /f /t 0");
                    //Console.ReadLine();
                }
            }
            catch (Exception ex)
            {
                var log = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "log");
                if (!Directory.Exists(log))
                {
                    Directory.CreateDirectory(log);
                }
                var file = Path.Combine(log, $"{DateTime.Now.ToString("yyyyMMdd_HHmm")}.txt");
                File.WriteAllText(file, ex.ToString());
            }
        }
    }
}
