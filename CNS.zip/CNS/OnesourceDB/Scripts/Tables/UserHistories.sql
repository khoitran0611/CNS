USE [CNS]
GO
CREATE TABLE [dbo].[UserHistories](
 [Id] [bigint] IDENTITY(1,1) NOT NULL PRIMARY KEY,
 [UserId] [bigint] NOT NULL,
 [TypeId] [int] NOT NULL,
 [Content] [nvarchar](max) NULL,
 [Pinned] BIT NOT NULL,
 [IsSystemAutogen] [bit] NOT NULL DEFAULT(0),
 [CreatedDate] [datetime] NOT NULL DEFAULT(0),
 CreatedUserId bigint NOT NULL,
 [IsDeleted] [bit] NOT NULL DEFAULT(0)
)