USE [CNS]
GO
CREATE TABLE [dbo].[SystemConfigs](
   Id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
   KeyName NVARCHAR(255) NOT NULL,
   Name NVARCHAR(255) NULL,
   Value NVARCHAR(MAX) NULL,
   CreatedDate datetime NULL,
   CreatedUserId bigint NOT NULL,
   UpdatedDate datetime NULL,
   UpdatedUserId bigint NULL,
   [IsDeleted] [bit] NULL
)
   