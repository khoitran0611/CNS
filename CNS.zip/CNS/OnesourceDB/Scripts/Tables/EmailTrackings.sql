USE [CNS]
GO

CREATE TABLE [dbo].[EmailTrackings](
 Id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
 SenderId BIGINT NOT NULL,
 ClientId BIGINT NOT NULL,
 Subject nvarchar(250) NOT NULL,
 Content nvarchar(max) NOT NULL,
 ScheduledTime datetime NOT NULL,
 Status int NOT NULL,
 ErrorNote nvarchar(max) NULL,
 ReadDate datetime NULL,
 ClickedDate datetime NULL,
 TypeId int NOT NULL
)