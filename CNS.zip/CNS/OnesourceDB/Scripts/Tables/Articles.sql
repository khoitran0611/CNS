USE [CNS]
GO

CREATE TABLE [dbo].[Articles](
 Id bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
 Subject nvarchar(250) NOT NULL,
 Title nvarchar(250) NOT NULL,
 ArticleDate datetime NOT NULL,
 URLTrackingId bigint NOT NULL,
 Summary nvarchar(max) NOT NULL,
 Picture nvarchar(250) NULL,
 Author nvarchar(350) NULL,
 LastSent datetime NULL,
 CreatedDate datetime NOT NULL,
 UpdatedDate datetime NOT NULL,
 IsDeleted bit NOT NULL DEFAULT(0),
 CreatedUserId bigint NOT NULL,
 UpdatedUserId bigint NOT NULL,
 ArticleTypeId int NOT NULL
)