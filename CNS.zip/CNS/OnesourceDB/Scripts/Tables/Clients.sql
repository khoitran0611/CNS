USE [CNS]
GO
CREATE TABLE [dbo].[Clients](
 [Id] [bigint] IDENTITY(1,1) NOT NULL,
 [FirstName] [nvarchar](150) NULL,
 [LastName] [nvarchar](150) NULL,
 [Salutation] [nvarchar](350) NULL,
 [Email] [nvarchar](150) NULL,
 [EmailSubscribe] [bit] NULL,
 [Phone] [nvarchar](50) NULL,
 [SMSSubscribe] [bit] NULL,
 [Birthday] [datetime] NULL,
 [BrokerRefNo] [nvarchar](150) NULL,
 [UserId] [BIGINT] NULL,
 [CreatedDate] [datetime] NULL,
 [UpdatedDate] [datetime] NULL,
 [IsDeleted] [bit] NULL,
 CONSTRAINT [PK_Clients] PRIMARY KEY CLUSTERED 
(
 [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO   