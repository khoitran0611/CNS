ALTER PROCEDURE [dbo].[User_FindRoles] @userId INT           = NULL,
                                @email  NVARCHAR(150) = NULL
AS
     BEGIN
  --SET NOCOUNT ON added to prevent extra result sets from
  --interfering with SELECT statements.
         SET NOCOUNT ON;
         SELECT r.RoleName,
                r.Id
         FROM UserRoles ur
              INNER JOIN Users u ON ur.UserId = u.Id
              INNER JOIN Roles r ON ur.RoleId = r.Id
         WHERE(u.Id = @userId
               OR @userId IS NULL)
              AND (u.Email = @email
                   OR @email IS NULL);
     END;