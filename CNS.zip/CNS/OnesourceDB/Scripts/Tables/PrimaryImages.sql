USE [CNS]
GO
CREATE TABLE [dbo].[PrimaryImages](
   Id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
   Name NVARCHAR(MAX) NOT NULL,
   CreatedDate datetime NULL,
   CreatedUserId bigint NOT NULL,
   UpdatedDate datetime NULL,
   UpdatedUserId bigint NOT NULL,
)
   