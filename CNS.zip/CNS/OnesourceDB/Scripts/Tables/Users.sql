USE [ApptitudeCNS]
GO

/****** Object:  Table [dbo].[Users]    Script Date: 12/06/2018 09:16:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Users](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Email] [nvarchar](256) NOT NULL,
	[PasswordHash] [nvarchar](max) NULL,
	[Password] [nvarchar](128) NULL,
	[FirstName] [nvarchar](150) NULL,
	[LastName] [nvarchar](150) NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[Phone] [nvarchar](50) NULL,
	[Company] [nvarchar](150) NULL,
	[Signature] [nvarchar](50) NULL,
	[PrimaryColor] [nvarchar](50) NULL,
	[SecondaryColor] [nvarchar](50) NULL,
	[SenderEmail] [nvarchar](256) NULL,
	[EmailSubscribe] [bit] NULL,
	[SMSSubscribe] [bit] NULL,
	[BrokerMessage] [nvarchar](max) NULL,
	[ActiveDateFrom] [datetime] NULL,
	[ActiveDateTo] [datetime] NULL,
	[IsActive] [bit] NOT NULL,
	[IsDelete] [bit] NOT NULL,
 CONSTRAINT [PK_Users] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

ALTER TABLE [dbo].[Users] ADD  CONSTRAINT [DF_Users_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[Users] ADD  CONSTRAINT [DF_Users_IsDelete]  DEFAULT ((0)) FOR [IsDelete]
GO


