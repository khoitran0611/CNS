USE [CNS]
GO
CREATE TABLE [dbo].[ArticleDoNotSendClientTypes](
   Id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
   ArticleId BIGINT NOT NULL,
   ClientTypeId INT NOT NULL
)
   