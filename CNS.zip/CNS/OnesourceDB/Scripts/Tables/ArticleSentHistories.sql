USE [CNS]
GO
CREATE TABLE [dbo].[ArticleSentHistories](
 [Id] [bigint] IDENTITY(1,1) NOT NULL PRIMARY KEY,
 [ArticleId] [bigint] NOT NULL,
 [RecipientTypeId] [int] NOT NULL,
 [CreatedDate] [datetime] NOT NULL DEFAULT(0),
 [CreatedUserId] bigint NOT NULL,
 [IsDeleted] [bit] NOT NULL DEFAULT(0)
)