USE [CNS]
GO
CREATE TABLE [dbo].[NewsLetterEmails](
   Id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
   UserId BIGINT NOT NULL,
   ArticleIds NVARCHAR(MAX) NOT NULL,
   CreatedDate datetime NULL,
   CreatedUserId bigint NOT NULL,
   UpdatedDate datetime NULL,
   IsChangable BIT DEFAULT(0) NOT NULL
)
   