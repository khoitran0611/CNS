USE [CNS]
GO
CREATE TABLE [dbo].[URLTrackings](
   Id bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
   ReturnedURL nvarchar(max) NOT NULL,
   CreatedDate datetime NOT NULL 
)
   