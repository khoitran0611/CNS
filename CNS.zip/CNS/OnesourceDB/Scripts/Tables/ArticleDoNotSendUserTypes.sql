USE [CNS]
GO
CREATE TABLE [dbo].[ArticleDoNotSendUserTypes](
   Id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
   ArticleId BIGINT NOT NULL,
   UserTypeId INT NOT NULL
)
   