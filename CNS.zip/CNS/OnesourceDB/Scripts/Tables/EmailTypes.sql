USE [CNS]
GO
CREATE TABLE [dbo].[EmailTypes](
   Id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
   Name nvarchar(150) NOT NULL,
)