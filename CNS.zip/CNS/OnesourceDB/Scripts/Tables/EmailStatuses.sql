USE [CNS]
GO
CREATE TABLE [dbo].[EmailStatuses](
   Id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
   Name nvarchar(150) NOT NULL,
)