USE [CNS]
GO
CREATE TABLE [dbo].[ManualArticleTags](
   Id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
   ArticleId BIGINT NOT NULL,
   TagId INT NOT NULL,
   IsIncluded BIT
)
   