-- =============================================
-- Author:		Peter
-- Create date: 11/06/2018
-- Description:	Get list of role by UserId or UserName
-- =============================================
CREATE PROCEDURE [dbo].[User_FindRoles] 
	@userId int = null,
	@email nvarchar(150) = null
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT r.RoleName,r.Id
	FROM UserRoles ur
		 INNER JOIN Users u ON ur.UserId = u.Id
		 INNER JOIN Roles r ON ur.RoleId = r.Id
	WHERE(u.Id = @userId OR @userId IS NULL) AND (u.Email = @email OR @email IS NULL);
END

GO


