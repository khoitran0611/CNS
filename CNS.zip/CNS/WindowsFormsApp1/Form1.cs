﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //webBrowser1.Navigate("https://giftcards.woolworths.com.au/viewEgiftCard?token=ek1:fe601310b8306a5f8c029548b36dd564&usa=old:e89c158ab076fcef8f452741e867a3d14126cf52c137cc8b16fd1c6c2f5fb398");
            //var br = new WebBrowser();
            //br.ScriptErrorsSuppressed = true;
            //br.DocumentCompleted += (object sender2, WebBrowserDocumentCompletedEventArgs e2) =>
            //{
            //    var brower = sender2 as WebBrowser;
            //    //brower.DocumentText
            //    if (brower.Url == e2.Url)
            //    {
            //        Console.WriteLine("Natigated to {0}", e2.Url);
            //        //Application.ExitThread();   // Stops the thread
            //    }
            //};
            //br.Navigate("https://giftcards.woolworths.com.au/viewEgiftCard?token=ek1:fe601310b8306a5f8c029548b36dd564&usa=old:e89c158ab076fcef8f452741e867a3d14126cf52c137cc8b16fd1c6c2f5fb398");
            //InitializeChromium();
        }

        //public void InitializeChromium()
        //{
        //    CefSettings settings = new CefSettings();
        //    // Initialize cef with the provided settings
        //    Cef.Initialize(settings);
        //    // Create a browser component
            
        //    var chromeBrowser = new ChromiumWebBrowser("http://ourcodeworld.com");
        //    // Add it to the form and fill it to the form window.
        //    this.Controls.Add(chromeBrowser);
        //    chromeBrowser.Dock = DockStyle.Fill;
        //}

        private void button1_Click(object sender, EventArgs e)
        {
            //webBrowser1.Refresh();
            webBrowser1.Navigate(textBox1.Text);
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
