﻿using HtmlAgilityPack;
using InfoCorp.Ico.Senc.Infrastructure.Logging;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace ApptitudeCNS.GetAutomaticData
{
    class Program
    {
        private static ILogger logger { get; set; }
        static string htmlPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "HtmlFiles");

        static void Main(string[] args)
        {
            logger = new Log4NetLogger(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "log4net.config"));
            //ExportExcel();

            //try
            //{
            //    //            ServicePointManager.ServerCertificateValidationCallback +=
            //    //(sender, cert, chain, sslPolicyErrors) => { return true; };
            //    //            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            //    //var link2 = "https://images.medicaldaily.com/sites/medicaldaily.com/files/styles/full_breakpoints_theme_medicaldaily_desktop_1x/public/2018/07/31/polyphenols.jpg";
            //    var link = "https://www.mortgageandfinancehelp.com.au/find-accredited-broker/?query=&location=&expertise=Residential";
            //    DownloadRemoteImageFile(link, $"{AppDomain.CurrentDomain.BaseDirectory}/test.jpg");

            //    //using (var webClient = new WebClientEx())
            //    //{
            //    //    //webClient.Headers["User-Agent"] = "User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36";
            //    //    //webClient.Headers.Add("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
            //    //    //webClient.Headers.Add("Accept-Encoding", "gzip, deflate");
            //    //    //webClient.Headers.Add("Accept-Language", "en-US, en-GB; q=0.7, en; q=0.3");
            //    //    //webClient.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134");

            //    //    var link = "https://images.medicaldaily.com/sites/medicaldaily.com/files/2018/07/31/polyphenols.jpg";

            //    //    //var data = 
            //    //    var file = $"{AppDomain.CurrentDomain.BaseDirectory}test.jpg";
            //    //    webClient.DownloadFile(link, file);
            //    //    //var type = System.Web.MimeMapping.GetMimeMapping(file);
            //    //}

            //}
            //catch (Exception ex)
            //{
            //    logger.LogError(ex.ToString());
            //}

            if (IsExportExcelFiles)
            {
                ExportExcel();
            }
            else
            {
                DownloadHtmlFiles();
            }
        }

        private static void DownloadRemoteImageFile(string uri, string fileName)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            if (request != null)
            {
                request.AllowWriteStreamBuffering = true;
                request.KeepAlive = true;
                request.Timeout = 1000 * 60 * 60;
                request.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8";
                request.Headers.Add("Accept-Encoding", "gzip, deflate");
                request.Headers.Add("Accept-Language", "en-US,en;q=0.9");
                request.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36";
                request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
                //if (IsCookies)
                //    request.CookieContainer = CookieContainer;
            }

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            // Check that the remote file was found. The ContentType
            // check is performed since a request for a non-existent
            // image file might be redirected to a 404-page, which would
            // yield the StatusCode "OK", even though the image was not
            // found.
            if ((response.StatusCode == HttpStatusCode.OK ||
                response.StatusCode == HttpStatusCode.Moved ||
                response.StatusCode == HttpStatusCode.Redirect) &&
                response.ContentType.StartsWith("image", StringComparison.OrdinalIgnoreCase))
            {

                // if the remote file was found, download oit
                using (Stream inputStream = response.GetResponseStream())
                using (Stream outputStream = File.OpenWrite(fileName))
                {
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    do
                    {
                        bytesRead = inputStream.Read(buffer, 0, buffer.Length);
                        outputStream.Write(buffer, 0, bytesRead);
                    } while (bytesRead != 0);
                }
            }
        }

        static bool IsExportExcelFiles
        {
            get
            {
                var value = ConfigurationManager.AppSettings["IsExportExcelFiles"];
                if (string.IsNullOrWhiteSpace(value)) return false;
                return value.Trim() == "1" || value.Trim().ToLower() == "true";
            }
        }
        static void DownloadHtmlFiles()
        {
            var data = new List<BrokerModel>();
            try
            {
                if (!Directory.Exists(htmlPath))
                {
                    Directory.CreateDirectory(htmlPath);
                }


                //CookieContainer cookieJar = new CookieContainer();
                using (var webClient = new WebClientEx())
                //using (var webClient = new WebClient())
                {
                    //webClient.Headers.Add("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
                    //webClient.Headers.Add("Accept-Encoding", "gzip, deflate, br");
                    //webClient.Headers.Add("Accept-Language", "en-US,en;q=0.9");
                    //webClient.Headers.Add("UserAgent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36");

                    webClient.Encoding = System.Text.Encoding.UTF8;
                    //System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Ssl3;
                    var maxLength = int.Parse(ConfigurationManager.AppSettings["MaxLength"]);
                    var index = int.Parse(ConfigurationManager.AppSettings["Index"]);
                    var retryIndexes = new List<int>();
                    for (int i = 0; i < maxLength; i++)
                    {
                        try
                        {
                            //var template = "https://www.mortgageandfinancehelp.com.au/find-accredited-broker/?page={0}&query=&location=";
                            SaveHtmlFiles(Path.Combine(htmlPath, $"{i + index}.html"), i, webClient);
                        }

                        catch (Exception ex)
                        {
                            retryIndexes.Add(i);
                            logger.LogError(ex.ToString());
                        }
                    }
                    retryIndexes = RetryIndexes(htmlPath, webClient, retryIndexes);
                    retryIndexes = RetryIndexes(htmlPath, webClient, retryIndexes);
                }
            }
            catch (Exception e)
            {
                logger.LogError(e.ToString());
            }
            //return data;
        }

        static void SaveHtmlFiles(string htmlFile, int index, WebClient webClient)
        {
            logger.LogInfo("Line " + index.ToString());
            //var link = string.Format(template, i + 1);
            //var link = index > 0 ? $"https://www.mortgageandfinancehelp.com.au/find-accredited-broker/?page={index + 1}&query=&location=" : "https://www.mortgageandfinancehelp.com.au/find-accredited-broker";
            var link = index > 0 ? $"https://www.mortgageandfinancehelp.com.au/find-accredited-broker/?page={index + 1}&query=&location=&expertise=Residential" : "https://www.mortgageandfinancehelp.com.au/find-accredited-broker/?query=&location=&expertise=Residential";

            //var bytes = webClient.DownloadData(link);
            //var test = UTF8Encoding.UTF8.GetString(bytes);
            //Console.WriteLine(webClient.DownloadString(link));
            webClient.DownloadFile(link, htmlFile);
            //File.WriteAllBytes(htmlFile, Encoding.UTF8, webClient.DownloadData(link));
        }

        static List<int> RetryIndexes(string htmlPath, WebClient webClient, List<int> retryIndexes)
        {
            var result = new List<int>();
            foreach (var item in retryIndexes)
            {
                try
                {
                    SaveHtmlFiles(Path.Combine(htmlPath, $"{item + 1}.html"), item, webClient);
                }
                catch (Exception ex)
                {
                    result.Add(item);
                    logger.LogError(ex.ToString());
                }
            }
            return result;
        }

        static List<BrokerModel> GetData()
        {
            var data = new List<BrokerModel>();
            try
            {
                string htmlPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "HtmlFiles");
                if (!Directory.Exists(htmlPath))
                {
                    Directory.CreateDirectory(htmlPath);
                }


                //CookieContainer cookieJar = new CookieContainer();
                //using (var webClient = new WebClientEx(cookieJar))
                //{
                //    var template = "https://www.mortgageandfinancehelp.com.au/find-accredited-broker/?page={0}&query=&location=";
                //    var maxLength = int.Parse(ConfigurationManager.AppSettings["MaxLength"]);
                //    for (int i = 0; i < maxLength; i++)
                //    {
                //        logger.LogInfo("Line " + i.ToString());
                //        var link = string.Format(template, i + 1);
                //        var htmlData = webClient.DownloadData(link);
                foreach (var filePath in Directory.GetFiles(htmlPath))
                {
                    var fileInfo = new FileInfo(filePath);
                    if (fileInfo.Length <= 0) continue;

                    using (var stream = new FileStream(filePath, FileMode.Open))
                    {
                        var duplicatedData = new List<BrokerModel>();
                        var html = new HtmlDocument();
                        html.Load(stream, Encoding.UTF8);
                        var list = html.DocumentNode.Descendants("a").Where(x => x.Id == "reveal_fullprofile");
                        foreach (var node in list)
                        {
                            try
                            {
                                var item = new BrokerModel();
                                var address = HttpUtility.HtmlDecode($"{node.Attributes["data-city"]?.Value.Trim()}, {node.Attributes["data-state"]?.Value.Trim()}");
                                item.ExternalId = HttpUtility.HtmlDecode(node.Attributes["data-external_id"]?.Value.Trim());
                                item.FirstName = HttpUtility.HtmlDecode(node.Attributes["data-preferred_name"]?.Value.Trim());
                                item.LastName = HttpUtility.HtmlDecode(node.Attributes["data-last_name"]?.Value.Trim());
                                item.Address = address;

                                item.Email = HttpUtility.HtmlDecode(node.Attributes["data-email"]?.Value.Trim());
                                item.Phone = HttpUtility.HtmlDecode(node.Attributes["data-phone"]?.Value.Trim());
                                item.Mobile = HttpUtility.HtmlDecode(node.Attributes["data-mobile"]?.Value.Trim());
                                item.Company = HttpUtility.HtmlDecode(node.Attributes["data-company"]?.Value.Trim());

                                //var phones = contactNode.Descendants("a").Where(x => x.GetAttributeValue("href", "").StartsWith("tel:")).ToList();
                                //SetPhones(phones, item);

                                if (data.Any(x => x.ExternalId == item.ExternalId && x.FirstName == item.FirstName))
                                {
                                    duplicatedData.Add(item);
                                }
                                else
                                {
                                    data.Add(item);
                                }
                            }
                            catch (Exception ex)
                            {
                                logger.LogError(ex.ToString());
                            }
                        }
                        //foreach (var node in list.ChildNodes)
                        //{
                        //    if (node.Name != "div") continue;

                        //    try
                        //    {
                        //        var item = new BrokerModel();
                        //        var address = node.Descendants("div").FirstOrDefault(x => x.HasClass("broker-desc-wrapper")).Descendants("p").FirstOrDefault().InnerText;
                        //        item.Name = HttpUtility.HtmlDecode(node.Descendants("h2").FirstOrDefault(x => x.HasClass("broker-name")).InnerText.Trim());
                        //        item.Address = HttpUtility.HtmlDecode(address.Trim().Replace("  ", "").Replace("\n", ", ").Replace(", ,", ",").Replace(", ,", ","));

                        //        var contactNode = node.Descendants("div").FirstOrDefault(x => x.HasClass("broker-contact")).Descendants("p").FirstOrDefault();
                        //        item.Email = HttpUtility.HtmlDecode(contactNode.Descendants("a").FirstOrDefault(x => x.GetAttributeValue("href", "").StartsWith("mailto:")).InnerText.Trim());
                        //        var phones = contactNode.Descendants("a").Where(x => x.GetAttributeValue("href", "").StartsWith("tel:")).ToList();
                        //        SetPhones(phones, item);

                        //        if (data.Any(x => x.Name == item.Name && x.Address == item.Address && x.Email == item.Email && x.Office == item.Office))
                        //        {
                        //            duplicatedData.Add(item);
                        //        }
                        //        else
                        //        {
                        //            data.Add(item);
                        //        }
                        //    }
                        //    catch (Exception ex)
                        //    {
                        //        logger.LogError(ex.ToString());
                        //    }
                        //}
                        if (duplicatedData.Count > 0)
                        {
                            logger.LogInfo($"The duplicated data for {filePath}: {duplicatedData.Count}, {Environment.NewLine} {Newtonsoft.Json.JsonConvert.SerializeObject(duplicatedData)}");
                        }
                    }
                }
                //    }
                //}
            }
            catch (Exception e)
            {
                logger.LogError(e.ToString());
            }
            return data;
        }

        static void SetPhones(List<HtmlNode> phones, BrokerModel item)
        {
            foreach (var node in phones)
            {
                if (string.IsNullOrWhiteSpace(node.InnerText)) continue;
                var phone = HttpUtility.HtmlDecode(node.InnerText).Split(':');
                switch (phone[0].ToLower().Trim())
                {
                    case "office":
                        item.Company = phone[1].Trim();
                        break;
                    case "mobile":
                        item.Mobile = phone[1].Trim();
                        break;
                }
            }
        }

        static void ExportExcel()
        {
            var data = GetData();

            string excelPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ExportExcels");
            if (!Directory.Exists(excelPath))
            {
                Directory.CreateDirectory(excelPath);
            }
            var file = Path.Combine(excelPath, "BrokerExport.xlsx");

            try
            {
                //FileInfo newFile = new FileInfo(pathDownload + "\\BrokerExport.xslx");
                using (var fileStream = new FileStream(file, FileMode.Create))
                {
                    using (var excelFile = new ExcelPackage(fileStream))
                    {
                        var worksheet = excelFile.Workbook.Worksheets.Add("Sheet1");
                        worksheet.Cells["A1"].LoadFromCollection(Collection: data, PrintHeaders: true);
                        worksheet.Cells.AutoFitColumns();
                        excelFile.Save();

                    }
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex.ToString());
            }
        }
    }
}
