﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.GetAutomaticData
{
    public class WebClientEx : WebClient
    {
        public WebClientEx(bool isImage = false, bool isCookies = true, CookieContainer container = null)
        {
            IsImage = isImage;
            IsCookies = isCookies;
            this.CookieContainer = container ?? new CookieContainer();
        }

        public bool IsImage
        {
            get; set;
        }
        public bool IsCookies
        {
            get; set;
        }
        public CookieContainer CookieContainer
        {
            get; set;
        }

        //private CookieContainer container = new CookieContainer();

        protected override WebRequest GetWebRequest(Uri address)
        {
            WebRequest r = base.GetWebRequest(address);
            var request = r as HttpWebRequest;
            if (request != null)
            {
                //request.AllowWriteStreamBuffering = true;
                request.KeepAlive = true;
                request.Timeout = 1000 * 60 * 60;
                request.Accept = "*/*";
                request.Headers.Add("Accept-Encoding", "gzip, deflate");
                request.Headers.Add("Accept-Language", "en-US, en-GB; q=0.7, en; q=0.3");
                request.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134";
                request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
                if (IsCookies)
                    request.CookieContainer = CookieContainer;
            }
            return r;
        }

        protected override WebResponse GetWebResponse(WebRequest request, IAsyncResult result)
        {
            WebResponse response = base.GetWebResponse(request, result);
            response.Headers.Set("Content-Type", "text/xml; charset=UTF-8");
            if (IsCookies)
                ReadCookies(response);
            return response;
        }

        protected override WebResponse GetWebResponse(WebRequest request)
        {
            WebResponse response = base.GetWebResponse(request);
            response.Headers.Set("Content-Type", "text/xml; charset=UTF-8");
            if (IsCookies)
                ReadCookies(response);
            return response;
        }

        private void ReadCookies(WebResponse r)
        {
            var response = r as HttpWebResponse;
            if (response != null && IsCookies)
            {
                CookieCollection cookies = response.Cookies;
                CookieContainer.Add(cookies);
            }
        }
    }
}
