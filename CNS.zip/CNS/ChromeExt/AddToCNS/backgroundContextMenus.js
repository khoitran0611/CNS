chrome.runtime.onInstalled.addListener(function () {
    chrome.contextMenus.create({
        "id": "add-to-CNS",
        "title": "Add to CNS",
        "contexts": ["all"]
    });

    // Set default settings
    chrome.storage.local.set({
        settings: {
            envTypeUrls: ["http://cns.apptitude.com.vn/Article", "N/a", "http://cns.proinspectapp.com/Article"],
            selectedEnvType: 2,
            textId: "searchText",
            buttonId: "buttonSearch"
        }
    });

    chrome.browserAction.setBadgeText({ text: "PRO" });
});

chrome.contextMenus.onClicked.addListener(function onClickedHanlder() {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        var activeTab = tabs[0];
        chrome.storage.local.get(function (data) {
            var envUrl = data.settings.envTypeUrls[data.settings.selectedEnvType];
            chrome.windows.create({
                url: envUrl,
                type: "normal",
                state: "maximized"
            }, function (newWindow) { // Create new window
                chrome.tabs.executeScript(newWindow.tabs[0].id, { file: "content.js" }, function () { // Excecute Content script in tab[0]
                    chrome.tabs.sendMessage(newWindow.tabs[0].id, {
                        message: "open_new_tab",
                        url: activeTab.url
                    });
                });
            })
        });
    });
});

chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        if (request.message === "change_env") {
            chrome.browserAction.setBadgeText({ text: request.badgeText });
        }
    }
);