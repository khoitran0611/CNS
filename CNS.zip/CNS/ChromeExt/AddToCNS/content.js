chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        if (request.message === "open_new_tab") {
            chrome.storage.local.get(function (data) {
                document.getElementById(data.settings.textId).value = request.url;
                document.getElementById(data.settings.buttonId).click();
            });
        }
    }
);