$(document).ready(function () {
  // Load settings
  chrome.storage.local.get(function (data) {
    $("input[name='environment']").eq(data.settings.selectedEnvType).prop("checked", true);
    $("#env-dev").val(data.settings.envTypeUrls[0]);
    $("#env-uat").val(data.settings.envTypeUrls[1]);
    $("#env-pro").val(data.settings.envTypeUrls[2]);
    $("#text-id").val(data.settings.textId);
    $("#button-id").val(data.settings.buttonId);
  });

  // Save settings
  $("#save-settings").click(function () {
    var envTexts = ["DEV", "UAT", "PRO"];
    var selectedEnvType = $("input[name='environment']:checked").val();

    chrome.storage.local.set({
      settings: {
        envTypeUrls: [
          $("#env-dev").val().trim(),
          $("#env-uat").val().trim(),
          $("#env-pro").val().trim()
        ],
        selectedEnvType: selectedEnvType,
        textId: $("#text-id").val().trim(),
        buttonId: $("#button-id").val().trim()
      }
    }, function () {
      chrome.runtime.sendMessage({
        message: "change_env",
        badgeText: envTexts[selectedEnvType]
      });
      window.close();
    });
  });
});
