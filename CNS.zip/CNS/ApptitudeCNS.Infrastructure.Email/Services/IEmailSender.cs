﻿namespace ApptitudeCNS.Infrastructure.Email.Services
{
    public interface IEmailSender
    {
        /// <summary>
        /// Sends an email. Attachment file name. If specified, then this file name will be sent to a recipient. Otherwise, "AttachmentFilePath" name will be used.
        /// </summary>
        void SendEmail(string toAddress, string subject, string body, string attachmentFilePath = null, string attachmentFileName = null);
    }
}
