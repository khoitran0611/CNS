﻿using System;
using System.IO;
using System.Linq;
using ApptitudeCNS.Infrastructure.Email.Domain.EmailTemplates;
using RazorEngine;
using RazorEngine.Templating;

namespace ApptitudeCNS.Infrastructure.Email.Services
{
    public class EmailService : IEmailService
    {
        //private readonly IEmailSender _emailSender;

        public EmailService()//IEmailSender emailSender)
        {
            //_emailSender = emailSender;
        }

        public string GetEmailHtml<T>(T templateModel, string templateName = null) where T : EmailTemplateViewModelBase
        {
            string templatePath = Directory.GetDirectories(AppDomain.CurrentDomain.BaseDirectory, "EmailTemplates", SearchOption.AllDirectories).ToList()[0];

            string templateFilenamePath = Path.Combine(templatePath, (templateName ?? templateModel.GetType().Name.Replace("ViewModel", "")) + ".cshtml");
            string razorBody = File.ReadAllText(templateFilenamePath);
            string body = Engine.Razor.RunCompile(razorBody, Guid.NewGuid().ToString(), null, templateModel);
 
            return body;
        }

        //public void SendEMail<T>(T templateModel) where T : EmailTemplateViewModelBase
        //{
        //    string body = GetEmailHtml(templateModel);
        //    _emailSender.SendEmail(templateModel.ToMail, templateModel.Subject, body);
        //}
    }
}
