﻿using ApptitudeCNS.Infrastructure.Email.Domain.EmailTemplates;

namespace ApptitudeCNS.Infrastructure.Email.Services
{
    public interface IEmailService
    {
        string GetEmailHtml<T>(T templateModel, string templateName = null) where T : EmailTemplateViewModelBase;

        //void SendEMail<T>(T templateModel) where T : EmailTemplateViewModelBase;
    }
}
