﻿using System.IO;
using System.Net;
using System.Net.Mail;

namespace ApptitudeCNS.Infrastructure.Email.Services
{
    public class EmailSender : IEmailSender
    {
        public string Host { get; }
        public int Port { get; }
        public string Username { get; }
        public string Password { get; }

        public EmailSender() { }

        public EmailSender(string host, int port, string username, string password)
        {
            Host = host;
            Port = port;
            Username = username;
            Password = password;
        }

        public virtual void SendEmail(string toAddress, string subject, string body,
                    string attachmentFilePath = null, string attachmentFileName = null)
        {
            MailMessage message = new MailMessage();

            // From, to
            message.From = new MailAddress(Username);
            message.To.Add(new MailAddress(toAddress));

            // Content
            message.Subject = subject;
            message.Body = body;

            // Create the file attachment for this e-mail message
            if (!string.IsNullOrEmpty(attachmentFilePath) && File.Exists(attachmentFilePath))
            {
                Attachment attachment = new Attachment(attachmentFilePath);
                attachment.ContentDisposition.CreationDate = File.GetCreationTime(attachmentFilePath);
                attachment.ContentDisposition.ModificationDate = File.GetLastWriteTime(attachmentFilePath);
                attachment.ContentDisposition.ReadDate = File.GetLastAccessTime(attachmentFilePath);
                if (!string.IsNullOrEmpty(attachmentFileName))
                {
                    attachment.Name = attachmentFileName;
                }
                message.Attachments.Add(attachment);
            }

            message.IsBodyHtml = true;

            // Send email
            using (var smtpClient = new SmtpClient())
            {
                smtpClient.Host = Host;
                smtpClient.Port = Port;
                smtpClient.EnableSsl = true;
                smtpClient.Credentials = new NetworkCredential(Username, Password);
                smtpClient.Send(message);
            }
        }
    }
}