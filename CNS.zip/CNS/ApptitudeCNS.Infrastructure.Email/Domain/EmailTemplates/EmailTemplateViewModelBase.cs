﻿using ApptitudeCNS.Helpers;
using System.Web;

namespace ApptitudeCNS.Infrastructure.Email.Domain.EmailTemplates
{
    public abstract class EmailTemplateViewModelBase
    {
        // public string LogoLink { get; set; }

        // public string SiteName { get; set; }

        //public string ToMail { get; set; }

        public string Subject { get; set; }

        public long ClientId { get; set; }
        public string EncryptClientId
        {
            get
            {
                return Encryption.Base64EncodeUrl(ClientId.ToString());
            }
        }

        //public long UserId { get; set; }
        //public string EncryptUserId
        //{
        //    get
        //    {
        //        return Encryption.Base64EncodeUrl(UserId.ToString());
        //    }
        //}

        public string ImageReadEmailUrl { get { return ClientId > 0 ? ConfigManager.ImageReadEmailUrl : ConfigManager.UserImageReadEmailUrl; } }
        //public string UserImageReadEmailUrl { get { return ConfigManager.UserImageReadEmailUrl; } }

        public string Url { get; set; }
        public string UnsubscribeControllerAction { get { return ArticleConstants.UNSUBSCRIBE_CONTROLLER_ACTION; } }
    }
}
