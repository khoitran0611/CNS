﻿using System.Collections.Generic;

namespace ApptitudeCNS.Infrastructure.Email.Domain.EmailTemplates
{
    public class LowestLendersViewModel : EmailTemplateViewModelBase
    {
        public LowestLendersViewModel(IList<LowestLenderViewModel> lowestLenderViewModels)
        {
            Subject = "Lowest Lenders";
            LowestLenderViewModels = lowestLenderViewModels;
        }

        public IList<LowestLenderViewModel> LowestLenderViewModels { get; }
    }

    public class LowestLenderViewModel
    {
        public string LenderName { get; set; }

        public RateCellViewModel VariableRate { get; set; }

        public RateCellViewModel FixedRate1Y { get; set; }
        public RateCellViewModel FixedRate2Y { get; set; }
        public RateCellViewModel FixedRate3Y { get; set; }
        public RateCellViewModel FixedRate4Y { get; set; }
        public RateCellViewModel FixedRate5Y { get; set; }
    }

    public class RateCellViewModel
    {
        public decimal Value { get; set; }
        public virtual string DisplayValue
        {
            get
            {
                return Value.ToString();
            }
        }

        public string Style
        {
            get
            {
                if (HasRedColor)
                {
                    return "background-color: red";
                }

                return "";
            }
        }

        public bool HasRedColor { get; set; }
    }

    public class NullRateCellViewModel : RateCellViewModel
    {
        public NullRateCellViewModel()
        {
            Value = decimal.MaxValue;
        }

        public override string DisplayValue
        {
            get
            {
                return "-";
            }
        }
    }
}
