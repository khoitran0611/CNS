﻿using ApptitudeCNS.Helpers;
using System;
using System.Collections.Generic;
using System.Web;

namespace ApptitudeCNS.Infrastructure.Email.Domain.EmailTemplates
{
    public class MailArticlesViewModel : EmailTemplateViewModelBase
    {
        //public string Subject { get; set; }
        public string PrimaryColor { get; set; }
        public string SecondaryColor { get; set; }
        //public string Salutation { get; set; }

        public string Logo { get; set; }
        public int? LogoPositionType { get; set; }
        public string LogoPositionTypeName
        {
            get
            {
                if (LogoPositionType == (int)EnumLogoPositionType.Right) return EnumLogoPositionType.Right.ToString().ToLower();
                return EnumLogoPositionType.Left.ToString().ToLower();
            }
        }

        public string ViewOnlineCss
        {
            get
            {
                if (LogoPositionType == (int)EnumLogoPositionType.Right) return EnumLogoPositionType.Left.ToString().ToLower();
                return EnumLogoPositionType.Right.ToString().ToLower();
            }
        }
        
        public string Address { get; set; }
        public string Company { get; set; }
        public string Phone { get; set; }
        public string FormatPhone
        {
            get
            {
                return PhoneHelper.FormatPhone(Phone);
            }
        }

        public string BrokerMessage { get; set; }

        public string ABN { get; set; }

        public string GooglePlusLink { get; set; }
        public string FacebookLink { get; set; }
        public string TwitterLink { get; set; }
        public string LinkedinLink { get; set; }
        public string WebsiteLink { get; set; }

        public string GooglePlusLinkDisplay
        {
            get
            {
                return string.IsNullOrWhiteSpace(GooglePlusLink) ? "none" : "block";
            }
        }

        public string FacebookLinkDisplay
        {
            get
            {
                return string.IsNullOrWhiteSpace(FacebookLink) ? "none" : "block";
            }
        }

        public string TwitterLinkDisplay
        {
            get
            {
                return string.IsNullOrWhiteSpace(TwitterLink) ? "none" : "block";
            }
        }

        public string LinkedinLinkDisplay
        {
            get
            {
                return string.IsNullOrWhiteSpace(LinkedinLink) ? "none" : "block";
            }
        }

        public string WebsiteLinkDisplay
        {
            get
            {
                return string.IsNullOrWhiteSpace(WebsiteLink) ? "none" : "block";
            }
        }

        public string LeftFooter
        {
            get
            {
                return CommonHelper.GetUserLeftFooterValue(Phone, Company);
                //var result = string.Empty;
                //var formatPhone = FormatPhone;
                //if (!string.IsNullOrWhiteSpace(Company) && !string.IsNullOrWhiteSpace(formatPhone))
                //{
                //    result = $"{Company} - Phone: {formatPhone}";
                //}
                //else if (!string.IsNullOrWhiteSpace(Company))
                //{
                //    result = $"{Company}";
                //}
                //else if (!string.IsNullOrWhiteSpace(formatPhone))
                //{
                //    result = $"Phone: {formatPhone}";
                //}

                //return result;
            }
        }

        public string GooglePlusIcon
        {
            get
            {
                var fileName = HttpUtility.UrlEncode($"{CNSConstant.GOOGLE_PLUS_ICON}{SecondaryColor}{CNSConstant.SOCIAL_ICON_EXTENSION}");
                return $"{CNSConstant.SOCIAL_ICON_PATH.Substring(2)}/{fileName}";
            }
        }

        public string FacebookIcon
        {
            get
            {
                var fileName = HttpUtility.UrlEncode($"{CNSConstant.FACEBOOK_ICON}{SecondaryColor}{CNSConstant.SOCIAL_ICON_EXTENSION}");
                return $"{CNSConstant.SOCIAL_ICON_PATH.Substring(2)}/{fileName}";
            }
        }

        public string TwitterIcon
        {
            get
            {
                var fileName = HttpUtility.UrlEncode($"{CNSConstant.TWITTER_ICON}{SecondaryColor}{CNSConstant.SOCIAL_ICON_EXTENSION}");
                return $"{CNSConstant.SOCIAL_ICON_PATH.Substring(2)}/{fileName}";
            }
        }

        public string LinkedinIcon
        {
            get
            {
                var fileName = HttpUtility.UrlEncode($"{CNSConstant.LINKEDIN_ICON}{SecondaryColor}{CNSConstant.SOCIAL_ICON_EXTENSION}");
                return $"{CNSConstant.SOCIAL_ICON_PATH.Substring(2)}/{fileName}";
            }
        }

        public string WebsiteIcon
        {
            get
            {
                var fileName = HttpUtility.UrlEncode($"{CNSConstant.WEBSITE_ICON}{SecondaryColor}{CNSConstant.SOCIAL_ICON_EXTENSION}");
                return $"{CNSConstant.SOCIAL_ICON_PATH.Substring(2)}/{fileName}";
            }
        }

        public string ControllerAction
        {
            get { return ArticleConstants.CONTROLLER_ACTION; }
        }

        public string NewsLetterEmailControllerAction
        {
            get { return ArticleConstants.NEWS_LETTER_EMAIL_CONTROLLER_ACTION; }
        }

        public string ViewEmailControllerAction
        {
            get { return ArticleConstants.VIEW_EMAIL_CONTROLLER_ACTION; }
        }

        public string PictureFolder
        {
            get { return ArticleConstants.UPLOADED_PICTURE_FOLDER.Substring(2); }
        }

        public string UserLogoFolder
        {
            get { return UserConstants.UPLOADED_LOGO_PHOTO_FOLDER.Substring(2); }
        }

        //public string ArticleImage
        //{
        //    get { return ArticleConstants.ARTICLE_EMAIL_TEMPLATE_IMAGE.Substring(2); }
        //}

        public string ArticleImage { get; set; }
        public bool IsPreSent { get; set; }

        public long NewsLetterEmailId { get; set; }
        public string EncryptNewsLetterEmailId
        {
            get
            {
                return Encryption.Base64EncodeUrl(NewsLetterEmailId.ToString());
            }
        }

        public MailArticlesViewModel(IList<MailArticleViewModel> mailArticlesViewModels)
        {
            MailArticlesViewModels = mailArticlesViewModels;
            //IsPreSent = isPreSent;
        }

        public IList<MailArticleViewModel> MailArticlesViewModels { get; set; }
    }

    public class MailArticleViewModel
    {
        //public string Subject { get; set; }
        public string Title { get; set; }
        public DateTime ArticleDate { get; set; }
        public string ArticleDateDisplay
        {
            get
            {
                return ArticleDate.ToString("dd/MM/yyyy");
            }
        }

        //public long LinkId { get; set; }
        public long Id { get; set; }
        public string EncryptId
        {
            get
            {
                return Encryption.Base64EncodeUrl(Id.ToString());
            }
        }
        //public string EncryptLinkId
        //{
        //    get
        //    {
        //        return string.Empty;
        //        //return Encryption.Base64EncodeUrl(LinkId.ToString());
        //    }
        //}

        public string Summary { get; set; }
        public string ShortSummary
        {
            get
            {
                return CommonHelper.KeepABlankLine(CommonHelper.GetWordsForEmail(Summary));
            }
        }
        public string Picture { get; set; }
        public string Link { get; set; }
        public string Author { get; set; }
        public string SiteName { get; set; }
        public string Organisation { get; set; }
        public string BrokerMessage { get; set; }

        public string RightItemText
        {
            get
            {
                var result = string.Empty;
                if (!string.IsNullOrWhiteSpace(Author) && !string.IsNullOrWhiteSpace(SiteName))
                {
                    return $"{Author}<br />{SiteName}";
                }

                if (!string.IsNullOrWhiteSpace(Author) && !string.IsNullOrWhiteSpace(Organisation))
                {
                    return $"{Author}<br />{Organisation}";
                }

                if (!string.IsNullOrWhiteSpace(SiteName) && !string.IsNullOrWhiteSpace(Organisation))
                {
                    return $"{SiteName}<br />{Organisation}";
                }

                return $"{Author}{SiteName}{Organisation}";
            }
        }
    }
}
