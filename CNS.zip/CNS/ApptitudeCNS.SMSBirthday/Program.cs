﻿using ApptitudeCNS.Application.Clients;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using ApptitudeCNS.Infrastructure.Persistence.DbContext;
using ApptitudeCNS.Infrastructure.Sms.Services;
using Autofac;
using InfoCorp.Ico.Senc.Infrastructure.Logging;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.SMSBirthday
{
    class Program
    {
        //private static IContainer Container { get; set; }
        private static IClientApp clientApp { get; set; }
        private static ILogger logger { get; set; }

        static void Main(string[] args)
        {
            try
            {
                DependencyRegisterConfig();
                logger.LogInfo("Successfully");
            }
            catch (Exception ex)
            {
                logger.LogError(ex.ToString());
            }
        }

        static void DependencyRegisterConfig()
        {
            var builder = new ContainerBuilder();

            // Data layer
            builder.Register<IDbContext>(c => new EfDbContext(ConfigurationManager.ConnectionStrings["CNS"].ConnectionString)).InstancePerLifetimeScope();
            builder.RegisterGeneric(typeof(EfGenericRepository<>)).As(typeof(IGenericRepository<>)).InstancePerLifetimeScope();
            builder.RegisterType<ClientApp>().As<IClientApp>().InstancePerLifetimeScope();

            builder.Register<ISmsService>(n => new TransmitSmsService(
                ConfigurationManager.AppSettings["SmsApiKey"],
                ConfigurationManager.AppSettings["SmsApiSecret"])).InstancePerLifetimeScope();
            builder.Register<ILogger>(n => new Log4NetLogger(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "log4net.config"))).SingleInstance();

            var container = builder.Build();
            using (var scope = container.BeginLifetimeScope())
            {
                logger = scope.Resolve<ILogger>();
                clientApp = scope.Resolve<IClientApp>();
                SendSMSBirthday();
                //app.Run();
            }
        }

        static void SendSMSBirthday()
        {
            clientApp.SendSMSBirthday();
        }
    }
}
