﻿using ApptitudeCNS.Application.Articles;
using ApptitudeCNS.Application.MailTrackings;
using ApptitudeCNS.Application.Tags;
using ApptitudeCNS.Application.UserMailTrackings;
using ApptitudeCNS.Application.ViewModel;
using ApptitudeCNS.Core.IRepository;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Infrastructure.Email.Services;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using ApptitudeCNS.Infrastructure.Persistence.DbContext;
using Autofac;
using Bp.Infrastructure.Persistence.Repositories;
using InfoCorp.Ico.Senc.Infrastructure.Logging;
using Newtonsoft.Json;
using NLog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Hosting;

namespace ApptitudeCNS.SendMail
{
    class Program
    {
        //private static IContainer Container { get; set; }
        private static IMailTrackingApp mailTrackingApp { get; set; }
        private static IUserMailTrackingApp userMailTrackingApp { get; set; }
        //private static ILogger logger { get; set; }
        private static Logger logger = LogManager.GetCurrentClassLogger();
        private const string ProinspectHistoryNoteTemplate = @"INSERT dbo.Child_UserInfoChangeLog
                            ( ChildUserID ,
                                LogDate ,
                                Page ,
		                        PageReferral ,
		                        IPAdress ,
		                        UserAgent ,
                                TriggerEvent ,
                                Author ,
                                Notes ,
                                IsPinnedNote
                            )
                    VALUES  ( {0} , -- ChildUserID - bigint
                              GETDATE() , -- LogDate - datetime
                              N'http://cns.proinspectapp.com' , -- Page - nvarchar(200)
                              N'http://cns.proinspectapp.com' , -- PageReferral - nvarchar(200)
                              N'40.115.78.221' , -- IPAdress - nvarchar(200)
                              N'CNS' , -- UserAgent - nvarchar(200)
                              105, -- TriggerEvent - int
                              {1} , -- Author - bigint
                              N'{2}' , -- Notes - nvarchar(max)
                              0  -- IsPinnedNote - bit
                            )";

        private const string BrokerpediaHistoryNoteTemplate = @"INSERT dbo.UserHistory
                                ( UserID ,
                                  LogDate ,
                                  Page ,
                                  PageReferral ,
                                  IPAdress ,
                                  UserAgent ,
                                  TriggerEvent ,
                                  Author ,
                                  Notes ,
                                  IsPinnedNote
                                )
                        VALUES  ({0} , -- UserID - bigint
                                  GETDATE() , -- LogDate - datetime
								  N'http://cns.proinspectapp.com' , -- Page - nvarchar(200)
								  N'http://cns.proinspectapp.com' , -- PageReferral - nvarchar(200)
								  N'40.115.78.221' , -- IPAdress - nvarchar(200)
								  N'CNS' , -- UserAgent - nvarchar(200)
                                  6 , -- TriggerEvent - int
                                  {1} , -- Author - bigint
                                  N'{2}', -- Notes - nvarchar(max)
                                  0  -- IsPinnedNote - bit
								  )";

        static void Main(string[] args)
        {
            try
            {
                DependencyRegisterConfig();
                logger.Info("Successfully");
            }
            catch (Exception ex)
            {
                logger.Error(ex.ToString());
            }
        }

        static void DependencyRegisterConfig()
        {
            var builder = new ContainerBuilder();

            // Data layer
            builder.Register<IDbContext>(c => new EfDbContext(ConfigurationManager.ConnectionStrings["CNS"].ConnectionString)).InstancePerLifetimeScope();
            builder.RegisterGeneric(typeof(EfGenericRepository<>)).As(typeof(IGenericRepository<>)).InstancePerLifetimeScope();
            builder.RegisterType<MailTrackingApp>().As<IMailTrackingApp>().InstancePerLifetimeScope();
            builder.RegisterType<UserMailTrackingApp>().As<IUserMailTrackingApp>().InstancePerLifetimeScope();
            builder.RegisterType<ArticleApp>().As<IArticleApp>().InstancePerLifetimeScope();
            builder.RegisterType<TagApp>().As<ITagApp>().InstancePerLifetimeScope();
            builder.RegisterType<EmailService>().As<IEmailService>().InstancePerLifetimeScope();
            builder.Register<IBpNoiseWordRepository>(n => new BpNoiseWordRepository(new EfDbContext(ConfigurationManager.ConnectionStrings["OneSource"].ConnectionString))).InstancePerLifetimeScope();
            //builder.Register<ILogger>(n => new Log4NetLogger(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "log4net.config"))).SingleInstance();

            var container = builder.Build();
            using (var scope = container.BeginLifetimeScope())
            {
                //logger = scope.Resolve<ILogger>();
                mailTrackingApp = scope.Resolve<IMailTrackingApp>();
                userMailTrackingApp = scope.Resolve<IUserMailTrackingApp>();
                SendClientEmail();
                SendUserEmail();
                //app.Run();
            }
        }

        static void SendClientEmail()
        {
            List<MailSendingViewModel> list = null;
            do
            {
                list = mailTrackingApp.GetMailSendingList();
                SendEmail(list, true);
                mailTrackingApp.UpdateMailSendingList(list);
                try
                {
                    //var bpSystemChildUserId = ConfigManager.BpSystemChildUserId;
                    //var proinspectUserId = ConfigManager.ProinspectUserId;
                    if (ConfigManager.BpSystemChildUserId <= 0 || !list.Any(x => x.BrokerRefNo > 0 || x.BrokerUserNo > 0))
                        return;

                    var commandText = string.Join(Environment.NewLine, list.Where(x => x.BrokerRefNo > 0).Select(x =>
                        string.Format(ProinspectHistoryNoteTemplate, x.BrokerRefNo, ConfigManager.BpSystemChildUserId,
                        string.Format("CNS Email sent {0}{2}{1}", x.Status == EnumEmailStatusType.Failed ? ": Fail" : "Successfully", x.Subject.Replace("'", "''").Trim(), Environment.NewLine))));

                    ExecuteNonQueryBrokerpedia(commandText);

                    //var author = 88895622;
                    commandText = string.Join(Environment.NewLine, list.Where(x => x.BrokerUserNo > 0).Select(x =>
                        string.Format(BrokerpediaHistoryNoteTemplate, x.BrokerUserNo, ConfigManager.BpSystemChildUserId,
                        string.Format("CNS Email sent {0}{2}{1}", x.Status == EnumEmailStatusType.Failed ? ": Fail" : "Successfully", x.Subject.Replace("'", "''").Trim(), Environment.NewLine))));

                    ExecuteNonQueryBrokerpedia(commandText);
                }
                catch (Exception ex)
                {
                    logger.Error(ex.ToString());
                }
            } while (list != null && list.Count > 0);

        }

        static void ExecuteNonQueryBrokerpedia(string commandText)
        {
            if (string.IsNullOrWhiteSpace(commandText)) return;

            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["OneSource"].ConnectionString))
            {
                connection.Open();
                if (!string.IsNullOrWhiteSpace(commandText))
                {
                    using (var command = new SqlCommand(commandText, connection))
                    {
                        command.CommandTimeout = 10 * 60;
                        command.ExecuteNonQuery();
                    }
                }
            }
        }

        static void SendUserEmail()
        {
            List<MailSendingViewModel> list = null;
            do
            {
                list = userMailTrackingApp.GetMailSendingList();
                SendEmail(list);
                userMailTrackingApp.UpdateMailSendingList(list);

                try
                {
                    var author = 88895622;
                    var commandText = string.Join(Environment.NewLine, list.Where(x => x.BrokerRefNo > 0 && x.SendSampleEmailType > 0).Select(x =>
                        string.Format(x.SendSampleEmailType.Value == (int)EnumSendSampleEmailType.Proinspect ? ProinspectHistoryNoteTemplate : BrokerpediaHistoryNoteTemplate,
                        x.BrokerRefNo, author, string.Format("Sent sample newsletter email \"{0}\"", x.Subject.Replace("'", "''").Trim(), Environment.NewLine))));
                    ExecuteNonQueryBrokerpedia(commandText);
                }
                catch (Exception ex)
                {
                    logger.Error(ex.ToString());
                }

            } while (list != null && list.Count > 0);
        }

        static void SendEmail(List<MailSendingViewModel> list, bool isClient = false)
        {
            foreach (var item in list)
            {
                try
                {
                    var mailMessage = new System.Net.Mail.MailMessage();
                    mailMessage.From = new System.Net.Mail.MailAddress(item.BrokerEmail, item.BrokerName);

                    if (ConfigManager.IsDevEnvironment)
                    {
                        mailMessage.Subject = $"{ConfigManager.EmailTitle} - {item.Subject?.Trim().Replace("\n", "").Replace("\r", "")} [{item.RecipientEmail}]";
                        MailHelper.AddMailMessageTo(mailMessage, ConfigManager.TestEmail);
                    }
                    else
                    {
                        mailMessage.Subject = item.Subject?.Trim().Replace("\n", "").Replace("\r", "");
                        mailMessage.To.Add(new System.Net.Mail.MailAddress(item.RecipientEmail, item.RecipientName));
                        MailHelper.AddMailMessageBcc(mailMessage, ConfigManager.TestEmail);
                    }
                    mailMessage.IsBodyHtml = true;
                    if (isClient)
                    {
                        mailMessage.Body = item.Content.Replace("{MailId}", Encryption.Base64EncodeUrl(item.Id.ToString())).Replace("{ClientId}", Encryption.Base64EncodeUrl(item.ClientId.ToString()));
                    }
                    else
                    {
                        mailMessage.Body = item.Content.Replace("{UserMailId}", Encryption.Base64EncodeUrl(item.Id.ToString()));
                    }
                    MailHelper.SendMail(mailMessage);
                    item.Status = EnumEmailStatusType.Sent;
                }
                catch (Exception ex)
                {
                    item.Status = EnumEmailStatusType.Failed;
                    item.ErrorNote = ex.Message;
                    logger.Error(JsonConvert.SerializeObject(item) + ex.ToString());
                }
            }
        }
    }
}
