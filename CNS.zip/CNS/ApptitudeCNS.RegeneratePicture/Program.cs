﻿using ApptitudeCNS.Application.Articles;
using ApptitudeCNS.Application.Clients;
using ApptitudeCNS.Application.Users;
using ApptitudeCNS.Core;
using ApptitudeCNS.Core.IRepository;
using ApptitudeCNS.Helpers;
using ApptitudeCNS.Infrastructure.Persistence.Core.DbContextBase;
using ApptitudeCNS.Infrastructure.Persistence.Core.Repository;
using ApptitudeCNS.Infrastructure.Persistence.DbContext;
using ApptitudeCNS.Infrastructure.Persistence.Repositories;
using Autofac;
using Bp.Infrastructure.Persistence.Repositories;
using InfoCorp.Ico.Senc.Infrastructure.Logging;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApptitudeCNS.RegeneratePicture
{
    class Program
    {
        private static IUserApp userApp { get; set; }
        private static IArticleApp articleApp { get; set; }
        private static ILogger logger { get; set; }

        static void Main(string[] args)
        {
            try
            {
                //WebBrowser browser = new WebBrowser();
                //browser.Navigate("http://www.iana.org/domains/example/");
                //HtmlDocument doc = browser.Document;
                runBrowserThread(new Uri("https://docs.microsoft.com/en-us/dotnet/framework/winforms/controls/how-to-add-web-browser-capabilities-to-a-windows-forms-application"));
                Console.ReadLine();
                //runBrowserThread(new Uri("https://giftcards.woolworths.com.au/viewEgiftCard?token=ek1:fe601310b8306a5f8c029548b36dd564&usa=old:e89c158ab076fcef8f452741e867a3d14126cf52c137cc8b16fd1c6c2f5fb398"));
                //doc.InvokeScript("someScript");
                //Console.WriteLine(doc.ToString());
                //var colorList = new string[] { "#654545", "#daa520", "#8b8b8b", "#3e81be", "#636366", "#ffffff", "#8b8b8b", "#3b3830", "#335599", "#c2dad3", "#000000" };

                //var oldColor = ColorTranslator.FromHtml("#3FA1DA");
                //ChangeColor("facebook-icon.png", oldColor, colorList);
                //ChangeColor("google-plus-icon.png", oldColor, colorList);
                //ChangeColor("linkedin-icon.png", oldColor, colorList);
                //ChangeColor("twitter-icon.png", oldColor, colorList);
                //ChangeColor("website-icon.png", oldColor, colorList);

                //DependencyRegisterConfig();
                //logger.LogInfo("Successfully");
            }
            catch (Exception ex)
            {
                logger.LogError(ex.ToString());
            }
        }

        static private void runBrowserThread(Uri url)
        {
            //TextBox textBox1 = new TextBox();
            //textBox1.BeginInvoke(new Action(() =>
            //{
            //    var wb = new WebBrowser();
            //    wb.ScriptErrorsSuppressed = true;
            //    wb.DocumentCompleted += (cur_sender, cur_e) =>
            //    {
            //        var cur_wb = cur_sender as WebBrowser;
            //        if (cur_wb.Url == cur_e.Url)
            //        {
            //            //textBox1.AppendText("Task " + tmp + ", navigated to " + cur_e.Url + Environment.NewLine);
            //            //completed_count++;
            //        }
            //    };
            //    wb.Navigate("https://stackoverflow.com/questions/4269800/webbrowser-control-in-a-new-thread");
            //}
            //));

            var th = new Thread(() =>
            {
                var br = new WebBrowser();
                br.ScriptErrorsSuppressed = true;
                br.DocumentCompleted += (object sender, WebBrowserDocumentCompletedEventArgs e) =>
                {
                    var brower = sender as WebBrowser;
                    if (brower.Url == e.Url)
                    {
                        Console.WriteLine("Natigated to {0}", e.Url);
                        //Application.ExitThread();   // Stops the thread
                    }
                };
                br.Navigate(url);
                //Application.Run();
            });
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        static void browser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            var br = sender as WebBrowser;
            if (br.Url == e.Url)
            {
                Console.WriteLine("Natigated to {0}", e.Url);
                //Application.ExitThread();   // Stops the thread
            }
        }

        static void DependencyRegisterConfig()
        {
            var builder = new ContainerBuilder();

            // Data layer
            builder.Register<IDbContext>(c => new EfDbContext(ConfigurationManager.ConnectionStrings["CNS"].ConnectionString)).InstancePerLifetimeScope();
            builder.RegisterGeneric(typeof(EfGenericRepository<>)).As(typeof(IGenericRepository<>)).InstancePerLifetimeScope();
            builder.RegisterType<ArticleApp>().As<IArticleApp>().InstancePerLifetimeScope();
            builder.RegisterType<UserApp>().As<IUserApp>().InstancePerLifetimeScope();
            builder.RegisterType<UserRepository>().As<IUserRepository>().InstancePerLifetimeScope();
            builder.RegisterType<RoleRepository>().As<IRoleRepository>().InstancePerLifetimeScope();
            builder.Register<IBpAggregatorRepository>(n => new BpAggregatorRepository(new EfDbContext(ConfigurationManager.ConnectionStrings["OneSource"].ConnectionString))).InstancePerLifetimeScope();

            builder.Register<ILogger>(n => new Log4NetLogger(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "log4net.config"))).SingleInstance();

            var container = builder.Build();
            using (var scope = container.BeginLifetimeScope())
            {
                logger = scope.Resolve<ILogger>();
                articleApp = scope.Resolve<IArticleApp>();
                userApp = scope.Resolve<IUserApp>();
                UpdateArticlePictureList();
                UpdateUserLogoList();
                //app.Run();
            }
        }

        static void UpdateArticlePictureList()
        {
            var list = articleApp.GetArticlePictureList();
            var dictionaryInfo = new DirectoryInfo(ConfigManager.RegenerateArticlePictureFolder);
            var files = dictionaryInfo.GetFiles().Where(x => !x.FullName.StartsWith(CNSConstant.THUMBNAIL_NAME)).OrderByDescending(x => x.LastAccessTime);
            foreach (var item in list)
            {
                var filePath = Path.Combine(ConfigManager.RegenerateArticlePictureFolder, item);
                if (File.Exists(filePath))
                {
                    var originalFilePath = Path.Combine(ConfigManager.RegenerateArticlePictureFolder, item.Substring(CNSConstant.THUMBNAIL_NAME.Length + 1));
                    if (!File.Exists(originalFilePath))
                    {
                        var fileModifedDate = new FileInfo(filePath);
                        originalFilePath = files.FirstOrDefault(x => x.LastAccessTime <= fileModifedDate.LastAccessTime && x.LastAccessTime.AddMinutes(2) >= fileModifedDate.LastAccessTime)?.FullName ?? originalFilePath;
                    }
                    if (!File.Exists(originalFilePath))
                    {
                        logger.LogInfo($"UpdateArticlePictureList: file Name: {item}, original: {originalFilePath}");
                        continue;
                    }
                    using (var image = ImageHelper.ResizeImage(originalFilePath))
                    {
                        //File.Delete(filePath);
                        filePath = Path.Combine(ConfigManager.RegenerateArticlePictureFolder, item.Replace(" ", "-"));
                        image.Save(filePath);
                        File.SetLastWriteTime(filePath, DateTime.Now);
                        //File.SetLastWriteTime(originalFilePath, DateTime.Now);
                    }
                }
            }
        }

        static void UpdateUserLogoList()
        {
            var list = userApp.GetUserLogoList();
            var dictionaryInfo = new DirectoryInfo(ConfigManager.RegenerateUserLogoFolder);
            var files = dictionaryInfo.GetFiles().Where(x => !x.FullName.StartsWith(CNSConstant.THUMBNAIL_NAME)).OrderByDescending(x => x.LastAccessTime);
            foreach (var item in list)
            {
                var filePath = Path.Combine(ConfigManager.RegenerateUserLogoFolder, item);
                if (File.Exists(filePath))
                {
                    var originalFilePath = Path.Combine(ConfigManager.RegenerateUserLogoFolder, item.Substring(CNSConstant.THUMBNAIL_NAME.Length + 1));
                    if (!File.Exists(originalFilePath))
                    {
                        var fileModifedDate = new FileInfo(filePath);
                        originalFilePath = files.FirstOrDefault(x => x.LastAccessTime <= fileModifedDate.LastAccessTime && x.LastAccessTime.AddMinutes(2) >= fileModifedDate.LastAccessTime)?.FullName ?? originalFilePath;
                    }
                    if (!File.Exists(originalFilePath))
                    {
                        logger.LogInfo($"UpdateUserLogoList: file Name: {item}, original: {originalFilePath}");
                        continue;
                    }
                    using (var image = ImageHelper.ResizeImage(originalFilePath, 150, 150))
                    {
                        //File.Delete(filePath);
                        filePath = Path.Combine(ConfigManager.RegenerateUserLogoFolder, item.Replace(" ", "-"));
                        image.Save(filePath);
                        File.SetLastWriteTime(filePath, DateTime.Now);
                        //File.SetLastWriteTime(originalFilePath, DateTime.Now);
                    }
                }
            }
        }

        static void ChangeColor(string fileName, Color oldColor, string[] list)
        {
            var folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "icon");
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            foreach (var item in list)
            {
                using (var image = new Bitmap(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, fileName)))
                {
                    var newColor = ColorTranslator.FromHtml(item.ToLower() == "#ffffff" ? "#daa520" : item);
                    ChangeColor(image, oldColor, newColor);
                    image.Save(Path.Combine(folder, $"{fileName.Substring(0, fileName.Length - 4)}{item}.png"));
                }
            }

        }

        public static void ChangeColor(Bitmap image, Color oldColor, Color newColor)
        {
            //var pxf = PixelFormat.Format24bppRgb;
            //var rect = new Rectangle(0, 0, image.Width, image.Height);

            //BitmapData bitData = image.LockBits(rect, ImageLockMode.ReadWrite, pxf);
            //IntPtr ptr = bitData.Scan0;
            //int numBytes = bitData.Stride * image.Height;
            //byte[] rgbValues = new byte[numBytes];

            //Marshal.Copy(ptr, rgbValues, 0, numBytes);

            //for (int i = 0; i < rgbValues.Length; i += 3)
            //{
            //    //if (rgbValues[i+1] == 207)
            //    {
            //        rgbValues[i] = newR;
            //        rgbValues[i + 1] = newG;
            //        if (i + 2 <= rgbValues.Length - 1)
            //            rgbValues[i + 2] = newB;
            //    }

            //}
            //Marshal.Copy(rgbValues, 0, ptr, numBytes);

            //// Unlock the bits.
            //image.UnlockBits(bitData);
            //image.MakeTransparent(Color.Black);

            //Color oldColor = Color.FromArgb(oldR, oldG, oldB);
            //Color newColor = Color.FromArgb(newR, newG, newB);
            var whiteColor = Color.White;
            //var color = ColorTranslator.FromHtml("#99CDEB").ToArgb();//.FromArgb(0);
            //var color = Color.Black;
            for (int x = 0; x < image.Width; x++)
            {
                for (int y = 0; y < image.Height; y++)
                {
                    var tempColor = image.GetPixel(x, y);
                    if (tempColor == oldColor)
                    {
                        image.SetPixel(x, y, newColor);
                    }
                    else if (tempColor.ToArgb() != whiteColor.ToArgb() && tempColor.ToArgb() != Color.Empty.ToArgb())
                    {
                        if (tempColor.R >= 180 && tempColor.G >= 217 && tempColor.B >= 240)
                        {
                            image.SetPixel(x, y, Color.White);// Color.FromArgb(80, newColor.R, newColor.G, newColor.B));
                        }
                        else
                        {
                            image.SetPixel(x, y, Color.FromArgb(tempColor.A, newColor.R, newColor.G, newColor.B));
                        }
                    }
                    //if (tempColor >= color && tempColor <= oldColor.ToArgb())
                    //{
                    //    image.SetPixel(x, y, newColor);
                    //}
                    //if (tempColor != whiteColor && tempColor != color)
                    //{
                    //    if (tempColor == oldColor)
                    //    {
                    //        image.SetPixel(x, y, newColor);
                    //    }
                    //}
                }
            }
        }
    }
}
