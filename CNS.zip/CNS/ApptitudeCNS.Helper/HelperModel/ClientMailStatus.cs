﻿namespace ApptitudeCNS.Helpers
{
    public class ClientMailStatus
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public bool IsDisabled { get; set; }
        public string Icon { get; set; }

        public string DisabledHtml
        {
            get
            {
                return IsDisabled ? "email-status-disabled" : string.Empty;
            }
        }
    }
}
