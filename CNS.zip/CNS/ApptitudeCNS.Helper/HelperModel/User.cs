﻿namespace ApptitudeCNS.Helpers
{
    public class BpUser 
    {
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string Company { get; set; }
        public string SenderEmail { get; set; }
        public long? BpUserId { get; set; }
        public long? AggregatorId { get; set; }
        public long? SubAggregatorId { get; set; }
        public string Address { get; set; }
    }
}
