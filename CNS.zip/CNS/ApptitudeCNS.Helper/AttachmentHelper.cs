﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;

namespace ApptitudeCNS.Helpers
{
    public class AttachmentHelper
    {
        public static object UploadAttachmentLink(string link, string path)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(link))
                {
                    if (link.StartsWith("//", StringComparison.OrdinalIgnoreCase))
                    {
                        link = $"http:{link}";
                    }

                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    var fileName = CommonHelper.GetFileName(link);
                    var fullpath = Path.Combine(path, fileName);
                    var originalName = Path.GetFileName(link);
                    using (var client = new WebClientEx(allowAutoRedirect: true))
                    {
                        client.DownloadFile(link, fullpath);
                        if (!string.IsNullOrWhiteSpace(client.RedirectLink) && client.RedirectLink != link)
                        {
                            originalName = Path.GetFileName(client.RedirectLink);
                            fileName = CommonHelper.GetFileName(client.RedirectLink);
                            File.Move(fullpath, Path.Combine(path, fileName));
                        }
                    }
                    return new { Name = fileName, OriginalName = originalName, OriginalFile = link };
                }
            }
            catch (Exception ex)
            {
                return new { Name = UploadAttachmentLinkAgain(link, path), OriginalName = Path.GetFileName(link), OriginalFile = link };
            }
            return null;
        }

        public static string UploadAttachmentLinkAgain(string link, string path)
        {
            if (!string.IsNullOrWhiteSpace(link))
            {
                if (link.StartsWith("//", StringComparison.OrdinalIgnoreCase))
                {
                    link = $"http:{link}";
                }

                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                var fileName = CommonHelper.GetFileName(link);
                path = Path.Combine(path, fileName);

                using (var client = new WebClient())
                {
                    client.DownloadFile(link, path);
                }
                link = fileName;
            }
            return link;
        }
    }
}