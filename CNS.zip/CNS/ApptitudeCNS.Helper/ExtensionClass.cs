﻿using ApptitudeCNS.Helpers.HelperModel;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Web;

namespace ApptitudeCNS.Helpers
{
    public static class ExtensionClass
    {
        public static IQueryable<TEntity> OrderBy<TEntity>(this IQueryable<TEntity> source, string orderByProperty,
                          bool desc)
        {
            string command = desc ? "OrderByDescending" : "OrderBy";
            var type = typeof(TEntity);
            var property = type.GetProperty(orderByProperty);
            var parameter = Expression.Parameter(type, "p");
            var propertyAccess = Expression.MakeMemberAccess(parameter, property);
            var orderByExpression = Expression.Lambda(propertyAccess, parameter);
            var resultExpression = Expression.Call(typeof(Queryable), command, new Type[] { type, property.PropertyType },
                                          source.Expression, Expression.Quote(orderByExpression));
            return source.Provider.CreateQuery<TEntity>(resultExpression);
        }

        /// <summary>
        /// Sort one collection based on keys defined in another
        /// </summary>
        /// <returns>Items sorted</returns>
        public static IEnumerable<TResult> SortBy<TResult, TKey>(
            this IEnumerable<TResult> itemsToSort,
            IEnumerable<TKey> sortKeys,
            Func<TResult, TKey> matchFunc)
        {
            return sortKeys.Join(itemsToSort,
                key => key,
                matchFunc,
                (key, iitem) => iitem);
        }

        public static bool EqualsListNumberic<T>(this IList<T> l1, IList<T> l2) where T : IComparable<T>
        {
            foreach (var a in l1)
            {
                if (l2.Contains(a)) return true;
            }
            return false;
        }

        public static string GetDescription<T>(this T enumerationValue)
            where T : struct
        {
            var type = enumerationValue.GetType();
            if (!type.IsEnum)
            {
                throw new ArgumentException($"{nameof(enumerationValue)} must be of Enum type", nameof(enumerationValue));
            }
            var memberInfo = type.GetMember(enumerationValue.ToString());
            if (memberInfo.Length > 0)
            {
                var attrs = memberInfo[0].GetCustomAttributes(typeof(DescriptionAttribute), false);

                if (attrs.Length > 0)
                {
                    return ((DescriptionAttribute)attrs[0]).Description;
                }
            }
            return enumerationValue.ToString();
        }

        public static List<PropertyCompareResult> Compare<T>(T oldObject, T newObject)
        {
            PropertyInfo[] properties = typeof(T).GetProperties();
            List<PropertyCompareResult> result = new List<PropertyCompareResult>();

            foreach (PropertyInfo pi in properties)
            {
                if (pi.CustomAttributes.Any(ca => ca.AttributeType == typeof(IgnorePropertyCompareAttribute)))
                {
                    continue;
                }

                object oldValue = pi.GetValue(oldObject), newValue = pi.GetValue(newObject);

                var objectName = pi.GetCustomAttribute<DisplayNameAttribute>(false);
                var displayName = objectName == null ? pi.Name : objectName.DisplayName;
                //if (oldObject is DateTime)
                //{
                //    if (DateTime.Compare((DateTime)oldValue, (DateTime)newValue) != 0)
                //    {
                //        result.Add(new PropertyCompareResult(displayName, oldValue, newValue));
                //    }
                //}
                //else 
                if (pi.PropertyType == typeof(String))
                {
                    if (oldValue?.ToString() != newValue?.ToString() && (!string.IsNullOrWhiteSpace(oldValue?.ToString()) || !string.IsNullOrWhiteSpace(newValue?.ToString())))
                    {
                        result.Add(new PropertyCompareResult(displayName, oldValue, newValue));
                    }
                }
                else if (pi.PropertyType == typeof(long?) || pi.PropertyType == typeof(int?))
                {
                    if (CommonHelper.GetLong(oldValue) != CommonHelper.GetLong(newValue))
                    {
                        result.Add(new PropertyCompareResult(displayName, oldValue, newValue));
                    }
                }
                else if (!object.Equals(oldValue, newValue))
                {
                    result.Add(new PropertyCompareResult(displayName, oldValue, newValue));
                }
            }

            return result;
        }

        public static string InsertSpaceBeforeUpperCase(this string str)
        {
            var sb = new StringBuilder();

            char previousChar = char.MinValue; // Unicode '\0'

            foreach (char c in str)
            {
                if (char.IsUpper(c))
                {
                    // If not the first character and previous character is not a space, insert a space before uppercase

                    if (sb.Length != 0 && previousChar != ' ')
                    {
                        sb.Append(' ');
                    }
                }

                sb.Append(c);

                previousChar = c;
            }

            return sb.ToString();
        }

        public static HtmlNode GetFirstNode(this HtmlDocument htmlDocument, HtmlTagInfo info)
        {
            return GetFirstNode(htmlDocument.DocumentNode, info);
            //htmlDocument.DocumentNode.Descendants(info.TagName).FirstOrDefault(d => string.IsNullOrWhiteSpace(info.PropertyName) || d.Attributes.Contains(info.PropertyName) &&
            //(string.IsNullOrWhiteSpace(info.PropertyValue) || d.Attributes[info.PropertyName].Value.Trim().Equals(info.PropertyValue))) ??
            //htmlDocument.DocumentNode.Descendants(info.TagName2).FirstOrDefault(d => string.IsNullOrWhiteSpace(info.PropertyName2) || d.Attributes.Contains(info.PropertyName2) &&
            //(string.IsNullOrWhiteSpace(info.PropertyValue2) || d.Attributes[info.PropertyName2].Value.Trim().Equals(info.PropertyValue2)));
        }

        public static HtmlNode GetFirstNode(this HtmlNode node, HtmlTagInfo info)
        {
            return node?.Descendants(info.TagName).FirstOrDefault(d => string.IsNullOrWhiteSpace(info.PropertyName) || (d.Attributes.Contains(info.PropertyName) &&
            (string.IsNullOrWhiteSpace(info.PropertyValue) || d.Attributes[info.PropertyName].Value.Trim().Equals(info.PropertyValue) ||
            (info.IsContained && d.Attributes[info.PropertyName].Value.Contains(info.PropertyValue))))) ??
            node?.Descendants(info.TagName2).FirstOrDefault(d => string.IsNullOrWhiteSpace(info.PropertyName2) || (d.Attributes.Contains(info.PropertyName2) &&
            (string.IsNullOrWhiteSpace(info.PropertyValue2) || d.Attributes[info.PropertyName2].Value.Trim().Equals(info.PropertyValue2) ||
            (info.IsContained2 && d.Attributes[info.PropertyName2].Value.Contains(info.PropertyValue2)))));
        }

        public static bool Exists(this HtmlNode node, HtmlTagInfo info)
        {
            return (node.Name == info.TagName && (string.IsNullOrWhiteSpace(info.PropertyName) || (node.Attributes.Contains(info.PropertyName) &&
            (string.IsNullOrWhiteSpace(info.PropertyValue) || node.Attributes[info.PropertyName].Value.Trim().Equals(info.PropertyValue) ||
            (info.IsContained && node.Attributes[info.PropertyName].Value.Contains(info.PropertyValue)))))) ||
            (node.Name == info.TagName2 && (string.IsNullOrWhiteSpace(info.PropertyName2) || (node.Attributes.Contains(info.PropertyName2) &&
            (string.IsNullOrWhiteSpace(info.PropertyValue2) || node.Attributes[info.PropertyName2].Value.Trim().Equals(info.PropertyValue2) ||
            (info.IsContained2 && node.Attributes[info.PropertyName2].Value.Contains(info.PropertyValue2))))));
        }

        public static bool IsGettingFirstNode(this HtmlNode node, HtmlTagInfo info)
        {
            return (info.IsFirstValue && node.Name == info.TagName && (string.IsNullOrWhiteSpace(info.PropertyName) || node.Attributes.Contains(info.PropertyName) &&
            (string.IsNullOrWhiteSpace(info.PropertyValue) || node.Attributes[info.PropertyName].Value.Trim().Equals(info.PropertyValue))));
        }

        public static IEnumerable<HtmlNode> GetNodes(this HtmlNode node, HtmlTagInfo info)
        {
            if (string.IsNullOrWhiteSpace(info.TagName2))
                return node?.Descendants(info.TagName).Where(d => (string.IsNullOrWhiteSpace(info.PropertyName) || d.Attributes.Contains(info.PropertyName) &&
                (string.IsNullOrWhiteSpace(info.PropertyValue) || d.Attributes[info.PropertyName].Value.Trim().Equals(info.PropertyValue) ||
            (info.IsContained && d.Attributes[info.PropertyName].Value.Contains(info.PropertyValue)))));

            return node?.Descendants().Where(d => (d.Name == info.TagName && (string.IsNullOrWhiteSpace(info.PropertyName) || d.Attributes.Contains(info.PropertyName) &&
            (string.IsNullOrWhiteSpace(info.PropertyValue) || d.Attributes[info.PropertyName].Value.Trim().Equals(info.PropertyValue) ||
            (info.IsContained && d.Attributes[info.PropertyName].Value.Contains(info.PropertyValue))))) ||
            (d.Name == info.TagName2 && (string.IsNullOrWhiteSpace(info.PropertyName2) || d.Attributes.Contains(info.PropertyName2) &&
            (string.IsNullOrWhiteSpace(info.PropertyValue2) || d.Attributes[info.PropertyName2].Value.Trim().Equals(info.PropertyValue2) ||
            (info.IsContained2 && d.Attributes[info.PropertyName2].Value.Contains(info.PropertyValue2))))));
        }

        public static string GetValue(this HtmlNode node, HtmlTagInfo info, string value = "")
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                //var child = node.GetFirstNode(info);
                if (string.IsNullOrWhiteSpace(info.PropertyNameValue))
                {
                    value = HttpUtility.HtmlDecode(node?.InnerText?.Trim()?.Replace("\t", "").Replace("\n\n", "\n"));
                }
                else
                {
                    value = HttpUtility.HtmlDecode(node?.Attributes[info.PropertyNameValue]?.Value?.Trim().Replace("\n\n", "\n"));
                }

                if (!string.IsNullOrWhiteSpace(value) && !string.IsNullOrWhiteSpace(info.FindWord))
                {
                    value = value.Replace(info.FindWord, info.ReplaceWord); 
                }
            }
            return value;
        }

        public static string GetValue(this HtmlDocument htmlDocument, HtmlTagInfo info, string value = "")
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                var node = htmlDocument.GetFirstNode(info);
                if (string.IsNullOrWhiteSpace(info.PropertyNameValue))
                {
                    value = HttpUtility.HtmlDecode(HttpUtility.HtmlDecode(node?.InnerText?.Trim()?.Replace("\t", "").Replace("\n\n", "\n")));
                }
                else
                {
                    value = HttpUtility.HtmlDecode(HttpUtility.HtmlDecode(node?.Attributes[info.PropertyNameValue]?.Value?.Trim().Replace("\n\n", "\n")));
                }
                if (!string.IsNullOrWhiteSpace(value) && !string.IsNullOrWhiteSpace(info.FindWord))
                {
                    value = value.Replace(info.FindWord, info.ReplaceWord);
                }
            }
            return value;
        }

        public static string GetValue(this HtmlDocument htmlDocument, HtmlTagInfo[] infoList, string value = "", int minWordCount = 0)
        {
            if ((string.IsNullOrWhiteSpace(value) || CommonHelper.GetWordCount(value) < minWordCount) && infoList?.Length > 0)
            {
                var node = htmlDocument.GetFirstNode(infoList[0]);
                for (int i = 1; i < infoList.Length; i++)
                {
                    if (node == null) return value;

                    if (infoList[i].IsMultiValues)
                    {
                        var result = new List<string>();
                        int wordCount = 0;
                        var textResult = node.GetMultiValues(infoList.Skip(i).ToArray(), result, ref wordCount, value, minWordCount);
                        textResult = HttpUtility.HtmlDecode(CommonHelper.GetWords(textResult, infoList[i].WordCount, Environment.NewLine)).Replace("\n\n", "\n");
                        if (!string.IsNullOrWhiteSpace(value) && !string.IsNullOrWhiteSpace(infoList[infoList.Length - 1].FindWord))
                        {
                            textResult = textResult.Replace(infoList[infoList.Length - 1].FindWord, infoList[infoList.Length - 1].ReplaceWord).Trim();
                        }
                        return textResult;
                    }
                    node = node.GetFirstNode(infoList[i]);
                }
                value = HttpUtility.HtmlDecode(HttpUtility.HtmlDecode(node.GetValue(infoList[infoList.Length - 1])));
                if (!string.IsNullOrWhiteSpace(value) && !string.IsNullOrWhiteSpace(infoList[infoList.Length - 1].FindWord))
                {
                    value = value.Replace(infoList[infoList.Length - 1].FindWord, infoList[infoList.Length - 1].ReplaceWord).Trim();
                }
            }
            return value;
        }

        public static string GetMultiValues(this HtmlNode node, HtmlTagInfo[] infoList, List<string> result, ref int wordCount, string value = "", int minWordCount = 0)
        {
            if (node == null) return value;

            var index = 0;
            //var nodes = node.GetNodes(infoList[index]);
            var nodes = infoList[index].IsFoundChildren ? node.GetNodes(infoList[index]) : node.ChildNodes;
            //var isFirstNode = false;
            var list = new List<string>();
            foreach (var item in nodes)
            {   
                var child = item;
                var data = string.Empty;
                //if (node.Name == infoList[i].TagName && 
                //    (isFirstNode ||     
                //    ((string.IsNullOrWhiteSpace(infoList[i].PropertyName) || node.Attributes.Contains(infoList[i].PropertyName)) &&
                //    ((string.IsNullOrWhiteSpace(infoList[i].PropertyValue) || node.Attributes[infoList[i].PropertyName].Value.Contains(infoList[i].PropertyValue))))))
                if (child.Exists(infoList[index]) && (infoList[index].IgnoreItem == null || !child.Exists(infoList[index].IgnoreItem)))
                {
                    //isFirstNode = true;
                    for (int j = index + 1; j < infoList.Length; j++)
                    {
                        if (infoList[index].WordCount > 0 && wordCount >= infoList[index].WordCount)
                        {
                            break;
                        }

                        if (infoList[j].IsMultiValues && !item.IsGettingFirstNode(infoList[index]))
                        {
                            data = child?.GetMultiValues(infoList.Skip(j).ToArray(), result, ref wordCount, value, minWordCount);
                            if (string.IsNullOrWhiteSpace(data) && !string.IsNullOrWhiteSpace(infoList[j].TagName3))
                            {
                                var info = new HtmlTagInfo { TagName = infoList[j].TagName3 };
                                data = item.GetFirstNode(info).GetValue(info);
                            }
                        }
                        else
                        {
                            child = child?.GetFirstNode(infoList[j]);
                            if (child == null && infoList[j].IsIgnored)
                            {
                                child = item;
                                //data = item.GetFirstNode(info).GetValue(infoList[infoList.Length - 1]);
                                //break;
                            }
                            if (j == infoList.Length - 1)
                            {
                                data = child?.GetValue(infoList[infoList.Length - 1]);
                            }
                        }
                    }
                    if (infoList.Length == 1)
                    {
                        data = child?.GetValue(infoList[infoList.Length - 1]);
                    }
                    if (child == null && string.IsNullOrWhiteSpace(data))
                    {
                        continue;
                    }
                }
                else if (child.Name == infoList[index].TagName3)
                {
                    data = child.GetValue(infoList[index]);
                }
                else
                {
                    continue;
                }

                if (!string.IsNullOrWhiteSpace(data) && !list.Contains(data))
                {
                    if (!result.Contains(data))
                    {
                        wordCount += CommonHelper.GetWordCount(data);
                    }
                    list.Add(data);
                }

                if (infoList[index].WordCount > 0 && wordCount >= infoList[index].WordCount)
                {
                    break;
                }
            }

            if (result.Count == 0 && !string.IsNullOrWhiteSpace(infoList[index].TagName3))
            {
                var info = new HtmlTagInfo { TagName = infoList[index].TagName3 };
                node = node.GetFirstNode(info);
                if (node != null)
                {
                    result.Add(node.GetValue(info));
                }
            }

            var text = string.Join(infoList[index].Separator, list);
            result.AddRange(list);
            //return string.Join(infoList[index].Separator, result);
            return text;
        }
    }
}
