﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ApptitudeCNS.Helpers
{
    public enum EnumHistoryType
    {
        Note = 1,
        Email,
        [Description("Phone Call")]
        PhoneCall,
        SMS,
        Other
    }

    public enum EnumEmailStatusType
    {
        Unsent = 1,
        Sent,
        Failed,
        Read,
        Clicked
    }

    public enum EnumEmailType
    {
        [Description("Broker Message")]
        BrokerMessage = 1,
        Article,
        [Description("Lowest Rates")]
        LowestRates
    }

    public enum EnumRecipientType
    {
        BrokerClient = 1,
        BrokerAccounts,
        ConveyancerClients,
        AccountantClient,
        General
    }

    public enum EnumArticleType
    {
        Finance = 1,
        Property,
        Law,
        Tax,
        [Description("Other 1")]
        Other1,
        [Description("Other 2")]
        Other2
    }

    public enum EnumUserType
    {
        Broker = 1,
        Conveyancer = 2,
        [Description("Conveyancers Real Estate Agents")]
        ConveyancersRealEstateAgents = 7,
        Solicitor = 3,
        Accountant = 4,
        [Description("Financial Planner")]
        FinancialPlanner = 5,
        [Description("Real Estate Agents")]
        RealEstateAgents = 6,
        [Description("Brokerpedia/Aggregator Groups")]
        Brokerpedia = 8,
        Industry = 9,
    }

    public enum EnumClientType
    {
        [Description("Brokers Clients")]
        Broker = 1,
        [Description("Conveyancers Clients")]
        Conveyancer = 2,
        [Description("Real Estate Agents")]
        ConveyancersRealEstateAgents = 7,
        [Description("Solicitors Clients")]
        Solicitor = 3,
        [Description("Accountants Clients")]
        Accountant = 4,
        [Description("Financial Planners Clients")]
        FinancialPlanner = 5,
        [Description("Real Estate Agents Clients")]
        RealEstateAgents = 6,
        [Description("Brokerpedia/Aggregator Groups")]
        Brokerpedia = 8,
    }

    public enum EnumArticleStatusType
    {
        None = 1,
        Reviewing,
        Sent
    }

    public enum EnumOrderBy
    {
        asc,
        desc
    }

    public enum EnumClientFilterType
    {
        None,
        [Display(Name = "AllClients")]
        AllClient,
        [Display(Name = "AllClients, send Email Only")]
        ClientWithSendEmailOnly,
        [Display(Name = "AllClients, send SMS Only")]
        ClientWithSendSMSOnly
    }

    public enum EnumRole
    {
        Administrator = 1,
        Broker = 2
    }

    //public enum EnumArticleTagType
    //{
    //    [Description("No Tag")]
    //    NoTag = 100,
    //    [Description("Australian Economy")]
    //    AustralianEconomy = 1,
    //    Business,
    //    Family,
    //    Finance,
    //    Health,
    //    International,
    //    //[Description("International Economy")]
    //    //InternationalEconomy,
    //    //[Description("International Property")]
    //    //InternationalProperty,
    //    [Description("Other Law")]
    //    OtherLaw = 8,
    //    Property,
    //    [Description("Property/Conveyancing Law")]
    //    PropertyConveyancingLaw,
    //    Sport,
    //    Inspirational,
    //    //[Description("Success/Motivation")]
    //    //SuccessMotivation,
    //    [Description("Super/CFP/SMSF")]
    //    SuperCFPSMSF,
    //    [Description("Tax/Accounting")]
    //    TaxAccounting,
    //    //Technology,
    //    Trends = 16,
    //    Trendy,
    //    Work,
    //    [Description("Andrew Personal")]
    //    AndrewPersonal, // Put it the end
    //    Timeless, // Put it the end
    //    Australia,
    //    [Description("Education/Learning")]
    //    EducationLearning,
    //    Innovation,
    //    //Leadership,
    //    //People,
    //    Personal = 26,
    //    //[Description("Personal Improvement")]
    //    //PersonalImprovement,
    //    //Science,
    //    //[Description("Personal Investment")]
    //    //PersonalInvestment,
    //}

    public enum EnumClientEmailStatus
    {
        Send = 1,
        Blank,
        [Description("Admin decided")]
        AdminDecided,
        [Description("Broker decided")]
        BrokerDecided,
        [Description("System failure")]
        SystemFailure,
        [Description("Client unsubscribe")]
        ClientUnsubscribe
    }

    public enum EnumSendSampleEmailType
    {
        [Description("ProinspectArticles")]
        Proinspect = 1,
        [Description("BrokerpediaArticles")]
        Brokerpedia = 2
    }

    public enum EnumLogoPositionType
    {
        Left = 1,
        Right = 2
    }

}