﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace ApptitudeCNS.Helpers
{
    public class HtmlTagInfo
    {
        public string TagName { get; set; }
        public string FindWord { get; set; }
        public string ReplaceWord { get; set; }

        public string PropertyName { get; set; }
        public string PropertyValue { get; set; }
        public string PropertyNameValue { get; set; }
        public bool IsContained { get; set; }
        public bool IsFirstValue { get; set; }
        public bool IsIgnored { get; set; }

        public bool IsContained2 { get; set; }
        public string TagName2 { get; set; }
        public string PropertyName2 { get; set; }
        public string PropertyValue2 { get; set; }

        public string TagName3 { get; set; }

        public bool IsMultiValues { get; set; }
        public int WordCount { get; set; }
        public string Separator { get; set; }
        public HtmlTagInfo IgnoreItem { get; set; }
        public bool IsFoundChildren { get; set; }
    }
}
