﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace ApptitudeCNS.Helpers
{
    public class UrlHelper
    {
        public static string StandardizeUrl(string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return string.Empty;

            Regex regex = new Regex("^(https?|ftp)://");
            if (!regex.IsMatch(url))
            {
                return $"http://{url}";
            }
            return url;
        }

        public static string NormaliseUrl(string url)
        {
            if (url.StartsWith("www."))
            {
                url = url.Substring(4);
            }
            var match = Regex.Match(url, @"\.com|\.org|\.net|\.int|\.edu|\.gov|\.mil|\.arpa|\.biz|\.asn", RegexOptions.IgnoreCase);
            if (match != null && match.Index > 0)
            {
                url = url.Substring(0, match.Index);
            }
            else
            {
                if (url.IndexOf('/') >= 0)
                {
                    url = url.Substring(0, url.IndexOf('/'));
                }

                if (url.LastIndexOf('.') > 0)
                {
                    url = url.Substring(0, url.LastIndexOf('.'));
                }
                //var index = sitename.lastIndexOf('.'), i = 0;
                //while (index > 0 && i++ < 2) {
                //    sitename = sitename(0, index);
                //    index = sitename.lastIndexOf('.');
                //}
            }

            if (url.LastIndexOf('.') > 0)
            {
                url = url.Substring(url.LastIndexOf('.') + 1);
            }
            return url.Trim();
        }
    }
}