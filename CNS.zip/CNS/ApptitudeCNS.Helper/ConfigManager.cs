﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Helpers
{
    public class ConfigManager
    {
        public static bool IsDevEnvironment
        {
            get
            {
                return CommonHelper.GetBool(ConfigurationManager.AppSettings["IsDevEnvironment"]);
            }
        }

        public static string[] TestEmail
        {
            get
            {
                var result = ConfigurationManager.AppSettings["TestEmail"];
                return ConfigurationManager.AppSettings["TestEmail"]?.Split(new char[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries);
            }
        }

        public static long SystemUserId
        {
            get
            {
                return CommonHelper.GetLong(ConfigurationManager.AppSettings["SystemUserId"]);
            }
        }

        public static long ClientTestId
        {
            get
            {
                return CommonHelper.GetLong(ConfigurationManager.AppSettings["ClientTestId"]);
            }
        }
        
        public static string SmptHost
        {
            get
            {
                return ConfigurationManager.AppSettings["SmptHost"];
            }
        }

        public static int SmptPort
        {
            get
            {
                return CommonHelper.GetInt(ConfigurationManager.AppSettings["SmptPort"]);
            }
        }

        public static string SmptUser
        {
            get
            {
                return ConfigurationManager.AppSettings["SmptUser"];
            }
        }

        public static string SmptPassword
        {
            get
            {
                return ConfigurationManager.AppSettings["SmptPassword"];
            }
        }

        public static bool SmptSsl
        {
            get
            {
                return CommonHelper.GetBool(ConfigurationManager.AppSettings["SmptSsl"]);
            }
        }

        public static string ImageReadEmailUrl
        {
            get
            {
                return ConfigurationManager.AppSettings["ImageReadEmailUrl"];
            }
        }

        public static string UserImageReadEmailUrl
        {
            get
            {
                return ConfigurationManager.AppSettings["UserImageReadEmailUrl"];
            }
        }

        public static string BpUserEditLink
        {
            get
            {
                return ConfigurationManager.AppSettings["BpUserEditLink"];
            }
        }

        public static string ProinspectUserEditLink
        {
            get
            {
                return ConfigurationManager.AppSettings["ProinspectUserEditLink"];
            }
        }
        
        public static string CNSTitle
        {
            get
            {
                return ConfigurationManager.AppSettings["CNSTitle"];
            }
        }

        public static string EmailTitle
        {
            get
            {
                return ConfigurationManager.AppSettings["EmailTitle"];
            }
        }

        public static string RegenerateArticlePictureFolder
        {
            get
            {
                return ConfigurationManager.AppSettings["RegenerateArticlePictureFolder"];
            }
        }

        public static string RegenerateUserLogoFolder
        {
            get
            {
                return ConfigurationManager.AppSettings["RegenerateUserLogoFolder"];
            }
        }

        public static long BpSystemChildUserId
        {
            get
            {
                return CommonHelper.GetLong(ConfigurationManager.AppSettings["BpSystemChildUserId"]);
            }
        }

        public static long ProinspectUserId
        {
            get
            {
                return CommonHelper.GetLong(ConfigurationManager.AppSettings["ProinspectUserId"]);
            }
        }


    }
}
