﻿namespace ApptitudeCNS.Helpers
{
    internal class IgnorePropertyCompareAttribute
    {
    }
}