﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace ApptitudeCNS.Helpers
{
    public class CommonHelper
    {
        public static char[] Delimiters = new char[] { '\r', '\n', ' ' };

        public static string GetCheckedBoxTristate(bool? val)
        {
            if (val.HasValue)
            {
                return val.Value ? "checked=checked" : string.Empty;
            }
            else
            {
                return "indeterminate=1";
            }
        }

        public static int GetInt(object value, int defaultValue = 0)
        {
            if (value == null || string.IsNullOrWhiteSpace(value.ToString())) return defaultValue;
            try
            {
                return int.Parse(value.ToString().Trim());
            }
            catch
            {
            }
            return defaultValue;
        }

        public static long GetLong(object value, long defaultValue = 0)
        {
            if (value == null || string.IsNullOrWhiteSpace(value.ToString())) return defaultValue;
            try
            {
                return long.Parse(value.ToString().Trim());
            }
            catch
            {
            }
            return defaultValue;
        }

        public static List<int> GetIdListForEnum<T>() where T : struct, IConvertible
        {
            if (typeof(T).IsEnum)
            {
                var result = new List<int>();
                foreach (var e in Enum.GetValues(typeof(T)))
                {
                    result.Add((int)e);
                }
                return result;
            }
            return null;
        }

        public static List<string> GetStringListForEnum<T>(bool isName = false) where T : struct, IConvertible
        {
            if (typeof(T).IsEnum)
            {
                var result = new List<string>();
                foreach (var e in Enum.GetValues(typeof(T)))
                {
                    result.Add(isName ? e.ToString() : ((T)e).GetDescription());
                }
                return result;
            }
            return null;
        }


        public static List<IdName> GetListForEnum<T>(bool isName = false, long startId = 0) where T : struct, IConvertible
        {
            if (typeof(T).IsEnum)
            {
                var result = new List<IdName>();
                foreach (var e in Enum.GetValues(typeof(T)))
                {
                    result.Add(new IdName() { Id = (int)e + startId, Name = isName ? e.ToString() : ((T)e).GetDescription() });
                }
                return result;
            }
            return null;
        }

        //public static List<IdName> GetArticleTags()
        //{
        //    var list = GetListForEnum<EnumArticleTagType>().OrderBy(x => x.Name).ToList();
        //    MoveValueToEnd(list, (int)EnumArticleTagType.AndrewPersonal);
        //    MoveValueToEnd(list, (int)EnumArticleTagType.Timeless);
        //    MoveValueToEnd(list, (int)EnumArticleTagType.NoTag);
        //    return list;
        //}

        public static void MoveValueToEnd(List<IdName> list, int value)
        {
            var item = list.First(x => x.Id == value);
            if (list.Remove(item))
            {
                list.Add(item);
            }
        }

        public static bool GetBool(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return false;
            if (value.Trim() == "1" || value.Trim().Equals("true", StringComparison.OrdinalIgnoreCase))
                return true;
            return false;
        }

        public static string ConvertDateTimeStringToString(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return string.Empty;
            try
            {
                return ConvertDateTimeString(value).ToString("dd/MM/yyyy");
                //switch (value)
                //{
                //    case "a day ago":
                //        value = "one day ago";
                //        break;
                //}
                //var parser = new Chronic.Parser();
                //var span = parser.Parse(value);
                //var result = span != null ? span.Start.Value : DateTime.Parse(value);
                ////var result = DateTime.Parse(value);
                //return result.ToString("dd/MM/yyyy");
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

        public static DateTime ConvertDateTimeString(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return DateTime.Now;
            try
            {
                var result = DateTime.Now;
                if (DateTime.TryParseExact(value, "d MMMM yyyy",
                    System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.AllowWhiteSpaces, out result))
                {
                    return result;
                }
                switch (value)
                {
                    case "a day ago":
                        value = "one day ago";
                        break;
                }
                var span = GetSpan(value);
                if (span == null && value.Contains(","))
                {
                    var stringDate = value.Substring(value.IndexOf(",") + 1).Trim();
                    span = GetSpan(stringDate);
                }
                if (span != null)
                {
                    return span.Start.Value;
                }

                if (value.Contains("+"))
                {
                    value = value.Substring(0, value.IndexOf("+"));
                }
                if (value.LastIndexOf("-") > value.IndexOf(":"))
                {
                    value = value.Substring(0, value.LastIndexOf("-"));
                }
                while (!char.IsDigit(value[value.Length - 1]))
                {
                    value = value.Substring(0, value.Length - 1);
                }
                return DateTime.Parse(value);
                ////var result = DateTime.Parse(value);
                //return result.ToString("dd/MM/yyyy");
            }
            catch (Exception ex)
            {
                return DateTime.Now;
            }
        }

        public static Chronic.Span GetSpan(string value)
        {
            var option = new Chronic.Options { EndianPrecedence = Chronic.EndianPrecedence.Little };
            var parser = new Chronic.Parser(option);
            return parser.Parse(value);
        }
        public static DateTime GetClientSentDate(DateTime value)
        {
            var result = value.AddDays(1);

            return result.Date + TimeSpan.FromHours(10);
            //return value;
        }

        public static bool CheckMatchedName(string firstName, string lastName, string textFilter, bool isEqual)
        {
            var result = false;
            var fullName = string.Format("{0} {1}", firstName, lastName).Trim();

            if (isEqual)
            {
                result = CheckEqualString(firstName, textFilter)
                    || CheckEqualString(lastName, textFilter)
                    || CheckEqualString(fullName, textFilter);
            }
            else
            {
                result = CheckContainString(fullName, textFilter);
            }
            return result;
        }

        public static bool CheckEqualString(string source, string target)
        {
            return !string.IsNullOrEmpty(source) && source.Equals(target, StringComparison.OrdinalIgnoreCase);
        }

        public static bool CheckContainString(string source, string target)
        {
            var searchItems = target.Split(Delimiters,
                             StringSplitOptions.RemoveEmptyEntries);
            if (string.IsNullOrEmpty(source))
            {
                return false;
            }

            source = source.ToLower();
            return searchItems.Any(s => source.Contains(s.ToLower()));
        }

        public static string GetMaxLength(string value, int maxLength)
        {
            if (string.IsNullOrWhiteSpace(value)) return string.Empty;
            if (value.Length > maxLength)
            {
                return value.Substring(0, maxLength);
            }
            return value;
        }

        public static string GetSubscribeLogName(bool? subscribe)
        {
            if (subscribe.HasValue)
            {
                return subscribe.Value ? "Subscribed" : "Unsubscribed";
            }
            else
            {
                return "Unidentified";
            }
        }

        public static int GetWordCount(string words)
        {
            if (string.IsNullOrWhiteSpace(words)) return 0;

            return Regex.Matches(words, @"[\w0-9'’]+").Count;
        }

        public static string GetWord(string words)
        {
            if (string.IsNullOrWhiteSpace(words)) return string.Empty;

            return string.Join(" ", Regex.Matches(words, @"[\w0-9'’]+").Cast<Match>().Select(x => x.Value));
        }

        public static string GetWords(string words, int maxWordCount = 50, string seperator = "")
        {
            if (string.IsNullOrWhiteSpace(words)) return string.Empty;
            if (maxWordCount <= 0) return words;

            var data = Regex.Matches(words, @"[\w0-9'’]+").Cast<Match>().Where(x => x.Value != "'").ToList();
            if (data.Count > maxWordCount)
            {
                if (string.IsNullOrEmpty(seperator))
                    return $"{words.Substring(0, data[maxWordCount - 1].Index + data[maxWordCount - 1].Value.Length)}...";
                var index = words.IndexOf(seperator, data[maxWordCount - 1].Index + 1);
                if (index < 0 && seperator == Environment.NewLine)
                {
                    seperator = "\n";
                    index = words.IndexOf(seperator, data[maxWordCount - 1].Index + 1);
                }
                if (index > 0 && index <= 2000)
                {
                    return words.Substring(0, index).Trim();
                }
                else if (words.Length > 1000)
                {
                    return $"{words.Substring(0, data[maxWordCount - 2].Index + data[maxWordCount - 2].Value.Length)}...";
                }
            }
            return words;
        }

        public static string GetWordsForEmail(string words, int maxWordCount = 45, int maxWordCount2 = 55)
        {
            if (string.IsNullOrWhiteSpace(words)) return string.Empty;
            if (maxWordCount <= 0) return words;

            var data = Regex.Matches(words, @"[\w0-9'’]+").Cast<Match>().Where(x => x.Value != "'").ToList();
            if (data.Count > maxWordCount2)
            {
                var seperator = ".";
                var index = words.IndexOf(seperator, data[maxWordCount - 1].Index, data[maxWordCount2].Index - 1 - data[maxWordCount - 1].Index);
                if (index < 0)
                {
                    seperator = Environment.NewLine;
                    index = words.IndexOf(seperator, data[maxWordCount - 1].Index, data[maxWordCount2].Index - 1 - data[maxWordCount - 1].Index);
                }
                if (index < 0)
                {
                    seperator = "\n";
                    index = words.IndexOf(seperator, data[maxWordCount - 1].Index, data[maxWordCount2].Index - 1 - data[maxWordCount - 1].Index);
                }

                if (index > 0)
                {
                    return words.Substring(0, index + 1).Trim();
                }
                return $"{words.Substring(0, data[maxWordCount].Index - 1)}...";
            }
            return words;
        }

        public static string KeepABlankLine(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return string.Empty;
            var result = value.Replace(Environment.NewLine, "<br />").Replace("\n", "<br />");
            result = string.Join("<br />", result.Split(new string[] { "<br />" }, StringSplitOptions.RemoveEmptyEntries).Where(x => !string.IsNullOrWhiteSpace(x)));
            while (result.Contains("<br /><br />"))
            {
                result = result.Replace("<br /><br />", "<br />");
            }
            return result;
        }

        public static Dictionary<int, string> GetIconList()
        {
            var result = new Dictionary<int, string>();
            result.Add((int)EnumClientEmailStatus.Send, "<i class=\"fas fa-check-circle\" title=\"Send\"></i>");
            result.Add((int)EnumClientEmailStatus.Blank, "<i class=\"fas fa-question-circle\" title=\"Blank\"></i>");
            result.Add((int)EnumClientEmailStatus.AdminDecided, "<i class=\"fas fa-minus-circle\" title=\"Admin Decided\"></i>");
            result.Add((int)EnumClientEmailStatus.BrokerDecided, "<i class=\"fas fa-ban\" title=\"Broker Decided\"></i>");
            result.Add((int)EnumClientEmailStatus.SystemFailure, "<i class=\"fas fa-exclamation-triangle\" title=\"System Failure\"></i>");
            result.Add((int)EnumClientEmailStatus.ClientUnsubscribe, "<i class=\"fas fa-times-circle\" title=\"Client Unsubscribe\"></i>");
            return result;
        }

        public static List<ClientMailStatus> GetClientMailStatusList(bool isDisabled, List<int> disabledList)
        {
            var icons = GetIconList();
            var list = GetListForEnum<EnumClientEmailStatus>().Select(x => new ClientMailStatus
            {
                Id = x.Id,
                Name = x.Name,
                IsDisabled = isDisabled || disabledList.Contains((int)x.Id),
                Icon = icons[(int)x.Id]
            }).ToList();

            return list;
        }

        public static string GetValue(string value, string defaultValue)
        {
            return string.IsNullOrWhiteSpace(value) ? defaultValue : value;
        }

        public static string GetUserLeftFooterValue(string Phone, string Company)
        {
            var result = string.Empty;
            var formatPhone = PhoneHelper.FormatPhone(Phone);
            if (!string.IsNullOrWhiteSpace(Company) && !string.IsNullOrWhiteSpace(formatPhone))
            {
                result = $"{Company} - Phone: {formatPhone}";
            }
            else if (!string.IsNullOrWhiteSpace(Company))
            {
                result = $"{Company}";
            }
            else if (!string.IsNullOrWhiteSpace(formatPhone))
            {
                result = $"Phone: {formatPhone}";
            }

            return result;
        }

        public static string GetFullname(string firstname, string lastname, string internalIdentifier)
        {
            var result = $"{firstname} {lastname}".Trim();
            if (string.IsNullOrWhiteSpace(internalIdentifier))
            {
                return result;
            }
            return $"{result} ({internalIdentifier})";
        }

        public static string GetFileName(string link)
        {
            var link2 = link.Contains("?") ? link.Substring(0, link.IndexOf("?")) : link;
            if (link2.EndsWith("/"))
            {
                link2 = link2.Substring(0, link2.Length - 1);
            }
            return $"{Path.GetFileNameWithoutExtension(link2.Replace(" ", "-"))}_{ DateTime.Now.ToString("yyyyMMddHHmmss")}{Path.GetExtension(link2)}";
        }

        public static string GetWordPattern(string pattern)
        {
            pattern = $"\\b{ Regex.Escape(pattern)}\\b";
            if (pattern[2] == '\\')
            {
                pattern = pattern.Substring(2);
            }
            if (pattern[pattern.Length - 4] == '\\')
            {
                pattern = pattern.Substring(0, pattern.Length - 2);
            }
            return pattern;
        }

        public static string ReplaceWord(string pattern, string input, string replace = "")
        {
            //word = Regex.Escape(word);
            return Regex.Replace(input, GetWordPattern(pattern), replace, RegexOptions.IgnoreCase);
        }


        public static bool CheckWord(string pattern, string input)
        {
            var result = Regex.IsMatch(input, GetWordPattern(pattern), RegexOptions.IgnoreCase);
            return result;
        }

        public static bool CheckWords(string searchText, string input)
        {
            var result = searchText.Split(new char[] { ' ', ',', '.', ':', '?', '_' }, StringSplitOptions.RemoveEmptyEntries).All(pattern => CheckWord(pattern, input));
            return result;
        }
    }
}