﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ApptitudeCNS.Helpers
{
    public class PhoneHelper
    {
        public static List<String> NormalizePhone(string toNumbers)
        {
            var countryCode = "61"; //  Australia
            String[] numbers = toNumbers.Split(',', ';');
            List<String> processedNumbers = new List<string>();
            foreach (String number in numbers)
            {
                String num = number;
                num = num.Trim(new char[] { ' ', ')', '(', '[', ']', '-' });
                bool startsWithPlus = num.StartsWith("+");
                bool startsWith0 = num.StartsWith("0"); // Or it starts with 0
                num = num.TrimStart(new char[] { ' ', '+', '0', ')', '(', '[', ']', '-', '.' }).
                    TrimEnd(' ', '+', ')', '(', '[', ']', '-', '.').
                    Replace(" ", "").Replace("-", "").
                    Replace(")", "").Replace("(", "").Replace("+", "").Replace(".", "");
                long numNum;
                if (num.Length > 5 && long.TryParse(num, out numNum))
                {
                    if (startsWith0)
                    {
                        //  Needs a country code:
                        if (num.Length >= 8 && num.Length <= 10) //  Only accept number from 8 to 10 chars
                        {
                            num = countryCode + num;
                        }
                        else
                            num = "";
                    }
                    else
                        if (startsWithPlus)
                    {
                        if (num.Length >= 9 && num.Length <= 14) //  Only accept number from 9 to 14 chars
                        {
                            //num = num;
                        }
                        else
                            num = "";
                    }
                    else
                    {
                        //  May need a country code for Australia:
                        if (countryCode == "61" && num.Length >= 8 && num.Length <= 10
                            && !num.StartsWith("61"))
                            num = countryCode + num;    //  Add country code for this
                        else
                            if (num.Length < 9 || num.Length > 14)
                            num = "";   //  Do not use this, too short or too long
                    }

                    if (num.Length > 0)
                        processedNumbers.Add(num);
                }
            }
            return processedNumbers;
        }

        public static string FormatPhone(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone)) return string.Empty;

            var result = string.Join("", Regex.Matches(phone, @"\d+").Cast<Match>().Select(x => x.Value));
            if (result.Length == 10)
            {
                return $"({result.Substring(0, 2)}) {result.Substring(2, 4)} {result.Substring(6)}";
            }

            if (result.Length == 12 && result.StartsWith("04"))
            {
                return $"{result.Substring(0, 4)} {result.Substring(4, 4)} {result.Substring(8)}";
            }

            return result;
        }
    }
}
