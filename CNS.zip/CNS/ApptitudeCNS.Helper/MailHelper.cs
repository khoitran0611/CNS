﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Helpers
{
    public class MailHelper
    {
        public static void SendMail(System.Net.Mail.MailMessage mailMessage)
        {
            using (System.Net.Mail.SmtpClient smtpClient = new System.Net.Mail.SmtpClient())
            {
                smtpClient.Host = ConfigManager.SmptHost;// "smtp.gmail.com";
                smtpClient.Port = ConfigManager.SmptPort; // 587;

                var user = ConfigManager.SmptUser;
                var password = ConfigManager.SmptPassword;
                if (!string.IsNullOrWhiteSpace(user) && !string.IsNullOrWhiteSpace(password))
                {
                    smtpClient.Credentials = new System.Net.NetworkCredential(user, password);
                }

                smtpClient.EnableSsl = ConfigManager.SmptSsl;
                smtpClient.Send(mailMessage);
            }
        }

        //public static void SendMail(String from, String to, String cc, String bcc,
        //    String subject, String body)
        //{
        //    System.Net.Mail.MailMessage msg = new System.Net.Mail.MailMessage();
        //    msg.Subject = subject;
        //    msg.Body = body;
        //    msg.IsBodyHtml = true;
        //    ParseAddresses(msg, from, to, cc, bcc);

        //    using (System.Net.Mail.SmtpClient smtpClient = new System.Net.Mail.SmtpClient())
        //    {
        //        smtpClient.Host = "smtp.gmail.com";
        //        smtpClient.Port = 587;
        //        smtpClient.Credentials = new System.Net.NetworkCredential("testapptitude", "@pptitude|123");
        //        smtpClient.EnableSsl = true;
        //        smtpClient.Send(msg);
        //    }
        //}

        public static void AddMailMessageTo(System.Net.Mail.MailMessage mailMessage, string[] tos)
        {
            if (tos == null || tos.Length == 0) return;

            foreach (var to in tos)
            {
                mailMessage.To.Add(to);
            }
        }

        public static void AddMailMessageBcc(System.Net.Mail.MailMessage mailMessage, string[] bccs)
        {
            if (bccs == null || bccs.Length == 0) return;

            foreach (var bcc in bccs)
            {
                mailMessage.Bcc.Add(bcc);
            }
        }

        public static System.Net.Mail.MailAddressCollection ParseMailAddresses(String adds)
        {
            System.Net.Mail.MailAddressCollection res = new System.Net.Mail.MailAddressCollection();
            String[] addStrings = adds.Split(new char[] { ',', ';' });
            foreach (String add in addStrings)
            {
                String[] parts = add.Replace("\"", " ").Replace("<", " ").Replace(">", " ").Trim().Split(' ');
                String email = "";
                StringBuilder displayName = new StringBuilder();
                if (parts.Length > 0)
                {
                    email = parts[parts.Length - 1];
                    if (!(email.Length > 7 && email.IndexOf("@") > 0 && email.IndexOf("@") < email.Length - 2))
                    {
                        email = "";
                    }
                }
                if (email.Length > 0)
                {
                    for (int i = 0; i < parts.Length - 1; i++)
                    {
                        if (displayName.Length > 0 && displayName[displayName.Length - 1] != ' ')
                            displayName.Append(" ");
                        displayName.Append(parts[i]);
                    }
                }
                if (email.Length > 0)
                {
                    System.Net.Mail.MailAddress addItem = new System.Net.Mail.MailAddress(email, displayName.ToString().Trim());
                    res.Add(addItem);
                }
            }
            return res;
        }


    }
}
