﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Web;

namespace ApptitudeCNS.Helpers
{
    public class ImageHelper
    {
        public static Image GetImage(string fullPath)
        {
            Image result;
            if (fullPath.EndsWith(".webp", StringComparison.OrdinalIgnoreCase))
            {
                var webPFormat = new ImageProcessor.Plugins.WebP.Imaging.Formats.WebPFormat();
                using (var stream = new FileStream(fullPath, FileMode.Open, FileAccess.Read))
                {
                    result = webPFormat.Load(stream);
                }
            }
            else
            {
                using (var bmpTemp = new Bitmap(fullPath))
                {
                    result = new Bitmap(bmpTemp);
                }
            }
            return result;
        }

        public static Image ResizeImage(string photoPath, int maxWidth = 250, int maxHeight = 250)
        {
            using (Image imgPhoto = Image.FromFile(photoPath))
            {
                return ResizeImage(imgPhoto, maxWidth, maxHeight);
            }
        }

        public static Image ResizeImage(Image image, int maxWidth = 250, int maxHeight = 250)
        {
            var ratioX = (double)maxWidth / image.Width;
            var ratioY = (double)maxHeight / image.Height;
            var ratio = Math.Min(ratioX, ratioY);

            if (ratio >= 1)
            {
                return image;
            }

            var newWidth = (int) (image.Width * ratio);
            var newHeight = (int)(image.Height * ratio);

            var newImage = new Bitmap(newWidth, newHeight);

            using (var graphics = Graphics.FromImage(newImage))
            {
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

                graphics.DrawImage(image, 0, 0, newWidth, newHeight);
            }
            return newImage;
        }

        public static Image FixedSize(Image imgPhoto, int Width = 250, int Height = 250)
        {
            int sourceWidth = imgPhoto.Width;
            int sourceHeight = imgPhoto.Height;
            int sourceX = 0;
            int sourceY = 0;
            int destX = 0;
            int destY = 0;

            float nPercent = 0;
            float nPercentW = 0;
            float nPercentH = 0;

            if (Height == 0)
            {
                Height = Width > sourceWidth ? sourceHeight : (int)((float)Width * sourceHeight / (float)sourceWidth);
            }
            else if (Width == 0)
            {
                Width = Height > sourceHeight ? sourceWidth : (int)((float)Height * sourceWidth / (float)sourceHeight);
            }

            nPercentW = ((float)Width / (float)sourceWidth);
            nPercentH = ((float)Height / (float)sourceHeight);
            if (nPercentH < nPercentW)
            {
                nPercent = nPercentH;
                destX = System.Convert.ToInt16((Width -
                              (sourceWidth * nPercent)) / 2);
            }
            else
            {
                nPercent = nPercentW;
                destY = System.Convert.ToInt16((Height -
                              (sourceHeight * nPercent)) / 2);
            }

            int destWidth = (int)Math.Round(sourceWidth * nPercent, 0);
            int destHeight = (int)(Math.Round(sourceHeight * nPercent));

            Bitmap bmPhoto = new Bitmap(Width, Height,
                              PixelFormat.Format24bppRgb);
            bmPhoto.SetResolution(imgPhoto.HorizontalResolution,
                             imgPhoto.VerticalResolution);

            Graphics grPhoto = Graphics.FromImage(bmPhoto);
            grPhoto.Clear(Color.White);
            grPhoto.InterpolationMode = InterpolationMode.HighQualityBicubic;

            grPhoto.DrawImage(imgPhoto,
                new Rectangle(destX, destY, destWidth, destHeight),
                new Rectangle(sourceX, sourceY, sourceWidth, sourceHeight),
                GraphicsUnit.Pixel);

            grPhoto.Dispose();
            return bmPhoto;
        }

        public static void DeletePicture(string imageName, string uploadedPictureFolder, string deletedPictureFolder, string thumbnailName)
        {
            if (!Directory.Exists(deletedPictureFolder))
            {
                Directory.CreateDirectory(deletedPictureFolder);
            }
            MoveFile(imageName, uploadedPictureFolder, deletedPictureFolder);
            MoveFile(imageName.Substring(thumbnailName.Length + 1), uploadedPictureFolder, deletedPictureFolder);
        }

        public static void MoveFile(string fileName, string sourceFolder, string descFolder)
        {
            var fullPath = Path.Combine(sourceFolder, fileName);
            if (File.Exists(fullPath))
            {
                File.Move(fullPath, Path.Combine(descFolder, fileName));
            }
        }

        public static string GetFullUrl(string url, string path, string filename)
        {
            return $"{url}{path}/{filename}";
        }

        public static void ConvertImage(Stream originalStream, ImageFormat format, string fullPath)
        {
            using (var image = new Bitmap(originalStream))
            {
                image.Save(fullPath, format);
            }
        }

        public static string GetJpecFileName(string fileName)
        {
            return fileName.EndsWith(".webp", StringComparison.OrdinalIgnoreCase) ? $"{fileName.Substring(0, fileName.Length - 5)}.jpg" : fileName;
        }

        public static void ChangeColorIcon(string path, string newColorString)
        {
            
            string[] fileNames = new string[] {
                $"{CNSConstant.FACEBOOK_ICON}{CNSConstant.SOCIAL_TEMPLATE_ICON}{CNSConstant.SOCIAL_ICON_EXTENSION}",
                $"{CNSConstant.GOOGLE_PLUS_ICON}{CNSConstant.SOCIAL_TEMPLATE_ICON}{CNSConstant.SOCIAL_ICON_EXTENSION}",
                $"{CNSConstant.LINKEDIN_ICON}{CNSConstant.SOCIAL_TEMPLATE_ICON}{CNSConstant.SOCIAL_ICON_EXTENSION}",
                $"{CNSConstant.TWITTER_ICON}{CNSConstant.SOCIAL_TEMPLATE_ICON}{CNSConstant.SOCIAL_ICON_EXTENSION}",
                $"{CNSConstant.WEBSITE_ICON}{CNSConstant.SOCIAL_TEMPLATE_ICON}{CNSConstant.SOCIAL_ICON_EXTENSION}" };

            var oldColor = ColorTranslator.FromHtml(CNSConstant.DEFAULT_BROKER_COLOR2);
            foreach (var item in fileNames)
            {
                ChangeColorIcon(path, item, oldColor, newColorString);
            }
        }

        public static void ChangeColorIcon(string path, string fileName, Color oldColor, string newColorString)
        {
            var newFileName = Path.Combine(path, $"{fileName.Substring(0, fileName.Length - CNSConstant.SOCIAL_TEMPLATE_ICON.Length - 4)}{newColorString}.png");
            if (!File.Exists(newFileName))
            {
                using (var image = new Bitmap(Path.Combine(path, fileName)))
                {
                    var newColor = GetColor(newColorString);
                    ChangeColor(image, oldColor, newColor);
                    image.Save(newFileName);
                }
            }
        }

        public static Color GetColor(string colorString)
        {
            return ColorTranslator.FromHtml(colorString.ToLower() == "#ffffff" ? "#daa520" : colorString);
        }

        public static void ChangeColor(Bitmap image, Color oldColor, Color newColor)
        {
            for (int x = 0; x < image.Width; x++)
            {
                for (int y = 0; y < image.Height; y++)
                {
                    var tempColor = image.GetPixel(x, y);
                    if (tempColor == oldColor)
                    {
                        image.SetPixel(x, y, newColor);
                    }
                    else if (tempColor.ToArgb() != Color.White.ToArgb() && tempColor.ToArgb() != Color.Empty.ToArgb())
                    {
                        if (tempColor.R >= 180 && tempColor.G >= 217 && tempColor.B >= 240)
                        {
                            image.SetPixel(x, y, Color.White);// Color.FromArgb(80, newColor.R, newColor.G, newColor.B));
                        }
                        else
                        {
                            image.SetPixel(x, y, Color.FromArgb(tempColor.A, newColor.R, newColor.G, newColor.B));
                        }
                    }
                }
            }
        }

        //public void ResizeImage(string fullPath,
        //             int canvasWidth, int canvasHeight,
        //             /* new */
        //             int originalWidth, int originalHeight)
        //{
        //    Image image = Image.FromFile(fullPath);

        //    System.Drawing.Image thumbnail =
        //        new Bitmap(canvasWidth, canvasHeight); // changed parm names
        //    System.Drawing.Graphics graphic =
        //                 System.Drawing.Graphics.FromImage(thumbnail);

        //    graphic.InterpolationMode = InterpolationMode.HighQualityBicubic;
        //    graphic.SmoothingMode = SmoothingMode.HighQuality;
        //    graphic.PixelOffsetMode = PixelOffsetMode.HighQuality;
        //    graphic.CompositingQuality = CompositingQuality.HighQuality;

        //    /* ------------------ new code --------------- */

        //    // Figure out the ratio
        //    double ratioX = (double)canvasWidth / (double)originalWidth;
        //    double ratioY = (double)canvasHeight / (double)originalHeight;
        //    // use whichever multiplier is smaller
        //    double ratio = ratioX < ratioY ? ratioX : ratioY;

        //    // now we can get the new height and width
        //    int newHeight = Convert.ToInt32(originalHeight * ratio);
        //    int newWidth = Convert.ToInt32(originalWidth * ratio);

        //    // Now calculate the X,Y position of the upper-left corner 
        //    // (one of these will always be zero)
        //    int posX = Convert.ToInt32((canvasWidth - (originalWidth * ratio)) / 2);
        //    int posY = Convert.ToInt32((canvasHeight - (originalHeight * ratio)) / 2);

        //    graphic.Clear(Color.White); // white padding
        //    graphic.DrawImage(image, posX, posY, newWidth, newHeight);

        //    /* ------------- end new code ---------------- */

        //    System.Drawing.Imaging.ImageCodecInfo[] info =
        //                     ImageCodecInfo.GetImageEncoders();
        //    EncoderParameters encoderParameters;
        //    encoderParameters = new EncoderParameters(1);
        //    encoderParameters.Param[0] = new EncoderParameter(Encoder.Quality,
        //                     100L);
        //    thumbnail.Save(path + newWidth + "." + originalFilename, info[1],
        //                     encoderParameters);
        //}
    }
}