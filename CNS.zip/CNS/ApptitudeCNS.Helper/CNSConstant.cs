﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApptitudeCNS.Helpers
{
    public class ArticleConstants
    {
        public const string CURRENT_PAGE_ARTICLE_SESSION = "CurrentPageArticleSession";
        public const string UPLOADED_PICTURE_FOLDER = "~/UploadedPictures";
        public const string UPLOADED_PRIMARY_IMAGE_FOLDER = "~/UploadedPrimaryImages";
        public const string DELETED_PICTURE_FOLDER = "~/DeletedPictures";
        public const string UPLOADED_ATTACHMENT_FOLDER = "~/UploadedAttachments";
        public const int PAGE_SIZE = 20;

        public const string CONTROLLER_ACTION = "MailLink/Redirect";
        public const string NEWS_LETTER_EMAIL_CONTROLLER_ACTION = "Article/NewsLetterEmail";
        public const string VIEW_EMAIL_CONTROLLER_ACTION = "MailLink/ViewEmail";

        public const string UNSUBSCRIBE_CONTROLLER_ACTION = "MailLink/Unsubscribe";

        public const string ARTICLE_TEMPLATE_FILE = "~/Templates/Articles/ArticleTemplate.html";
        public const string ARTICLE_DETAIL_TEMPLATE_FILE = "~/Templates/Articles/ArticleDetailTemplate.html";
        public const string IMAGE_TAG_TEMPLATE_FILE = "~/Templates/Articles/ImageTagTemplate.html";
        public const string LINE_TAG_TEMPLATE_FILE = "~/Templates/Articles/LineTagTemplate.html";

        public const string ARTICLE_EMAIL_TEMPLATE_IMAGE = "~/Content/Images/article-email-template.png";

        public const string SELECTED_ARTICLE_LIST_NAME = "SelectedArticles";
    }

    public class MailTrackingConstants
    {
        public const int PAGE_SIZE = 100;

    }

    public class LinkTrackingConstants
    {
        public const int PAGE_SIZE = 100;

    }

    public class TagConstants
    {
        public const int NO_TAG = 100;

    }

    public class UserConstants
    {
        public const string CLIENT_EXCEL_TEMPLATE_FILE = "~/Templates/Users/ClientTemplate.xlsx";
        public const string UPLOADED_EXCEL_FOLDER = "~/UploadedExcels";
        public const string UPLOADED_LOGO_PHOTO_FOLDER = "~/UploadedLogos";
        public const string UPLOADED_COMPANY_IMAGE_PHOTO_FOLDER = "~/UploadedCompanyImages";
    }

    public class CNSConstant
    {
        public const string GOOGLE_PLUS_ICON = "google-plus-icon";
        public const string FACEBOOK_ICON = "facebook-icon";
        public const string TWITTER_ICON = "twitter-icon";
        public const string LINKEDIN_ICON = "linkedin-icon";
        public const string WEBSITE_ICON = "website-icon";
        public const string SOCIAL_ICON_PATH = "~/SocialIcons";
        public const string SOCIAL_TEMPLATE_ICON = "-template";
        public const string SOCIAL_ICON_EXTENSION = ".png";

        public const string Administrator = "Administrator";
        public const string Broker = "Broker";
        public const int PAGE_SIZE = 25;
        public const string DEFAULT_BROKER_COLOR = "blue";
        public const string DEFAULT_BROKER_COLOR2 = "#daa520";
        public const string THUMBNAIL_NAME = "Thumbnail";
    }
}
